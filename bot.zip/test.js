const TelegramBot = require("node-telegram-bot-api")

/* file contoh/percobaan, TIDAK dipakai index.js (bot utama polling di index.js).
   Jangan taruh token asli di sini. */
const token = process.env.TELEGRAM_TOKEN || "PASTE_TOKEN_DISINI"

const bot = new TelegramBot(token,{ polling:true })

bot.on("message", async msg=>{
console.log("dapet pesan dari:", msg.chat.id)

await bot.sendMessage(msg.chat.id,"HALO DARI TEST")
})