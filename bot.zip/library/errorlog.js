const fs = require("fs")
const path = require("path")

const ERROR_LOG_PATH = path.join(__dirname, "database", "errorlog.json")
const ROOT = path.resolve(__dirname, "..")

const readErrors = () => {
  try {
    const raw = JSON.parse(fs.readFileSync(ERROR_LOG_PATH, "utf8"))
    return Array.isArray(raw) ? raw : []
  } catch { return [] }
}

const writeErrors = (data) => {
  try {
    fs.mkdirSync(path.dirname(ERROR_LOG_PATH), { recursive: true })
    fs.writeFileSync(ERROR_LOG_PATH, JSON.stringify(data, null, 2))
  } catch {}
}

/* ── v2: parse stack → lokasi error di project (skip node_modules/internal) ── */
const parseStack = (error) => {
  const out = { file: null, line: null, func: null, code: null }
  try {
    const st = error && error.stack ? error.stack : ""
    if (!st) return out
    const frames = st.split("\n").slice(1)
    for (const raw of frames) {
      const line = raw.trim()
      if (!/^\w+ at |^at /.test(line) && !line.includes(":")) continue
      if (/node_modules|node:internal|\(|^at Array|^at Function|^at Object\.|^at async Promise/.test(line) && !line.includes("botproject")) continue
      const m = line.match(/at (?:(\S+) )?\(?([^()]+?):(\d+):(\d+)\)?/)
      if (!m) continue
      let [, func, file, ln] = m
      if (!file || !file.includes("/")) continue
      if (file.includes("node_modules") || file.includes("node:internal")) continue
      out.file = path.relative(ROOT, file) || file
      out.line = parseInt(ln) || null
      out.func = func && func !== "Object.<anonymous>" && func !== "<anonymous>" ? func : null
      break
    }
    /* fallback: frame pertama apa pun */
    if (!out.file) {
      const m = st.split("\n")[1] && st.split("\n")[1].match(/at .*?([^\/\s]+\.js):(\d+)/)
      if (m) { out.file = m[1]; out.line = parseInt(m[2]) || null }
    }
    /* snippet kode: 4 baris sekitar lokasi */
    if (out.file && out.line) {
      try {
        const abs = path.join(ROOT, out.file)
        if (fs.existsSync(abs)) {
          const lines = fs.readFileSync(abs, "utf8").split("\n")
          const from = Math.max(0, out.line - 3)
          const to = Math.min(lines.length, out.line + 2)
          out.code = lines.slice(from, to)
            .map((l, i) => `${from + i + 1}${from + i + 1 === out.line ? " →" : "   "} ${l}`)
            .join("\n").slice(0, 900)
        }
      } catch {}
    }
  } catch {}
  return out
}

/* ── simpan error + lokasi + snippet ── */
const logError = (feature, error, source) => {
  const errors = readErrors()
  const errStr = String(error?.message || error || "Unknown error")
  const loc = error && error.stack ? parseStack(error) : { file: null, line: null, func: null, code: null }
  const existing = errors.find(e => e.feature === feature && e.source === source)
  if (existing) {
    existing.error = errStr
    existing.lastSeen = Date.now()
    existing.count = (existing.count || 0) + 1
    if (loc.file) { existing.file = loc.file; existing.line = loc.line; existing.func = loc.func; existing.code = loc.code }
  } else {
    errors.push({
      feature: String(feature), error: errStr, source: source || "unknown",
      file: loc.file || null, line: loc.line || null, func: loc.func || null, code: loc.code || null,
      firstSeen: Date.now(), lastSeen: Date.now(), count: 1
    })
  }
  writeErrors(errors)
  return existing || errors[errors.length - 1]
}

/* ── deteksi error QUERY/API (bukan cuma syntax).
   KETAT: menangkap frasa Indonesia/EN umum dari plugin:
   "gagal", "tidak ada hasil", "terjadi kesalahan", "maaf", "coba lagi",
   "invalid", "rate limit", dsb. Dipanggil handler.js saat plugin membalas gagal. */
const FAIL_RE = /^(?:❌|⚠️|\u26a0\ufe0f|\u274c|\ud83d\udea8)?\s*(?:gagal|error|failed|failure|tidak (?:dapat|bisa|ditemukan|ada|boleh)|tidak ada (?:hasil|data|url|jawaban|audio|video|gambar)|tak (?:dapat|bisa|ditemukan)|not found|cannot|can't|couldn'?t|no (?:results?|data|url|media|response|answer)|nothing found|something went wrong|went wrong|terjadi (?:kesalahan|error)|kesalahan (?:terjadi|saat)|maaf(?:,| )|sorry,?|coba lagi|try again later|timeout(?:ed)?|timed out|http \d{3}|api (?:error|menolak|tidak)|rate ?limit|too many requests|invalid(?: (?:response|api ?key|token|link|url|params?))?|unauthorized|forbidden|expired|kedaluwarsa|kosong|empty|menolak|blocked|diblokir|unsupported|tidak didukung|(?:memutar|memproses|mengirim|mengambil|memuat)[^\n]{0,40}(?:gagal|error)|error[^\n]{0,30}(?:saat|when|while)|\w+[\/\\-]?error)/i

const isFailReply = (text) => {
  const s = String(text || "").replace(/<[^>]+>/g, "").trim()
  if (!s || s.length > 300) return false
  /* whitelist: petunjuk pemakaian BUKAN error (rawan false positive) */
  if (/(?:^|\n)\s*(?:how to use|cara pakai)|usage:|contoh:|example:|use:|reply (?:foto|photo|audio|video|media|pesan|message)|kirim (?:link|foto|audio)|send (?:the )?(?:link|photo|audio)/i.test(s)) return false
  if (/^\u274c|^\u26a0\ufe0f|^\ud83d\udea8/.test(s)) return true
  return FAIL_RE.test(s)
}

/* ── format AI-ready: tinggal copy-paste ke AI untuk minta fix ── */
const rawError = (feature) => {
  const e = readErrors().find(x => x.feature === feature)
  if (!e) return null
  let out = "=== ERROR REPORT (AI-READY) ===\n"
  out += "Feature : " + e.feature + "\n"
  out += "Source  : " + (e.source || "-") + "\n"
  out += "Error   : " + e.error + "\n"
  if (e.file) out += "Location: " + e.file + (e.line ? ":" + e.line : "") + (e.func ? " (function " + e.func + ")" : "") + "\n"
  if (e.code) out += "Code:\n<pre>" + e.code + "</pre>\n"
  out += "Count   : " + (e.count || 1) + "x, last " + new Date(e.lastSeen).toISOString()
  return out
}

const reportError = (feature, error, source) => {
  const entry = logError(feature, error, source)
  const bot = global.Rafz
  const shouldNotify = entry.count === 1 || (Date.now() - (entry.lastNotified || 0) > 60 * 60 * 1000)
  if (bot && shouldNotify) {
    entry.lastNotified = Date.now()
    writeErrors(readErrors())
    notifyOwner(bot, entry)
  }
  return entry
}

const resolveFeature = (feature) => {
  if (hasError(feature)) removeError(feature)
}

const removeError = (feature) => {
  let errors = readErrors()
  errors = errors.filter(e => e.feature !== feature)
  writeErrors(errors)
}

const clearErrors = () => { writeErrors([]) }
const getErrors = () => readErrors()
const hasError = (feature) => readErrors().some(e => e.feature === feature)

const notifyOwner = async (bot, entry) => {
  try {
    const loc = entry.file ? "\n📍 Lokasi: <code>" + entry.file + (entry.line ? ":" + entry.line : "") + "</code>" + (entry.func ? " (<code>" + entry.func + "</code>)" : "") : ""
    const snippet = entry.code ? "\n📋 Kode:\n<pre>" + entry.code.slice(0, 700) + "</pre>" : ""
    for (const oid of global.owner || []) {
      try {
        await bot.sendMessage(oid,
          `⚠️ <b>Fitur Error Terdeteksi</b>\n\n` +
          `📦 Fitur: <code>${entry.feature}</code>\n` +
          `📄 Sumber: <code>${entry.source || "unknown"}</code>\n` +
          `❌ Error: <code>${entry.error}</code>` +
          loc + snippet +
          `\n🕐 Waktu: ${new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })}`,
          {
            parse_mode: "HTML",
            reply_markup: {
              inline_keyboard: [
                [{ text: "🤖 Fix (AI)", callback_data: "/errorfix " + entry.feature, style: "success" },
                 { text: "📋 Kode Mentah", callback_data: "/errorraw " + entry.feature, style: "primary" }],
                [{ text: "🗑️ Hapus Fitur", callback_data: "/errordelete " + entry.feature, style: "danger" },
                 { text: "🔎 Ambil Kode", callback_data: "/errorcode " + entry.feature, style: "secondary" }]
              ]
            }
          }
        )
      } catch {}
    }
  } catch {}
}

const wrapHandler = async (fn, feature, source, m, ctx) => {
  try {
    const result = await fn(m, ctx)
    if (hasError(feature)) removeError(feature)
    return result
  } catch (e) {
    const entry = logError(feature, e, source)
    const bot = ctx?.Rafz || global.Rafz
    if (bot && entry.count === 1) notifyOwner(bot, entry)
    throw e
  }
}

module.exports = { logError, removeError, clearErrors, getErrors, hasError, notifyOwner, wrapHandler, reportError, isFailReply, resolveFeature, rawError, parseStack, ERROR_LOG_PATH }

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
