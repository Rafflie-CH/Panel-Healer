// library/backup.js — backup otomatis & manual
// backup: settings.js, semua file database, package.json

"use strict"

const fs = require("fs")
const path = require("path")
const archiver = require("archiver")
const chalk = require("chalk")

const log = {
  info:  (m) => console.log(chalk.cyan("[BACKUP]"), m),
  ok:    (m) => console.log(chalk.green("[BACKUP]"), m),
  error: (m) => console.log(chalk.red("[BACKUP]"), m)
}

/* file yang dibackup */
const BACKUP_FILES = [
  "settings.js",
  "package.json",
  "library/database/owner.json",
  "library/database/seller.json",
  "library/database/superseller.json",
  "library/database/panel.json",
  "library/database/admin.json",
  "library/database/private.json",
  "library/database/usercache.json",
  "library/database/blclean.json",
  "library/database/lang.json"
]

const ROOT = path.join(__dirname, "..")

/* buat zip backup, return path file zip */
const createBackupZip = () =>
  new Promise((resolve, reject) => {
    const ts = new Date().toISOString().replace(/[:.]/g, "-").slice(0, 19)
    const outPath = path.join(ROOT, "library", "database", `backup-${ts}.zip`)

    const output = fs.createWriteStream(outPath)
    const archive = archiver("zip", { zlib: { level: 9 } })

    output.on("close", () => resolve(outPath))
    archive.on("error", reject)

    archive.pipe(output)

    for (const rel of BACKUP_FILES) {
      const full = path.join(ROOT, rel)
      if (fs.existsSync(full)) {
        archive.file(full, { name: rel })
      }
    }

    archive.finalize()
  })

/* hapus backup lama (simpan 5 terbaru) */
const pruneOldBackups = () => {
  try {
    const dir = path.join(ROOT, "library", "database")
    const files = fs.readdirSync(dir)
      .filter(f => f.startsWith("backup-") && f.endsWith(".zip"))
      .map(f => ({ name: f, mt: fs.statSync(path.join(dir, f)).mtimeMs }))
      .sort((a, b) => b.mt - a.mt)

    for (const f of files.slice(5)) {
      try { fs.unlinkSync(path.join(dir, f.name)) } catch {}
    }
  } catch {}
}

/* kirim backup ke owner ONLY (tidak ke grup) */
const sendBackup = async (bot, note = "Backup otomatis") => {
  let zipPath
  try {
    zipPath = await createBackupZip()
    pruneOldBackups()
    log.ok("Zip dibuat: " + path.basename(zipPath))
  } catch (e) {
    log.error("Gagal buat zip: " + e.message)
    return
  }

  const targets = []
  if (global.backup?.sendToOwner !== false) {
    for (const oid of global.owner || []) targets.push(oid)
  }

  const stat = fs.statSync(zipPath)
  const sizekb = (stat.size / 1024).toFixed(1)

  const caption =
    `📦 <b>Backup ${global.botname || "Bot"}</b>\n\n` +
    `📝 Catatan : ${note}\n` +
    `📁 File    : ${path.basename(zipPath)}\n` +
    `📏 Size    : ${sizekb} KB\n` +
    `🕐 Waktu   : ${new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })}\n\n` +
    `<i>Upload ke server untuk restore instan.</i>`

  for (const target of [...new Set(targets)]) {
    try {
      await bot.sendDocument(target, zipPath, { caption, parse_mode: "HTML" })
    } catch (e) {
      log.error(`Kirim ke ${target}: ${e.message}`)
    }
  }
}

/* timer otomatis */
let _timer = null

const start = (bot) => {
  /* backup otomatis MATI di clone bot (global.isClone) — sesuai desain clone:
     beberapa fitur dihapus di versi clone untuk menghindari penyalahgunaan */
  if (global.isClone) return
  if (_timer) clearInterval(_timer)
  const cfg = global.backup || {}
  if (!cfg.enabled) return

  const intervalMs = cfg.intervalMs || 6 * 60 * 60 * 1000
  _timer = setInterval(() => {
    sendBackup(bot, "Backup otomatis terjadwal").catch(e => log.error(e.message))
  }, intervalMs)

  if (_timer.unref) _timer.unref()
  log.info(`Backup aktif — interval ${Math.round(intervalMs / 60000)} menit`)
}

const stop = () => {
  if (_timer) { clearInterval(_timer); _timer = null }
}

module.exports = { createBackupZip, sendBackup, start, stop }
