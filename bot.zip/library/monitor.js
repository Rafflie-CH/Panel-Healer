/**
 * RAFZ Monitor — multi-server panel resource guard
 * Integrasi ke rafzbotz, baca config dari global.panelServer + global.monitor
 */
"use strict"

const fs = require("fs")
const path = require("path")
const chalk = require("chalk")

const C = {
  reset: "\x1b[0m",
  bold: "\x1b[1m",
  red: "\x1b[31m",
  green: "\x1b[32m",
  yellow: "\x1b[33m",
  cyan: "\x1b[36m",
  gray: "\x1b[90m",
  magenta: "\x1b[35m",
}

const ts = () =>
  `${C.gray}[${new Date().toLocaleString("id-ID", { hour12: false, timeZone: "Asia/Jakarta" })}]${C.reset}`

const log = {
  info: (m) => console.log(`${ts()} ${C.cyan}◈ MONITOR${C.reset} ⌲ ${m}`),
  ok: (m) => console.log(`${ts()} ${C.green}◈ MONITOR${C.reset} ⌲ ${m}`),
  warn: (m) => console.log(`${ts()} ${C.yellow}◈ MONITOR${C.reset} ⌲ ${m}`),
  error: (m) => console.log(`${ts()} ${C.red}◈ MONITOR${C.reset} ⌲ ${m}`),
  spike: (m) => console.log(`${ts()} ${C.bold}${C.red}◈ ALERT${C.reset} ⌲ ${m}`),
}

/* ── state ── */
let botRef = null
let timer = null
let running = false
const suspendedServers = new Map() // key: `${srvKey}:${uuid}` -> timestamp
const notifiedRecovery = new Set()
const diskHistory = new Map()

function cfg() {
  return global.monitor || {}
}

function panels() {
  return global.panelServer || {}
}

function dbPath() {
  const p = cfg().dbPath || "./library/database/ptero-stats.json"
  try {
    fs.mkdirSync(path.dirname(p), { recursive: true })
  } catch {}
  return p
}

function dbLoad() {
  try {
    if (fs.existsSync(dbPath())) {
      return JSON.parse(fs.readFileSync(dbPath(), "utf8"))
    }
  } catch (e) {
    log.error(`dbLoad: ${e.message}`)
  }
  return { topDisk: [], topCpu: [], lastUpdated: null }
}

function dbSave(data) {
  try {
    fs.writeFileSync(dbPath(), JSON.stringify(data, null, 2), "utf8")
  } catch (e) {
    log.error(`dbSave: ${e.message}`)
  }
}

function dbUpdateTop10(snapshots) {
  try {
    const db = dbLoad()
    db.topDisk = [...snapshots].sort((a, b) => b.diskUsed - a.diskUsed).slice(0, 10)
    db.topCpu = [...snapshots].sort((a, b) => b.cpuUsed - a.cpuUsed).slice(0, 10)
    db.lastUpdated = new Date().toISOString()
    dbSave(db)
  } catch (e) {
    log.error(`dbUpdateTop10: ${e.message}`)
  }
}

/* ── helpers ── */
function formatMiB(mib) {
  if (mib == null) return "N/A"
  const n = Number(mib)
  return n >= 1024 ? `${(n / 1024).toFixed(2)} GiB` : `${n.toFixed(0)} MiB`
}

function progressBar(percent, len = 10) {
  const filled = Math.round((Math.min(Number(percent) || 0, 100) / 100) * len)
  return "▬".repeat(filled) + "▭".repeat(len - filled)
}

function escHtml(str) {
  return String(str ?? "")
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
}

function nowWIB() {
  return new Date().toLocaleString("id-ID", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
    timeZone: "Asia/Jakarta",
  })
}

function stateKey(srvKey, uuid) {
  return `${srvKey}:${uuid}`
}

/* ── API ── */
async function pteroApp(srv, endpoint, method = "GET", body = null) {
  const url = `${srv.domain}/api/application${endpoint}`
  const opts = {
    method,
    headers: {
      Authorization: `Bearer ${srv.apikey}`,
      "Content-Type": "application/json",
      Accept: "application/json",
    },
  }
  if (body) opts.body = JSON.stringify(body)
  const res = await fetch(url, opts)
  if (!res.ok) {
    const text = await res.text().catch(() => "")
    throw new Error(`Ptero ${method} ${endpoint} → HTTP ${res.status}: ${text.slice(0, 200)}`)
  }
  if (res.status === 204) return null
  return res.json()
}

async function getAllServersOnPanel(srv) {
  const servers = []
  let page = 1
  while (true) {
    try {
      const data = await pteroApp(srv, `/servers?per_page=100&page=${page}&include=user`)
      if (!data || !Array.isArray(data.data)) break
      servers.push(...data.data)
      const total = data.meta?.pagination?.total_pages || 1
      if (page >= total) break
      page++
    } catch (e) {
      log.error(`getAllServers (${srv.name}): ${e.message}`)
      break
    }
  }
  return servers
}

async function getServerResources(srv, uuid) {
  try {
    const url = `${srv.domain}/api/client/servers/${uuid}/resources`
    const res = await fetch(url, {
      headers: {
        Authorization: `Bearer ${srv.capikey}`,
        Accept: "application/json",
      },
    })
    if (!res.ok) {
      if (cfg().debug) log.warn(`resources ${uuid} → HTTP ${res.status}`)
      return null
    }
    return res.json()
  } catch (e) {
    if (cfg().debug) log.warn(`resources ${uuid}: ${e.message}`)
    return null
  }
}

async function suspendServer(srv, serverId) {
  return pteroApp(srv, `/servers/${serverId}/suspend`, "POST")
}

async function unsuspendServer(srv, serverId) {
  return pteroApp(srv, `/servers/${serverId}/unsuspend`, "POST")
}

async function deleteServer(srv, serverId) {
  return pteroApp(srv, `/servers/${serverId}`, "DELETE")
}

/* ── notify ── */
async function notify(text, opts = {}) {
  if (!botRef) return
  const options = { parse_mode: "HTML", disable_web_page_preview: true, ...opts }
  const chatIds = []

  try {
    if (cfg().chatId) {
      chatIds.push(String(cfg().chatId))
    } else {
      const owners = Array.isArray(global.owner) ? global.owner.map(String) : []
      try {
        const extra = JSON.parse(fs.readFileSync("./library/database/owner.json", "utf8"))
        if (Array.isArray(extra)) owners.push(...extra.map(String))
      } catch {}
      chatIds.push(...[...new Set(owners)])
    }
  } catch (e) {
    log.error(`notify resolve chat: ${e.message}`)
  }

  for (const cid of chatIds) {
    try {
      await botRef.sendMessage(cid, text, options)
    } catch (e) {
      log.error(`notify ${cid}: ${e.message}`)
    }
  }
}

/* ── message builders (HTML + blockquote) ── */
function buildSpikeMessage({
  serverName,
  serverUuid,
  serverId,
  owner,
  node,
  panelName,
  spikeType,
  reason,
  ramPercent,
  diskPercent,
  ramUsed,
  ramLimit,
  diskUsed,
  diskLimit,
  isRamUnlimited,
  isDiskUnlimited,
  srvKey,
}) {
  const ramPctVisual =
    ramPercent ?? Math.min((ramUsed / (cfg().ramAbsoluteMaxMiB || 6144)) * 100, 100)
  const diskPctVisual =
    diskPercent ?? Math.min((diskUsed / (cfg().diskAbsoluteMaxMiB || 30720)) * 100, 100)

  const spikeLabel =
    spikeType === "SUSPICIOUS"
      ? "ᴅɪsᴋ ᴍᴇɴᴄᴜʀɪɢᴀᴋᴀɴ"
      : spikeType === "RAM"
        ? "ʀᴀᴍ ᴏᴠᴇʀʟᴏᴀᴅ"
        : spikeType === "DISK"
          ? "ᴅɪsᴋ ᴏᴠᴇʀʟᴏᴀᴅ"
          : "sʏsᴛᴇᴍ ᴏᴠᴇʀʟᴏᴀᴅ"

  const ramPctLabel = isRamUnlimited ? `${formatMiB(ramUsed)}` : `${Number(ramPercent).toFixed(1)}%`
  const diskPctLabel = isDiskUnlimited
    ? `${formatMiB(diskUsed)}`
    : `${Number(diskPercent).toFixed(1)}%`
  const ramLimitTxt = isRamUnlimited ? "Unlimited" : formatMiB(ramLimit)
  const diskLimitTxt = isDiskUnlimited ? "Unlimited" : formatMiB(diskLimit)
  const reasonLine = reason ? `\n⌲ <b>ᴅᴇᴛᴀɪʟ:</b> ${escHtml(reason)}` : ""

  return `
◈ <b>sᴇʀᴠᴇʀ ᴀᴜᴛᴏᴍᴀᴛɪᴄ sᴜsᴘᴇɴᴅ</b>

<blockquote>⌗ <b>sᴛᴀᴛᴜs:</b> ${spikeLabel}${reasonLine}
⌲ <b>ɴᴀᴍᴀ:</b> ${escHtml(serverName)}
⌲ <b>ɪᴅ:</b> <code>${serverId}</code>
⌲ <b>ᴜᴜɪᴅ:</b> <code>${serverUuid}</code>
⌲ <b>ᴘᴇᴍɪʟɪᴋ:</b> ${escHtml(owner ?? "Unknown")}
⌲ <b>ɴᴏᴅᴇ:</b> ${escHtml(node ?? "Unknown")}
⌲ <b>ᴘᴀɴᴇʟ:</b> ${escHtml(panelName)} (${escHtml(srvKey)})</blockquote>

◈ <b>ʀᴇsᴏᴜʀᴄᴇ</b>
<blockquote>⌗ <b>ʀᴀᴍ</b> [ ${ramPctLabel} ]
<code>${progressBar(ramPctVisual)}</code>
↳ ${formatMiB(ramUsed)} / ${ramLimitTxt}

⌗ <b>ᴅɪsᴋ</b> [ ${diskPctLabel} ]
<code>${progressBar(diskPctVisual)}</code>
↳ ${formatMiB(diskUsed)} / ${diskLimitTxt}</blockquote>

◈ <b>ᴀᴄᴛɪᴏɴ</b>
<blockquote>ᴜɴsᴜsᴘᴇɴᴅ:
<code>/unsuspend ${serverId}|${srvKey}</code></blockquote>

⌗ <i>${nowWIB()}</i>
⌲ <b>ʀᴀꜰᴢ ᴍᴏɴɪᴛᴏʀ</b>
`.trim()
}

function buildRecoveryMessage({ serverName, serverUuid, ramPercent, diskPercent, ramUsed, diskUsed, panelName }) {
  const ramStr =
    ramPercent != null ? `${Number(ramPercent).toFixed(1)}%` : `${Number(ramUsed).toFixed(0)} MiB`
  const diskStr =
    diskPercent != null
      ? `${Number(diskPercent).toFixed(1)}%`
      : `${(diskUsed / 1024).toFixed(2)} GiB`
  return `
◈ <b>sᴇʀᴠᴇʀ ʀᴇsᴛᴏʀᴇᴅ</b>

<blockquote>⌲ <b>ɴᴀᴍᴀ:</b> ${escHtml(serverName)}
⌲ <b>ᴜᴜɪᴅ:</b> <code>${serverUuid}</code>
⌲ <b>ᴘᴀɴᴇʟ:</b> ${escHtml(panelName)}
⌲ <b>ʀᴀᴍ:</b> ${ramStr}
⌲ <b>ᴅɪsᴋ:</b> ${diskStr}</blockquote>

sᴛᴀᴛᴜs ʀᴇsᴏᴜʀᴄᴇ ᴋᴇᴍʙᴀʟɪ ɴᴏʀᴍᴀʟ.

⌗ <i>${nowWIB()}</i>
`.trim()
}

function buildDeleteMessage({ serverName, serverUuid, panelName }) {
  return `
◈ <b>sᴇʀᴠᴇʀ ᴀᴜᴛᴏ ᴘᴜʀɢᴇ</b>

<blockquote>⌲ <b>ɴᴀᴍᴀ:</b> ${escHtml(serverName)}
⌲ <b>ᴜᴜɪᴅ:</b> <code>${serverUuid}</code>
⌲ <b>ᴘᴀɴᴇʟ:</b> ${escHtml(panelName)}
⌲ <b>ʀᴇᴀsᴏɴ:</b> Tersuspend terlalu lama</blockquote>

sᴇʀᴠᴇʀ ᴛᴇʟᴀʜ ᴅɪʜᴀᴘᴜs ᴘᴇʀᴍᴀɴᴇɴ.

⌗ <i>${nowWIB()}</i>
`.trim()
}

function buildTop10Message(db) {
  const fmtDisk = (arr) =>
    arr.length === 0
      ? "<i>Tidak ada data</i>"
      : arr
          .map(
            (s, i) =>
              `<b>${i + 1}.</b> <code>${escHtml(s.name)}</code> <i>(${escHtml(s.panel || "?")})</i>\n↳ ᴅɪsᴋ: <code>${formatMiB(s.diskUsed)}</code> | ᴏᴡɴᴇʀ: <i>${escHtml(s.owner ?? "Unknown")}</i>`
          )
          .join("\n\n")

  const fmtCpu = (arr) =>
    arr.length === 0
      ? "<i>Tidak ada data</i>"
      : arr
          .map(
            (s, i) =>
              `<b>${i + 1}.</b> <code>${escHtml(s.name)}</code> <i>(${escHtml(s.panel || "?")})</i>\n↳ ᴄᴘᴜ: <code>${Number(s.cpuUsed).toFixed(1)}%</code> | ᴏᴡɴᴇʀ: <i>${escHtml(s.owner ?? "Unknown")}</i>`
          )
          .join("\n\n")

  const updated = db.lastUpdated
    ? new Date(db.lastUpdated).toLocaleString("id-ID", {
        hour12: false,
        timeZone: "Asia/Jakarta",
      })
    : "Never"

  return `
◈ <b>ᴛᴏᴘ 10 ᴜᴛɪʟɪᴛʏ</b>

◈ <b>ʜɪɢʜᴇsᴛ ᴅɪsᴋ</b>
<blockquote>${fmtDisk(db.topDisk)}</blockquote>

◈ <b>ʜɪɢʜᴇsᴛ ᴄᴘᴜ</b>
<blockquote>${fmtCpu(db.topCpu)}</blockquote>

⌗ sʏɴᴄ: <i>${updated} WIB</i>
`.trim()
}

/* ── auto delete (opsional, default off) ── */
async function checkAutoDelete() {
  const after = Number(cfg().autoDeleteAfterMs) || 0
  if (after <= 0) return

  const now = Date.now()
  for (const [key, suspendedAt] of suspendedServers.entries()) {
    if (now - suspendedAt < after) continue

    const [srvKey, uuid] = key.split(":")
    const srv = panels()[srvKey]
    if (!srv) {
      suspendedServers.delete(key)
      continue
    }

    let serverData = null
    try {
      const all = await getAllServersOnPanel(srv)
      serverData = all.find((s) => s.attributes?.uuid === uuid)
    } catch (e) {
      log.error(`auto-delete lookup ${key}: ${e.message}`)
      continue
    }

    if (!serverData) {
      suspendedServers.delete(key)
      continue
    }

    const { name, id: serverId } = serverData.attributes
    try {
      await deleteServer(srv, serverId)
      suspendedServers.delete(key)
      notifiedRecovery.delete(key)
      diskHistory.delete(key)
      log.ok(`Auto-purged "${name}" on ${srv.name}`)
      await notify(buildDeleteMessage({ serverName: name, serverUuid: uuid, panelName: srv.name }))
    } catch (e) {
      log.error(`auto-delete "${name}": ${e.message}`)
    }
  }
}

/* ── main loop ── */
async function monitorLoop() {
  if (!running) return
  try {
    log.info("cycle start...")
    await checkAutoDelete()

    const panelMap = panels()
    const keys = Object.keys(panelMap)
    if (!keys.length) {
      log.warn("tidak ada panel di global.panelServer")
      return
    }

    const snapshots = []
    const conf = cfg()
    const now = Date.now()

    for (const srvKey of keys) {
      const srv = panelMap[srvKey]
      if (!srv || !srv.domain || !srv.apikey || !srv.capikey) {
        log.warn(`panel ${srvKey} config tidak lengkap, skip`)
        continue
      }

      let servers = []
      try {
        servers = await getAllServersOnPanel(srv)
      } catch (e) {
        log.error(`fetch servers ${srv.name}: ${e.message}`)
        continue
      }

      for (const s of servers) {
        try {
          const attr = s.attributes || {}
          const uuid = attr.uuid
          const name = attr.name
          const node = attr.node
          const serverId = attr.id
          const owner = attr.relationships?.user?.attributes?.email ?? null
          const key = stateKey(srvKey, uuid)

          let resources = null
          try {
            resources = await getServerResources(srv, uuid)
          } catch {
            continue
          }
          if (!resources) continue

          const currentState = resources.attributes?.current_state ?? "unknown"
          const stats = resources.attributes?.resources ?? {}
          const ramUsed = (stats.memory_bytes ?? 0) / (1024 * 1024)
          const diskUsed = (stats.disk_bytes ?? 0) / (1024 * 1024)
          const cpuUsed = stats.cpu_absolute ?? 0

          const ramLimitRaw = attr.limits?.memory
          const diskLimitRaw = attr.limits?.disk
          const isRamUnlimited = !ramLimitRaw || ramLimitRaw === 0
          const isDiskUnlimited = !diskLimitRaw || diskLimitRaw === 0
          const ramLimit = isRamUnlimited ? null : ramLimitRaw
          const diskLimit = isDiskUnlimited ? null : diskLimitRaw

          const ramPercent = ramLimit ? (ramUsed / ramLimit) * 100 : null
          const diskPercent = diskLimit ? (diskUsed / diskLimit) * 100 : null

          snapshots.push({
            uuid,
            name,
            owner,
            diskUsed,
            cpuUsed,
            ramUsed,
            panel: srv.name,
            srvKey,
          })

          if (conf.debug) {
            log.info(
              `${srv.name} ⌲ ${String(name).padEnd(20)} | CPU ${cpuUsed.toFixed(1)}% | RAM ${(ramPercent || 0).toFixed(0)}% | DISK ${(diskPercent || 0).toFixed(0)}%`
            )
          }

          /* suspicious growth */
          let suspiciousReason = null
          const prevDisk = diskHistory.get(key)
          if (prevDisk != null) {
            const growth = diskUsed - prevDisk
            const growthPct = diskLimit ? (growth / diskLimit) * 100 : 0
            if (growth >= (conf.suspiciousDiskGrowthMiB || 3584)) {
              suspiciousReason = `Anomali disk +${formatMiB(growth)} instan`
            } else if (diskLimit && growthPct >= (conf.suspiciousDiskGrowthPct || 35)) {
              suspiciousReason = `Write disk +${growthPct.toFixed(1)}% terlalu cepat`
            }
          }
          diskHistory.set(key, diskUsed)

          /* absolute limits (unlimited servers) */
          const ramAbsSpike =
            isRamUnlimited && ramUsed >= (conf.ramAbsoluteMaxMiB || 6144)
          const diskAbsSpike =
            isDiskUnlimited && diskUsed >= (conf.diskAbsoluteMaxMiB || 30720)

          const ramSpike =
            (ramPercent != null && ramPercent >= (conf.ramThreshold || 90)) || ramAbsSpike
          const diskSpike =
            (diskPercent != null && diskPercent >= (conf.diskThreshold || 92)) || diskAbsSpike

          const shouldAct =
            currentState === "running" &&
            (ramSpike || diskSpike || suspiciousReason)

          if (shouldAct) {
            const last = suspendedServers.get(key) || 0
            if (now - last < (conf.suspendCooldownMs || 300000)) continue

            const spikeType = suspiciousReason
              ? "SUSPICIOUS"
              : ramSpike && diskSpike
                ? "RAM+DISK"
                : ramSpike
                  ? "RAM"
                  : "DISK"

            try {
              await suspendServer(srv, serverId)
              suspendedServers.set(key, now)
              notifiedRecovery.delete(key)
              log.spike(`suspend "${name}" @ ${srv.name} (${spikeType})`)
            } catch (e) {
              log.error(`suspend "${name}": ${e.message}`)
              continue
            }

            try {
              await notify(
                buildSpikeMessage({
                  serverName: name,
                  serverUuid: uuid,
                  serverId,
                  owner,
                  node,
                  panelName: srv.name,
                  spikeType,
                  reason: suspiciousReason,
                  ramPercent,
                  diskPercent,
                  ramUsed,
                  ramLimit,
                  diskUsed,
                  diskLimit,
                  isRamUnlimited,
                  isDiskUnlimited,
                  srvKey,
                })
              )
            } catch (e) {
              log.error(`notify spike: ${e.message}`)
            }
          } else if (
            suspendedServers.has(key) &&
            !notifiedRecovery.has(key) &&
            currentState === "running"
          ) {
            try {
              await notify(
                buildRecoveryMessage({
                  serverName: name,
                  serverUuid: uuid,
                  ramPercent,
                  diskPercent,
                  ramUsed,
                  diskUsed,
                  panelName: srv.name,
                })
              )
              notifiedRecovery.add(key)
            } catch (e) {
              log.error(`notify recovery: ${e.message}`)
            }
          }
        } catch (e) {
          log.error(`server loop: ${e.message}`)
        }
      }
    }

    if (snapshots.length > 0) dbUpdateTop10(snapshots)
    log.ok(`cycle done — ${snapshots.length} server scanned`)
  } catch (e) {
    log.error(`monitorLoop fatal: ${e.message}`)
  }
}

/* ── public API ── */
function start(bot) {
  try {
    if (running) {
      log.warn("sudah running")
      return false
    }
    botRef = bot
    running = true
    const interval = Number(cfg().pollIntervalMs) || 45000
    log.ok(`start multi-panel monitor (interval ${interval / 1000}s)`)
    monitorLoop().catch((e) => log.error(`first cycle: ${e.message}`))
    timer = setInterval(() => {
      monitorLoop().catch((e) => log.error(`cycle: ${e.message}`))
    }, interval)
    if (timer.unref) timer.unref()
    return true
  } catch (e) {
    log.error(`start: ${e.message}`)
    running = false
    return false
  }
}

function stop() {
  try {
    running = false
    if (timer) {
      clearInterval(timer)
      timer = null
    }
    log.ok("monitor stopped")
    return true
  } catch (e) {
    log.error(`stop: ${e.message}`)
    return false
  }
}

function isRunning() {
  return running
}

function getStatus() {
  const uptime = process.uptime()
  const uptimeStr = `${Math.floor(uptime / 3600)}j ${Math.floor((uptime % 3600) / 60)}m`
  const panelKeys = Object.keys(panels())
  return {
    running,
    uptime: uptimeStr,
    suspended: suspendedServers.size,
    tracking: diskHistory.size,
    panels: panelKeys.map((k) => panels()[k]?.name || k),
    config: {
      ram: cfg().ramThreshold,
      disk: cfg().diskThreshold,
      interval: (cfg().pollIntervalMs || 45000) / 1000,
      autoDelete: (cfg().autoDeleteAfterMs || 0) > 0,
    },
  }
}

function getTop10() {
  return dbLoad()
}

async function doUnsuspend(srvKey, serverId) {
  const srv = panels()[srvKey]
  if (!srv) throw new Error(`panel ${srvKey} tidak ada`)
  const data = await pteroApp(srv, `/servers/${serverId}`)
  const attr = data?.attributes
  if (!attr) throw new Error("server tidak ditemukan")
  await unsuspendServer(srv, serverId)
  const key = stateKey(srvKey, attr.uuid)
  suspendedServers.delete(key)
  notifiedRecovery.delete(key)
  return { name: attr.name, uuid: attr.uuid, id: attr.id }
}

module.exports = {
  start,
  stop,
  isRunning,
  getStatus,
  getTop10,
  doUnsuspend,
  buildTop10Message,
  buildSpikeMessage,
  escHtml,
  formatMiB,
  nowWIB,
}
