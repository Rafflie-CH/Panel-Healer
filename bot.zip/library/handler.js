const fs = require("fs")
const path = require("path")
const logger = require("./logger")
const store = require("./store")
const { getLang, setLang, t, autoTranslate } = require("./language")
const antiflood = require("./antiflood")

const pluginsDir = path.join(__dirname, "..", "plugins")

/* plugin store: command -> [handler1, handler2, ...] (fallback chain).
   Kalau handler pertama error, handler berikutnya (fitur duplikat dari
   plugin lain) dicoba — jadi fitur dobel jadi backup otomatis. */
let plugins = new Map()
/* Auto-cleanup plugin OBSOLETE (sisa versi lama di folder owner — permintaan
   "fitur yang dibuang jangan masih nyangkut"): kalau file masih ada padahal
   fiturnya sudah dibuang, fitur 404-nya akan terus keuji di /testall. */
const OBSOLETE_PLUGINS = new Set(["textmaker.js"])
try {
  for (const ob of OBSOLETE_PLUGINS) {
    const obPath = path.join(pluginsDir, ob)
    if (fs.existsSync(obPath)) { fs.unlinkSync(obPath); console.log("[cleanup] removed obsolete plugin:", ob) }
  }
} catch {}

const loadPlugins = () => {
  try {
    plugins.clear()
    if (!fs.existsSync(pluginsDir)) return
    for (const file of fs.readdirSync(pluginsDir)) {
      if (!file.endsWith(".js")) continue
      const p = path.join(pluginsDir, file)
      try {
        delete require.cache[require.resolve(p)]
        const plugin = require(p)
        if (!plugin || !plugin.command) continue
        for (const cmd of plugin.command) {
          const key = String(cmd).toLowerCase()
          if (!plugins.has(key)) plugins.set(key, [])
          plugins.get(key).push(plugin)
        }
      } catch (e) {
        console.log("Plugin load error:", file, e.message)
      }
    }
    console.log("Plugin loaded:", plugins.size)
  } catch (e) {
    console.log("loadPlugins error:", e.message)
  }
}

try {
  loadPlugins()
} catch {}

try {
  fs.watch(pluginsDir, { recursive: true }, () => setTimeout(loadPlugins, 300))
} catch {}

let caseFile
try {
  caseFile = require("../case")
} catch (e) {
  console.error("Gagal load case.js:", e.message)
  caseFile = async () => false
}

/* cache @username -> id */
const readCache = () => {
  try {
    const raw = JSON.parse(fs.readFileSync("./library/database/usercache.json"))
    return raw && typeof raw === "object" && !Array.isArray(raw) ? raw : {}
  } catch {
    return {}
  }
}

const cleanCmd = (cmd) => {
  try {
    return String(cmd || "").split("@")[0].toLowerCase()
  } catch {
    return ""
  }
}

const parsePrefix = (text) => {
  try {
    if (!text) return { isCmd: false }

    if (text.startsWith("/")) {
      const body = text.slice(1).trim()
      const [cmd, ...args] = body.split(/\s+/)
      return { isCmd: true, prefix: "/", command: cleanCmd(cmd), args, body }
    }

    for (const p of global.prefix || []) {
      if (text.startsWith(p)) {
        const body = text.slice(p.length).trim()
        const [cmd, ...args] = body.split(/\s+/)
        return { isCmd: true, prefix: p, command: cleanCmd(cmd), args, body }
      }
    }

    if (global.noPrefix) {
      const body = text.trim()
      const [cmd, ...args] = body.split(/\s+/)
      return { isCmd: true, prefix: "", command: cleanCmd(cmd), args, body }
    }

    return { isCmd: false }
  } catch {
    return { isCmd: false }
  }
}

const fullName = (u) => {
  try {
    return [u?.first_name, u?.last_name].filter(Boolean).join(" ") || null
  } catch {
    return null
  }
}

const buildForward = (src) => {
  try {
    if (!src) return null
    const o = src.forward_origin

    if (o) {
      if (o.type === "user" && o.sender_user)
        return { id: String(o.sender_user.id), name: fullName(o.sender_user), username: o.sender_user.username || null, hidden: false }
      if (o.type === "hidden_user")
        return { id: null, name: o.sender_user_name || null, username: null, hidden: true }
      return null
    }

    if (src.forward_from)
      return { id: String(src.forward_from.id), name: fullName(src.forward_from), username: src.forward_from.username || null, hidden: false }

    if (src.forward_sender_name)
      return { id: null, name: src.forward_sender_name, username: null, hidden: true }

    return null
  } catch {
    return null
  }
}

/* ── ekstrak media dari SEMUA jenis pesan (dipakai pesan sendiri & reply) ── */
const buildMedia = (msg) => {
  try {
    if (!msg) return null
    if (msg.photo && msg.photo.length) {
      const p = msg.photo[msg.photo.length - 1]
      return { fileId: p.file_id, filename: "photo.jpg", mimetype: "image/jpeg", mediaType: "photo" }
    }
    if (msg.video) {
      return { fileId: msg.video.file_id, filename: msg.video.file_name || "video.mp4", mimetype: msg.video.mime_type || "video/mp4", mediaType: "video" }
    }
    if (msg.audio) {
      return { fileId: msg.audio.file_id, filename: msg.audio.file_name || "audio.mp3", mimetype: msg.audio.mime_type || "audio/mpeg", mediaType: "audio" }
    }
    if (msg.voice) {
      return { fileId: msg.voice.file_id, filename: "voice.ogg", mimetype: msg.voice.mime_type || "audio/ogg", mediaType: "voice" }
    }
    if (msg.video_note) {
      return { fileId: msg.video_note.file_id, filename: "videonote.mp4", mimetype: msg.video_note.mime_type || "video/mp4", mediaType: "video_note" }
    }
    if (msg.document) {
      return { fileId: msg.document.file_id, filename: msg.document.file_name || "document", mimetype: msg.document.mime_type || "application/octet-stream", mediaType: "document" }
    }
    if (msg.sticker) {
      const st = msg.sticker
      return {
        fileId: st.file_id,
        filename: "sticker." + (st.is_animated ? "tgs" : st.is_video ? "webm" : "webp"),
        mimetype: st.mime_type || (st.is_animated ? "application/x-tgsticker" : st.is_video ? "video/webm" : "image/webp"),
        mediaType: "sticker",
        sticker: { setName: st.set_name || null, emoji: st.emoji || "🙂", isAnimated: !!st.is_animated, isVideo: !!st.is_video }
      }
    }
    if (msg.animation) {
      return { fileId: msg.animation.file_id, filename: msg.animation.file_name || "animation.mp4", mimetype: msg.animation.mime_type || "video/mp4", mediaType: "animation" }
    }
  } catch {}
  return null
}

const buildQuoted = (msg) => {
  try {
    if (!msg.reply_to_message) return null
    const q = msg.reply_to_message
    const media = buildMedia(q)

    return {
      id: q.message_id,
      chat: q.chat.id,
      sender: q.from?.id ?? null,
      name: fullName(q.from),
      username: q.from?.username || null,
      forward: buildForward(q),
      text: q.text || q.caption || "",
      /* media fields (kompatibel kode lama) */
      fileId: media?.fileId || null,
      filename: media?.filename || null,
      mimetype: media?.mimetype || null,
      mediaType: media?.mediaType || null,
      sticker: media?.sticker || null
    }
  } catch {
    return null
  }
}

/* ── fallback tombol tanpa style (kalau server/client belum dukung) ── */
const withoutStyle = (opt = {}) => {
  try {
    const o = { ...opt }
    const kb = o.reply_markup?.inline_keyboard
    if (kb) {
      o.reply_markup = {
        inline_keyboard: kb.map((r) =>
          r.map(({ style, ...b }) => b)
        )
      }
    }
    return o
  } catch {
    return opt
  }
}

const withoutMarkup = (opt = {}) => {
  try {
    const o = { ...opt }
    delete o.reply_markup
    return o
  } catch {
    return opt
  }
}

/* ── PAGINATION: pesan >3900 char dipecah jadi beberapa halaman ──
   Batas Telegram 4096 char — pesan lebih dari itu ditolak
   ("message is too long") dan bot terlihat diam.
   Pemecahan HANYA di batas baris + tag HTML yang terbuka lintas chunk
   ditutup & dibuka ulang, supaya parse_mode HTML tetap valid. */
const MAX_MSG_LEN = 3900
const HTML_TAGS = ["blockquote", "b", "i", "u", "s", "code", "pre"]

const scanOpenTags = (line, stack) => {
  try {
    const re = /<(\/?)((?:b|i|u|s|code|pre|blockquote|a))(?:\s[^>]*)?>/g
    let mm
    while ((mm = re.exec(line)) !== null) {
      const closing = mm[1] === "/"
      const tag = mm[2].toLowerCase()
      if (closing) {
        for (let i = stack.length - 1; i >= 0; i--) {
          if (stack[i].tag === tag) { stack.splice(i, 1); break }
        }
      } else {
        const href = tag === "a" ? ((mm[0].match(/href="([^"]*)"/) || [])[1] || "") : ""
        stack.push({ tag, href })
      }
    }
  } catch {}
}

const openTagsStr = (stack) =>
  stack.map(t => (t.tag === "a" ? `<a href="${t.href}">` : `<${t.tag}>`)).join("")
const closeTagsStr = (stack) =>
  stack.slice().reverse().map(t => `</${t.tag}>`).join("")

const splitLongMessage = (text) => {
  const str = String(text ?? "")
  if (str.length <= MAX_MSG_LEN) return [str]

  const lines = str.split("\n")
  const chunks = []
  let cur = []
  let curLen = 0
  let open = [] /* tag HTML yang masih terbuka di chunk ini */

  for (const rawLine of lines) {
    let line = rawLine
    /* baris tunggal yang lebih panjang dari maxLen → hard split */
    while (line.length > MAX_MSG_LEN) {
      if (cur.length) { chunks.push(cur.join("\n")); cur = []; curLen = 0 }
      chunks.push(openTagsStr(open) + line.slice(0, MAX_MSG_LEN) + closeTagsStr(open))
      line = line.slice(MAX_MSG_LEN)
    }
    if (curLen + line.length + 1 > MAX_MSG_LEN && cur.length) {
      chunks.push(cur.join("\n") + closeTagsStr(open))
      cur = []
      curLen = 0
      /* tag terbuka dibuka ulang di halaman berikutnya */
      cur.push(openTagsStr(open))
      curLen += openTagsStr(open).length
    }
    scanOpenTags(line, open)
    cur.push(line)
    curLen += line.length + 1
  }
  if (cur.length) chunks.push(cur.join("\n"))
  return chunks.length ? chunks : [str]
}

/* ── PAGER ROW (module scope — dipakai replyPaged & callback /pg) ── */
const pagerRow = (st, page, uid) => {
  if (!st || st.pages <= 1) return []
  return [{
    text: "◀",
    callback_data: "/pg " + (page - 1) + " " + uid,
    style: "primary"
  }, {
    text: (page + 1) + "/" + st.pages,
    callback_data: "/pg " + page + " " + uid,
    style: "primary"
  }, {
    text: "▶",
    callback_data: "/pg " + (page + 1) + " " + uid,
    style: "primary"
  }]
}

const isParseError = (msg) =>
  /can't parse|parse entities|unsupported start tag|unclosed tag|bad request.*entity/i.test(String(msg || ""))

/* label tombol pager dari language.js (i18n, fallback aman) */
const PAGER_LABELS = {
  home: () => {
    try { return t("id", "menu.btnHome") } catch { return "Home" }
  },
  owner: () => {
    try { return "👤 " + global.namaOwner } catch { return "👤 Owner" }
  },
  expired: () => {
    try { return t("id", "allhandlers.failed") } catch { return "⚠️ All handlers for this command failed. Owner has been notified." }
  },
  notYours: () => {
    try { return t("id", "denied.buttonsRole") } catch { return "🚫 These buttons are not yours." }
  },
  error: () => {
    try { return t("id", "pager.internalError") } catch { return "An internal error occurred. Please try again later." }
  }
}

const buildMessage = (msg, bot) => {
  const m = {}
  try {
    m.entities = []

    const messageText = msg.text || msg.caption || ""
    const ents = Array.isArray(msg.entities)
      ? msg.entities
      : Array.isArray(msg.caption_entities)
        ? msg.caption_entities
        : []

    /* SAVE USER CACHE */
    try {
      const file = "./library/database/usercache.json"
      const db = readCache()
      const keep = (un, id) => {
        if (un && id) db[String(un).toLowerCase()] = String(id)
      }

      keep(msg.from?.username, msg.from?.id)
      keep(msg.reply_to_message?.from?.username, msg.reply_to_message?.from?.id)

      const fwdSelf = buildForward(msg)
      if (fwdSelf && fwdSelf.id) keep(fwdSelf.username, fwdSelf.id)

      for (const e of ents) {
        if (e.user?.id) keep(e.user.username, e.user.id)
      }

      fs.writeFileSync(file, JSON.stringify(db, null, 2))
    } catch {}

    /* ── MENTION: text_mention (id pasti) + mention @username (cache/lookup) ── */
    m.mentioned = []
    try {
      for (const e of ents) {
        try {
          if ((e.type === "text_mention" || e.type === "mention_user") && e.user) {
            m.mentioned.push({
              id: String(e.user.id),
              username: e.user.username || null,
              name: fullName(e.user),
              text: messageText.substring(e.offset, e.offset + e.length)
            })
            m.entities.push({ type: "text_mention", user: { id: String(e.user.id) } })
            continue
          }

          if (e.type === "mention" && messageText) {
            const mentionText = messageText.substring(e.offset, e.offset + e.length)
            const username = mentionText.replace("@", "").toLowerCase()
            try {
              const cache = readCache()
              if (cache[username]) {
                const id = String(cache[username])
                m.mentioned.push({ id, username, name: null, text: mentionText })
                m.entities.push({ type: "text_mention", user: { id } })
              } else {
                /* belum ada di cache — tetap catat username-nya */
                m.mentioned.push({ id: null, username, name: null, text: mentionText })
              }
            } catch {}
          }
        } catch {}
      }
    } catch {}

    m.raw = msg.text || msg.caption || ""
    m.id = msg.message_id
    m.chat = msg.chat.id
    m.sender = msg.from?.id
    m.pushName = msg.from?.first_name || "NoName"
    m.isGroup = String(msg.chat.type || "").includes("group")
    m.text = msg.text || msg.caption || ""
    m.body = m.text
    m.thread = msg.message_thread_id
    m.quoted = buildQuoted(msg)
    m.forward = buildForward(msg)

    /* MEDIA PESAN INI (bukan cuma reply) — dipakai /bratpack, /tourl, dll */
    try {
      const own = buildMedia(msg)
      m.media = own
      m.fileId = own?.fileId || null
      m.filename = own?.filename || null
      m.mimetype = own?.mimetype || null
      m.mediaType = own?.mediaType || null
      m.sticker = own?.sticker || null
    } catch {
      m.media = null
      m.fileId = null
      m.filename = null
      m.mimetype = null
      m.mediaType = null
      m.sticker = null
    }

    /* LANGUAGE */
    try {
      m.lang = getLang(m.sender)
      m.t = (key, vars) => t(m.lang, key, vars)
      m.setLang = (lang) => {
        const ok = setLang(m.sender, lang)
        if (ok) m.lang = String(lang).toLowerCase()
        return ok
      }
    } catch {
      m.lang = "id"
      m.t = (key) => key
      m.setLang = () => false
    }

    if (msg._callback) m.callback = msg._callback

    m.type =
      msg.photo ? "imageMessage" :
      msg.video ? "videoMessage" :
      msg.voice ? "audioMessage" :
      msg.document ? "documentMessage" :
      msg.sticker ? "stickerMessage" : "conversation"

    /* kirim SATU potongan pesan dengan seluruh fallback (parse error → tanpa style → tanpa markup) */
    const sendOne = async (text, opt = {}) => {
      const base = {
        parse_mode: "HTML",
        allow_sending_without_reply: true,
        message_thread_id: m.thread
      }
      const o = { ...base, ...opt }
      try {
        return await bot.sendMessage(m.chat, String(text), o)
      } catch (err) {
        const msgErr = String(err?.message || err)
        if (msgErr.includes("not modified")) return null

        /* 1. HTML rusak → kirim plain */
        if (isParseError(msgErr)) {
          try {
            const o2 = { ...withoutStyle(opt) }
            delete o2.parse_mode
            return await bot.sendMessage(m.chat, String(text), { ...base, ...o2 })
          } catch {}
        }

        /* 2. style belum didukung → buang style, warna hilang TAPI tombol tetap ada */
        try {
          return await bot.sendMessage(m.chat, String(text), { ...base, ...withoutStyle(opt) })
        } catch {}

        /* 3. terakhir → buang markup sama sekali */
        try {
          return await bot.sendMessage(m.chat, String(text), { ...base, ...withoutMarkup(opt) })
        } catch {}

        console.log("reply fallback fail:", msgErr)
        return null
      }
    }

    /* ── PAGER STATE v2: persistent (file) + merge tombol menu + ◀ N/M ▶ ──
       - state disimpan ke library/database/pagerstore.json → TIDAK hilang
         saat bot restart (tombol ◀▶ di pesan lama tetap jalan)
       - tombol ◀▶ DI-MERGE di bawah tombol menu asli, bukan menimpa
       - maks 200 entri, yang terlama dibuang otomatis */
    if (!global._pagerStore) {
      global._pagerStore = new Map()
      const PAGER_FILE = path.join(__dirname, "..", "library", "database", "pagerstore.json")
      try {
        const raw = JSON.parse(fs.readFileSync(PAGER_FILE, "utf8"))
        if (Array.isArray(raw)) for (const [k, v] of raw) global._pagerStore.set(String(k), v)
      } catch {}
      let _gcTimer = null
      global._pagerSave = () => {
        try {
          if (_gcTimer) return
          _gcTimer = setTimeout(() => {
            _gcTimer = null
            try {
              /* buang yang terlama kalau kelebihan kapasitas */
              while (global._pagerStore.size > 200) {
                let oldest = null, oldTs = Infinity
                for (const [k, v] of global._pagerStore.entries()) {
                  if ((v.ts || 0) < oldTs) { oldTs = v.ts || 0; oldest = k }
                }
                if (oldest) global._pagerStore.delete(oldest); else break
              }
              fs.mkdirSync(path.dirname(PAGER_FILE), { recursive: true })
              fs.writeFileSync(PAGER_FILE, JSON.stringify([...global._pagerStore.entries()]))
            } catch {}
          }, 1500)
        } catch {}
      }
    }

    const replyPaged = async (chunks, opt = {}) => {
      const uid = String(m.sender)
      /* pakai ulang pesan pager lama di chat yang sama (anti spam pesan) */
      for (const [mid, st] of global._pagerStore.entries()) {
        if (st.uid === uid && String(st.chat) === String(m.chat)) {
          try { await bot.deleteMessage(m.chat, mid) } catch {}
          global._pagerStore.delete(mid)
          global._pagerSave && global._pagerSave()
        }
      }
      const st = {
        uid,
        chat: m.chat,
        pages: chunks.length,
        page: 0,
        chunks,
        baseKb: (opt.reply_markup && Array.isArray(opt.reply_markup.inline_keyboard))
          ? opt.reply_markup.inline_keyboard
          : [],
        ts: Date.now()
      }
      if (chunks.length > 1) {
        const row = pagerRow(st, 0, uid)
        const baseRows = st.baseKb.length ? st.baseKb : []
        opt = { ...opt, reply_markup: { inline_keyboard: [...baseRows, row, [{ text: "🏠 " + PAGER_LABELS.home(), callback_data: "/menu home " + uid, style: "danger" }, { text: PAGER_LABELS.owner(), url: global.linkOwner || "https://t.me/" }]] } }
      } else {
        /* pesan pendek pun dapat navigasi minimal (kalau belum ada tombol apa pun) */
        if (!opt.reply_markup || !opt.reply_markup.inline_keyboard) {
          opt = { ...opt, reply_markup: { inline_keyboard: [[{ text: "🏠 " + PAGER_LABELS.home(), callback_data: "/menu home " + uid, style: "danger" }, { text: PAGER_LABELS.owner(), url: global.linkOwner || "https://t.me/" }]] } }
        }
      }
      const sent = await sendOne(chunks[0], opt)
      if (chunks.length > 1 && sent?.message_id) {
        global._pagerStore.set(String(sent.message_id), st)
        global._pagerSave && global._pagerSave()
      }
      return sent
    }

    /* AUTO-TRANSLATE: sisa teks ID hardcoded dari plugin mana pun
       otomatis diterjemahkan ke EN saat user pakai mode EN (permintaan owner:
       "tidak boleh ada teks Indonesia saat mode English"). */
    const _userLang = String(m.lang || "id").toLowerCase()
    const _trOut = (s) => _userLang === "en" ? autoTranslate(s) : s

    m.reply = async (text, opt = {}) => {
      /* DETEKSI ERROR QUERY/API: plugin yang menangkap error sendiri lalu
         membalas "❌ Gagal ..." tidak pernah sampai ke wrapHandler — catat
         di errorlog + notify owner supaya fitur rusak terdeteksi & ditandai ❌
         di menu. Fitur yang sukses dipanggil lagi otomatis dibersihkan. */
      try {
        const errorLog = require("./errorlog")
        if (m.command && errorLog.isFailReply(text) && !m._failReported) {
          m._failReported = true
          errorLog.reportError(m.command, String(text).replace(/<[^>]+>/g, "").trim().slice(0, 140), "query")
        }
      } catch {}
      /* PAGINATION: pesan panjang → 1 pesan + tombol ◀ 1/N ▶ */
      const chunks = splitLongMessage(_trOut(text))
      return await replyPaged(chunks, opt)
    }

    m.send = async (text, opt = {}) => {
      /* PAGINATION juga berlaku di m.send */
      const chunks = splitLongMessage(_trOut(text))
      let last = null
      for (const c of chunks) {
        try {
          last = await bot.sendMessage(m.chat, String(c), {
            allow_sending_without_reply: true,
            message_thread_id: m.thread,
            ...opt
          })
        } catch (e) {
          try {
            last = await bot.sendMessage(m.chat, String(c), {
              allow_sending_without_reply: true,
              message_thread_id: m.thread,
              ...withoutStyle(opt)
            })
          } catch (e2) {
            console.log("m.send error:", e2.message)
          }
        }
      }
      return last
    }
    /* reaksi asli Telegram — via raw API (method ini belum ada di
       node-telegram-bot-api v0.64) + auto-retry 429 */
    m.react = async (emoji) => {
      const tryOnce = async () => {
        const token = bot.token || global.Rafz?.token
        const url = `https://api.telegram.org/bot${token}/setMessageReaction`
        const res = await fetch(url, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            chat_id: m.chat,
            message_id: m.id,
            reaction: emoji ? [{ type: "emoji", emoji }] : []
          })
        })
        const j = await res.json().catch(() => null)
        if (!res.ok) {
          const ra = j && j.parameters ? j.parameters.retry_after : null
          const err = new Error(`429 setMessageReaction${ra ? ": retry after " + ra : ""}`)
          err.response = { statusCode: res.status, body: j }
          throw err
        }
        return j
      }
      try {
        return await antiflood.withRetry(tryOnce, "m.react")
      } catch {
        return null
      }
    }

    m.edit = async (text, opt = {}) => {
      if (!m.callback) {
        /* bukan callback → pakai pager penuh */
        const chunks = splitLongMessage(_trOut(text))
        return await replyPaged(chunks, opt)
      }

      /* callback: pesan hasil → pager juga (edit + simpan state) */
      const chunks = splitLongMessage(_trOut(text))
      const uid = String(m.sender)
      const mid = m.callback.message?.message_id
      const st = {
        uid,
        chat: m.chat,
        pages: chunks.length,
        page: 0,
        chunks,
        baseKb: (opt.reply_markup && Array.isArray(opt.reply_markup.inline_keyboard))
          ? opt.reply_markup.inline_keyboard
          : [],
        ts: Date.now()
      }
      if (chunks.length > 1) {
        const row = pagerRow(st, 0, uid)
        opt = { ...opt, reply_markup: { inline_keyboard: [...st.baseKb, row] } }
      }
      const res = await editOne(chunks[0], opt)
      if (chunks.length > 1 && mid) {
        global._pagerStore.set(String(mid), st)
        global._pagerSave && global._pagerSave()
      }
      return res
    }

    const editOne = async (text, opt = {}) => {
      const send = async (o) =>
        bot.editMessageText(String(text), {
          chat_id: m.chat,
          message_id: m.callback.message.message_id,
          parse_mode: "HTML",
          ...o
        })

      try {
        return await send(opt)
      } catch (e) {
        const msgErr = String(e?.message || e)
        if (msgErr.includes("not modified")) return null

        if (isParseError(msgErr)) {
          try {
            const o = { ...withoutStyle(opt) }
            delete o.parse_mode
            return await send(o)
          } catch {}
        }
        try {
          return await send(withoutStyle(opt))
        } catch {}
        return m.reply(text, withoutStyle(opt))
      }
    }

    global.conn = {
      sendMessage: (chat, content, opt = {}) => {
        try {
          if (typeof content === "string") return bot.sendMessage(chat, content, opt)
          if (content?.text) {
            const { text, ...options } = content
            return bot.sendMessage(chat, text, { ...options, ...opt })
          }
          if (content?.react)
            return bot.sendMessage(chat, content.react, {
              reply_to_message_id: opt?.quoted?.id
            })
        } catch (e) {
          console.log("conn.sendMessage error:", e.message)
        }
      }
    }

    try {
      store.save(m)
    } catch {}

    return m
  } catch (e) {
    console.error("buildMessage fatal:", e.message)
    return m
  }
}

exports.message = async (msg, bot) => {
  try {
    if (msg.from?.is_bot) return

    /* ── ROSE MEMBER HOOK: welcome/goodbye/captcha/antiraid (service messages) ── */
    try {
      if ((msg.new_chat_members || msg.left_chat_member) && typeof global.roseMemberHook === "function") {
        await global.roseMemberHook(msg, bot)
      }
    } catch (e) { console.log("[ROSE MEMBER]", e.message) }

    const m = buildMessage(msg, bot)
    try {
      logger.msg(m)
    } catch {}

    const parsed = parsePrefix(m.body)

    m.isCmd = parsed.isCmd
    m.prefix = parsed.prefix
    m.command = parsed.command
    m.args = parsed.args || []
    m.text = parsed.isCmd && parsed.body ? parsed.body.slice(parsed.command.length).trim() : m.body

    if (!m.isCmd) {
      /* ── ROSE MSG HOOK: locks/blocklist/antiflood/antiraid/captcha/shield/barker cache ──
         return true = pesan sudah ditangani (dihapus/diblok) → stop proses */
      try {
        if (typeof global.roseMsgHook === "function") {
          const r = await global.roseMsgHook(m, { Rafz: bot })
          if (r === true) return
        }
      } catch (e) { console.log("[ROSE MSG]", e.message) }
      /* ── ROSE FILTERS (auto-reply non-command) ── */
      try {
        const gstore = require("./gstore")
        if (m.isGroup) {
          const fl = gstore.arrGet("filters", String(m.chat))
          const body = String(m.body || "").toLowerCase()
          for (const f of fl) {
            const t = String(f.t || "").toLowerCase()
            const hit = f.mode === "exact" ? body === t
              : f.mode === "prefix" ? body.startsWith(t)
              : body.includes(t)
            if (hit) { await m.reply(String(f.reply).slice(0, 3000), { parse_mode: "HTML" }).catch(() => {}); break }
          }
          /* ── ROSE NOTES #trigger ── */
          const nm = String(m.body || "").match(/^#([a-z0-9_-]{1,32})$/i)
          if (nm) {
            const note = gstore.get("notes", String(m.chat) + ":" + nm[1].toLowerCase(), null)
            if (note) { await m.reply("\ud83d\udddd\ufe0f *#" + nm[1] + "*\n\n" + String(note.text).slice(0, 2500), { parse_mode: "HTML" }).catch(() => {}) }
          }
        }
      } catch (e) { console.log("[ROSE FILTER]", e.message) }
      try {
        if (await antiflood.withRetry(() => caseFile(m, bot), "case:nocmd")) return
      } catch (e) {
        console.log("CASE (non-cmd) ERR:", e.message)
      }
      return
    }

    try {
      logger.cmd(m)
    } catch {}

    /* statistik command & user (buat /topcmd & /topmessage) */
    try {
      if (typeof global.cmdStatHook === "function") global.cmdStatHook(m.command)
      if (typeof global.msgStatHook === "function") global.msgStatHook(m.sender)
    } catch {}

    let handled = false
    try {
      /* anti-flood: kalau 429 keluar dari case.js, tunggu limit lepas lalu eksekusi ulang */
      handled = await antiflood.withRetry(() => caseFile(m, bot), "case:" + (m.command || "cmd"))
    } catch (e) {
      console.log("CASE ERR:", e && e.stack ? e.stack : e.message)
      try {
        await m.reply("⚠️ " + PAGER_LABELS.expired())
      } catch {}
    }
    if (handled) {
      /* ── ROSE: cleancommand — hapus PESAN command setelah eksekusi ── */
      try {
        const gstore = require("./gstore")
        const mode = gstore.get("cleancommand", String(m.chat), "off")
        if (mode && mode !== "off" && m.isGroup) {
          let isAdm = false
          try {
            const admins = await bot.getChatAdministrators(m.chat)
            isAdm = admins.some(a => String(a.user?.id) === String(m.sender))
          } catch {}
          if ((global.owner || []).includes(String(m.sender))) isAdm = true
          const hit = mode === "all" || (mode === "user" && !isAdm) || (mode === "admin" && isAdm)
          if (hit) { try { await bot.deleteMessage(m.chat, m.id) } catch {} }
        }
      } catch {}
      return
    }

    /* ── PAGER CALLBACK: ◀ 1/4 ▶ (balik/lanjut halaman pesan panjang) ── */
    if (m.command === "pg") {
      try {
        const uid = String(m.sender)
        const mid = m.callback?.message?.message_id
        const key = mid ? String(mid) : null
        const st = key ? global._pagerStore?.get(key) : null

        if (!st || String(st.chat) !== String(m.chat) || !Array.isArray(st.chunks)) {
          /* kedaluwarsa → edit pesannya jadi notice rapi + lepas tombol,
             jangan biarin tombol mati nongkrong selamanya */
          m.callback.answered = true
          try { await bot.answerCallbackQuery(m.callback.id, { text: PAGER_LABELS.expired() }) } catch {}
          try {
            await bot.editMessageReplyMarkup({ inline_keyboard: [] }, { chat_id: m.chat, message_id: mid })
          } catch {}
          return true
        }
        if (st.uid !== uid) {
          m.callback.answered = true
          try { await bot.answerCallbackQuery(m.callback.id, { text: PAGER_LABELS.notYours(), show_alert: false }) } catch {}
          return true
        }

        let page = parseInt(String(m.args[0] ?? ""), 10)
        if (!Number.isFinite(page)) page = st.page || 0
        page = Math.max(0, Math.min(st.pages - 1, page))
        st.page = page
        st.ts = Date.now()

        const row = pagerRow(st, page, uid)
        const baseRows = (st.baseKb && st.baseKb.length) ? st.baseKb : []
        const kb = { inline_keyboard: [...baseRows, row, [{ text: "🏠 " + PAGER_LABELS.home(), callback_data: "/menu home " + uid, style: "danger" }, { text: PAGER_LABELS.owner(), url: global.linkOwner || "https://t.me/" }]] }
        try {
          await bot.editMessageText(st.chunks[page], {
            chat_id: m.chat,
            message_id: mid,
            parse_mode: "HTML",
            disable_web_page_preview: true,
            reply_markup: kb
          })
        } catch (e) {
          const em = String(e?.message || e)
          if (!em.includes("not modified")) {
            try {
              await bot.editMessageText(st.chunks[page], {
                chat_id: m.chat, message_id: mid,
                disable_web_page_preview: true,
                reply_markup: { inline_keyboard: [...baseRows, row.map(({ style, ...b }) => b)] }
              })
            } catch {}
          }
        }
        m.callback.answered = true
        try { await bot.answerCallbackQuery(m.callback.id) } catch {}
        global._pagerSave && global._pagerSave()
      } catch (e) {
        console.log("[PAGER]", e?.message)
      }
      return true
    }

    /* ALIAS SHORTCUT: /youtubedownload → /ytdl, dll.
       Kalau command tidak ditemukan tapi punya alias, jalankan command aslinya. */
    let pluginChain = plugins.get(m.command)
    if (!pluginChain) {
      try {
        if (typeof global.resolveAlias === "function") {
          const aliased = global.resolveAlias(m.command)
          if (aliased && aliased !== m.command) {
            pluginChain = plugins.get(aliased)
            if (pluginChain) m.command = aliased
          }
        }
      } catch {}
    }
    if (!pluginChain) return
    /* ── ROSE: command disabled per grup? (admin tetap bisa) ── */
    try {
      const gstore = require("./gstore")
      if (m.isGroup) {
        const dis = gstore.arrGet("disabled", String(m.chat))
        if (dis.includes(m.command)) {
          let isAdmin = false
          try {
            const admins = await bot.getChatAdministrators(m.chat)
            isAdmin = admins.some(a => String(a.user?.id) === String(m.sender))
          } catch {}
          if (!isAdmin && !(global.owner || []).includes(String(m.sender))) return
        }
      }
    } catch {}
    // Try each plugin in the fallback chain
    handled = false
    let lastErr = null
    for (const plugin of pluginChain) {
      try {
        await antiflood.withRetry(() => plugin(m, {
          conn: global.conn,
          Rafz: bot,
          args: m.args,
          text: m.text,
          command: m.command,
          prefix: m.prefix
        }), "plugin:" + m.command)
        handled = true
        break
      } catch (e) {
        lastErr = e
        console.log("[PLUGIN FALLBACK] " + m.command + " error in " + (plugin.constructor?.name || "plugin") + ": " + e.message)
        /* KETAT: catat ke errorlog DENGAN lokasi file:baris + snippet kode */
        try {
          const errorLog = require("./errorlog")
          errorLog.logError(m.command, e, "plugin-throw")
        } catch {}
        // Try next plugin in chain
      }
    }

    if (handled) {
      // If feature worked, remove from error log if it was there
      try {
        const errorLog = require("./errorlog")
        if (errorLog.hasError(m.command)) errorLog.removeError(m.command)
      } catch {}
    } else {
      // All handlers failed
      try {
        const errorLog = require("./errorlog")
        const source = pluginChain.length > 1 ? "fallback" : "plugin"
        /* log ERROR ASLI (dgn stack → file:baris:kode) bukan generik,
           supaya owner dapat lokasi persis + bisa auto-fix via AI */
        const entry = errorLog.logError(m.command, lastErr || new Error("All handlers failed"), source)
        if (entry.count === 1) errorLog.notifyOwner(bot, entry)
      } catch {}
      try {
        await m.reply("⚠️ " + PAGER_LABELS.expired())
      } catch {}
    }
  } catch (e) {
    console.error("[HANDLER MESSAGE FATAL]", e && e.stack ? e.stack : e)
  }
}

exports.callback = async (cb, bot) => {
  try {
    await exports.message(
      {
        message_id: cb.message?.message_id,
        chat: cb.message?.chat,
        from: cb.from,
        text: cb.data,
        message_thread_id: cb.message?.message_thread_id,
        _callback: cb
      },
      bot
    )
    if (!cb.answered) {
      try {
        /* auto-retry sampai limit lepas; callback kedaluwarsa dianggap selesai */
        await antiflood.withRetry(() => bot.answerCallbackQuery(cb.id), "answerCallbackQuery")
      } catch (e) {
        console.log("answerCallbackQuery:", e.message)
      }
    }
  } catch (e) {
    console.error("[CALLBACK ERR]", e && e.stack ? e.stack : e)
    try {
      await antiflood.withRetry(() => bot.answerCallbackQuery(cb.id, {
        text: PAGER_LABELS.error(),
        show_alert: true
      }), "answerCallbackQuery")
    } catch {}
    try {
      if (cb.message?.chat?.id) {
        await bot.sendMessage(
          cb.message.chat.id,
          "⚠️ Callback error: " + (e.message || "unknown"),
          { parse_mode: "HTML", reply_to_message_id: cb.message.message_id }
        )
      }
    } catch {}
  }
}

/* hot-reload self */
try {
  let file = require.resolve(__filename)
  fs.watchFile(file, () => {
    try {
      fs.unwatchFile(file)
      delete require.cache[file]
      require(file)
    } catch {}
  })
} catch {}
