/* ============================================================
   LANGUAGE CORE
   Semua teks bot ada di sini. Tambah bahasa baru = tambah
   entri di SUPPORTED + META + terjemahan tiap key di STRINGS.
   ============================================================ */

const fs = require("fs")
const path = require("path")

const DB_PATH = path.join(__dirname, "database", "lang.json")

const SUPPORTED = ["id", "en"]

/* default bisa diubah dari settings.js (global.defaultLang) */
const DEFAULT_LANG = SUPPORTED.includes(String(global.defaultLang || "").toLowerCase())
  ? String(global.defaultLang).toLowerCase()
  : "id"

/* name = label tombol, flag = emoji bendera, style = warna tombol */
const META = {
  en: { name: "English", flag: "🇬🇧", style: "primary" },
  id: { name: "Indonesia", flag: "🇮🇩", style: "success" }
}

const STRINGS = {

/* ================= UMUM ================= */

"common.example": {
  id: "\n<b>Prefix yang tersedia</b>: {prefix}\nGunakan Salah satu jangan semua! \n\n<blockquote><b>Contoh Penggunaan :</b></blockquote>\nKetik <code>{cmd} {args}</code>\n",
  en: "\n<b>Available prefixes</b>: {prefix}\nUse only one, not all!\n\n<blockquote><b>Usage example :</b></blockquote>\nType <code>{cmd} {args}</code>\n"
},
"common.needTarget": {
  id: "🔎 Reply user / @username / ID",
  en: "🔎 Reply to the user / @username / ID"
},
"common.needTargetShort": {
  id: "🔎 Reply / ID diperlukan",
  en: "🔎 A reply / ID is required"
},
"common.notFound": {
  id: "🔎 ID tidak ditemukan",
  en: "🔎 ID not found"
},
"common.notFoundLong": {
  id: "❌ ID user tidak ditemukan. Gunakan ID, @username, atau me.",
  en: "❌ User ID not found. Use an ID, @username, or me."
},
"session.already": {
  id: "⚠️ Sesi {cmd} masih jalan di chat lain ({where}).",
  en: "⚠️ The {cmd} session is still running in another chat ({where})."
},
"session.howto": {
  id: "Lanjutkan dari pesan itu, atau tap tombol di bawah buat mengakhiri sesi lama dan mulai sesi baru di chat ini.",
  en: "Continue from that message, or tap the button below to end the old session and start a new one in this chat."
},
"session.newBtn": {
  id: "🆕 Akhiri yang lama, buat baru di sini",
  en: "🆕 End the old one, start new here"
},
"session.ended": {
  id: "♻️ Sesi {cmd} sebelumnya ({where}) sudah selesai atau kedaluwarsa, jadi dibatalkan.\nSilakan lanjutkan sesi baru di chat ini.",
  en: "♻️ The previous {cmd} session ({where}) is finished or expired, so it was cancelled.\nContinue with the new session in this chat."
},
"common.usernameNotFound": {
  id: "❌ @username nggak bisa diresolve. Suruh user-nya /start bot dulu, atau pakai ID / reply pesan-nya.",
  en: "❌ Couldn't resolve that @username. Ask the user to /start the bot first, or use their ID / reply to their message."
},
"common.badParam": {
  id: "⚠️ Parameter kurang",
  en: "⚠️ Missing parameter"
},
"common.searching": {
  id: "Mencari...",
  en: "Searching..."
},
"common.failed": {
  id: "❌ Gagal:",
  en: "❌ Failed:"
},
"common.checkPv": {
  id: "📩 Cek private chat",
  en: "📩 Check your private chat"
},
"common.serverMissing": {
  id: "❌ Server tidak ditemukan",
  en: "❌ Server not found"
},
"common.badFormat": {
  id: "⚠️ Format salah",
  en: "⚠️ Wrong format"
},
"common.unknown": {
  id: "❓ Penyebab tidak diketahui",
  en: "❓ Unknown reason"
},
"common.unlimited": {
  id: "Unlimited",
  en: "Unlimited"
},
"common.pvFailed": {
  id: "❌ Gagal kirim PV. Suruh user chat bot dulu.",
  en: "❌ Failed to send a private message. Ask the user to start the bot first."
},
"copy.usage": {
  id: "teksnya",
  en: "the text"
},
"eval.sendCode": {
  id: "kirim kode",
  en: "send the code"
},

/* ================= AKSES DITOLAK ================= */

"denied.creator": {
  id: "⛔ AKSES DITOLAK\nPerintah ini hanya untuk Owner Utama.",
  en: "⛔ ACCESS DENIED\nThis command is for the Main Owner only."
},
"denied.owner": {
  id: "⛔ AKSES DITOLAK\nPerintah ini hanya untuk Owner.",
  en: "⛔ ACCESS DENIED\nThis command is for Owners only."
},
"denied.admin": {
  id: "⛔ AKSES DITOLAK\nPerintah ini hanya untuk Admin.",
  en: "⛔ ACCESS DENIED\nThis command is for Admins only."
},
"denied.seller": {
  id: "⛔ AKSES DITOLAK\nPerintah ini hanya untuk Seller.\n\nIngin bergabung?\nHubungi @Rafzbotz",
  en: "⛔ ACCESS DENIED\nThis command is for Sellers only.\n\nWant to join?\nContact @Rafzbotz"
},
"denied.super": {
  id: "⛔ AKSES DITOLAK\nPerintah ini hanya untuk SuperSeller.\n\nUpgrade akses:\nHubungi @Rafzbotz",
  en: "⛔ ACCESS DENIED\nThis command is for SuperSellers only.\n\nUpgrade access:\nContact @Rafzbotz"
},
"denied.group": {
  id: "⛔ AKSES DITOLAK\nPerintah ini hanya dapat digunakan di Grup.",
  en: "⛔ ACCESS DENIED\nThis command can only be used in a Group."
},
"denied.private": {
  id: "⛔ AKSES DITOLAK\nPerintah ini hanya dapat digunakan di Private Chat.",
  en: "⛔ ACCESS DENIED\nThis command can only be used in a Private Chat."
},
"denied.buttons": {
  id: "🚫 Tombol itu punya orang lain.\nKamu tidak bisa pakai tombol orang lain.\n\nKetik sendiri: {cmd}",
  en: "🚫 Those buttons belong to someone else.\nYou cannot use someone else's buttons.\n\nRun it yourself: {cmd}"
},
"denied.prem": {
  id: "⛔ AKSES DITOLAK\nFitur khusus pengguna Premium.",
  en: "⛔ ACCESS DENIED\nPremium-only feature."
},

/* ================= SERVER V3 PRIVAT ================= */

"pv.noAccess": {
  id: "⛔ Kamu belum mendapat akses Server V3 Privat.",
  en: "⛔ You don't have access to the Private V3 Server yet."
},
"pv.noAccessContact": {
  id: "⛔ Kamu belum mendapat akses Server V3 Privat. Hubungi owner untuk whitelist.",
  en: "⛔ You don't have access to the Private V3 Server yet. Contact the owner to be whitelisted."
},
"pv.already": {
  id: "✅ User sudah mendapat akses Server V3 Privat.",
  en: "✅ User already has access to the Private V3 Server."
},
"pv.added": {
  id: "✅ Akses Server V3 Privat ditambahkan\nID: <code>{id}</code>",
  en: "✅ Private V3 Server access granted\nID: <code>{id}</code>"
},
"pv.notListed": {
  id: "❌ User tidak ada di whitelist Server V3 Privat.",
  en: "❌ User is not in the Private V3 Server whitelist."
},
"pv.removed": {
  id: "✅ Akses Server V3 Privat dicabut\nID: <code>{id}</code>",
  en: "✅ Private V3 Server access revoked\nID: <code>{id}</code>"
},
"pv.listEmpty": {
  id: "Whitelist Server V3 Privat kosong.",
  en: "Private V3 Server whitelist is empty."
},
"pv.listHeader": {
  id: "<b>🔐 WHITELIST SERVER V3 PRIVAT</b>",
  en: "<b>🔐 PRIVATE V3 SERVER WHITELIST</b>"
},
"pv.help": {
  id: `<b>🛡 SERVER V3 PRIVAT</b>

<code>/pvcreate nama|id/@username/me|ram|cpu|disk</code>
<code>/pvlist</code>
<code>/pvinfo id</code>
<code>/pvdelete id</code>
<code>/pvstart id</code>
<code>/pvstop id</code>

<b>Resource:</b> isi <code>0</code> untuk unlimited.
RAM/Disk dalam GB, CPU dalam persen.

Contoh:
<code>/pvcreate myserver|me|2|100|5</code>
<code>/pvcreate myserver|123456789|0|0|0</code>`,
  en: `<b>🛡 PRIVATE V3 SERVER</b>

<code>/pvcreate name|id/@username/me|ram|cpu|disk</code>
<code>/pvlist</code>
<code>/pvinfo id</code>
<code>/pvdelete id</code>
<code>/pvstart id</code>
<code>/pvstop id</code>

<b>Resource:</b> use <code>0</code> for unlimited.
RAM/Disk in GB, CPU in percent.

Example:
<code>/pvcreate myserver|me|2|100|5</code>
<code>/pvcreate myserver|123456789|0|0|0</code>`
},
"pv.usage": {
  id: "nama|id/@username/me|ram|cpu|disk\nContoh: pvcreate myserver|me|2|100|5\nIsi 0 untuk unlimited.",
  en: "name|id/@username/me|ram|cpu|disk\nExample: pvcreate myserver|me|2|100|5\nUse 0 for unlimited."
},
"pv.format": {
  id: "Format: /pvcreate nama|id/@username/me|ram|cpu|disk",
  en: "Format: /pvcreate name|id/@username/me|ram|cpu|disk"
},
"pv.badResource": {
  id: "❌ Resource tidak valid. Gunakan angka >= 0. Nilai 0 = unlimited.",
  en: "❌ Invalid resource. Use a number >= 0. 0 = unlimited."
},
"pv.badName": {
  id: "❌ Nama server tidak valid.",
  en: "❌ Invalid server name."
},
"pv.userFail": {
  id: "❌ Gagal membuat user panel.\n",
  en: "❌ Failed to create the panel user.\n"
},
"pv.eggFail": {
  id: "❌ Egg Server V3 tidak valid.",
  en: "❌ Private V3 Server egg is invalid."
},
"pv.createFail": {
  id: "❌ Gagal membuat Server V3.\n",
  en: "❌ Failed to create the V3 Server.\n"
},
"pv.created": {
  id: `<b>✅ SERVER V3 PRIVAT BERHASIL DIBUAT</b>

Nama: <code>{name}</code>
ID: <code>{id}</code>
Pemilik: <code>{owner}</code>
RAM: <code>{ram}</code>
CPU: <code>{cpu}</code>
Disk: <code>{disk}</code>
Panel: <a href="{domain}">{domain}</a>
Username: <code>{username}</code>`,
  en: `<b>✅ PRIVATE V3 SERVER CREATED</b>

Name: <code>{name}</code>
ID: <code>{id}</code>
Owner: <code>{owner}</code>
RAM: <code>{ram}</code>
CPU: <code>{cpu}</code>
Disk: <code>{disk}</code>
Panel: <a href="{domain}">{domain}</a>
Username: <code>{username}</code>`
},
"pv.passExisting": {
  id: "Gunakan password panel yang sudah ada.",
  en: "Use the panel password you already have."
},
"pv.listEmptyAll": {
  id: "Tidak ada server V3 privat.",
  en: "No private V3 servers."
},
"pv.listHeader": {
  id: "<b>🖥 SERVER V3 PRIVAT</b>",
  en: "<b>🖥 PRIVATE V3 SERVERS</b>"
},
"pv.item": {
  id: "ID <code>{id}</code> | <b>{name}</b>\nRAM: {ram} MB | CPU: {cpu}% | Disk: {disk} MB",
  en: "ID <code>{id}</code> | <b>{name}</b>\nRAM: {ram} MB | CPU: {cpu}% | Disk: {disk} MB"
},
"pv.infoFormat": {
  id: "Format: /pvinfo id",
  en: "Format: /pvinfo id"
},
"pv.notFound": {
  id: "🔎 Server tidak ditemukan.",
  en: "🔎 Server not found."
},
"pv.notYours": {
  id: "⛔ Server itu bukan milikmu.",
  en: "⛔ That server is not yours."
},
"pv.info": {
  id: "<b>🖥 SERVER INFO</b>\nID: <code>{id}</code>\nName: <code>{name}</code>\nIdentifier: <code>{identifier}</code>\nRAM: <code>{ram} MB</code>\nDisk: <code>{disk} MB</code>\nCPU: <code>{cpu}%</code>",
  en: "<b>🖥 SERVER INFO</b>\nID: <code>{id}</code>\nName: <code>{name}</code>\nIdentifier: <code>{identifier}</code>\nRAM: <code>{ram} MB</code>\nDisk: <code>{disk} MB</code>\nCPU: <code>{cpu}%</code>"
},
"pv.delFormat": {
  id: "Format: /pvdelete id",
  en: "Format: /pvdelete id"
},
"pv.delFail": {
  id: "Gagal menghapus server.",
  en: "Failed to delete the server."
},
"pv.deleted": {
  id: "✅ Server V3 privat <code>{id}</code> dihapus.",
  en: "✅ Private V3 server <code>{id}</code> deleted."
},
"pv.powerFormat": {
  id: "Format: /{cmd} id",
  en: "Format: /{cmd} id"
},
"pv.powerFail": {
  id: "Gagal {action} server.",
  en: "Failed to {action} the server."
},
"pv.powerSent": {
  id: "✅ Server <code>{id}</code> dikirim perintah <b>{action}</b>.",
  en: "✅ Server <code>{id}</code> received the <b>{action}</b> command."
},

/* ================= PANEL ================= */

"panel.usage": {
  id: "user|id/tag/me\n\nContoh: {cmd} rafz|me\n→ nanti muncul tombol pilih RAM, Disk, CPU, Durasi\n\nMode cepat (langsung jadi):\n{cmd} rafz|me|ram|bulan|server\n\nIsi 0 untuk unli",
  en: "user|id/tag/me\n\nExample: {cmd} rafz|me\n→ you'll get buttons to pick RAM, Disk, CPU, Duration\n\nQuick mode (straight away):\n{cmd} rafz|me|ram|months|server\n\nUse 0 for unlimited"
},
"panel.ramLabel": {
  id: "RAM",
  en: "RAM"
},
"panel.diskLabel": {
  id: "DISK",
  en: "DISK"
},
"panel.cpuLabel": {
  id: "CPU",
  en: "CPU"
},
"panel.durationLabel": {
  id: "Durasi",
  en: "Duration"
},
"panel.askStart": {
  id: "<b>🖥️ CREATE PANEL</b>\n\nKetik nama server + target:\n<code>nama|id</code> — contoh <code>myserver|me</code>\n\nTarget bisa <code>id</code>, <code>@username</code>, reply pesan, atau <code>me</code>.\n\nMode cepat: <code>{prefix}cpanel nama|id|ram|bulan|server</code>",
  en: "<b>🖥️ CREATE PANEL</b>\n\nType the server name + target:\n<code>name|id</code> — example <code>myserver|me</code>\n\nTarget can be <code>id</code>, <code>@username</code>, a replied message, or <code>me</code>.\n\nQuick mode: <code>{prefix}cpanel name|id|ram|months|server</code>"
},
"panel.wizardTitle": {
  id: "<b>🖥️ CREATE PANEL</b>",
  en: "<b>🖥️ CREATE PANEL</b>"
},
"panel.wizardUser": {
  id: "Nama",
  en: "Name"
},
"panel.wizardTarget": {
  id: "Target",
  en: "Target"
},
"panel.wizardServerLabel": {
  id: "Server",
  en: "Server"
},
"panel.wizardAsk": {
  id: "Pilih {res}:",
  en: "Choose {res}:"
},
"panel.wizardSelectServer": {
  id: "Pilih server:",
  en: "Choose a server:"
},
"panel.custom": {
  id: "Custom",
  en: "Custom"
},
"panel.cancel": {
  id: "Batal",
  en: "Cancel"
},
"panel.cancelled": {
  id: "❌ Create panel dibatalkan.",
  en: "❌ Panel creation cancelled."
},
"panel.wizardBadValue": {
  id: "❌ Nilai tidak valid. Ketik ulang atau tekan tombol.",
  en: "❌ Invalid value. Type it again or tap a button."
},
"panel.wizardExpired": {
  id: "❌ Sesi create panel sudah habis.\nMulai lagi: <code>{cmd} nama|id</code>",
  en: "❌ Panel creation session expired.\nStart again: <code>{cmd} name|id</code>"
},
"panel.wizardCreating": {
  id: "⏳ Membuat panel...",
  en: "⏳ Creating the panel..."
},
"panel.customAsk": {
  id: "✏️ Ketik nilai <b>{res}</b> ({unit}) langsung di chat.\nContoh: <code>8</code>\n\nTulis <code>0</code> untuk unlimited.",
  en: "✏️ Type the <b>{res}</b> value ({unit}) right in the chat.\nExample: <code>8</code>\n\nType <code>0</code> for unlimited."
},
"panel.monthsOption": {
  id: "{n} Bulan",
  en: "{n} Month(s)"
},
"panel.badName": {
  id: "❌ Nama server tidak valid.",
  en: "❌ Invalid server name."
},
"panel.fail": {
  id: "❌ GAGAL — panel belum jadi\n<b>Alasan:</b> <code>{reason}</code>",
  en: "❌ FAILED — panel was not created\n<b>Reason:</b> <code>{reason}</code>"
},
"panel.eggFail": {
  id: "⚠️ Egg panel tidak valid. Cek <code>nestid</code>/<code>egg</code> di settings.js",
  en: "⚠️ Panel egg is invalid. Check <code>nestid</code>/<code>egg</code> in settings.js"
},
"panel.done": {
  id: "✅ <b>DONE!</b> {tag}\n\n<blockquote>👤 Username : <code>{username}</code>\n🖥️ Server : <code>{srv}</code>\n🆔 ID Server : <code>{id}</code></blockquote>\n📩 Cek Private Message, Please!",
  en: "✅ <b>DONE!</b> {tag}\n\n<blockquote>👤 Username : <code>{username}</code>\n🖥️ Server : <code>{srv}</code>\n🆔 Server ID : <code>{id}</code></blockquote>\n📩 Check Private Message, Please!"
},
"panel.doneDmFail": {
  id: "⚠️ <b>DONE!</b> {tag} — panel sudah dibuat, tapi Private Message GAGAL dikirim\n<b>Alasan:</b> <code>{reason}</code>\n\nKalau alasannya <i>chat not found</i>, berarti user BELUM pernah start bot.\nSuruh user chat bot dulu (kirim /start), atau kirim data ini manual:\nUsername: <code>{username}</code>\nPassword: <code>{password}</code>\nID Server: <code>{id}</code>",
  en: "⚠️ <b>DONE!</b> {tag} — the panel was created, but the Private Message FAILED to send\n<b>Reason:</b> <code>{reason}</code>\n\nIf the reason is <i>chat not found</i>, the user has never started the bot.\nAsk them to message the bot first (send /start), or send this manually:\nUsername: <code>{username}</code>\nPassword: <code>{password}</code>\nServer ID: <code>{id}</code>"
},
"panel.created": {
  id: `<b>🖥️ PANEL BERHASIL DIBUAT</b>

<b>👤 Username</b>
<code>{username}</code>

<b>🔐 Password</b>
<code>{password}</code>

<b>🌐 Login</b>
<a href='{domain}'>{loginText}</a>
────────────────────
<b>📦 Resource</b>
• RAM : <code>{ram}</code>
• Disk : <code>{disk}</code>
• CPU : <code>{cpu}</code>

<b>🆔 ID Server</b>
<code>{id}</code>
<b>⏳ Expired</b>
<code>{months} Bulan</code>
────────────────────
<b>⚠️ Rules Pembelian Panel</b>
• Simpan data ini baik-baik
• Seller hanya mengirim 1x
• Data hilang bukan tanggung jawab seller
• Garansi aktif 15 hari (2x replace)
• Claim wajib bawa bukti chat`,
  en: `<b>🖥️ PANEL CREATED SUCCESSFULLY</b>

<b>👤 Username</b>
<code>{username}</code>

<b>🔐 Password</b>
<code>{password}</code>

<b>🌐 Login</b>
<a href='{domain}'>{loginText}</a>
────────────────────
<b>📦 Resource</b>
• RAM : <code>{ram}</code>
• Disk : <code>{disk}</code>
• CPU : <code>{cpu}</code>

<b>🆔 Server ID</b>
<code>{id}</code>
<b>⏳ Expired</b>
<code>{months} Month(s)</code>
────────────────────
<b>⚠️ Panel Purchase Rules</b>
• Keep this data safe
• The seller only sends it once
• Lost data is not the seller's responsibility
• Warranty is valid for 15 days (2x replace)
• Claims must include chat proof`
},
"panel.loginText": {
  id: "Klik Login Panel",
  en: "Click to Login"
},
"panel.allHeader": {
  id: "📊 SEMUA PANEL",
  en: "📊 ALL PANELS"
},
"panel.serverHeader": {
  id: "SERVER {name}",
  en: "SERVER {name}"
},
"panel.allItem": {
  id: "ID {id} | {name} | RAM {ram} | CPU {cpu}%",
  en: "ID {id} | {name} | RAM {ram} | CPU {cpu}%"
},
"panel.empty": {
  id: "📭 Panel kosong",
  en: "📭 No panels"
},
"panel.yourHeader": {
  id: "PANEL KAMU",
  en: "YOUR PANELS"
},
"panel.yourItem": {
  id: "ID {id} | SERVER {srv}",
  en: "ID {id} | SERVER {srv}"
},
"panel.delFormat": {
  id: "format: {prefix}delpanel id|server",
  en: "format: {prefix}delpanel id|server"
},
"panel.deleteChooseServer": {
  id: "<b>🗑️ DELETE PANEL</b>\n\nPilih server tempat panel berada:",
  en: "<b>🗑️ DELETE PANEL</b>\n\nChoose the server where the panel is located:"
},
"panel.deleteSearchPrompt": {
  id: "<b>🗑️ DELETE PANEL</b>\n\nServer: <code>{server}</code>\n\nTekan <b>Search ID</b> untuk mencari ID panel yang akan dihapus.",
  en: "<b>🗑️ DELETE PANEL</b>\n\nServer: <code>{server}</code>\n\nPress <b>Search ID</b> to find the panel ID to delete."
},
"panel.deleteIdPrompt": {
  id: "<b>🔎 SEARCH ID</b>\n\nKetik ID panel yang ingin dihapus dari server <code>{server}</code>.",
  en: "<b>🔎 SEARCH ID</b>\n\nType the panel ID to delete from server <code>{server}</code>."
},
"panel.deleted": {
  id: "✅ Panel {id} di server {srv} dihapus",
  en: "✅ Panel {id} on server {srv} deleted"
},
"panel.notYours": {
  id: "⛔ Panel itu bukan milikmu",
  en: "⛔ That panel is not yours"
},

/* ================= ADMIN ================= */

"admin.usage": {
  id: "format: {prefix}cadmin user|id/tag/me|server",
  en: "format: {prefix}cadmin user|id/tag/me|server"
},
"admin.askStart": {
  id: "<b>👑 CREATE ADMIN PANEL</b>\n\nKetik username admin + target:\n<code>nama|id</code> — contoh <code>rafzadmin|me</code>\n\nTarget bisa <code>id</code>, <code>@username</code>, reply pesan, atau <code>me</code>.\n\nMode cepat: <code>{prefix}cadmin nama|id|server</code>",
  en: "<b>👑 CREATE ADMIN PANEL</b>\n\nType the admin username + target:\n<code>name|id</code> — example <code>rafzadmin|me</code>\n\nTarget can be <code>id</code>, <code>@username</code>, a replied message, or <code>me</code>.\n\nQuick mode: <code>{prefix}cadmin name|id|server</code>"
},
"admin.startBtn": {
  id: "➕ Buat Admin",
  en: "➕ Create Admin"
},
"admin.startPrompt": {
  id: "<b>👑 CREATE ADMIN PANEL</b>\n\nTekan tombol di bawah buat mulai.\n\nMode cepat: <code>{prefix}cadmin nama|id|server</code>",
  en: "<b>👑 CREATE ADMIN PANEL</b>\n\nTap the button below to start.\n\nQuick mode: <code>{prefix}cadmin name|id|server</code>"
},
"admin.created": {
  id: `<b>👑 ADMIN PANEL BERHASIL DIBUAT</b>

<b>👤 Username</b>
<code>{username}</code>

<b>🔐 Password</b>
<code>{password}</code>

<b>🆔 ID Admin</b>
<code>{id}</code>

<b>🌐 Login</b>
<code>{domain}</code>

━━━━━━━━━━━━━━━
<b>⚠️ Rules Admin Panel</b>
• Jangan menyalahgunakan akses
• Jangan ubah data seller lain
• Dilarang membuat panel sembarangan
• Garansi 10 hari
• Abuse = auto delete`,
  en: `<b>👑 ADMIN PANEL CREATED SUCCESSFULLY</b>

<b>👤 Username</b>
<code>{username}</code>

<b>🔐 Password</b>
<code>{password}</code>

<b>🆔 Admin ID</b>
<code>{id}</code>

<b>🌐 Login</b>
<code>{domain}</code>

━━━━━━━━━━━━━━━
<b>⚠️ Admin Panel Rules</b>
• Do not abuse your access
• Do not modify other sellers' data
• Do not create panels carelessly
• 10 day warranty
• Abuse = auto delete`
},
"admin.globalHeader": {
  id: "ADMIN GLOBAL",
  en: "GLOBAL ADMINS"
},
"admin.item": {
  id: "ID {id} | {username}",
  en: "ID {id} | {username}"
},
"admin.empty": {
  id: "kosong",
  en: "empty"
},
"admin.yourHeader": {
  id: "ADMIN LU:",
  en: "YOUR ADMINS:"
},
"admin.pickServer": {
  id: "<b>👑 CREATE ADMIN PANEL</b>\n\nUsername: <code>{name}</code>\n\nPilih server:",
  en: "<b>👑 CREATE ADMIN PANEL</b>\n\nUsername: <code>{name}</code>\n\nChoose a server:"
},
"admin.delId": {
  id: "id?",
  en: "id?"
},
"admin.delNotFound": {
  id: "🔎 Admin ID tidak ditemukan",
  en: "🔎 Admin ID not found"
},
"admin.deleted": {
  id: "✅ Admin dihapus",
  en: "✅ Admin deleted"
},
"admin.fail": {
  id: "❌ GAGAL — admin panel belum jadi\n<b>Alasan:</b> <code>{reason}</code>",
  en: "❌ FAILED — admin panel was not created\n<b>Reason:</b> <code>{reason}</code>"
},
"admin.done": {
  id: "✅ <b>DONE!</b> {tag}\n\n<blockquote>👤 Username : <code>{username}</code>\n🖥️ Server : <code>{srv}</code>\n🆔 ID Admin : <code>{id}</code></blockquote>\n📩 Cek Private Message, Please!",
  en: "✅ <b>DONE!</b> {tag}\n\n<blockquote>👤 Username : <code>{username}</code>\n🖥️ Server : <code>{srv}</code>\n🆔 Admin ID : <code>{id}</code></blockquote>\n📩 Check Private Message, Please!"
},
"admin.doneExisting": {
  id: "ℹ️ User panel ini sudah ada sebelumnya, password lamanya tetap dipakai.",
  en: "ℹ️ This panel user already existed, the old password still applies."
},
"admin.doneDmFail": {
  id: "⚠️ <b>DONE!</b> {tag} — admin sudah dibuat, tapi Private Message GAGAL dikirim\n<b>Alasan:</b> <code>{reason}</code>\n\nKalau alasannya <i>chat not found</i>, berarti user BELUM pernah start bot.\nSuruh user chat bot dulu (kirim /start), atau kirim manual:\nUsername: <code>{username}</code>\n{passinfo}\nID Admin: <code>{id}</code>",
  en: "⚠️ <b>DONE!</b> {tag} — the admin was created, but the Private Message FAILED to send\n<b>Reason:</b> <code>{reason}</code>\n\nIf the reason is <i>chat not found</i>, the user has never started the bot.\nAsk them to message the bot first (send /start), or send it manually:\nUsername: <code>{username}</code>\n{passinfo}\nAdmin ID: <code>{id}</code>"
},
"admin.passLine": {
  id: "Password: <code>{password}</code>",
  en: "Password: <code>{password}</code>"
},
"admin.existingPass": {
  id: "gunakan password panel yang lama",
  en: "use the existing panel password"
},

/* ================= SELLER / SUPERSELLER / OWNER ================= */

"seller.usage": {
  id: "Format: {prefix}addseller id / @username / reply pesan user",
  en: "Format: {prefix}addseller id / @username / reply to the user's message"
},
"super.usage": {
  id: "Format: {prefix}addsuper id / @username / reply pesan user",
  en: "Format: {prefix}addsuper id / @username / reply to the user's message"
},
"pv.addUsage": {
  id: "Format: {prefix}addpv id / @username / reply pesan user",
  en: "Format: {prefix}addpv id / @username / reply to the user's message"
},

"seller.already": {
  id: "udah seller",
  en: "already a seller"
},
"seller.added": {
  id: "seller ditambah\nID: {id}",
  en: "seller added\nID: {id}"
},
"seller.empty": {
  id: "seller kosong",
  en: "no sellers"
},
"seller.header": {
  id: "<b>LIST SELLER</b>",
  en: "<b>SELLER LIST</b>"
},
"seller.notSeller": {
  id: "🔎 ID tidak terdaftar sebagai seller",
  en: "🔎 ID is not registered as a seller"
},
"seller.removed": {
  id: "✅ Seller dihapus",
  en: "✅ Seller removed"
},

"super.already": {
  id: "udah superseller",
  en: "already a superseller"
},
"super.added": {
  id: "superseller ditambah\nID: {id}",
  en: "superseller added\nID: {id}"
},
"super.empty": {
  id: "superseller kosong",
  en: "no supersellers"
},
"super.header": {
  id: "<b>LIST SUPERSELLER</b>",
  en: "<b>SUPERSELLER LIST</b>"
},
"super.notSuper": {
  id: "🔎 ID tidak terdaftar sebagai superseller",
  en: "🔎 ID is not registered as a superseller"
},
"super.removed": {
  id: "✅ Superseller dihapus",
  en: "✅ Superseller removed"
},

"owner.already": {
  id: "udah owner",
  en: "already an owner"
},
"owner.added": {
  id: "owner ditambah\nID: {id}",
  en: "owner added\nID: {id}"
},
"owner.header": {
  id: "<b>OWNER LIST</b>",
  en: "<b>OWNER LIST</b>"
},
"owner.main": {
  id: "Owner Utama:",
  en: "Main Owner:"
},
"owner.extra": {
  id: "Owner Tambahan:",
  en: "Extra Owners:"
},
"owner.usage": {
  id: "Format: {prefix}addowner id / @username / reply pesan user",
  en: "Format: {prefix}addowner id / @username / reply to the user's message"
},

"confirm.title": {
  id: "⚠️ KONFIRMASI",
  en: "⚠️ CONFIRMATION"
},
"confirm.askOwner": {
  id: "Yakin mau menambahkan user ini sebagai Owner?",
  en: "Are you sure you want to add this user as an Owner?"
},
"confirm.askSeller": {
  id: "Yakin mau menambahkan user ini sebagai Seller?",
  en: "Are you sure you want to add this user as a Seller?"
},
"confirm.askSuper": {
  id: "Yakin mau menambahkan user ini sebagai SuperSeller?",
  en: "Are you sure you want to add this user as a SuperSeller?"
},
"confirm.askPv": {
  id: "Yakin mau memberi user ini akses Server V3 Privat?",
  en: "Are you sure you want to give this user Private V3 Server access?"
},
"confirm.name": {
  id: "Nama",
  en: "Name"
},
"confirm.username": {
  id: "Username / Tag",
  en: "Username / Tag"
},
"confirm.id": {
  id: "ID Telegram",
  en: "Telegram ID"
},
"confirm.none": {
  id: "tidak ada",
  en: "none"
},
"confirm.yes": {
  id: "✅ Ya, lanjutkan",
  en: "✅ Yes, continue"
},
"confirm.no": {
  id: "❌ Tidak, batal",
  en: "❌ No, cancel"
},
"confirm.cancelled": {
  id: "❌ Dibatalkan.",
  en: "❌ Cancelled."
},
"confirm.expired": {
  id: "❌ Tidak ada konfirmasi yang aktif. Jalankan ulang command-nya.",
  en: "❌ No active confirmation. Run the command again."
},

"owner.notExtra": {
  id: "🔎 ID bukan owner tambahan",
  en: "🔎 ID is not an extra owner"
},
"owner.removed": {
  id: "✅ Owner dihapus",
  en: "✅ Owner removed"
},

/* ================= DOMAIN ================= */

"domain.usageAdd": {
  id: "sub|ip|on/off|domain",
  en: "sub|ip|on/off|domain"
},
"domain.usagePanel": {
  id: "nama|ip|domain",
  en: "name|ip|domain"
},
"domain.usageList": {
  id: "domain",
  en: "domain"
},
"domain.usageDel": {
  id: "host|domain",
  en: "host|domain"
},
"domain.notAvailable": {
  id: "domain tidak tersedia\n",
  en: "domain not available\n"
},
"domain.exists": {
  id: "subdomain sudah ada",
  en: "subdomain already exists"
},
"domain.created": {
  id: `<b>🌐 SUBDOMAIN CREATED</b>

🌍 Host
<code>{host}</code>

🧭 IP Address
<code>{ip}</code>

🛡 Proxy
<code>{proxy}</code>

📊 Status
<code>{status}</code>`,
  en: `<b>🌐 SUBDOMAIN CREATED</b>

🌍 Host
<code>{host}</code>

🧭 IP Address
<code>{ip}</code>

🛡 Proxy
<code>{proxy}</code>

📊 Status
<code>{status}</code>`
},
"domain.proxyOn": {
  id: "ON 🟠",
  en: "ON 🟠"
},
"domain.proxyOff": {
  id: "OFF ⚪",
  en: "OFF ⚪"
},
"domain.statusActive": {
  id: "Active",
  en: "Active"
},
"domain.statusRemoved": {
  id: "Removed",
  en: "Removed"
},
"domain.panelCreated": {
  id: `<b>🖥️ PANEL DOMAIN READY</b>

🌐 Panel
<code>{panel}</code> (Proxy OFF)

📡 Node
<code>{node}</code> (Proxy OFF)

🧭 VPS IP
<code>{ip}</code>

📊 Status
<code>{status}</code>`,
  en: `<b>🖥️ PANEL DOMAIN READY</b>

🌐 Panel
<code>{panel}</code> (Proxy OFF)

📡 Node
<code>{node}</code> (Proxy OFF)

🧭 VPS IP
<code>{ip}</code>

📊 Status
<code>{status}</code>`
},
"domain.deployReady": {
  id: "Deploy Ready",
  en: "Deploy Ready"
},
"domain.listHeader": {
  id: "<b>📜 LIST SUBDOMAIN</b>",
  en: "<b>📜 SUBDOMAIN LIST</b>"
},
"domain.listEmpty": {
  id: "<i>Kosong</i>",
  en: "<i>Empty</i>"
},
"domain.delNotFound": {
  id: "subdomain tidak ditemukan",
  en: "subdomain not found"
},
"domain.deleted": {
  id: `<b>🗑️ SUBDOMAIN DELETED</b>

🌍 Host
<code>{host}</code>

📊 Status
<code>{status}</code>`,
  en: `<b>🗑️ SUBDOMAIN DELETED</b>

🌍 Host
<code>{host}</code>

📊 Status
<code>{status}</code>`
},

/* ================= BLCLEAN ================= */

"blclean.usage": {
  id: `format:
{prefix}blclean bl|id|server
{prefix}blclean unbl|id|server

contoh:
{prefix}blclean bl|15|1
{prefix}blclean unbl|15|1`,
  en: `format:
{prefix}blclean bl|id|server
{prefix}blclean unbl|id|server

example:
{prefix}blclean bl|15|1
{prefix}blclean unbl|15|1`
},
"blclean.badOption": {
  id: "option hanya bl / unbl",
  en: "option must be bl / unbl"
},
"blclean.badId": {
  id: "id panel tidak valid",
  en: "invalid panel id"
},
"blclean.serverMissing": {
  id: "server tidak ditemukan",
  en: "server not found"
},
"blclean.exists": {
  id: "panel {id} sudah blacklist",
  en: "panel {id} is already blacklisted"
},
"blclean.added": {
  id: "berhasil blacklist panel\n\nid: {id}\nserver: {srv}",
  en: "panel blacklisted successfully\n\nid: {id}\nserver: {srv}"
},
"blclean.missing": {
  id: "panel {id} tidak ada di blacklist",
  en: "panel {id} is not in the blacklist"
},
"blclean.removed": {
  id: "berhasil hapus blacklist\n\nid: {id}\nserver: {srv}",
  en: "blacklist removed successfully\n\nid: {id}\nserver: {srv}"
},

/* ================= CLEANPANEL ================= */

"cleanpanel.usage": {
  id: `format:
{prefix}cleanpanel 1
{prefix}cleanpanel 2
{prefix}cleanpanel 3
{prefix}cleanpanel 123
{prefix}cleanpanel 123|1

mode:
1 = hapus user tanpa server
2 = hapus server disk kosong
3 = stop semua server aktif

server:
|1
|2
|own
dll`,
  en: `format:
{prefix}cleanpanel 1
{prefix}cleanpanel 2
{prefix}cleanpanel 3
{prefix}cleanpanel 123
{prefix}cleanpanel 123|1

mode:
1 = delete users without servers
2 = delete servers with an empty disk
3 = stop all running servers

server:
|1
|2
|own
etc`
},
"cleanpanel.badMode": {
  id: "mode tidak valid",
  en: "invalid mode"
},
"cleanpanel.userDeleted": {
  id: "SERVER {srv}\nMODE 1\nUSER DIHAPUS: {n}",
  en: "SERVER {srv}\nMODE 1\nUSERS DELETED: {n}"
},
"cleanpanel.serverDeleted": {
  id: "SERVER {srv}\nMODE 2\nSERVER DIHAPUS: {n}",
  en: "SERVER {srv}\nMODE 2\nSERVERS DELETED: {n}"
},
"cleanpanel.serverStopped": {
  id: "SERVER {srv}\nMODE 3\nSERVER DIMATIKAN: {n}",
  en: "SERVER {srv}\nMODE 3\nSERVERS STOPPED: {n}"
},
"cleanpanel.serverError": {
  id: "SERVER {srv}\nERROR: {msg}",
  en: "SERVER {srv}\nERROR: {msg}"
},

/* ================= LANGUAGE ================= */

"lang.title": {
  id: "<b>🌐 PILIH BAHASA</b>\n\nBahasa aktif: {active}\n\nPilih bahasa di bawah:",
  en: "<b>🌐 CHOOSE LANGUAGE</b>\n\nActive language: {active}\n\nPick a language below:"
},
"lang.set": {
  id: "✅ Bahasa diubah ke {active}",
  en: "✅ Language changed to {active}"
},
"lang.unsupported": {
  id: "❌ Bahasa tidak didukung.\nTersedia: {list}\n\nPakai: {prefix}lang en",
  en: "❌ Unsupported language.\nAvailable: {list}\n\nUse: {prefix}lang en"
},
"lang.label": {
  id: "{flag} {name}",
  en: "{flag} {name}"
},

/* ================= MENU PLUGIN ================= */

"menu.tagline": {
  id: "Panel & Management Bot",
  en: "Panel & Management Bot"
},
"menu.userInfo": {
  id: "👤 INFORMASI USER",
  en: "👤 USER INFO"
},
"menu.name": {
  id: "Nama",
  en: "Name"
},
"menu.id": {
  id: "ID",
  en: "ID"
},
"menu.role": {
  id: "Role",
  en: "Role"
},
"menu.roleCreator": {
  id: "Owner Utama",
  en: "Main Owner"
},
"menu.roleOwner": {
  id: "Owner",
  en: "Owner"
},
"menu.roleSuper": {
  id: "SuperSeller",
  en: "SuperSeller"
},
"menu.roleSeller": {
  id: "Seller",
  en: "Seller"
},
"menu.roleUser": {
  id: "User",
  en: "User"
},
"menu.panelMenu": {
  id: "📦 MENU PANEL",
  en: "📦 PANEL MENU"
},
"menu.adminMenu": {
  id: "👑 ADMIN PANEL",
  en: "👑 PANEL ADMIN"
},
"menu.sellerMenu": {
  id: "🛒 SELLER",
  en: "🛒 SELLER"
},
"menu.ownerMenu": {
  id: "⚙️ OWNER",
  en: "⚙️ OWNER"
},
"menu.domainMenu": {
  id: "🌍 DOMAIN / SUBDOMAIN",
  en: "🌍 DOMAIN / SUBDOMAIN"
},
"menu.serverMenu": {
  id: "🖥️ SERVER SLOT",
  en: "🖥️ SERVER SLOTS"
},
"menu.pickServer": {
  id: "Pilih nomor server saat create panel",
  en: "Pick a server number when creating a panel"
},
"menu.noServer": {
  id: "Tidak ada server",
  en: "No servers"
},
"menu.activePrefix": {
  id: "Prefix Aktif :",
  en: "Active prefix :"
},
"menu.langMenu": {
  id: "🌐 BAHASA",
  en: "🌐 LANGUAGE"
},
"menu.langHint": {
  id: "Ganti bahasa bot",
  en: "Change the bot language"
},
"menu.superMenu": {
  id: "💎 SUPER SELLER",
  en: "💎 SUPER SELLER"
},
"menu.pvMenu": {
  id: "🔒 SERVER V3 PRIVAT",
  en: "🔒 PRIVATE V3 SERVER"
},
"menu.extraMenu": {
  id: "🛠️ LAINNYA",
  en: "🛠️ OTHERS"
},
"menu.buttonHint": {
  id: "tanpa argumen = muncul tombol",
  en: "no arguments = buttons appear"
},
"menu.chooseMenu": {
  id: "Pilih menu di bawah ini:",
  en: "Choose a menu below:"
},
"menu.btnHelp": {
  id: "❓ Bantuan",
  en: "❓ Help"
},
"menu.btnPanel": {
  id: "📦 Panel",
  en: "📦 Panel"
},
"menu.btnAdmin": {
  id: "👑 Admin",
  en: "👑 Admin"
},
"menu.btnOwner": {
  id: "⚙️ Owner",
  en: "⚙️ Owner"
},
"menu.btnSeller": {
  id: "🛒 Seller",
  en: "🛒 Seller"
},
"menu.btnSuper": {
  id: "💎 Super",
  en: "💎 Super"
},
"menu.btnPv": {
  id: "🔒 V3 Privat",
  en: "🔒 V3 Private"
},
"menu.btnDomain": {
  id: "🌐 Domain",
  en: "🌐 Domain"
},
"menu.btnLang": {
  id: "🌐 Bahasa",
  en: "🌐 Language"
},
"menu.btnListAdmin": {
  id: "👑 Daftar Admin",
  en: "👑 Admin List"
},
"menu.btnListSeller": {
  id: "🛒 Daftar Seller",
  en: "🛒 Seller List"
},
"menu.btnListOwner": {
  id: "⚙️ Daftar Owner",
  en: "⚙️ Owner List"
},
"menu.btnListPanel": {
  id: "🖥️ Daftar Panel",
  en: "🖥️ Panel List"
},
"menu.btnBack": {
  id: "⬅️ Kembali",
  en: "⬅️ Back"
},
"menu.listsHint": {
  id: "Tombol daftar = data asli dari panel / database.",
  en: "The list buttons show the real data from the panels / database."
},
"menu.btnServer": {
  id: "🖥️ Server",
  en: "🖥️ Server"
},
"menu.serverHint": {
  id: "Slot server yang kepakai waktu create panel / admin.",
  en: "The server slots used when creating a panel / admin."
},
"denied.buttonsRole": {
  id: "🚫 Kamu tidak bisa pakai tombol ini.\nHanya role yang punya akses.",
  en: "🚫 You cannot use these buttons.\nOnly Access Roles can."
},

/* ================= PLUGIN SAY ================= */

"say.noText": {
  id: "teks?",
  en: "text?"
},

/* ================= START / WELCOME ================= */

"start.tagline": {
  id: "Panel Manager • Tools • Hiburan",
  en: "Panel Manager • Tools • Fun"
},
"start.hello": {
  id: "Halo, {name}! 👋",
  en: "Hello, {name}! 👋"
},
"start.welcome": {
  id: "Selamat datang di {bot}",
  en: "Welcome to {bot}"
},
"start.useMenu": {
  id: "Ketik {prefix}menu untuk semua fitur, atau {prefix}allmenu untuk daftar lengkap.",
  en: "Type {prefix}menu for features, or {prefix}allmenu for the full list."
},

/* ================= MENU BARU ================= */

"menu.btnSticker": {
  id: "🎨 Sticker",
  en: "🎨 Sticker"
},
"menu.btnPremium": {
  id: "✨ Premium",
  en: "✨ Premium"
},
"menu.btnTools": {
  id: "🛠️ Tools",
  en: "🛠️ Tools"
},
"menu.btnFun": {
  id: "🎲 Fun",
  en: "🎲 Fun"
},
"menu.btnUtility": {
  id: "🧰 Utility",
  en: "🧰 Utility"
},
"menu.btnOwnerTools": {
  id: "⚙️ Owner Tools",
  en: "⚙️ Owner Tools"
},
"menu.btnMonitor": {
  id: "◈ Monitor",
  en: "◈ Monitor"
},
"menu.btnBackup": {
  id: "💾 Backup",
  en: "💾 Backup"
},
"menu.btnDownloader": {
  id: "📥 Downloader",
  en: "📥 Downloader"
},
"menu.btnMaker": {
  id: "🖨️ Maker",
  en: "🖨️ Maker"
},
"menu.btnFake": {
  id: "💸 Fake",
  en: "💸 Fake"
},
"menu.btnStalker": {
  id: "🕵️ Stalker",
  en: "🕵️ Stalker"
},
"menu.btnAudio": {
  id: "🎧 Audio",
  en: "🎧 Audio"
},
"menu.btnAnime": {
  id: "🌸 Anime",
  en: "🌸 Anime"
},
"menu.btnAI": {
  id: "🤖 AI",
  en: "🤖 AI"
},
"menu.btnGroup": {
  id: "👥 Group",
  en: "👥 Group"
},
"menu.btnHome": {
  id: "Home",
  en: "Home"
},
"menu.btnAllMenu": {
  id: "All Menu",
  en: "All Menu"
},
"menu.btnConverter": {
  id: "🔄 Convert",
  en: "🔄 Convert"
},
"menu.totalCmds": {
  id: "semua fitur per kategori",
  en: "all features by category"
},

/* ================= PAGER (handler.js) ================= */

"pager.expired": {
  id: "⚠️ Halaman kedaluwarsa — ketik ulang command-nya.",
  en: "⚠️ Page expired — run the command again."
},
"pager.internalError": {
  id: "⚠️ Terjadi error internal pada command. Silakan coba lagi.",
  en: "⚠️ An internal error occurred. Please try again."
},

/* ================= STICKER PACK ================= */

"sticker.making": {
  id: "⏳ Membuat stiker...",
  en: "⏳ Making sticker..."
},
"sticker.done": {
  id: "Stiker berhasil dibuat!",
  en: "Sticker created!"
},
"sticker.openPack": {
  id: "Buka pack stiker",
  en: "Open sticker pack"
},
"sticker.saveHint": {
  id: "Buka pack-nya lalu simpan stiker ke Favorit supaya muncul di saran stiker.",
  en: "Open the pack and save the sticker to Favorites so it appears in suggestions."
},
"sticker.tooLong": {
  id: "❌ Teks maksimal 200 karakter.",
  en: "❌ Max 200 characters."
},
"sticker.noBotUser": {
  id: "❌ Gagal mengambil username bot. Coba lagi.",
  en: "❌ Failed to get bot username. Try again."
},
"sticker.packCreated": {
  id: "Pack baru dibuat untuk kamu.",
  en: "A new pack was created for you."
},
"sticker.packAdded": {
  id: "Stiker ditambahkan ke pack kamu.",
  en: "Sticker added to your pack."
},
"sticker.packInfo": {
  id: "Info Pack Stiker",
  en: "Sticker Pack Info"
},
"sticker.packCount": {
  id: "Jumlah stiker",
  en: "Sticker count"
},
"sticker.packEmpty": {
  id: "📦 Kamu belum punya pack stiker.\nBuat dulu dengan /bratpack atau /sticker.",
  en: "📦 You don't have a sticker pack yet.\nCreate one with /bratpack or /sticker."
},

/* ================= UTILITY / FUN ================= */

"util.loading": {
  id: "⏳ Memproses...",
  en: "⏳ Processing..."
},
"util.badExpr": {
  id: "Ekspresi matematika tidak valid.",
  en: "Invalid math expression."
},
"util.notFound": {
  id: "Data tidak ditemukan.",
  en: "Data not found."
},
"util.passHint": {
  id: "Jangan bagikan password ini ke siapa pun.",
  en: "Don't share this password with anyone."
},

/* ================= PERSAMAAN UI (dipakai semua plugin) ================= */

"use.usage": {
  id: "⚠️ Penggunaan:",
  en: "⚠️ Usage:"
},
"use.example": {
  id: "Contoh:",
  en: "Example:"
},
"use.replyMedia": {
  id: "Reply/kirim media dengan",
  en: "Reply to / send media with"
},
"use.making": {
  id: "⏳ Membuat...",
  en: "⏳ Creating..."
},
"use.processing": {
  id: "⏳ Memproses...",
  en: "⏳ Processing..."
},
"use.failed": {
  id: "❌ Gagal:",
  en: "❌ Failed:"
},
"use.notFound": {
  id: "❌ Tidak ditemukan",
  en: "❌ Not found"
},
"use.textHint": {
  id: "teks kamu",
  en: "your text"
},
"sticker.animatedNo": {
  id: "❌ Stiker animasi (.tgs) tidak bisa ditambahkan ke pack. Gunakan foto atau video stiker.",
  en: "❌ Animated (.tgs) stickers can't be added to a pack. Use a photo or video sticker instead."
},

/* ================= STICKER / QC / SMEME / STYLE / FX ================= */

"sticker.usage": {
  id: "• Reply foto/stiker dengan {cmd}\n• Kirim foto dengan caption {cmd}",
  en: "• Reply to a photo/sticker with {cmd}\n• Send a photo captioned {cmd}"
},
"sticker.fail": {
  id: "Gagal buat stiker",
  en: "Failed to create sticker"
},
"sticker.packFail": {
  id: "Pack gagal",
  en: "Pack failed"
},
"sticker.asSticker": {
  id: "Stiker terkirim (sebagai stiker biasa).",
  en: "Sticker sent (as a regular sticker)."
},
"qc.usage": {
  id: "teks kamu | Nama (atau reply pesan)",
  en: "your text | Name (or reply a message)"
},
"qc.making": {
  id: "Membuat quote chat...",
  en: "Making quote chat..."
},
"qc.fail": {
  id: "Gagal membuat qc",
  en: "Failed to make qc"
},
"smeme.usage": {
  id: "teks-atas , teks-bawah (reply foto)",
  en: "top-text , bottom-text (reply a photo)"
},
"smeme.making": {
  id: "Membuat meme...",
  en: "Making meme..."
},
"smeme.fail": {
  id: "Gagal membuat meme",
  en: "Failed to make meme"
},
"style.usage": {
  id: "teks (atau: nomor-gaya + teks)",
  en: "text (or: style-number + text)"
},
"style.title": {
  id: "STYLE TEXT — {n} gaya",
  en: "STYLE TEXT — {n} styles"
},
"style.hint": {
  id: "Pakai nomor: {cmd} 3 teks",
  en: "Use a number: {cmd} 3 text"
},
"fx.usage": {
  id: "Reply audio/voice/video dengan {cmd}",
  en: "Reply to an audio/voice/video with {cmd}"
},
"fx.processing": {
  id: "Memproses audio...",
  en: "Processing audio..."
},
"fx.list": {
  id: "Efek:",
  en: "Effects:"
},

/* ================= QUIZ / GAMES ================= */

"quiz.question": {
  id: "Pertanyaan:",
  en: "Question:"
},
"quiz.answer": {
  id: "Jawaban:",
  en: "Answer:"
},
"quiz.correct": {
  id: "BENAR! Jawabannya:",
  en: "CORRECT! The answer is:"
},
"quiz.wrong": {
  id: "Salah! Coba lagi.",
  en: "Wrong! Try again."
},
"quiz.noGame": {
  id: "Tidak ada game aktif. Ketik",
  en: "No active game. Type"
},
"quiz.startHint": {
  id: "Jawab langsung di chat!",
  en: "Answer right in the chat!"
},
"quiz.skipAnswer": {
  id: "Kuis di-skip. Jawabannya:",
  en: "Quiz skipped. The answer is:"
},
"quiz.tries": {
  id: "Sisa kesempatan",
  en: "tries left"
},
"quiz.tooSmall": {
  id: "Terlalu kecil!",
  en: "Too small!"
},
"quiz.tooBig": {
  id: "Terlalu besar!",
  en: "Too big!"
},

/* ================= GETPP / BATAL / SETCOMMANDS ================= */

"pp.taking": {
  id: "Mengambil foto profil...",
  en: "Fetching profile photo..."
},
"pp.none": {
  id: "User ini tidak punya foto profil (atau belum pernah /start bot).",
  en: "This user has no profile photo (or never /started the bot)."
},
"pp.fail": {
  id: "Gagal:",
  en: "Failed:"
},
"pp.caption": {
  id: "Foto profil:",
  en: "Profile photo:"
},
"batal.none": {
  id: "✅ Tidak ada sesi aktif. Semua bersih!",
  en: "✅ No active sessions. All clear!"
},
"batal.title": {
  id: "🧹 SEMUA SESI DIBERSIHKAN",
  en: "🧹 ALL SESSIONS CLEARED"
},
"batal.sessions": {
  id: "🗑️ Sesi:",
  en: "🗑️ Sessions:"
},
"batal.pager": {
  id: "📄 Pesan pager dilepas:",
  en: "📄 Pager messages removed:"
},
"batal.done": {
  id: "✅ Sekarang ketik command apa pun dengan normal.",
  en: "✅ You can now type any command normally."
},
"cmdlist.ok": {
  id: "{n} command terdaftar ke menu Telegram (garis 3).\n\nTutup chat bot lalu buka lagi, atau tap ikon menu untuk melihatnya.",
  en: "{n} commands registered to the Telegram menu (3-line icon).\n\nClose and reopen the bot chat, or tap the menu icon to see them."
},
"cmdlist.registering": {
  id: "Mendaftarkan command list ke Telegram...",
  en: "Registering the command list to Telegram..."
},

/* ================= FUN CONTENT (EN) ================= */

"fun.8ballList": {
  id: "🔮 Pasti banget!|🔮 Sepertinya iya.|🔮 Ya, tapi nanti.|🔮 Kagak tau, tanya bapakmu.|🔮 Jangan harap banget.|🔮 Menurutku nggak.|🔮 Masa depanmu cerah!|🔮 Coba lagi nanti.|🔮 Fokus dulu, baru berdoa.|🔮 100% iya!",
  en: "🔮 Definitely!|🔮 Probably yes.|🔮 Yes, but later.|🔮 No idea, ask your dad.|🔮 Don't count on it.|🔮 I'd say no.|🔮 Your future is bright!|🔮 Try again later.|🔮 Focus first, then pray.|🔮 100% yes!"
},
"fun.cocokDesc": {
  id: "Menikah tahun depan! 🎉|Cocok banget, jalan terus! 💕|Lumayan, saling pengertian ya 🌱|Hmm, mungkin cuma teman 🥲",
  en: "Married next year! 🎉|Great match, keep going! 💕|Not bad, keep understanding each other 🌱|Hmm, maybe just friends 🥲"
},
"fun.bucinList": {
  id: "Aku nggak sedang bucin, aku cuma setia menunggu yang tak pasti.|Cintaku padamu seperti WiFi, kuat kalau dekat, hilang kalau jauh.|Setiap lihat notifikasi, hatiku berharap namamu yang muncul.|Kamu tahu nggak? Senja saja iri melihat senyummu.|Aku bisa lupa charger, tapi nggak bisa lupa kamu.|Katanya jodoh tak akan tertukar, tapi kok chatku nggak dibalas-balas?|Bukan maksudku bucin, tapi kalau kamu minta bulan, aku cari tangga.|Hujan turun, hati pun berhujan, karena kamu jauh.|Kalau kamu hujan, aku mau jadi tanah, biar selalu bersama.",
  en: "I'm not being clingy, I'm just loyal to something uncertain.|My love for you is like WiFi: strong when close, gone when far.|Every notification makes my heart hope it's your name.|You know what? Even the sunset envies your smile.|I can forget my charger, but I can't forget you.|They say soulmates aren't swapped — so why aren't my texts answered?|Not trying to be cheesy, but if you asked for the moon, I'd find a ladder.|Rain falls, my heart rains with it, because you're far away.|If you were the rain, I'd be the soil, so we'd always be together."
},
"fun.quoteList": {
  id: "Hidup itu bukan soal menunggu badai berlalu, tapi belajar menari di bawah hujan.|Sukses adalah jumlah usaha kecil yang dilakukan berulang setiap hari.|Jangan takut lambat, takutlah kalau kamu berhenti.|Yang penting bukan seberapa sering jatuh, tapi seberapa sering bangun.|Perubahan dimulai dari keputusan, bukan dari besok.|Lakukan yang bisa kamu lakukan hari ini, dengan semua yang kamu punya.|Kegagalan adalah bumbu yang memberi rasa pada kesuksesan.|Bermimpilah setinggi langit, jika jatuh, jatuhlah di antara bintang.",
  en: "Life isn't about waiting for the storm to pass, but learning to dance in the rain.|Success is the sum of small efforts repeated daily.|Don't fear going slow, fear standing still.|What matters isn't how often you fall, but how often you rise.|Change starts with a decision, not tomorrow.|Do what you can today, with all you have.|Failure is the spice that gives success its flavor.|Dream as high as the sky — if you fall, you'll fall among the stars."
},
"fun.loveDesc": {
  id: "Menikah tahun depan! 🎉|Cocok banget, jalan terus! 💕|Lumayan, saling pengertian ya 🌱|Hmm, mungkin cuma teman 🥲",
  en: "Married next year! 🎉|Great match, keep going! 💕|Not bad, keep understanding each other 🌱|Hmm, maybe just friends 🥲"
},

/* ================= FUN: pertanyaan & label ================= */

"fun.question": {
  id: "Pertanyaan:",
  en: "Question:"
},
"fun.q8ball": {
  id: "apakah aku akan kaya?",
  en: "will I be rich?"
},
"fun.dice": {
  id: "Dadu",
  en: "Dice"
},
"fun.youGot": {
  id: "Kamu dapat",
  en: "You got"
},
"fun.heads": {
  id: "🪙 GAMBAR",
  en: "🪙 HEADS"
},
"fun.tails": {
  id: "🪙 ANGKA",
  en: "🪙 TAILS"
},
"fun.coinToss": {
  id: "Lempar koin...",
  en: "Flipping coin..."
},
"fun.result": {
  id: "Hasil",
  en: "Result"
},
"fun.qRate": {
  id: "kecantikanmu",
  en: "your beauty"
},
"fun.rating": {
  id: "Rating",
  en: "Rating"
},
"fun.match": {
  id: "Kecocokan",
  en: "Match"
},
"fun.qPick": {
  id: "nasi, mie, roti",
  en: "rice, noodles, bread"
},
"fun.iPick": {
  id: "Aku pilih",
  en: "I choose"
},
"fun.roll": {
  id: "Roll",
  en: "Roll"
},
"fun.reversed": {
  id: "Terbalik",
  en: "Reversed"
},
"fun.wpickHint": {
  id: "tag minimal 2 orang:",
  en: "tag at least 2 people:"
},
"fun.chosenOne": {
  id: "Yang terpilih",
  en: "The chosen one"
},

/* ================= FUN2 ================= */

"fun2.tarot": {
  id: "ARTI TAROT",
  en: "TAROT READING"
},
"fun2.card": {
  id: "Kartu",
  en: "Card"
},
"fun2.justFun": {
  id: "Untuk hiburan saja.",
  en: "For entertainment only."
},
"fun2.facts": {
  id: "FAKTA UNIK",
  en: "FUN FACT"
},
"fun2.poem": {
  id: "PUISI",
  en: "POEM"
},
"fun2.shortStory": {
  id: "CERITA PENDEK",
  en: "SHORT STORY"
},
"fun2.kepoMeter": {
  id: "KEPO METER",
  en: "NOSY METER"
},
"fun2.kepoLevel": {
  id: "Tingkat kepoan kamu hari ini",
  en: "Your nosiness level today"
},
"fun2.fortune": {
  id: "ARAH REZEKI",
  en: "FORTUNE DIRECTION"
},
"fun2.tarotMeanings": {
  id: "Awal baru, petualangan, keberanian mengambil risiko.|Kekuatan, kreativitas, dan kemampuan mewujudkan keinginan.|Harmoni, pilihan hati, dan hubungan yang mendalam.|Perubahan besar, jangan takut pada keruntuhan yang membebaskan.|Harapan, penyembuhan, dan keyakinan pada masa depan.|Kesuksesan, kebahagiaan, dan energi positif mengelilingimu.|Intuisi, misteri, dan perasaan yang perlu didengarkan.|Akhir satu babak, awal kehidupan baru yang lebih baik.|Kemakmuran, kesuburan ide, dan kasih sayang.|Keberuntungan berputar — bersiaplah untuk perubahan tak terduga.",
  en: "New beginnings, adventure, courage to take risks.|Power, creativity, and the ability to manifest desires.|Harmony, choices of the heart, and deep relationships.|Great change — don't fear the collapse that sets you free.|Hope, healing, and faith in the future.|Success, happiness, and positive energy around you.|Intuition, mystery, and feelings that need to be heard.|The end of one chapter, the start of a better new life.|Abundance, fertile ideas, and affection.|Luck is turning — get ready for unexpected change."
},
"fun2.factList": {
  id: "Gurita punya 3 jantung dan darah berwarna biru.|Madu tidak pernah basi — madu 3000 tahun masih bisa dimakan.|Hiu sudah ada sebelum pohon muncul di bumi.|Semut tidak punya paru-paru, mereka bernapas lewat lubang kecil di tubuh.|Bulan menjauh dari Bumi sekitar 3,8 cm per tahun.|Pisang termasuk buah beri secara botani, tapi stroberi bukan.|Telinga dan hidung terus tumbuh sepanjang hidup manusia.|Satu hari di planet Venus lebih lama daripada satu tahunnya.",
  en: "Octopuses have 3 hearts and blue blood.|Honey never spoils — 3000-year-old honey is still edible.|Sharks existed before trees appeared on Earth.|Ants have no lungs; they breathe through tiny holes in their bodies.|The Moon drifts away from Earth about 3.8 cm per year.|Bananas are botanically berries, but strawberries are not.|Ears and noses keep growing throughout a human's life.|One day on Venus is longer than its year."
},
"fun2.poemList": {
  id: "Di antara senja yang merona,\naku menitipkan rasa pada angin,\nmoga sampai ke hatimu yang jauh,\ntanpa harus berkata apa-apa.||Hujan turun di kota kecil ini,\nmembasahi jalan dan atap seng,\nseperti rindu yang tak bisa dibendung,\nmengalir diam-diam.||Bintang-bintang tak pernah bersuara,\ntapi malam tetap penuh makna,\nseperti aku yang diam,\ntapi penuh cerita tentangmu.",
  en: "Among the glowing dusk,\nI entrust my feelings to the wind,\nhoping they reach your distant heart,\nwithout saying a word.||Rain falls in this small town,\nwetting the roads and tin roofs,\nlike a longing that cannot be dammed,\nflowing quietly.||The stars never speak,\nyet the night is full of meaning,\nlike me — silent,\nbut full of stories about you."
},
"fun2.wiseList": {
  id: "Hidup itu 10% apa yang terjadi padamu, 90% bagaimana kamu meresponsnya.|Jangan bandingkan awalmu dengan milik orang lain di tengah jalan.|Kegagalan bukan lawan dari sukses, tapi bagian dari prosesnya.|Yang penting bukan seberapa cepat, tapi tetap melangkah maju.|Kebaikan kecil yang dilakukan terus-menerus mengubah segalanya.",
  en: "Life is 10% what happens to you, 90% how you respond.|Don't compare your beginning to someone else's middle.|Failure isn't the opposite of success — it's part of the process.|It doesn't matter how fast you go, as long as you keep moving forward.|Small good deeds, done consistently, change everything."
},
"fun2.flirtList": {
  id: "Kamu tahu nggak kenapa matahari terbit pagi? Karena pengen lihat senyummu.|Kalau kamu saye, aku saye. Kalau kamu mesin cuci, aku deterjen.|Jarak terdekat itu bukan garis lurus, tapi dari kamu ke hatiku.|Kamu bukan Google, tapi kamu jawaban dari semua pertanyaanku.|Aku bukan tukang parkir, tapi hatiku udah lama nungguin kamu.|Pulau terpencil aja masih ditemuin, masa cintaku ke kamu nggak?",
  en: "Know why the sun rises every morning? It wants to see your smile.|If you're mine, I'm yours. If you're a washing machine, I'm the detergent.|The shortest distance isn't a straight line — it's from you to my heart.|You're not Google, but you're the answer to all my questions.|I'm not a parking attendant, but my heart has waited for you so long.|Even remote islands get found — how could my love for you not?"
},
"fun2.motivationList": {
  id: "Mulailah dengan yang kecil, tapi mulailah HARI INI.|Disiplin mengalahkan motivasi saat motivasi hilang.|Kamu tidak harus jadi yang terbaik, cukup lebih baik dari kemarin.|Jalan pintas tidak ada, tapi jalan yang benar selalu ada.|Jangan tunggu kesempatan, ciptakan!",
  en: "Start small, but start TODAY.|Discipline beats motivation when motivation runs out.|You don't have to be the best — just better than yesterday.|There are no shortcuts, but the right path is always there.|Don't wait for opportunity — create it!"
},
"fun2.storyList": {
  id: "Seorang pemuda menemukan lampu tua di pasar malam. Saat diseka, isinya bukan jin, tapi selembar surat dari dirinya 10 tahun yang lalu: 'Jangan takut gagal, aku sudah membuktikan kamu berhasil.'||Kucing hitam itu setiap malam duduk di depan toko roti. Pemilik toko akhirnya mengikutinya, dan menemukan kucing itu menunggui kucing tua buta yang tak bisa lagi mencari makan sendiri.||Ada bintang yang jatuh setiap kali seseorang menyerah. Tapi yang jarang diketahui: setiap kali seseorang mencoba lagi, satu bintang baru menyala.",
  en: "A young man found an old lamp at a night market. When wiped, out came no genie — just a letter from himself 10 years ago: 'Don't fear failure; I've proven you'll make it.'||Every night a black cat sat in front of a bakery. The owner finally followed it, and found the cat watching over an old blind cat that could no longer feed itself.||A star falls each time someone gives up. But few know: each time someone tries again, a new star lights up."
},
"fun2.fortuneList": {
  id: "Rezekimu sedang menunggu dari arah utara 🧭|Segera ada rezeki tak terduga dari pekerjaan yang udah kamu lupa 🌟|Orang yang baru kamu kenal akan membuka pintu rezekimu 🤝|Sabar sedikit lagi — rezeki besar datang setelah ujian kecil 💰|Rezekimu tertahan karena sedang disiapkan dalam jumlah yang lebih besar 🍀",
  en: "Your fortune awaits from the north 🧭|An unexpected windfall from work you've forgotten is coming 🌟|Someone you just met will open the door to your fortune 🤝|Be patient a little longer — great fortune follows a small test 💰|Your fortune is delayed because a bigger amount is being prepared 🍀"
},

/* ================= QUIZ TAMBAHAN ================= */

"quiz.right": {
  id: "benar",
  en: "is right"
},
"quiz.correctWord": {
  id: "Benar",
  en: "Correct"
},
"quiz.allFound": {
  id: "Semua jawaban ketemu — kuis selesai!",
  en: "All answers found — quiz complete!"
},
"quiz.fullAnswer": {
  id: "Jawaban lengkap",
  en: "Full answers"
},
"quiz.answeredBy": {
  id: "menjawab",
  en: "answered"
},
"quiz.activeQuestion": {
  id: "SOAL AKTIF",
  en: "ACTIVE QUESTION"
},
"quiz.alreadyFound": {
  id: "Sudah ketemu",
  en: "Already found"
},
"quiz.noGameHint": {
  id: "Tidak ada kuis aktif. Mulai dengan {px}tebakbendera / asahotak / family100 / dll.",
  en: "No active quiz. Start with {px}tebakbendera / asahotak / family100 / etc."
},
"quiz.found": {
  id: "Ditemukan",
  en: "Found"
},
"quiz.needCount": {
  id: "butuh {n} jawaban",
  en: "{n} answers needed"
},
"quiz.toSkip": {
  id: "untuk skip",
  en: "to skip"
},
"quiz.f100Fruit": {
  id: "Buah yang rasanya manis?",
  en: "A sweet fruit?"
},
"quiz.f100FruitA": {
  id: "mangga,pisang,semangka,durian,anggur,rambutan,jeruk,sirsak",
  en: "mango,banana,watermelon,durian,grape,rambutan,orange,soursop"
},
"quiz.f100Pet": {
  id: "Hewan peliharaan populer?",
  en: "A popular pet?"
},
"quiz.f100PetA": {
  id: "kucing,anjing,burung,ikan,kelinci,hamster,ayam,bebek",
  en: "cat,dog,bird,fish,rabbit,hamster,chicken,duck"
},
"quiz.f100Vehicle": {
  id: "Alat transportasi darat?",
  en: "A land vehicle?"
},
"quiz.f100VehicleA": {
  id: "mobil,motor,sepeda,bus,kereta,becak,truk,ojek",
  en: "car,motorcycle,bicycle,bus,train,rickshaw,truck,taxi"
},
"quiz.f100Rainbow": {
  id: "Warna pelangi?",
  en: "A rainbow color?"
},
"quiz.f100RainbowA": {
  id: "merah,jingga,kuning,hijau,biru,nila,ungu,putih",
  en: "red,orange,yellow,green,blue,indigo,violet,white"
},

/* ================= START TAMBAHAN ================= */

"start.btnMenu": {
  id: "Menu Utama",
  en: "Main Menu"
},
"start.btnAll": {
  id: "All Menu",
  en: "All Menu"
},
"start.btnInfo": {
  id: "Info Bot",
  en: "Bot Info"
},
"start.btnOwner": {
  id: "Hubungi Owner",
  en: "Contact Owner"
},
"start.welcomeSound": {
  id: "Welcome sound!",
  en: "Welcome sound!"
},

/* ================= TESTALL ================= */

"test.creatorOnly": {
  id: "Hanya Creator yang bisa test all fitur.",
  en: "Only the Creator can run the feature test."
},
"test.running": {
  id: "🧪 Testing semua fitur... ini bisa memakan waktu.",
  en: "🧪 Testing all features... this may take a while."
},
"test.report": {
  id: "TEST ALL FITUR REPORT",
  en: "FEATURE TEST REPORT"
},
"test.total": {
  id: "Total commands",
  en: "Total commands"
},
"test.okCount": {
  id: "OK (handled)",
  en: "OK (handled)"
},
"test.notHandled": {
  id: "Not handled (butuh argumen/media/akses)",
  en: "Not handled (needs args/media/access)"
},
"isl3.netError": {
  id: "🌐 Jaringan/API islami sedang bermasalah — coba lagi beberapa saat.",
  en: "🌐 Network/Islamic API is having issues — try again in a moment."
},
"test.errorCount": {
  id: "Error",
  en: "Errors"
},
"test.skipCount": {
  id: "Skip (expected: usage/grup/state)",
  en: "Skipped (expected: usage/group/state)"
},
"test.skipList": {
  id: "SKIP (bukan error)",
  en: "SKIPPED (not errors)"
},
"test.errorList": {
  id: "DAFTAR ERROR (masuk errorlog)",
  en: "ERROR LIST (saved to errorlog)"
},
"test.moreErrors": {
  id: "dan {n} error lainnya.",
  en: "and {n} more errors."
},
"test.checkHint": {
  id: "Cek {px}geterror atau {px}errorfix &lt;fitur&gt;",
  en: "Check {px}geterror or {px}errorfix &lt;feature&gt;"
},
"test.allOk": {
  id: "Semua fitur OK!",
  en: "All features OK!"
},
"test.liveMode": {
  id: "LIVE MODE — hasil fitur dikirim beneran ke chat ini",
  en: "LIVE MODE — feature results are actually sent to this chat"
},
"test.groupTip": {
  id: "Jalankan /testall di grup biar fitur admin & group-only ikut teruji (syarat otomatis dipenuhi).",
  en: "Run /testall in a group so admin & group-only features get tested too (requirements auto-met)."
},

/* ================= BROADCAST / STATS ================= */

"bc.ownerOnly": {
  id: "❌ Hanya owner yang bisa broadcast.",
  en: "❌ Only owners can broadcast."
},
"bc.usageText": {
  id: "pesan yang mau dikirim",
  en: "the message to send"
},
"bc.sentToAll": {
  id: "Pesan akan dikirim ke semua user yang pernah /start bot.",
  en: "The message will be sent to everyone who has /started the bot."
},
"bc.noUsers": {
  id: "❌ Belum ada user yang terdaftar.",
  en: "❌ No registered users yet."
},
"bc.sending": {
  id: "⏳ Mengirim broadcast ke {n} user...",
  en: "⏳ Sending broadcast to {n} users..."
},
"bc.from": {
  id: "Pesan dari {owner}",
  en: "Message from {owner}"
},
"bc.done": {
  id: "Broadcast selesai!",
  en: "Broadcast complete!"
},
"bc.okCount": {
  id: "Terkirim",
  en: "Sent"
},
"bc.failCount": {
  id: "Gagal",
  en: "Failed"
},
"bc.totalCount": {
  id: "Total",
  en: "Total"
},
"bc.ownerOnlyStats": {
  id: "❌ Hanya owner yang bisa lihat stats.",
  en: "❌ Only owners can view stats."
},
"stats.title": {
  id: "Statistik {bot}",
  en: "{bot} Statistics"
},
"stats.users": {
  id: "USER",
  en: "USERS"
},
"stats.totalUsers": {
  id: "Total user",
  en: "Total users"
},
"stats.owners": {
  id: "Owner",
  en: "Owners"
},
"stats.supers": {
  id: "Super Seller",
  en: "Super Sellers"
},
"stats.sellers": {
  id: "Seller",
  en: "Sellers"
},
"stats.privates": {
  id: "Private",
  en: "Private"
},
"stats.panels": {
  id: "PANEL",
  en: "PANELS"
},
"stats.totalPanels": {
  id: "Total panel",
  en: "Total panels"
},
"stats.serversActive": {
  id: "Server aktif",
  en: "Active servers"
},
"stats.uptime": {
  id: "Uptime",
  en: "Uptime"
},
"stats.memory": {
  id: "Memory",
  en: "Memory"
},
"stats.notifGroup": {
  id: "Notif grup",
  en: "Notif group"
},
"stats.notSet": {
  id: "Belum diset",
  en: "Not set"
},
"mypanel.empty": {
  id: "📭 Kamu belum punya panel. Hubungi seller untuk membeli.",
  en: "📭 You don't have a panel yet. Contact a seller to buy one."
},
"mypanel.title": {
  id: "Panel Kamu ({n})",
  en: "Your Panels ({n})"
},
"mypanel.server": {
  id: "Server",
  en: "Server"
},
"mypanel.hint": {
  id: "Gunakan {px}listpanel untuk detail lengkap.",
  en: "Use {px}listpanel for full details."
},
"uptime.title": {
  id: "Uptime Bot",
  en: "Bot Uptime"
},
"uptime.h": {
  id: " jam ",
  en: "h "
},
"uptime.m": {
  id: " menit ",
  en: "m "
},
"uptime.s": {
  id: " detik",
  en: "s"
},

/* ================= MONITOR ================= */

"monitor.notLoaded": {
  id: "Module belum terload. Restart bot.",
  en: "Module not loaded. Restart the bot."
},
"monitor.alreadyOn": {
  id: "Sudah aktif.",
  en: "Already active."
},
"monitor.turnedOn": {
  id: "Multi-panel monitoring diaktifkan.\nPanel dari <code>global.panelServer</code>.",
  en: "Multi-panel monitoring enabled.\nPanels from <code>global.panelServer</code>."
},
"monitor.turnedOff": {
  id: "Monitoring dihentikan.",
  en: "Monitoring stopped."
},
"monitor.status": {
  id: "Status",
  en: "Status"
},
"monitor.suspended": {
  id: "Suspended",
  en: "Suspended"
},
"monitor.tracking": {
  id: "Tracking",
  en: "Tracking"
},
"monitor.panelsLabel": {
  id: "Panel",
  en: "Panels"
},
"monitor.interval": {
  id: "Interval",
  en: "Interval"
},
"monitor.allOwners": {
  id: "semua owner",
  en: "all owners"
},
"monitor.noData": {
  id: "Belum ada data. Tunggu siklus pertama...",
  en: "No data yet. Wait for the first cycle..."
},
"monitor.idMustNumber": {
  id: "ID harus angka.",
  en: "The ID must be a number."
},
"monitor.turnOn": {
  id: "Nyalakan",
  en: "Turn on"
},
"monitor.turnOff": {
  id: "Matikan",
  en: "Turn off"
},
"monitor.releaseSuspend": {
  id: "Lepas suspend",
  en: "Release suspend"
},
"monitor.notes": {
  id: "CATATAN",
  en: "NOTES"
},
"monitor.noteAuto": {
  id: "Monitor otomatis memantau semua panel di <code>global.panelServer</code>",
  en: "The monitor automatically watches all panels in <code>global.panelServer</code>"
},
"monitor.noteConfig": {
  id: "Threshold & interval diatur di <code>settings.js</code> → <code>global.monitor</code>",
  en: "Thresholds & interval are set in <code>settings.js</code> → <code>global.monitor</code>"
},
"monitor.noteNotif": {
  id: "Notifikasi dikirim ke <code>chatId</code> atau semua owner",
  en: "Notifications go to <code>chatId</code> or all owners"
},
"monitor.noteAutoDelete": {
  id: "Auto delete default mati (aman)",
  en: "Auto delete is off by default (safe)"
},

/* ================= SETTINGS PLUGIN ================= */

"set.creatorOnly": {
  id: "⛔ Hanya Creator yang bisa mengubah settings.",
  en: "⛔ Only the Creator can change settings."
},
"set.current": {
  id: "SETTINGS SAAT INI",
  en: "CURRENT SETTINGS"
},
"set.notSet": {
  id: "Belum diset",
  en: "Not set"
},
"set.panelServers": {
  id: "Server Panel",
  en: "Panel Servers"
},
"set.noServer": {
  id: "Tidak ada server",
  en: "No servers"
},
"set.manager": {
  id: "SETTINGS MANAGER",
  en: "SETTINGS MANAGER"
},
"set.hours": {
  id: "jam",
  en: "hours"
},
"set.seeAll": {
  id: "lihat semua setting",
  en: "view all settings"
},
"set.badInterval": {
  id: "Interval harus angka > 0 (jam)",
  en: "Interval must be a number > 0 (hours)"
},
"set.unknownKey": {
  id: "Key tidak dikenali. Gunakan: botname, ownername, linkowner, prefix, lang, welcome, backup, backupinterval, notifgroup, server, amkey, tolakbot",
  en: "Unknown key. Use: botname, ownername, linkowner, prefix, lang, welcome, backup, backupinterval, notifgroup, server, amkey, tolakbot"
},
"set.writeFail": {
  id: "Memory OK, tapi gagal tulis file:",
  en: "Memory OK, but failed to write the file:"
},
"set.changed": {
  id: "Setting <b>{key}</b> diubah ke <code>{val}</code>",
  en: "Setting <b>{key}</b> changed to <code>{val}</code>"
},
"set.noChange": {
  id: "Setting tidak berubah.",
  en: "No settings were changed."
},
"set.srvExample": {
  id: "Contoh: <code>/addserver 2|SGP2|sgp2.panelku.com|apikeyku|capikeyku|15|5|1</code>",
  en: "Example: <code>/addserver 2|SGP2|sgp2.mypad.com|myapikey|mycapikey|15|5|1</code>"
},
"set.srvBadId": {
  id: "❌ ID server hanya boleh huruf, angka, - dan _",
  en: "❌ Server ID can only contain letters, numbers, - and _"
},
"set.srvReady": {
  id: "🚀 Server <code>{id}</code> siap dipakai: <code>/cpanel user|ram|bulan|{id}</code>",
  en: "🚀 Server <code>{id}</code> ready: <code>/cpanel user|ram|months|{id}</code>"
},
"set.srvNotFound": {
  id: "❌ Server tidak ditemukan. Cek /servers",
  en: "❌ Server not found. Check /servers"
},
"set.srvPrivate": {
  id: "❌ Server ini dipakai private server, tidak boleh dihapus",
  en: "❌ This server is used by private server and cannot be deleted"
},
"set.srvDeleted": {
  id: "🗑️ Server <code>{id}</code> dihapus dari config",
  en: "🗑️ Server <code>{id}</code> removed from config"
},
"set.srvList": {
  id: "DAFTAR SERVER PANEL",
  en: "PANEL SERVER LIST"
},
"set.subdoHint": {
  id: "Zone ID & API Key diambil dari dashboard Cloudflare (My Profile → API Tokens → Zone ID). Domain harus sudah aktif di akun Cloudflare kamu.",
  en: "Zone ID & API Key come from your Cloudflare dashboard (My Profile → API Tokens → Zone ID). The domain must be active on your Cloudflare account."
},
"set.subdoBadDomain": {
  id: "❌ Format domain tidak valid. Contoh: tailsx.my.id",
  en: "❌ Invalid domain format. Example: tailsx.my.id"
},
"set.subdoAdded": {
  id: "DOMAIN TERDAFTARKAN",
  en: "DOMAIN REGISTERED"
},
"set.subdoNext": {
  id: "Sekarang bisa buat subdomain: <code>{px}cdomain sub|ip|on|{domain}</code>",
  en: "You can now create subdomains: <code>{px}cdomain sub|ip|on|{domain}</code>"
},
"set.subdoNotFound": {
  id: "❌ Domain tidak terdaftar di config. Cek /getset",
  en: "❌ Domain not registered in config. Check /getset"
},
"set.subdoDeleted": {
  id: "🗑️ Domain <code>{domain}</code> dihapus dari config",
  en: "🗑️ Domain <code>{domain}</code> removed from config"
},
"clone.stopped": {
  id: "🛑 Clone <b>{name}</b> berhasil dihentikan.\nData & token tetap tersimpan — buat ulang lewat /clone kalau dibutuhkan.",
  en: "🛑 Clone <b>{name}</b> stopped successfully.\nData & token remain saved — recreate via /clone if needed."
},
"clone.alreadyDead": {
  id: "⚠️ Clone <b>{name}</b> sudah tidak berjalan (PID mati).",
  en: "⚠️ Clone <b>{name}</b> is not running (dead PID)."
},
"fun3.janda": {
  id: "{who} terdeteksi sejanda tingkat dewa",
  en: "{who} detected as a certified single lady"
},
"fun3.duda": {
  id: "{who} terdeteksi seduda kelas kakap",
  en: "{who} detected as a certified single man"
},
"fun3.jelek": {
  id: "Tingkat ke-jelek-an {who}",
  en: "{who}'s ugliness level"
},
"fun3.ganteng": {
  id: "Tingkat kegantengan {who}",
  en: "{who}'s handsomeness level"
},
"fun3.cantik": {
  id: "Tingkat kecantikan {who}",
  en: "{who}'s beauty level"
},
"fun3.pedofil": {
  id: "Indikasi pedofil {who}",
  en: "{who}'s pedophile indication"
},
"fun3.penyakit": {
  id: "Penyakit aneh {who}:",
  en: "{who}'s weird disease:"
},
"fun3.pekerjaan": {
  id: "Pekerjaan cocok buat {who}",
  en: "Suitable job for {who}"
},
"fun3.nasib": {
  id: "Nasib {who} hari ini",
  en: "{who}'s fortune today"
},
"fun3.rezeki": {
  id: "Rezeki {who} bulan ini",
  en: "{who}'s fortune this month"
},
"fun3.sifat": {
  id: "Sifat asli {who}",
  en: "{who}'s true nature"
},
"fun3.hobi": {
  id: "Hobi tersembunyi {who}",
  en: "{who}'s hidden hobby"
},
"fun3.pintar": {
  id: "Kecerdasan {who}",
  en: "{who}'s intelligence"
},
"fun3.maling": {
  id: "Kemampuan mencuri {who}",
  en: "{who}'s stealing skill"
},
"fun3.haribaik": {
  id: "Keberuntungan {who} hari ini",
  en: "{who}'s luck today"
},
"fun3.harisial": {
  id: "Pekelialaan {who} hari ini",
  en: "{who}'s bad-luck level today"
},
"fun3.nikah": {
  id: "Peluang {who} nikah tahun ini",
  en: "{who}'s chance to marry this year"
},
"fun3.pesugihan": {
  id: "Indikasi pesugihan {who}",
  en: "{who}'s black-magic money indication"
},
"fun3.hoki": {
  id: "Level hoki {who}",
  en: "{who}'s hoki level"
},
"fun3.future": {
  id: "Kecerahan masa depan {who}",
  en: "{who}'s future brightness"
},
"media2.needPhoto": {
  id: "⚠️ Reply foto dulu, baru ketik command filter-nya.",
  en: "⚠️ Reply to a photo first, then type the filter command."
},
"tm2.fakeReact": {
  id: "Fake chat reaction",
  en: "Fake chat reaction"
},
"tm2.typeWriter": {
  id: "Typewriter text",
  en: "Typewriter text"
},
"tm2.captcha": {
  id: "Kode captcha kamu",
  en: "Your captcha code"
},
"isl2.wirid": {
  id: "Wirid Harian",
  en: "Daily Remembrance"
},
"isl2.asma": {
  id: "Asmaul Husna (random 5)",
  en: "Asmaul Husna (random 5)"
},
"isl2.niat": {
  id: "Niat Sholat Wajib",
  en: "Obligatory Prayer Intention"
},
"isl2.tahlil": {
  id: "Bacaan Tahlil Singkat",
  en: "Short Tahlil Reading"
},
"isl2.tahlilNote": {
  id: "Bacakan untuk saudara kita yang telah wafat.",
  en: "Recite for our departed brothers and sisters."
},
"owner2.seller": {
  id: "Seller",
  en: "Seller"
},
"owner2.super": {
  id: "Super Seller",
  en: "Super Seller"
},
"owner2.owner": {
  id: "Owner",
  en: "Owner"
},
"owner2.already": {
  id: "⚠️ <code>{id}</code> sudah terdaftar.",
  en: "⚠️ <code>{id}</code> is already registered."
},
"owner2.removed": {
  id: "dihapus dari daftar",
  en: "removed from the list"
},
"owner2.listEmpty": {
  id: "📭 Daftar {label} masih kosong.",
  en: "📭 The {label} list is empty."
},
"owner2.warned": {
  id: "{name} dapat warning {n}/{max}",
  en: "{name} received warning {n}/{max}"
},
"owner2.warnMax": {
  id: "{name} mencapai batas warning (3/3). Harusnya dikick dari grup.",
  en: "{name} reached the warning limit (3/3). Should be kicked from the group."
},
"owner2.noWarn": {
  id: "{name} bersih, tidak ada warning.",
  en: "{name} is clean, no warnings."
},
"owner2.warnReset": {
  id: "Warning {name} direset.",
  en: "{name}'s warnings were reset."
},
"fun3.row": {
  id: "{emoji} {key}: {who} — {p}%",
  en: "{emoji} {key}: {who} — {p}%"
},
"fun3.footer": {
  id: "Ini cuma hiburan, bukan angka nyata 😄",
  en: "Just for fun, not real stats 😄"
},
"dl3.needQuery": {
  id: "⚠️ Mau cari apa? Contoh: /ttsearch luka",
  en: "⚠️ What do you want to search? Example: /ttsearch luka"
},
"dl3.needUrl": {
  id: "⚠️ Kirim link-nya. Contoh: /aiodl https://tiktok.com/...",
  en: "⚠️ Send the link. Example: /aiodl https://tiktok.com/..."
},
"dl3.noResult": {
  id: "❌ Tidak ada hasil. Coba kata kunci lain.",
  en: "❌ No results. Try another keyword."
},
"dl3.noMedia": {
  id: "❌ Media tidak ditemukan di pin ini.",
  en: "❌ No media found on this pin."
},
"dl3.pinNeedUrl": {
  id: "⚠️ Kirim link pin Pinterest. Contoh: /pindl https://pinterest.com/pin/123...",
  en: "⚠️ Send a Pinterest pin link. Example: /pindl https://pinterest.com/pin/123..."
},
"dl3.ttResult": {
  id: "🎵 TikTok: {q}",
  en: "🎵 TikTok: {q}"
},
"dl3.ttRandom": {
  id: "🎲 TikTok random: {q}",
  en: "🎲 TikTok random: {q}"
},
"dl3.scResult": {
  id: "🔊 SoundCloud: {q}",
  en: "🔊 SoundCloud: {q}"
},
"dl3.spotifyResult": {
  id: "🎧 Spotify: {q}",
  en: "🎧 Spotify: {q}"
},
"dl3.sfileResult": {
  id: "📁 Sfile: {q}",
  en: "📁 Sfile: {q}"
},
"dl3.gdriveResult": {
  id: "📁 Google Drive: {q}",
  en: "📁 Google Drive: {q}"
},
"dl3.followers": {
  id: "pengikut",
  en: "followers"
},
"dl3.following": {
  id: "mengikuti",
  en: "following"
},
"dl3.aioTitle": {
  id: "ALL-IN-ONE DOWNLOADER",
  en: "ALL-IN-ONE DOWNLOADER"
},
"dl3.aioUnknown": {
  id: "❌ Link tidak dikenali. TikTok / IG / YouTube / Pinterest / MediaFire / Terabox didukung.",
  en: "❌ Unknown link. TikTok / IG / YouTube / Pinterest / MediaFire / Terabox supported."
},
"grp2.groupOnly": {
  id: "⚠️ Fitur ini khusus grup.",
  en: "⚠️ This feature is group-only."
},
"grp2.announce": {
  id: "PENGUMUMAN",
  en: "ANNOUNCEMENT"
},
"grp2.absenOpen": {
  id: "ABSEN DIBUKA",
  en: "ATTENDANCE OPEN"
},
"grp2.absenHint": {
  id: "Member absen dengan ketik {px}absen",
  en: "Members check in by typing {px}absen"
},
"grp2.absenDup": {
  id: "⚠️ Kamu sudah absen.",
  en: "⚠️ You already checked in."
},
"grp2.absenOk": {
  id: "✅ {name} absen! Total: {n}",
  en: "✅ {name} checked in! Total: {n}"
},
"grp2.absenList": {
  id: "DAFTAR HADIR ({n} orang)",
  en: "ATTENDANCE LIST ({n} people)"
},
"grp2.absenNone": {
  id: "⚠️ Tidak ada sesi absen aktif.",
  en: "⚠️ No active attendance session."
},
"grp2.absenClosed": {
  id: "Sesi absen ditutup. Total hadir: {n}",
  en: "Attendance closed. Total present: {n}"
},
"grp2.voteUsage": {
  id: "pertanyaan|opsi1|opsi2",
  en: "question|option1|option2"
},
"grp2.voteActive": {
  id: "⚠️ Masih ada vote aktif. Tutup dulu dengan /voteselesai",
  en: "⚠️ A vote is already active. Close it first with /voteselesai"
},
"grp2.voteOpen": {
  id: "VOTE DIBUKA",
  en: "VOTE OPEN"
},
"grp2.voteHint": {
  id: "Balas dengan /1 /2 /3 sesuai opsi.",
  en: "Reply with /1 /2 /3 for your option."
},
"grp2.voteCast": {
  id: "✅ Vote tersimpan: {opt}",
  en: "✅ Vote saved: {opt}"
},
"grp2.voteNone": {
  id: "⚠️ Tidak ada vote aktif.",
  en: "⚠️ No active vote."
},
"grp2.voteResult": {
  id: "HASIL VOTE",
  en: "VOTE RESULT"
},
"grp2.voteDone": {
  id: "VOTE DITUTUP",
  en: "VOTE CLOSED"
},
"grp2.voteWinner": {
  id: "Pemenang: {opt}",
  en: "Winner: {opt}"
},
"clone.stopped": {
  id: "🛑 Clone <b>{name}</b> berhasil dihentikan.\nData & token tetap tersimpan — buat ulang lewat /clone kalau dibutuhkan.",
  en: "🛑 Clone <b>{name}</b> stopped successfully.\nData & token remain saved — recreate via /clone if needed."
},
"clone.alreadyDead": {
  id: "⚠️ Clone <b>{name}</b> sudah tidak berjalan (PID mati).",
  en: "⚠️ Clone <b>{name}</b> is not running (dead PID)."
},

/* ================= MAKER ================= */

"maker.title": {
  id: "Judul",
  en: "Title"
},
"maker.joinNow": {
  id: "Join sekarang!",
  en: "Join now!"
},
"maker.fakeWarn": {
  id: "FAKE — hanya untuk hiburan",
  en: "FAKE — for entertainment only"
},
"maker.sickLetter": {
  id: "Surat Keterangan Sakit",
  en: "Sick Note"
},
"maker.weddingInv": {
  id: "Undangan Pernikahan",
  en: "Wedding Invitation"
},
"maker.payUsage": {
  id: "Nominal|Nama",
  en: "Amount|Name"
},
"maker.transferSuccess": {
  id: "Transfer Berhasil",
  en: "Transfer Successful"
},

/* ================= PREMIUM ================= */

"prem.unknownGame": {
  id: "❌ Game tidak dikenali. Gunakan: ff, ml",
  en: "❌ Unknown game. Use: ff, ml"
},

/* ================= SEARCH2 ================= */

"s2.googleSearch": {
  id: "GOOGLE SEARCH",
  en: "GOOGLE SEARCH"
},
"s2.query": {
  id: "Query",
  en: "Query"
},
"s2.searchFail": {
  id: "❌ Pencarian gagal. Coba kata kunci lain.",
  en: "❌ Search failed. Try different keywords."
},
"s2.searching": {
  id: "🔍 Mencari...",
  en: "🔍 Searching..."
},
"s2.imageNotFound": {
  id: "❌ Gambar tidak ditemukan",
  en: "❌ Image not found"
},
"s2.lyricsTitle": {
  id: "LIRIK LAGU",
  en: "SONG LYRICS"
},
"s2.lyricsNotFound": {
  id: "❌ Lirik tidak ditemukan",
  en: "❌ Lyrics not found"
},
"s2.kbbiNotFound": {
  id: "❌ Kata tidak ditemukan di KBBI",
  en: "❌ Word not found in KBBI"
},
"s2.phoneNotFound": {
  id: "❌ HP tidak ditemukan",
  en: "❌ Phone not found"
},
"s2.gsmTitle": {
  id: "Spesifikasi HP",
  en: "Phone Specs"
},

/* ================= MENU HINTS ================= */

"menu.hint.fastPanel": { id: "Panel cepat per GB", en: "Quick panel per GB" },
"menu.hint.unliPanel": { id: "Panel unlimited", en: "Unlimited panel" },
"menu.hint.setVia": { id: "Pengaturan via bot", en: "Settings via bot" },
"menu.hint.panelmanager": { id: "Panduan config panel & domain", en: "Panel & domain config guide" },
"menu.hint.addserver": { id: "Tambah server panel tanpa edit file", en: "Add panel server without editing files" },
"menu.hint.servers": { id: "Daftar server panel", en: "List panel servers" },
"menu.hint.addsubdo": { id: "Daftarkan domain Cloudflare", en: "Register Cloudflare domain" },
"menu.hint.stopclone": { id: "Hentikan clone yang berjalan", en: "Stop a running clone" },
"menu.hint.ttsearch": { id: "Cari video TikTok", en: "Search TikTok videos" },
"menu.hint.scs": { id: "Cari lagu SC/Spotify", en: "Search SC/Spotify tracks" },
"menu.hint.pindl": { id: "Download media Pinterest", en: "Download Pinterest media" },
"menu.hint.sfile": { id: "Cari file di sfile/drive", en: "Search files on sfile/drive" },
"menu.hint.apkmod": { id: "Cari APK mod", en: "Search mod APKs" },
"menu.hint.aiodl": { id: "Deteksi link apa pun", en: "Detect any link" },
"menu.hint.pinstalk": { id: "Profil Pinterest", en: "Pinterest profile" },
"menu.hint.npmsearch": { id: "Cari paket npm", en: "Search npm packages" },
"menu.hint.threadsstalk": { id: "Profil Threads", en: "Threads profile" },
"menu.hint.xstalk": { id: "Profil X/Twitter", en: "X/Twitter profile" },
"menu.hint.modrinth": { id: "Cari mod Minecraft", en: "Search Minecraft mods" },
"menu.hint.fontlist": { id: "Cari font dafont", en: "Search dafont fonts" },
"menu.hint.apksearch": { id: "Cari APK", en: "Search APKs" },
"menu.hint.fakereact": { id: "Chat dengan reaksi", en: "Chat with reaction" },
"menu.hint.typewriter": { id: "Teks mesin ketik", en: "Typewriter text" },
"menu.hint.captcha": { id: "Gambar captcha", en: "Captcha image" },
"menu.hint.filter": { id: "Filter foto (reply)", en: "Photo filter (reply)" },
"menu.hint.checkme": { id: "Semua cek sekaligus", en: "All checks at once" },
"menu.hint.islamic2": { id: "Doa & dzikir harian", en: "Daily prayers & dhikr" },
"menu.hint.pengumuman": { id: "Pengumuman grup", en: "Group announcement" },
"menu.hint.absen": { id: "Sesi absen grup", en: "Group attendance" },
"menu.hint.vote": { id: "Vote grup", en: "Group vote" },
"menu.hint.viaReply": { id: "Kelola via reply", en: "Manage via reply" },
"menu.hint.warn2": { id: "Warning grup (3x kick)", en: "Group warns (3x kick)" },
"menu.hint.setKey": { id: "API key & balasan tolak", en: "API key & reject reply" },
"menu.hint.seeSet": { id: "Lihat semua setting", en: "View all settings" },
"menu.hint.clone": { id: "Clone bot (db terpisah)", en: "Clone bot (separate db)" },
"menu.hint.cloneList": { id: "Lihat daftar clone", en: "View clone list" },
"menu.hint.addFeature": { id: "Tambah fitur", en: "Add feature" },
"menu.hint.delFeature": { id: "Hapus fitur", en: "Delete feature" },
"menu.hint.getFeature": { id: "Ambil kode fitur", en: "Get feature code" },
"menu.hint.listFeature": { id: "Lihat semua fitur", en: "View all features" },
"menu.hint.getCase": { id: "Ambil kode case", en: "Get case code" },
"menu.hint.testAll": { id: "Test semua fitur", en: "Test all features" },
"menu.hint.errList": { id: "Lihat fitur error", en: "View erroring features" },
"menu.hint.errFix": { id: "AI fix fitur error", en: "AI fix erroring feature" },
"menu.hint.errCode": { id: "Ambil kode fitur error", en: "Get erroring feature code" },
"menu.hint.errDelete": { id: "Hapus dari daftar error", en: "Remove from error list" },
"menu.hint.yts": { id: "Cari video YouTube", en: "Search YouTube videos" },
"menu.hint.ytdl": { id: "Download YouTube (video/mp3)", en: "Download YouTube (video/mp3)" },
"menu.hint.play": { id: "Play audio dari YouTube", en: "Play audio from YouTube" },
"menu.hint.tt": { id: "Download TikTok", en: "Download TikTok" },
"menu.hint.mediafire": { id: "Download MediaFire", en: "Download MediaFire" },
"menu.hint.gitclone": { id: "Download repo GitHub", en: "Download GitHub repo" },
"menu.hint.spotify": { id: "Download Spotify", en: "Download Spotify" },
"menu.hint.soundcloud": { id: "Download SoundCloud", en: "Download SoundCloud" },
"menu.hint.terabox": { id: "Download Terabox", en: "Download Terabox" },
"menu.hint.capcut": { id: "Download CapCut", en: "Download CapCut" },
"menu.hint.threads": { id: "Download Threads", en: "Download Threads" },
"menu.hint.tourl": { id: "Upload media ke 10 host", en: "Upload media to 10 hosts" },
"menu.hint.brat": { id: "Buat stiker brat (pack)", en: "Make brat sticker (pack)" },
"menu.hint.sticker": { id: "Reply foto/stiker → pack", en: "Reply photo/sticker → pack" },
"menu.hint.stickerinfo": { id: "Info pack stiker kamu", en: "Your sticker pack info" },
"menu.hint.qc": { id: "Quote chat sticker", en: "Quote chat sticker" },
"menu.hint.smeme": { id: "Meme sticker (reply foto)", en: "Meme sticker (reply photo)" },
"menu.hint.style": { id: "25 gaya font", en: "25 font styles" },
"menu.hint.ttp": { id: "Text sticker", en: "Text sticker" },
"menu.hint.toimg": { id: "Stiker → foto (reply)", en: "Sticker → photo (reply)" },
"menu.hint.emojimix": { id: "Gabung 2 emoji", en: "Mix 2 emojis" },
"menu.hint.blackpink": { id: "Logo Blackpink", en: "Blackpink logo" },
"menu.hint.pornhub": { id: "Logo Pornhub", en: "Pornhub logo" },
"menu.hint.textpro": { id: "Logo textpro", en: "Textpro logo" },
"menu.hint.ektp": { id: "Generator e-KTP (foto)", en: "e-KTP generator (photo)" },
"menu.hint.suratsakit": { id: "Generator surat (foto)", en: "Letter generator (photo)" },
"menu.hint.undangan": { id: "Generator undangan (foto)", en: "Invitation generator (photo)" },
"menu.hint.fakelobby": { id: "Fake lobby FF/ML (foto)", en: "Fake FF/ML lobby (photo)" },
"menu.hint.fakeff": { id: "Lobby image FF/ML (foto)", en: "FF/ML lobby image (photo)" },
"menu.hint.fakedana": { id: "Fake payment Dana (foto)", en: "Fake Dana payment (photo)" },
"menu.hint.fakepay": { id: "Fake payment (foto)", en: "Fake payment (photo)" },
"menu.hint.faketweet": { id: "Fake tweet (foto)", en: "Fake tweet (photo)" },
"menu.hint.fakewa": { id: "Fake chat WA (foto)", en: "Fake WA chat (photo)" },
"menu.hint.ampremium": { id: "AM premium via email", en: "AM premium via email" },
"menu.hint.amverify": { id: "Verifikasi AM premium", en: "Verify AM premium" },
"menu.hint.amreg": { id: "Registrasi AM + OTP", en: "AM registration + OTP" },
"menu.hint.amotp": { id: "Verifikasi OTP", en: "Verify OTP" },
"menu.hint.presetam": { id: "Info preset Alight Motion", en: "Alight Motion preset info" },
"menu.hint.githubstalk": { id: "Stalk GitHub", en: "Stalk GitHub" },
"menu.hint.npmstalk": { id: "Stalk npm", en: "Stalk npm" },
"menu.hint.igstalk": { id: "Stalk Instagram", en: "Stalk Instagram" },
"menu.hint.tiktokstalk": { id: "Stalk TikTok", en: "Stalk TikTok" },
"menu.hint.ffstalk": { id: "Stalk Free Fire", en: "Stalk Free Fire" },
"menu.hint.robloxstalk": { id: "Stalk Roblox", en: "Stalk Roblox" },
"menu.hint.ytstalk": { id: "Stalk YouTube", en: "Stalk YouTube" },
"menu.hint.discordstalk": { id: "Stalk Discord", en: "Stalk Discord" },
"menu.hint.gempa": { id: "Info gempa BMKG", en: "BMKG earthquake info" },
"menu.hint.google": { id: "Cari Google", en: "Search Google" },
"menu.hint.pinterest": { id: "Cari gambar", en: "Search images" },
"menu.hint.lirik": { id: "Musik", en: "Music" },
"menu.hint.kbbi": { id: "Kamus KBBI", en: "KBBI dictionary" },
"menu.hint.gsmarena": { id: "Spesifikasi HP", en: "Phone specs" },
"menu.hint.info": { id: "Info lengkap user", en: "Full user info" },
"menu.hint.short": { id: "Pendekkan URL", en: "Shorten URL" },
"menu.hint.qr": { id: "Buat QR code", en: "Make QR code" },
"menu.hint.calc": { id: "Kalkulator", en: "Calculator" },
"menu.hint.weather": { id: "Info cuaca", en: "Weather info" },
"menu.hint.wiki": { id: "Wikipedia", en: "Wikipedia" },
"menu.hint.tr": { id: "Terjemahan", en: "Translation" },
"menu.hint.ip": { id: "Info IP", en: "IP info" },
"menu.hint.github": { id: "Profil GitHub", en: "GitHub profile" },
"menu.hint.npm": { id: "Info package npm", en: "npm package info" },
"menu.hint.pass": { id: "Generator password", en: "Password generator" },
"menu.hint.b64": { id: "Base64 encode/decode", en: "Base64 encode/decode" },
"menu.hint.hash": { id: "Hash md5/sha1/sha256", en: "md5/sha1/sha256 hash" },
"menu.hint.time": { id: "Waktu suatu lokasi", en: "Time at a location" },
"menu.hint.ss": { id: "Screenshot website", en: "Website screenshot" },
"menu.hint.tts": { id: "Text to speech", en: "Text to speech" },
"menu.hint.define": { id: "Kamus Inggris", en: "English dictionary" },
"menu.hint.getid": { id: "ID user/chat/pesan", en: "User/chat/message ID" },
"menu.hint.audiofx": { id: "Efek audio (reply)", en: "Audio effect (reply)" },
"menu.hint.tupai": { id: "Efek tupai (reply)", en: "Squirrel effect (reply)" },
"menu.hint.toaudio": { id: "Audio → voice/mp3 (reply)", en: "Audio → voice/mp3 (reply)" },
"menu.hint.tovideo": { id: "Video note → video (reply)", en: "Video note → video (reply)" },
"menu.hint.removebg": { id: "Hapus background (reply foto)", en: "Remove background (reply photo)" },
"menu.hint.alquran": { id: "Al-Qur'an per surah", en: "Al-Qur'an per surah" },
"menu.hint.murotal": { id: "Audio murotal", en: "Murotal audio" },
"menu.hint.kisahnabi": { id: "Kisah 25 nabi", en: "Stories of 25 prophets" },
"menu.hint.jadwalsholat": { id: "Jadwal sholat", en: "Prayer times" },
"menu.hint.hadist": { id: "Hadist", en: "Hadith" },
"menu.hint.artimimpi": { id: "Tafsir mimpi", en: "Dream interpretation" },
"menu.hint.primbon": { id: "Primbon", en: "Primbon" },
"menu.hint.ramalanjodoh": { id: "Ramalan pasangan", en: "Couple compatibility" },
"menu.hint.artinama": { id: "Arti nama", en: "Name meaning" },
"menu.hint.8ball": { id: "Tanya bola ajaib", en: "Ask the magic ball" },
"menu.hint.quick": { id: "Cepat", en: "Quick" },
"menu.hint.rate": { id: "Rate sesuatu", en: "Rate something" },
"menu.hint.love": { id: "Kecocokan cinta", en: "Love compatibility" },
"menu.hint.pick": { id: "Pilih salah satu", en: "Pick one option" },
"menu.hint.words": { id: "Kata-kata", en: "Quotes & words" },
"menu.hint.wpick": { id: "Pilih user dari tag", en: "Pick a user from tags" },
"menu.hint.random": { id: "Random", en: "Random" },
"menu.hint.ttt": { id: "TicTacToe", en: "TicTacToe" },
"menu.hint.quiz": { id: "Kuis", en: "Quiz" },
"menu.hint.family100": { id: "Family 100 — 8 jawaban", en: "Family 100 — 8 answers" },
"menu.hint.games": { id: "Games", en: "Games" },
"menu.hint.askbot": { id: "Tanya bot", en: "Ask the bot" },
"menu.hint.cek": { id: "Cek-kodam & co", en: "Kodam check & co" },
"menu.hint.randomPic": { id: "Random pic", en: "Random pic" },
"menu.hint.reaction": { id: "Reaction", en: "Reaction" },
"menu.hint.animequote": { id: "Quote anime", en: "Anime quote" },
"menu.hint.wallpaper": { id: "Wallpaper", en: "Wallpaper" },
"menu.hint.ai": { id: "Chat AI (multi-model)", en: "AI chat (multi-model)" },
"menu.hint.aiAlias": { id: "Alias AI", en: "AI alias" },
"menu.hint.roseWarn": { id: "Rose warn (admin)", en: "Rose warn (admin)" },
"menu.hint.protect": { id: "Protect (admin)", en: "Protect (admin)" },
"menu.hint.groupAdmin": { id: "Group (admin)", en: "Group (admin)" },
"menu.hint.broadcast": { id: "Kirim pesan ke semua user", en: "Send message to all users" },
"menu.hint.stats": { id: "Statistik bot & user", en: "Bot & user stats" },
"menu.hint.uptime": { id: "Uptime & memory bot", en: "Bot uptime & memory" },
"menu.hint.topstats": { id: "Statistik penggunaan", en: "Usage statistics" },
"menu.hint.afk": { id: "Set mode AFK", en: "Set AFK mode" },
"menu.hint.addgb": { id: "Daftarkan grup notifikasi", en: "Register notification group" },
"menu.hint.ping": { id: "Cek latency", en: "Check latency" },
"menu.hint.setcommands": { id: "Daftar command ke Telegram", en: "Register commands to Telegram" },
"menu.hint.backup": { id: "Backup manual sekarang", en: "Manual backup now" },
"menu.hint.backupset": { id: "Atur interval backup", en: "Set backup interval" },
"menu.hint.getpp": { id: "Foto profil user", en: "User profile photo" },
"menu.hint.batal": { id: "Bersihkan sesi stuck", en: "Clear stuck sessions" },

/* ================= ROSE + BARKER + PROTECTRON (batch-5) ================= */

"rose.adminOnly": {
  id: "⛔ Khusus admin grup.",
  en: "⛔ Group admins only."
},
"rose.groupOnly": {
  id: "👥 Khusus grup.",
  en: "👥 Groups only."
},
"rose.botAdmin": {
  id: "⚠️ Aku butuh jadi admin dulu!",
  en: "⚠️ I need to be an admin first!"
},
"rose.promoteMe": {
  id: "Promosikan aku: Delete messages + Ban users",
  en: "Promote me with: Delete messages + Ban users"
},
"rose.needTarget": {
  id: "🔎 Reply user / @user / ID",
  en: "🔎 Reply to a user / @user / ID"
},
"rose.needText": {
  id: "⚠️ Teksnya mana?",
  en: "⚠️ Where is the text?"
},
"rose.replyMsg": {
  id: "🔎 Reply pesannya dulu.",
  en: "🔎 Reply to the message first."
},
"rose.replyOld": {
  id: "🔎 Reply pesan LAMA (awal purge).",
  en: "🔎 Reply to the OLDEST message (purge start)."
},
"rose.banned": {
  id: "Diban!",
  en: "Banned!"
},
"rose.kicked": {
  id: "Dikick!",
  en: "Kicked!"
},
"rose.muted": {
  id: "Dimute",
  en: "Muted"
},
"rose.unmuted": {
  id: "Diunmute!",
  en: "Unmuted!"
},
"rose.unbanned": {
  id: "Diunban!",
  en: "Unbanned!"
},
"rose.temp": {
  id: "sementara",
  en: "temporary"
},
"rose.connected": {
  id: "🔗 Terhubung! Sekarang admin bisa kelola grup ini dari PM.",
  en: "🔗 Connected! Admins can now manage this group from PM."
},
"rose.connectedTo": {
  id: "🔗 Terhubung ke",
  en: "🔗 Connected to"
},
"rose.currentConn": {
  id: "🔗 Connection aktif:",
  en: "🔗 Active connection:"
},
"rose.needChatId": {
  id: "Kirim /connect di dalam grup, atau /connect -100xxx di PM.",
  en: "Send /connect inside the group, or /connect -100xxx from PM."
},
"rose.disconnected": {
  id: "✅ Connection diputus.",
  en: "✅ Disconnected."
},
"rose.noConn": {
  id: "❌ Tidak ada connection.",
  en: "❌ No connection."
},
"rose.reconnected": {
  id: "🔄 Reconnect ke",
  en: "🔄 Reconnected to"
},
"rose.warnlimitSet": {
  id: "Batas warning:",
  en: "Warning limit:",
  vars: { n: 1 }
},
"rose.warnmodeSet": {
  id: "Aksi warning:",
  en: "Warning action:"
},
"rose.warnmodeHint": {
  id: "Mode yang tersedia",
  en: "Available modes"
},
"rose.warnLimit": {
  id: "Batas warning",
  en: "Warning limit"
},
"rose.warnMode": {
  id: "Aksi saat limit",
  en: "Action at limit"
},
"rose.status": {
  id: "Status",
  en: "Status"
},
"rose.purged": {
  id: "pesan dihapus:",
  en: "messages deleted:"
},
"rose.done": {
  id: "Selesai!",
  en: "Done!"
},
"rose.noPinned": {
  id: "📌 Tidak ada pesan pinned.",
  en: "📌 No pinned message."
},
"rose.pinnedMsg": {
  id: "PESAN PINNED",
  en: "PINNED MESSAGE"
},
"rose.reported": {
  id: "Laporan diteruskan ke admin!",
  en: "Report sent to admins!"
},
"rose.resetDone": {
  id: "Semua setting grup direset.",
  en: "All group settings have been reset."
},
"rose.resetDone2": {
  id: "Direset:",
  en: "Reset:"
},
"rose.unknownLock": {
  id: "Tipe lock tidak dikenal",
  en: "Unknown lock type"
},
"rose.seeLocktypes": {
  id: "Lihat tipe:",
  en: "See types:"
},
"rose.lockDone": {
  id: "Lock diperbarui:",
  en: "Locks updated:"
},
"rose.active": {
  id: "Aktif",
  en: "Active"
},
"rose.lockWarns": {
  id: "Warning saat pelanggaran lock",
  en: "Warn on lock violation"
},
"rose.lockWarnsOn": {
  id: "Aktifkan lockwarns",
  en: "Enable lock warnings"
},
"rose.lockWarnsOff": {
  id: "Matikan lockwarns",
  en: "Disable lock warnings"
},
"rose.empty": {
  id: "masih kosong",
  en: "still empty"
},
"rose.blAdded": {
  id: "Ditambahkan ke blocklist:",
  en: "Added to blocklist:"
},
"rose.blRemoved": {
  id: "Dihapus dari blocklist:",
  en: "Removed from blocklist:"
},
"rose.blCleared": {
  id: "Blocklist dibersihkan.",
  en: "Blocklist cleared."
},
"rose.blMode": {
  id: "Mode blocklist:",
  en: "Blocklist mode:"
},
"rose.floodSet": {
  id: "Batas flood:",
  en: "Flood limit:"
},
"rose.floodTimerSet": {
  id: "Flood dalam periode:",
  en: "Flood within period:"
},
"rose.floodMode": {
  id: "Aksi flood:",
  en: "Flood action:"
},
"rose.floodLimit": {
  id: "Batas",
  en: "Limit"
},
"rose.floodMode2": {
  id: "Aksi",
  en: "Action"
},
"rose.floodHit": {
  id: "Flood terdeteksi!",
  en: "Flood detected!"
},
"rose.captchaOk": {
  id: "Terverifikasi! Selamat datang 👋",
  en: "Verified! Welcome 👋"
},
"rose.captchaHint": {
  id: "Member baru harus verifikasi sebelum bisa chat.",
  en: "New members must verify before chatting."
},
"rose.mode": {
  id: "Mode",
  en: "Mode"
},
"rose.off": {
  id: "Status: OFF",
  en: "Status: OFF"
},
"rose.welcomeOff": {
  id: "Welcome belum diset.",
  en: "Welcome is not set yet."
},
"rose.goodbyeOff": {
  id: "Goodbye belum diset.",
  en: "Goodbye is not set yet."
},
"rose.welcomeMute": {
  id: "Mute member baru (via captcha)",
  en: "Mute new members (via captcha)"
},
"rose.saved": {
  id: "tersimpan!",
  en: "saved!"
},
"rose.filterSaved": {
  id: "Filter dibuat",
  en: "Filter created"
},
"rose.filterRemoved": {
  id: "Filter dihapus.",
  en: "Filter removed."
},
"rose.noteSaved": {
  id: "Note disimpan",
  en: "Note saved"
},
"rose.noteNotFound": {
  id: "❌ Note tidak ditemukan.",
  en: "❌ Note not found."
},
"rose.noteRemoved": {
  id: "Note dihapus:",
  en: "Note removed:"
},
"rose.cmdDisabled": {
  id: "Command dinonaktifkan:",
  en: "Command disabled:"
},
"rose.cmdEnabled": {
  id: "Command diaktifkan:",
  en: "Command enabled:"
},
"rose.alreadyHaveFed": {
  id: "Kamu sudah punya fed:",
  en: "You already own a federation:"
},
"rose.noFed": {
  id: "❌ Fed tidak ditemukan / grup belum join fed.",
  en: "❌ Federation not found / chat has not joined one."
},
"rose.fedNotFound": {
  id: "❌ Fed dengan ID itu tidak ada.",
  en: "❌ Federation with that ID does not exist."
},
"rose.fedJoined": {
  id: "Grup join fed",
  en: "Chat joined federation"
},
"rose.fedLeft": {
  id: "Grup keluar dari fed.",
  en: "Chat left the federation."
},
"rose.fedChats": {
  id: "Grup terhubung",
  en: "Connected chats"
},
"rose.fedBans": {
  id: "Fed bans",
  en: "Fed bans"
},
"rose.fedOwnerOnly": {
  id: "⛔ Khusus owner federation.",
  en: "⛔ Federation owner only."
},
"allhandlers.failed": {
  id: "⚠️ Semua handler untuk command ini gagal. Owner sudah dilaporkan.",
  en: "⚠️ All handlers for this command failed. Owner has been notified."
},
"rose.captchaNotYours": {
  id: "Captcha ini bukan untuk kamu!",
  en: "This captcha is not yours!"
},
"rose.adminsTitle": {
  id: "ADMIN LIST",
  en: "ADMIN LIST"
},
"rose.noRules": {
  id: "Belum ada rules. Set dengan",
  en: "No rules yet. Set with"
},
"ping.checking": {
  id: "Mengecek server...",
  en: "Checking server..."
},
"ping.latency": {
  id: "Latensi",
  en: "Latency"
},
"ping.uptime": {
  id: "Uptime",
  en: "Uptime"
},
"ping.version": {
  id: "Versi bot",
  en: "Bot version"
},
"ping.cores": {
  id: "Core CPU",
  en: "CPU cores"
},
"ping.cpuUse": {
  id: "Pemakaian CPU",
  en: "CPU usage"
},
"ping.load": {
  id: "Load average",
  en: "Load average"
},
"ping.arch": {
  id: "Arsitektur",
  en: "Architecture"
},
"ping.hostname": {
  id: "Hostname",
  en: "Hostname"
},
"ping.ramUse": {
  id: "RAM terpakai",
  en: "RAM used"
},
"ping.ramFree": {
  id: "RAM bebas",
  en: "RAM free"
},
"ping.botUse": {
  id: "Pakai bot",
  en: "Bot usage"
},
"ping.disk": {
  id: "DISK",
  en: "DISK"
},
"ping.diskUse": {
  id: "Disk terpakai",
  en: "Disk used"
},
"ping.diskFree": {
  id: "Disk bebas",
  en: "Disk free"
},
"ping.activeErrors": {
  id: "Error aktif",
  en: "Active errors"
},
"port5.joined": {
  id: "Bergabung",
  en: "Joined"
},
"port5.recentRepos": {
  id: "Repo terbaru",
  en: "Recent repos"
},
"port5.latest": {
  id: "Versi terbaru",
  en: "Latest version"
},
"port5.modified": {
  id: "Diupdate",
  en: "Updated"
},
"port5.versions": {
  id: "Total versi",
  en: "Total versions"
},
"port5.tikwmDead": {
  id: "🚫 Search TikTok tidak tersedia (API tikwm diblokir Cloudflare).",
  en: "🚫 TikTok search unavailable (tikwm API blocked by Cloudflare)."
},
"port5.tikwmAlt": {
  id: "💡 Gunakan /ttsearch sebagai alternatif.",
  en: "💡 Use /ttsearch instead."
},
"port5.skStart": {
  id: "Kata awal",
  en: "Starting word"
},
"port5.skRule": {
  id: "Balas dengan kata berujung",
  en: "Reply with a word ending in"
},
"port5.ended": {
  id: "diakhiri.",
  en: "ended."
},
"port5.nextWord": {
  id: "Lanjut! Kata berikutnya harus berujung",
  en: "Next! Word must end with"
},
"webx.noArchive": {
  id: "Belum ada arsip Wayback untuk URL itu",
  en: "No Wayback snapshot for that URL"
},
"webx.snapshot": {
  id: "Snapshot",
  en: "Snapshot"
},
"webx.date": {
  id: "Tanggal",
  en: "Date"
},
"webx.open": {
  id: "Buka arsip",
  en: "Open archive"
},
"webx.media": {
  id: "media",
  en: "media"
},
"webx.tempmailHint": {
  id: "Email sementara aktif ~10 menit. Cek inbox:",
  en: "Temp mail active ~10 min. Check inbox:"
},
"webx.noTempmail": {
  id: "Belum buat temp mail. Buat dulu:",
  en: "No temp mail yet. Create first:"
},
"webx.inboxEmpty": {
  id: "Inbox kosong.",
  en: "Inbox empty."
},
"webx.from": {
  id: "Dari",
  en: "From"
},
"game.hintBtn": {
  id: "Petunjuk",
  en: "Hint"
},
"game.surrender": {
  id: "Menyerah",
  en: "Surrender"
},
"game.none": {
  id: "Tidak ada game aktif untuk kamu.",
  en: "No active game for you."
},
"game.hint": {
  id: "Petunjuk",
  en: "Hint"
},
"game.answerWas": {
  id: "Jawabannya",
  en: "The answer was"
},
"game.correct": {
  id: "Benar! Jawabannya",
  en: "Correct! The answer was"
},
"menu.btnFaker": {
  id: "🎭 Faker",
  en: "🎭 Faker"
},
"menu.btnWebx": {
  id: "🌐 Web & Music",
  en: "🌐 Web & Music"
},
"menu.btnNews": {
  id: "📰 News & Primbon",
  en: "📰 News & Primbon"
},
"menu.hint.fakerKtp": {
  id: "Buat e-KTP fake realistis (render lokal)",
  en: "Create realistic fake e-KTP (local render)"
},
"menu.hint.fakerPay": {
  id: "Fake payment Dana/OVO/Gopay/BCA",
  en: "Fake Dana/OVO/Gopay/BCA payment"
},
"menu.hint.fakerGame": {
  id: "Fake lobby Free Fire / Mobile Legends",
  en: "Fake Free Fire / ML lobby"
},
"menu.hint.fakerChat": {
  id: "Fake chat WA / tweet / voice note",
  en: "Fake WA chat / tweet / voice note"
},
"menu.hint.fakerSoc": {
  id: "Fake profil IG / story / threads",
  en: "Fake IG profile / story / threads"
},
"menu.hint.fakerHp": {
  id: "Fake notifikasi & panggilan HP",
  en: "Fake phone notifications & calls"
},
"menu.hint.genius": {
  id: "Cari lagu + link via Genius",
  en: "Search songs + links via Genius"
},
"menu.hint.archive": {
  id: "Cari file di Internet Archive",
  en: "Search files on Internet Archive"
},
"menu.hint.tweet": {
  id: "Info tweet + media dari URL",
  en: "Tweet info + media from URL"
},
"menu.hint.tempmail": {
  id: "Buat & cek email sementara",
  en: "Create & check temporary email"
},
"menu.hint.searchfit": {
  id: "Cari semua fitur bot dari kata kunci",
  en: "Search all bot features by keyword"
},
"menu.hint.ffstalk": {
  id: "Cek nickname akun Free Fire",
  en: "Check Free Fire account nickname"
},
"menu.hint.berita": {
  id: "Berita terbaru dari portal Indonesia",
  en: "Latest news from Indonesian portals"
},
"menu.hint.primbonApi": {
  id: "Primbon via API (arti nama, mimpi, jodoh)",
  en: "Primbon via API (name meaning, dreams, match)"
},
"menu.hint.kodepos": {
  id: "Cari kode pos Indonesia",
  en: "Search Indonesian postal codes"
},
"menu.hint.searchApi": {
  id: "Search engine & musik via API",
  en: "Search engines & music via API"
},
"searchfit.hint": {
  id: "Cari dari {n} fitur bot dengan kata kunci:",
  en: "Search {n} bot features by keyword:"
},
"searchfit.none": {
  id: "Tidak ada fitur untuk: {q}",
  en: "No feature found for: {q}"
},
"searchfit.found": {
  id: "Ditemukan {n} (dari {total} fitur):",
  en: "Found {n} (of {total} features):"
},
"searchfit.tap": {
  id: "Tekan tombol untuk langsung menjalankan.",
  en: "Tap a button to run it instantly."
},
"rose.fedBanned": {
  id: "Fed ban dijalankan di",
  en: "Fed ban executed in"
},
"rose.purgeFrom": {
  id: "🧹 Titik awal purge diset di pesan",
  en: "🧹 Purge start point set at message"
},
"rose.purgeNowTo": {
  id: "sekarang reply pesan akhir lalu kirim /purgeto",
  en: "now reply the end message and send /purgeto"
},
"rose.purgeNoFrom": {
  id: "⚠️ Belum ada /purgefrom. Reply pesan awal → /purgefrom dulu.",
  en: "⚠️ No /purgefrom yet. Reply the start message → /purgefrom first."
},
"rose.captchaKickSet": {
  id: "Kick-time captcha diset ke",
  en: "Captcha kick-time set to"
},
"rose.language": {
  id: "Bahasa",
  en: "Language"
},
"rose.langSet": {
  id: "Bahasa diganti ke",
  en: "Language changed to"
},
"rose.sentToPm": {
  id: "📩 Note dikirim ke PM kamu.",
  en: "📩 Note sent to your PM."
},
"menu.hint.roseAdmin2": {
  id: "Kelola admin grup, log channel & setelan lanjutan",
  en: "Manage group admins, log channel & advanced settings"
},
"menu.hint.roseMisc": {
  id: "Utilitas info grup/user & pencarian",
  en: "Group/user info utilities & search"
},
"menu.hint.barkerAdv": {
  id: "Fitur lanjutan Barker: helper bot & template tag",
  en: "Barker advanced: helper bots & tag templates"
},
"rose.action": {
  id: "Aksi akhir",
  en: "Final action"
},
"rose.adminCache": {
  id: "Cache admin di-refresh, total",
  en: "Admin cache refreshed, total"
},
"rose.backOnline": {
  id: "Selamat datang kembali!",
  en: "Welcome back!"
},
"rose.captchaMuteSet": {
  id: "Mute awal captcha di-set",
  en: "Captcha initial mute set"
},
"rose.captchaTextSet": {
  id: "Teks captcha custom di-set",
  en: "Custom captcha text set"
},
"rose.chatId": {
  id: "ID Chat",
  en: "Chat ID"
},
"rose.demoted": {
  id: "Di-demote",
  en: "Demoted"
},
"rose.exported": {
  id: "Setting grup di-export",
  en: "Settings exported"
},
"rose.fedDeleted": {
  id: "Federasi dihapus",
  en: "Federation deleted"
},
"rose.fedDemoted": {
  id: "Dihapus dari admin fed",
  en: "Removed from fed admins"
},
"rose.fedName": {
  id: "nama",
  en: "name"
},
"rose.fedNotBanned": {
  id: "Tidak di-ban di fed ini",
  en: "Not banned in this fed"
},
"rose.fedOwner": {
  id: "Hanya pemilik fed yang bisa",
  en: "Only fed owner can do this"
},
"rose.fedRenamed": {
  id: "Fed di-rename jadi",
  en: "Fed renamed to"
},
"rose.groupLink": {
  id: "Link Grup",
  en: "Group Link"
},
"rose.helperAdd": {
  id: "Helper bot ditambahkan",
  en: "Helper bot added"
},
"rose.importFail": {
  id: "Import gagal",
  en: "Import failed"
},
"rose.importHint": {
  id: "Reply file .json settings dengan /import",
  en: "Reply the settings .json file with /import"
},
"rose.imported": {
  id: "Setting di-import",
  en: "Settings imported"
},
"rose.latency": {
  id: "Latensi",
  en: "Latency"
},
"rose.logSet": {
  id: "Channel log di-set",
  en: "Log channel set"
},
"rose.noFedChat": {
  id: "Chat ini tidak tergabung federasi",
  en: "This chat is not in any federation"
},
"rose.priv1": {
  id: "disimpan hanya untuk moderasi (warn/ban)",
  en: "stored only for moderation (warns/bans)"
},
"rose.priv2": {
  id: "disimpan per-grup saja",
  en: "stored per-group only"
},
"rose.priv3": {
  id: "counter per-grup, bisa direset admin",
  en: "per-group counters, resettable by admins"
},
"rose.priv4": {
  id: "Tidak ada data dibagikan ke luar bot",
  en: "Nothing is shared outside this bot"
},
"rose.promoted": {
  id: "Di-promote",
  en: "Promoted"
},
"rose.reason": {
  id: "Alasan",
  en: "Reason"
},
"rose.rules": {
  id: "Rules",
  en: "Rules"
},
"rose.rulesCleared": {
  id: "Rules dihapus",
  en: "Rules cleared"
},
"rose.rulesPh": {
  id: "teks rules",
  en: "the rules text"
},
"rose.rulesSaved": {
  id: "Rules disimpan",
  en: "Rules saved"
},
"rose.spamHit": {
  id: "Proteksi spam terpicu",
  en: "Spam protection triggered"
},
"rose.udNo": {
  id: "Tidak ada hasil Urban Dictionary",
  en: "No Urban Dictionary result"
},
"rose.unwarnBtn": {
  id: "hapus warning",
  en: "remove warning"
},
"rose.userId": {
  id: "ID User",
  en: "User ID"
},
"rose.varFirst": {
  id: "nama depan",
  en: "first name"
},
"rose.warnLimitHit": {
  id: "LIMIT WARN TERCAPAI",
  en: "WARN LIMIT REACHED"
},
"rose.warnMinus": {
  id: "Warning dikurangi, jadi",
  en: "Warning removed, now"
},
"rose.warnReset": {
  id: "Semua warning direset untuk",
  en: "All warnings reset for"
},
"rose.warnSelf": {
  id: "Tidak bisa warning diri sendiri",
  en: "You can't warn yourself"
},
"rose.warnZero": {
  id: "User tidak punya warning",
  en: "User has no warnings"
},
"rose.welcomeSet": {
  id: "Pesan welcome di-set",
  en: "Welcome message set"
},
"rose.welcomeText": {
  id: "teks welcome",
  en: "the welcome text"
},
"rose.you": {
  id: "Kamu",
  en: "You"
},
"rose.fedUnbanned": {
  id: "Fed ban dicabut.",
  en: "Fed ban removed."
},
"rose.fedPromoted": {
  id: "Fed admin dipromosikan.",
  en: "Federation admin promoted."
},
"barker.noMembers": {
  id: "📭 Belum ada member tercache. Minta mereka chat dulu.",
  en: "📭 No cached members yet. Ask them to chat first."
},
"barker.admins": {
  id: "PANGGILAN ADMIN",
  en: "ADMIN CALL"
},
"barker.callsignSet": {
  id: "Callsign diset",
  en: "Callsign set"
},
"barker.noCallsign": {
  id: "Belum ada callsign. Set dengan /setme emoji|teks",
  en: "No callsign yet. Set one with /setme emoji|text"
},
"barker.unregOn": {
  id: "Kamu TIDAK akan ditag lagi di /all (semua grup).",
  en: "You will NOT be tagged in /all anymore (all chats)."
},
"barker.unregOff": {
  id: "Kamu akan ditag lagi di /all.",
  en: "You will be tagged in /all again."
},
"barker.upatternsInfo": {
  id: "Keluar/masuk dari tag massal",
  en: "Opt out/in of mass tagging"
},
"barker.cpatternsInfo": {
  id: "Kelola panggilan personalmu",
  en: "Manage your personal callsign"
},
"shield.readMsgs": {
  id: "Baca pesan",
  en: "Read messages"
},
"shield.delMsgs": {
  id: "Hapus pesan",
  en: "Delete messages"
},
"shield.banUsers": {
  id: "Ban user",
  en: "Ban users"
},
"shield.activeFeatures": {
  id: "Fitur aktif",
  en: "Active features"
},
"shield.setupHint": {
  id: "Aktifkan fitur dengan",
  en: "Enable features with"
},
"shield.imageHint": {
  id: "Reply foto + /checknsfw untuk tes manual.",
  en: "Reply a photo with /checknsfw to test manually."
},
"shield.wbInfo": {
  id: "Ban lintas-grup berdasarkan riwayat pelanggaran user (max 10).",
  en: "Cross-group bans based on user violation history (max 10)."
},
"shield.wbCheck": {
  id: "Cek pelanggaran user",
  en: "Check user violations"
},
"shield.wbCount": {
  id: "Total pelanggaran",
  en: "Total violations"
},
"shield.antispamMode": {
  id: "Mode antispam",
  en: "Antispam mode"
},
"shield.reported": {
  id: "Spam dilaporkan & dihapus!",
  en: "Spam reported & deleted!"
},
"shield.replyPhoto": {
  id: "🔎 Reply fotonya dulu.",
  en: "🔎 Reply to the photo first."
},
"shield.nsfwLabel": {
  id: "Label",
  en: "Label"
},
"shield.confidence": {
  id: "Keyakinan",
  en: "Confidence"
},
"shield.nsfwDetected": {
  id: "Konten dewasa terdeteksi!",
  en: "Adult content detected!"
},
"shield.safe": {
  id: "Foto aman.",
  en: "Photo looks safe."
},
"menu.btnRose": {
  id: "🌹 Rose Moderation",
  en: "🌹 Rose Moderation"
},
"menu.btnShield": {
  id: "🛡️ Shield Protectron",
  en: "🛡️ Shield Protectron"
},
"menu.btnBarker": {
  id: "📣 Barker Tag",
  en: "📣 Barker Tag"
},
"menu.hint.connect": {
  id: "Kelola grup dari PM (max 5)",
  en: "Manage groups from PM (max 5)"
},
"menu.hint.roseMod": {
  id: "Ban/mute/kick + varian d/s + temp (10m/2h/3d/1w)",
  en: "Ban/mute/kick + d/s variants + temp (10m/2h/3d/1w)"
},
"menu.hint.roseWarn": {
  id: "Konfigurasi warning grup",
  en: "Group warning configuration"
},
"menu.hint.rosePurge": {
  id: "Hapus pesan massal (reply pesan lama)",
  en: "Mass delete messages (reply to oldest)"
},
"menu.hint.roseLocks": {
  id: "Lock tipe pesan (gif/video/sticker/dll)",
  en: "Lock message types (gif/video/sticker/etc)"
},
"menu.hint.roseBlocklist": {
  id: "Kata terlarang + custom punishment",
  en: "Forbidden words + custom punishment"
},
"menu.hint.roseFlood": {
  id: "Antiflood per grup",
  en: "Per-group antiflood"
},
"menu.hint.roseRaid": {
  id: "Anti raid join member",
  en: "Member-join raid protection"
},
"menu.hint.roseCaptcha": {
  id: "Verifikasi member baru (button/math)",
  en: "New member verification (button/math)"
},
"menu.hint.roseWelcome": {
  id: "Welcome/goodbye + fillings {first} {chatname}",
  en: "Welcome/goodbye + fillings {first} {chatname}"
},
"menu.hint.roseFilters": {
  id: "Auto-reply keyword",
  en: "Keyword auto-reply"
},
"menu.hint.roseNotes": {
  id: "Simpan/ambil note (#trigger)",
  en: "Save/get notes (#trigger)"
},
"menu.hint.roseFed": {
  id: "Federation: ban lintas grup",
  en: "Federation: cross-group bans"
},
"menu.hint.shieldToggles": {
  id: "Toggle filter: link/forward/location/dll",
  en: "Toggle filters: links/forwards/location/etc"
},
"menu.hint.shieldBlacklist": {
  id: "Blacklist/whitelist kata",
  en: "Word blacklist/whitelist"
},
"menu.hint.shieldWb": {
  id: "Ban lintas-grup pelanggar berulang",
  en: "Cross-group ban for repeat offenders"
},
"menu.hint.shieldStatus": {
  id: "Cek permission bot + fitur aktif",
  en: "Check bot permissions + active features"
},
"menu.hint.barkerAll": {
  id: "Tag semua member (batching anti-limit)",
  en: "Tag all members (batched anti-limit)"
},
"menu.hint.barkerCall": {
  id: "Tag satu-satu atau admin saja",
  en: "Tag one-by-one or admins only"
},
"menu.hint.barkerMe": {
  id: "Callsign personal (emoji/teks)",
  en: "Personal callsign (emoji/text)"
},
"menu.hint.errRaw": {
  id: "Format error siap kirim ke AI (file:baris:kode)",
  en: "AI-ready error format (file:line:code)"
},
"test.errRaw": {
  id: "📋 FORMAT ERROR (AI-READY)",
  en: "📋 ERROR FORMAT (AI-READY)"
},
"test.noErr": {
  id: "✅ Fitur ini tidak ada error.",
  en: "✅ This feature has no errors."
},

/* ================= PORTING WA BATCH-4 (textmaker3, islamic3, games3, media3, nekos3, quotegen, primbon2) ================= */

"common.enjoy": {
  id: "Semoga suka!",
  en: "Enjoy!"
},
"tm3.needText": {
  id: "Teksnya mana? Contoh:",
  en: "Where is the text? Example:"
},
"tm3.needMore": {
  id: "Butuh {n} teks (pisah dengan |). Contoh:",
  en: "Needs {n} texts (separate with |). Example:"
},
"tm3.needPhoto": {
  id: "⚠️ Kirim/reply foto dulu, lalu ketik commandnya lagi.",
  en: "⚠️ Send/reply a photo first, then type the command again."
},
"tm3.making": {
  id: "⏳ Membuat efek...",
  en: "⏳ Creating effect..."
},
"tm3.done": {
  id: "selesai!",
  en: "done!"
},
"tm3.fail": {
  id: "❌ Gagal membuat efek. Coba lagi nanti.",
  en: "❌ Failed to create effect. Try again later."
},
"fx.pageInfo": {
  id: "Halaman {page}/{pages} — ketik /listfx kata untuk mencari",
  en: "Page {page}/{pages} — type /listfx word to search"
},
"isl3.surahHint": {
  id: "Ketik {px}surah 1 atau {px}surah al-fatihah",
  en: "Type {px}surah 1 or {px}surah al-fatihah"
},
"isl3.surahNotFound": {
  id: "❌ Surah tidak ditemukan (1-114 atau nama).",
  en: "❌ Surah not found (1-114 or name)."
},
"isl3.moreAyah": {
  id: "{n} ayat lainnya",
  en: "{n} more verses"
},
"isl3.downloading": {
  id: "⏳ Mengunduh audio...",
  en: "⏳ Downloading audio..."
},
"isl3.audioLink": {
  id: "Audio terlalu besar untuk dikirim langsung:",
  en: "Audio too large to send directly:"
},
"isl3.doaHint": {
  id: "Ketik {px}doa 1 atau {px}doa makan",
  en: "Type {px}doa 1 or {px}doa makan"
},
"isl3.doaNotFound": {
  id: "❌ Doa tidak ditemukan. Coba nomor atau kata kunci lain.",
  en: "❌ Prayer not found. Try another number or keyword."
},
"prim2.usage": {
  id: "Format penggunaan:",
  en: "Usage format:"
},
"media3.mcOffline": {
  id: "Server offline",
  en: "Server is offline"
},
"media3.kursNotFound": {
  id: "Kode mata uang tidak ditemukan",
  en: "Currency code not found"
},
"media3.pickBelow": {
  id: "Tap tombol di bawah untuk membuka detail:",
  en: "Tap a button below to open details:"
},
"qt.needName": {
  id: "Butuh nama. Contoh:",
  en: "Name required. Example:"
},
"menu.btnEffects": {
  id: "🎨 Effect Maker",
  en: "🎨 Effect Maker"
},
"menu.hint.listfx": {
  id: "Lihat semua 800+ efek",
  en: "Browse all 800+ effects"
},
"menu.hint.fxText": {
  id: "Efek teks dari teksmu",
  en: "Text effect from your text"
},
"menu.hint.fxText2": {
  id: "Efek dengan 2 input teks",
  en: "Effect with 2 text inputs"
},
"menu.hint.fxPhoto": {
  id: "Efek photo frame",
  en: "Photo frame effect"
},
"menu.hint.soal3": {
  id: "Lihat soal kuis yang aktif",
  en: "Show the active quiz question"
},
"menu.hint.surah3": {
  id: "Baca surah + audio",
  en: "Read surah + audio"
},
"menu.hint.ayat3": {
  id: "Satu ayat + terjemahan",
  en: "Single verse + translation"
},
"menu.hint.murotal3": {
  id: "Audio per surah",
  en: "Audio per surah"
},
"menu.hint.kiblat3": {
  id: "Arah kiblat & kalender hijriah",
  en: "Qibla direction & Hijri calendar"
},
"menu.hint.ttnowm": {
  id: "TikTok tanpa watermark/audio/info",
  en: "TikTok no-watermark/audio/info"
},
"menu.hint.mcserver": {
  id: "Status server Minecraft",
  en: "Minecraft server status"
},
"menu.hint.kurs": {
  id: "Kurs mata uang",
  en: "Currency exchange rates"
},
"menu.hint.gempa2": {
  id: "Gempa dirasakan (BMKG)",
  en: "Felt earthquakes (BMKG)"
},
"menu.hint.provinsi": {
  id: "Wilayah Indonesia: provinsi→desa",
  en: "Indonesia regions: province→village"
},

}

/* ================= DB ================= */

let cache = null

function read() {
  if (cache !== null) return cache
  try {
    const raw = JSON.parse(fs.readFileSync(DB_PATH, "utf8"))
    cache = raw && typeof raw === "object" && !Array.isArray(raw) ? raw : {}
  } catch {
    cache = {}
  }
  return cache
}

function write() {
  try {
    fs.mkdirSync(path.dirname(DB_PATH), { recursive: true })
    fs.writeFileSync(DB_PATH, JSON.stringify(cache || {}, null, 2))
  } catch (e) {
    console.log("LANG DB ERR:", e.message)
  }
}

const isSupported = (lang) => SUPPORTED.includes(String(lang || "").toLowerCase())

function getLang(uid) {
  const db = read()
  const val = String(db[String(uid)] || "").toLowerCase()
  return isSupported(val) ? val : DEFAULT_LANG
}

function setLang(uid, lang) {
  const val = String(lang || "").toLowerCase()
  if (!isSupported(val)) return false
  read()[String(uid)] = val
  write()
  return true
}

/* ================= TRANSLATE ================= */

function t(lang, key, vars = {}) {
  const entry = STRINGS[key]
  if (!entry) return key

  const use = isSupported(lang) ? lang : DEFAULT_LANG
  let out = entry[use] ?? entry[DEFAULT_LANG] ?? entry.en ?? key

  for (const [k, v] of Object.entries(vars)) {
    out = out.split("{" + k + "}").join(v === undefined || v === null ? "" : String(v))
  }
  return out
}

/* t() yang sudah terikat ke bahasa satu user */
function tFor(uid) {
  const lang = getLang(uid)
  return (key, vars) => t(lang, key, vars)
}

/* ================= HELPER TAMPILAN ================= */

const label = (lang, code) => {
  const m = META[code] || {}
  return t(lang, "lang.label", { flag: m.flag || "", name: m.name || code })
}

const list = () => SUPPORTED.map((c) => c).join(" | ")

/* Tombol picker bahasa (flag + warna) */
function langKeyboard(active) {
  const now = String(active || "").toLowerCase()
  return SUPPORTED.map((code) => ({
    text: `${META[code] ? META[code].flag + " " : ""}${META[code] ? META[code].name : code}${now === code ? " ✅" : ""}`,
    callback_data: `/lang ${code}`,
    style: META[code] ? META[code].style : undefined
  }))
}

/* ============================================================
   global.mess lama (settings.js) tetap ada supaya plugin buatan
   sendiri tidak rusak, tapi isinya diambil dari kamus di atas
   dalam bahasa default. Satu sumber teks = language.js.
   ============================================================ */
global.mess = {
  creator: t(DEFAULT_LANG, "denied.creator"),
  owner: t(DEFAULT_LANG, "denied.owner"),
  admin: t(DEFAULT_LANG, "denied.admin"),
  seller: t(DEFAULT_LANG, "denied.seller"),
  super: t(DEFAULT_LANG, "denied.super"),
  group: t(DEFAULT_LANG, "denied.group"),
  private: t(DEFAULT_LANG, "denied.private"),
  prem: t(DEFAULT_LANG, "denied.prem"),
  wait: "Loading...",
  error: "Error",
  done: "Done"
}

/* ============================================================
   AUTO-TRANSLATE (fallback lapisan ke-2)
   Sisa teks ID hardcoded dari plugin mana pun otomatis diganti
   ke EN saat output (m.reply/m.send) dipakai user mode EN.
   Aturan: frase umum + istilah khas ("Panel", "Sticker", dll)
   — bukan terjemahan penuh, cukup supaya hasilnya natural.
   Hanya menyentuh teks yang TIDAK dalam tag HTML.
   ============================================================ */

const ID_EN_PHRASES = [
  /* multi-word dulu (sebelum kata tunggal) */
  [/\bAngka apa yang kamu lihat di gambar\??/g, "What number do you see in the image?"],
  [/\bBrand apa ini\??/g, "Which brand is this?"],
  [/\bSiapa nama member ini\??/g, "Who is this member?"],
  [/\bHero siapa yang mendengar voice line ini\??/g, "Which hero does this voice line belong to?"],
  [/\bJaringan\/API islami sedang bermasalah[^.]*\.?/g, "Islamic network/API is having issues — try again in a moment."],
  [/\bSearch TikTok tidak tersedia \(API diblokir\)\.?/g, "TikTok search unavailable (API blocked)."],
  [/\bGunakan \/ttsearch sebagai alternatif\.?/g, "Use /ttsearch instead."],
  [/\bTitik awal purge diset di pesan/g, "Purge start point set at message"],
  [/\bsekarang reply pesan akhir lalu kirim \/purgeto/g, "now reply the end message and send /purgeto"],
  [/\bBelum ada \/purgefrom\.[^\u26a0\ufe0f]*/g, "No /purgefrom yet. "],
  [/\bReply pesan awal → \/purgefrom dulu\./g, "Reply the start message → /purgefrom first."],
  [/\bNote dikirim ke PM kamu\.?/g, "Note sent to your PM."],
  [/\bBahasa diganti ke/g, "Language changed to"],
  [/\bKick-time captcha diset ke/g, "Captcha kick-time set to"],
  [/\bGagal mengambil gambar anime/g, "Failed to fetch anime image"],
  [/\bMencari gambar\.\.\./g, "Searching image..."],
  [/\baccount gagal dibuat/g, "account creation failed"],
  [/\bHanya owner yang bisa menjalankan perintah ini\.?/g, "Only the owner can run this command."],
  [/\bHanya admin grup\.?/g, "Group admins only."],
  [/\bHanya di grup\.?/g, "Groups only."],
  [/\bdaftarkan grup\/chat ini sebagai penerima\b/g, "register this chat as a recipient"],
  [/\bdaftarkan grup dengan ID tertentu\b/g, "register a group by ID"],
  [/\btest kirim gagal\b/g, "test send failed"],
  [/\bTest pesan berhasil dikirim\.?/g, "Test message sent successfully."],
  [/\bTest pesan gagal\b/g, "Test message failed"],
  [/\bpastikan bot sudah masuk grup\.?/g, "make sure the bot joined the group."],
  [/\bSelamat datang kembali!\s*/g, "Welcome back! "],
  [/\bKamu afk selama\b/g, "You were AFK for"],
  [/\bBackup gagal\b/g, "Backup failed"],
  [/\bSesi clone sudah ada\.?/g, "A clone session already exists."],
  [/\bBelum ada clone yang berjalan\.?/g, "No clone running."],
  [/\bBelum ada clone\.?/g, "No clone yet."],
  [/\bID owner harus angka\.?/g, "Owner ID must be numeric."],
  [/\bCLONE BERHASIL DIBUAT!?/g, "CLONE CREATED!"],
  [/\bClone bot sudah berjalan dengan database terpisah\.?/g, "Clone bot already running with a separate database."],
  [/\bGagal membuat clone\b/g, "Failed to create clone"],
  [/\bGagal mengambil gambar\b/g, "Failed to fetch image"],
  [/\bKecocokan cinta\b/g, "Love match"],
  [/\bpertanyaan kamu\b/g, "your question"],
  [/\bLihat panel kamu\b/g, "View your panels"],
  [/\bRingkasan panel kamu\b/g, "Your panel summary"],
  [/\bWarn user \(grup\)\b/g, "Warn user (group)"],
  [/\bRules grup\b/g, "Group rules"],
  [/\bdaftar\b/g, "list"],
  [/\bDaftar\b/g, "List"],
  [/\bgrup\b/g, "group"],
  [/\bGrup\b/g, "Group"],
  [/\bGagal mencari\b/g, "Failed to search"],
  [/\bMencari di YouTube\b/g, "Searching YouTube"],
  [/\bMencari:\b/g, "Searching:"],
  [/\bmencari\b/g, "searching"],
  [/\bTidak ada game aktif\b/g, "No active game"],
  [/\bCara pakai\b/g, "How to use"],
  [/\bCoba kata kunci lain\b/g, "Try different keywords"],
  [/\bTerima kasih\b/g, "Thank you"],
  [/\bFormat salah\b/g, "Wrong format"],
  [/\bFormat tidak valid\b/g, "Invalid format"],
  [/\bCoba lagi nanti\b/g, "Try again later"],
  [/\bGagal mengambil\b/g, "Failed to fetch"],
  [/\bGagal memproses\b/g, "Failed to process"],
  [/\bGagal kirim\b/g, "Failed to send"],
  [/\bLagu tidak ditemukan\b/g, "Song not found"],
  [/\bKota tidak ditemukan\b/g, "City not found"],
  [/\bNabi tidak ditemukan\b/g, "Prophet not found"],
  [/\bZodiak tidak ditemukan\b/g, "Zodiac not found"],
  [/\bPaket tidak ditemukan\b/g, "Package not found"],
  [/\bTidak ditemukan hasil\b/g, "No results found"],
  [/\bberhasil dikirim\b/g, "sent successfully"],
  [/\bBerhasil dikirim\b/g, "Sent successfully"],
  [/\bSedang diproses\b/g, "Processing"],
  [/\bPenggunaan\b/g, "Usage"],
  /* fun/games/quiz common */
  [/\bPertanyaan\b/g, "Question"],
  [/\bpertanyaan\b/g, "question"],
  [/\bJawaban\b/g, "Answer"],
  [/\bjawaban\b/g, "answer"],
  [/\bBisa jadi\b/g, "Maybe"],
  [/\bbisa jadi\b/g, "maybe"],
  [/\bTentu saja\b/g, "Of course"],
  [/\bTentu\b/g, "Sure"],
  [/\bMungkin\b/g, "Maybe"],
  [/\bmungkin\b/g, "maybe"],
  [/\bJawaban benar\b/g, "Correct answer"],
  [/\bJawaban salah\b/g, "Wrong answer"],
  [/\bBenar\b/g, "Correct"],
  [/\bbenar\b/g, "correct"],
  [/\bSalah\b/g, "Wrong"],
  [/\bsalah\b/g, "wrong"],
  [/\bMenang\b/g, "You win"],
  [/\bKalah\b/g, "You lose"],
  [/\bSkor\b/g, "Score"],
  [/\bNyawa\b/g, "Lives"],
  [/\bWaktu habis\b/g, "Time's up"],
  [/\bSelamat\b/g, "Congratulations"],
  [/\bBagus\b/g, "Nice"],
  [/\bKeren\b/g, "Cool"],
  [/\bGila\b/g, "Crazy"],
  [/\bMulai\b/g, "Start"],
  [/\bWaduh\b/g, "Whoa"],
  [/\bTepat\b/g, "Exactly"],
  [/\bHebat\b/g, "Awesome"],
  [/\bPemenang\b/g, "Winner"],
  [/\bMain lagi\b/g, "Play again"],
  [/\bYa\b/g, "Yes"],
  [/\bTidak\b/g, "No"],
  [/\bIya\b/g, "Yes"],
  [/\bSudah\b/g, "Already"],
  [/\bAku\b/g, "I"],
  [/\bKamu\b/g, "You"],
  [/\bkamu\b/g, "you"],
  [/\bContoh\b/g, "Example"],
  [/\bGagal\b/g, "Failed"],
  [/\bBerhasil\b/g, "Success"],
  [/\bSukses\b/g, "Success"],
  [/\bMencari\b/g, "Searching"],
  [/\bDitemukan\b/g, "found"],
  [/\btidak ditemukan\b/g, "not found"],
  [/\bTidak ditemukan\b/g, "Not found"],
  [/\bTidak ada\b/g, "No"],
  [/\btidak ada\b/g, "no"],
  [/\btidak valid\b/g, "invalid"],
  [/\bTidak valid\b/g, "Invalid"],
  [/\bGunakan\b/g, "Use"],
  [/\bgunakan\b/g, "use"],
  [/\bMasukkan\b/g, "Enter"],
  [/\bKirim\b/g, "Send"],
  [/\bkirim\b/g, "send"],
  [/\bMengirim\b/g, "Sending"],
  [/\bMendownload\b/g, "Downloading"],
  [/\bMengambil\b/g, "Fetching"],
  [/\bMemproses\b/g, "Processing"],
  [/\bMembuat\b/g, "Making"],
  [/\bTunggu\b/g, "Wait"],
  [/\btunggu\b/g, "wait"],
  [/\bSebentar\b/g, "a moment"],
  [/\bSelesai\b/g, "Done"],
  [/\bselesai\b/g, "done"],
  [/\bBalas\b/g, "Reply"],
  [/\bbalas\b/g, "reply"],
  [/\bReply\b/g, "Reply"],
  [/\bFormat salah\b/g, "Wrong format"],
  [/\bFormat tidak valid\b/g, "Invalid format"],
  [/\bCoba lagi nanti\b/g, "Try again later"],
  [/\bcoba lagi\b/g, "try again"],
  [/\bKata kunci\b/g, "Keyword"],
  [/\bnama\b/g, "name"],
  [/\bNama\b/g, "Name"],
  [/\bWaktu\b/g, "Time"],
  [/\bwaktu\b/g, "time"],
  [/\bJumlah\b/g, "Amount"],
  [/\bStatus\b/g, "Status"],
  [/\bDurasi\b/g, "Duration"],
  [/\bChannel\b/g, "Channel"],
  [/\bhasil\b/g, "result"],
  [/\bHasil\b/g, "Result"],
  [/\bQuery\b/g, "Query"],
  [/\bPencarian\b/g, "Search"],
  [/\bKuis\b/g, "Quiz"],
  [/\bGames\b/g, "Games"],
  [/\bCara pakai\b/g, "How to use"],
  [/\bHapus\b/g, "Delete"],
  [/\bhapus\b/g, "delete"],
  [/\bDaftar\b/g, "List"],
  [/\bdaftar\b/g, "list"],
  [/\bLihat\b/g, "View"],
  [/\blihat\b/g, "view"],
  [/\bAtur\b/g, "Set"],
  [/\batur\b/g, "set"],
  [/\bUbah\b/g, "Change"],
  [/\bubah\b/g, "change"],
  [/\bTambah\b/g, "Add"],
  [/\btambah\b/g, "add"],
  [/\bSemua\b/g, "All"],
  [/\bsemua\b/g, "all"],
  [/\bKosong\b/g, "Empty"],
  [/\bkosong\b/g, "empty"],
  [/\bSedang\b/g, "Currently"],
  [/\bSudah\b/g, "Already"],
  [/\bBelum\b/g, "Not yet"],
  [/\bAktif\b/g, "Active"],
  [/\bNonaktif\b/g, "Inactive"],
  [/\bGambar\b/g, "Image"],
  [/\bgambar\b/g, "image"],
  [/\bFoto\b/g, "Photo"],
  [/\bfoto\b/g, "photo"],
  [/\bVideo\b/g, "Video"],
  [/\bLagu\b/g, "Song"],
  [/\blagu\b/g, "song"],
  [/\bLirik\b/g, "Lyrics"],
  [/\b Kota\b/g, " City"],
  [/\bkota\b/g, "city"],
  [/\bKota\b/g, "City"],
  [/\bCuaca\b/g, "Weather"],
  [/\bcuaca\b/g, "weather"],
  [/\bGempa\b/g, "Earthquake"],
  [/\bgempa\b/g, "earthquake"],
  [/\bStiker\b/g, "Sticker"],
  [/\bstiker\b/g, "sticker"],
  [/\bPaket\b/g, "Package"],
  [/\bpaket\b/g, "package"],
  [/\bPanel\b/g, "Panel"],
  [/\bServer\b/g, "Server"],
  [/\bserver\b/g, "server"],
  [/\bRam\b/g, "RAM"],
  [/\bCpu\b/g, "CPU"],
  [/\bDisk\b/g, "Disk"],
  [/\bBulan\b/g, "Month(s)"],
  [/\bbulan\b/g, "month(s)"],
  [/\bHari\b/g, "Day(s)"],
  [/\bhari\b/g, "day(s)"],
  [/\bJam\b/g, "Hour(s)"],
  [/\bjam\b/g, "hour(s)"],
  [/\bMenit\b/g, "minute(s)"],
  [/\bDetik\b/g, "seconds"],
  [/\bUsername\b/g, "Username"],
  [/\bUser\b/g, "User"],
  [/\bOwner\b/g, "Owner"],
  [/\bAdmin\b/g, "Admin"],
  [/\bGrup\b/g, "Group"],
  [/\bgrup\b/g, "group"],
  [/\bGroup\b/g, "Group"],
  [/\bPesan\b/g, "Message"],
  [/\bpesan\b/g, "message"],
  [/\bTeks\b/g, "Text"],
  [/\bteks\b/g, "text"],
  [/\bLink\b/g, "Link"],
  [/\blink\b/g, "link"],
  [/\bCek\b/g, "Check"],
  [/\bcek\b/g, "check"],
  [/\bSilakan\b/g, "Please"],
  [/\bsilakan\b/g, "please"],
  [/\bTerima kasih\b/g, "Thank you"],
  [/\bMaaf\b/g, "Sorry"],
  [/\bmaaf\b/g, "sorry"],
  [/\bMohon\b/g, "Please"],
  [/\bHanya\b/g, "Only"],
  [/\bhanya\b/g, "only"],
  [/\bboleh\b/g, "allowed"],
  [/\bBoleh\b/g, "Allowed"],
  [/\bdilarang\b/g, "forbidden"],
  [/\bDilarang\b/g, "Forbidden"],
  [/\bBerikan\b/g, "Provide"],
  [/\bberikan\b/g, "provide"],
  [/\bDikirim\b/g, "Sent"],
  [/\bdikirim\b/g, "sent"],
  [/\bDiterima\b/g, "Received"],
  [/\bPeriksa\b/g, "Check"],
  [/\bperiksa\b/g, "check"],
  [/\bPastikan\b/g, "Make sure"],
  [/\bhubungi\b/g, "contact"],
  [/\bHubungi\b/g, "Contact"],
  [/\bProspectus\b/g, "Overview"],
  [/\bInfo\b/g, "Info"],
  [/\binfo\b/g, "info"],
  [/\bBantuan\b/g, "Help"],
  [/\bPanduan\b/g, "Guide"],
  [/\bAcak\b/g, "Random"]
]

const autoTranslate = (text) => {
  let s = String(text || "")
  if (!s) return s
  /* lewati kalau sudah hampir semua ASCII-tagged HTML — tetap translate isinya */
  for (const [re, en] of ID_EN_PHRASES) s = s.replace(re, en)
  return s
}

module.exports = {
  DEFAULT_LANG,
  SUPPORTED,
  META,
  getLang,
  setLang,
  isSupported,
  t,
  tFor,
  label,
  list,
  langKeyboard,
  autoTranslate
}

try {
let f = require.resolve(__filename)
fs.watchFile(f, () => {
  try {
    fs.unwatchFile(f)
    delete require.cache[f]
    require(f)
  } catch(e) {
    console.log("language reload error:", e.message)
  }
})
} catch(e) {
  console.log("language watch error:", e.message)
}
