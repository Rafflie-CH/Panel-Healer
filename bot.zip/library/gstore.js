/* gstore.js — group settings store (per chat, per kolom).
   Dipakai plugin Rose/Protectron/Barker. Struktur: DB_PATH/<col>.json = { key: value }
   Atomic write + in-memory cache (write-through). Key selalu string. */

"use strict"
const fs = require("fs")
const path = require("path")

const DIR = path.join(__dirname, "database", "gstore")
fs.mkdirSync(DIR, { recursive: true })

const cache = new Map()

const fileOf = (col) => path.join(DIR, String(col).replace(/[^a-z0-9_-]/gi, "_") + ".json")

const load = (col) => {
  if (cache.has(col)) return cache.get(col)
  let obj = {}
  try { obj = JSON.parse(fs.readFileSync(fileOf(col), "utf8")) } catch {}
  if (!obj || typeof obj !== "object" || Array.isArray(obj)) obj = {}
  cache.set(col, obj)
  return obj
}

const persist = (col) => {
  try {
    const obj = cache.get(col) || {}
    const tmp = fileOf(col) + ".tmp"
    fs.writeFileSync(tmp, JSON.stringify(obj, null, 1))
    fs.renameSync(tmp, fileOf(col))
  } catch (e) { console.error("[gstore]", col, e.message) }
}

const K = (key) => String(key)

const get = (col, key, def) => {
  const obj = load(col)
  const v = obj[K(key)]
  return v === undefined ? (def === undefined ? null : def) : v
}

const set = (col, key, val) => {
  const obj = load(col)
  obj[K(key)] = val
  persist(col)
  return val
}

const del = (col, key) => {
  const obj = load(col)
  delete obj[K(key)]
  persist(col)
}

const has = (col, key) => K(key) in load(col)

/* semua entry kolom → [[key, value], ...] */
const list = (col) => Object.entries(load(col))

/* array helpers: ambil array kolom, push/remove item */
const arrGet = (col, key) => {
  const v = get(col, key, [])
  return Array.isArray(v) ? v : []
}
const arrAdd = (col, key, item, max = 200) => {
  const a = arrGet(col, key)
  if (!a.includes(item)) { a.push(item); while (a.length > max) a.shift(); set(col, key, a) }
  return a
}
const arrRemove = (col, key, item) => {
  const a = arrGet(col, key).filter(x => x !== item)
  set(col, key, a)
  return a
}

/* counter per key (antiflood/warn/raid) dengan TTL detik opsional */
const counters = new Map()
const counterGet = (col, key, ttlSec) => {
  const now = Date.now()
  const c = counters.get(col)
  if (c) {
    for (const [k, v] of c) if (v.exp && v.exp < now) c.delete(k)
  }
  const entry = (counters.get(col) || new Map()).get(K(key))
  if (!entry) return 0
  if (ttlSec && now - entry.t0 > ttlSec * 1000) return 0
  return entry.n
}
const counterInc = (col, key, ttlSec) => {
  if (!counters.has(col)) counters.set(col, new Map())
  const c = counters.get(col)
  const k = K(key)
  const now = Date.now()
  const e = c.get(k)
  if (!e || (ttlSec && now - e.t0 > ttlSec * 1000)) {
    c.set(k, { n: 1, t0: now, exp: ttlSec ? now + ttlSec * 1000 : 0 })
    return 1
  }
  e.n++
  e.exp = ttlSec ? now + ttlSec * 1000 : 0
  return e.n
}
const counterReset = (col, key) => {
  const c = counters.get(col)
  if (c) c.delete(K(key))
}

module.exports = { get, set, del, has, list, arrGet, arrAdd, arrRemove, counterGet, counterInc, counterReset, DIR }

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
