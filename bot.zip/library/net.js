/* library/net.js — DNS lookup tahan sinkhole.
   Beberapa environment/ISP sesaat memetakan domain ke 127.0.0.1/0.0.0.0
   (DNS sinkhole) sehingga request gagal ECONNREFUSED/ENOTFOUND padahal
   server hidup. smartLookup: kalau OS lookup mengembalikan alamat sinkhole,
   resolve ulang via public DNS (1.1.1.1/8.8.8.8) dan pakai hasil itu.

   Pemakaian: https.get(url, { lookup: smartLookup, ... }, cb) */

"use strict"
const dns = require("dns")

const SINKHOLES = new Set(["127.0.0.1", "::1", "0.0.0.0", "::"])
const PUBLIC_DNS = ["1.1.1.1", "8.8.8.8"]

const smartLookup = (hostname, opts, cb) => {
  /* dukung signature lookup(hostname, cb) tanpa opts */
  if (typeof opts === "function") { cb = opts; opts = {} }
  dns.lookup(hostname, opts, (err, address, family) => {
    if (!err && address && SINKHOLES.has(String(address))) {
      const r = new dns.Resolver()
      try { r.setServers(PUBLIC_DNS) } catch { }
      r.resolve4(hostname, (e2, addrs) => {
        if (!e2 && Array.isArray(addrs) && addrs.length) {
          return cb(null, addrs[Math.floor(Math.random() * addrs.length)], 4)
        }
        return cb(err, address, family)
      })
      return
    }
    cb(err, address, family)
  })
}

module.exports = { smartLookup }
