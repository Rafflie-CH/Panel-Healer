const store = {
  msgs: new Map(),
  groups: new Map()
}

exports.save = (m) => {
  try {
    if (m && m.id) store.msgs.set(m.id, m)
  } catch {}
}

exports.get = (id) => {
  try {
    return store.msgs.get(id)
  } catch {
    return undefined
  }
}

exports.group = (id, data) => {
  try {
    if (data) store.groups.set(id, data)
    return store.groups.get(id)
  } catch {
    return undefined
  }
}

try {
  let fs = require("fs")
  let file = require.resolve(__filename)
  fs.watchFile(file, () => {
    try {
      fs.unwatchFile(file)
      delete require.cache[file]
      require(file)
    } catch {}
  })
} catch {}
