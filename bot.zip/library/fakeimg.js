/* library/fakeimg.js — generator gambar fake (sharp + SVG, 100% lokal tanpa API)
   Semua fitur "fake" menghasilkan FOTO asli (PNG). Porting dari 3 bot WA
   (Furina/Prabowo/Rafzbotz) tapi tanpa canvas-API eksternal yang suka mati.
   Setiap output diberi watermark FAKE. */

"use strict"
const sharp = require("sharp")

const escapeXml = (s) =>
  String(s == null ? "" : s)
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, "")
    .replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;").replace(/'/g, "&apos;")

const rnd = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min
const pick = (arr) => arr[Math.floor(Math.random() * arr.length)]

/* render SVG string → PNG buffer (verifikasi dimensi) */
const renderPng = async (svg, width, height) => {
  const buf = await sharp({
    create: { width, height, channels: 4, background: { r: 255, g: 255, b: 255, alpha: 1 } }
  }).composite([{ input: Buffer.from(svg), top: 0, left: 0 }]).png().toBuffer()
  const meta = await sharp(buf).metadata()
  if (!meta.width || !meta.height || meta.width > 10000 || meta.height > 10000)
    throw new Error("invalid image dimensions")
  return buf
}

/* helper SVG */
const FONT = "DejaVu Sans, sans-serif"
const T = (x, y, size, fill, text, opts = {}) => {
  const anchor = opts.anchor || "start"
  const weight = opts.weight || "normal"
  const extra = (opts.opacity != null) ? ` opacity="${opts.opacity}"` : ""
  return `<text x="${x}" y="${y}" font-family="${FONT}" font-size="${size}" fill="${fill}" font-weight="${weight}" text-anchor="${anchor}"${extra}>${escapeXml(text)}</text>`
}
const R = (x, y, w, h, fill, rx = 0) => `<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${fill}" rx="${rx}"/>`
const C = (cx, cy, r, fill) => `<circle cx="${cx}" cy="${cy}" r="${r}" fill="${fill}"/>`
const LG = (id, c1, c2, x1 = 0, y1 = 0, x2 = 0, y2 = 1) =>
  `<defs><linearGradient id="${id}" x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}"><stop offset="0%" stop-color="${c1}"/><stop offset="100%" stop-color="${c2}"/></linearGradient></defs>`

const fmtRp = (n) => "Rp " + (Number(String(n).replace(/[^0-9]/g, "")) || 0).toLocaleString("id-ID")

/* avatar inisial (lingkaran warna + huruf) */
const AVATAR_COLORS = ["#4f8ef7", "#f75f5f", "#8e44ad", "#16a085", "#f39c12", "#e84393", "#0984e3", "#6c5ce7"]
const avatar = (cx, cy, r, name, fontSize) => {
  const col = AVATAR_COLORS[String(name || "?").length % AVATAR_COLORS.length]
  const ini = String(name || "?").trim().split(/\s+/).map(w => w[0]).join("").slice(0, 2).toUpperCase()
  return C(cx, cy, r, col) + T(cx, cy + fontSize * 0.36, fontSize, "#ffffff", ini, { anchor: "middle", weight: "bold" })
}

const watermark = (w, h) => T(w / 2, h - 12, 13, "#9aa4ad", "FAKE — " + (global.botname || "BOT"), { anchor: "middle", opacity: 0.8 })

function wrapLines(text, maxChars) {
  const words = String(text).split(/\s+/).filter(Boolean)
  const lines = []
  let line = ""
  for (const w of words) {
    if ((line + " " + w).trim().length > maxChars) {
      if (line) lines.push(line.trim())
      line = w
    } else {
      line = (line + " " + w).trim()
    }
  }
  if (line) lines.push(line.trim())
  return lines.length ? lines : [""]
}

/* jam format HH.MM */
const jam = () => new Date().toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit", timeZone: global.timeZone || "Asia/Jakarta" }).replace(":", ".")
const tanggal = () => new Date().toLocaleDateString("id-ID", { day: "numeric", month: "long", year: "numeric", timeZone: global.timeZone || "Asia/Jakarta" })

/* ══════════════ FAKE PAYMENT (dana/ovo/gopay/bca/qris/bangjago) ══════════════ */
const PAY_THEMES = {
  dana: { bg: "#118eea", bg2: "#0e6fc0", name: "DANA", accent: "#ffffff", card: "#f0f7ff" },
  ovo: { bg: "#4c2a86", bg2: "#31135e", name: "OVO", accent: "#ffffff", card: "#f4efff" },
  gopay: { bg: "#00aed6", bg2: "#0088a8", name: "GOPAY", accent: "#ffffff", card: "#eafaff" },
  bca: { bg: "#0b4ea2", bg2: "#073b7a", name: "BCA", accent: "#ffffff", card: "#eef4fc" },
  qris: { bg: "#c62828", bg2: "#8e1b1b", name: "QRIS", accent: "#ffffff", card: "#fff3f3" },
  bangjago: { bg: "#ff8a00", bg2: "#e06e00", name: "BANG JAGO", accent: "#ffffff", card: "#fff7ec" }
}
const W = 720, H = 1080

const paymentSvg = (app, amount, nama) => {
  const c = PAY_THEMES[String(app).toLowerCase()] || PAY_THEMES.dana
  const transId = String(app).toUpperCase().replace(/\s/g, "") + Date.now().toString().slice(-10)
  const lines = wrapLines(String(nama || "-"), 24).slice(0, 2)
  let y = 560
  let body = ""
  body += R(60, 480, 600, 220, c.card, 24)
  body += T(90, 530, 24, "#8a8a8a", "Nominal")
  body += T(90, 585, 52, "#1a1a2e", fmtRp(amount), { weight: "bold" })
  body += T(90, 640, 24, "#8a8a8a", "Diterima oleh")
  lines.forEach((l, i) => { body += T(90, 672 + i * 26, 24, "#1a1a2e", l) })
  body += R(60, 740, 600, 150, "#ffffff", 20)
  body += T(90, 790, 22, "#8a8a8a", "Waktu")
  body += T(90, 824, 26, "#1a1a2e", tanggal() + " • " + jam())
  body += T(90, 862, 22, "#8a8a8a", "ID Transaksi")
  body += T(90, 896 - 14, 22, "#1a1a2e", transId)
  return `<svg width="${W}" height="${H}" xmlns="http://www.w3.org/2000/svg">
  ${LG("hd", c.bg, c.bg2)}
  ${R(0, 0, W, H, "#f5f6fa")}
  ${R(0, 0, W, 380, "url(#hd)")}
  ${C(600, 120, 130, "rgba(255,255,255,0.08)")}
  ${C(120, 340, 90, "rgba(255,255,255,0.06)")}
  ${C(360, 200, 62, "rgba(255,255,255,0.18)")}
  ${T(360, 218, 44, c.accent, "✓", { anchor: "middle", weight: "bold" })}
  ${T(360, 315, 34, c.accent, "Transfer " + c.name + " Berhasil", { anchor: "middle", weight: "bold" })}
  ${body}
  ${watermark(W, H)}
</svg>`
}
const fakePayment = async (app, amount, nama) => renderPng(paymentSvg(app, amount, nama), W, H)

/* ══════════════ FAKE LOBBY FF / ML ══════════════ */
const fakeLobby = async (game, title) => {
  const isFF = String(game).toLowerCase() === "ff"
  const GW = 860, GH = 540
  const mode = title || (isFF ? "RANKED PUSH" : "CLASSIC")
  const players = [
    [String(rnd(100, 999)).padStart(4, "0"), pick(["Alvino", "Rizky", "Sans", "Zeus", "Raka", "Fajar"])],
    [String(rnd(100, 999)).padStart(4, "0"), pick(["Bintang", "Galang", "Yoga", "Rafa", "Nolan", "Ibra"])],
    [String(rnd(100, 999)).padStart(4, "0"), pick(["Kevlar", "Sniper", "Tank", "Mage", "Roam", "Jungle"])],
    [String(rnd(100, 999)).padStart(4, "0"), pick(["ProGamer", "NoobMaster", "Kalem", "Santuy", "GG", "MVP"])]
  ]
  let rows = ""
  players.forEach(([id, nm], i) => {
    const yy = 200 + i * 74
    rows += R(60, yy, 740, 60, i === 0 ? "#2e3b52" : "#242e40", 14)
    rows += avatar(105, yy + 30, 22, nm, 20)
    rows += T(150, yy + 37, 24, "#ffffff", nm)
    rows += T(770, yy + 37, 22, "#9fb3d1", "ID " + id, { anchor: "end" })
  })
  const svg = `<svg width="${GW}" height="${GH}" xmlns="http://www.w3.org/2000/svg">
  ${LG("bg2", isFF ? "#1c2733" : "#221436", isFF ? "#0e1620" : "#120a20")}
  ${R(0, 0, GW, GH, "url(#bg2)")}
  ${T(430, 70, 40, "#ffffff", isFF ? "FREE FIRE" : "MOBILE LEGENDS", { anchor: "middle", weight: "bold" })}
  ${T(430, 112, 24, "#f5b942", String(mode).toUpperCase().slice(0, 28), { anchor: "middle" })}
  ${R(60, 140, 740, 2, "#3d4c66")}
  ${rows}
  ${R(280, 480, 300, 44, "#f5b942", 22)}
  ${T(430, 509, 22, "#1a1a2e", "MULAI MATCH", { anchor: "middle", weight: "bold" })}
  ${watermark(GW, GH)}
</svg>`
  return renderPng(svg, GW, GH)
}

/* ══════════════ FAKE TWEET / X ══════════════ */
const fakeTweet = async (nama, text) => {
  const TW = 700
  const lines = wrapLines(text, 46)
  const TH = 300 + lines.length * 40
  const handle = "@" + String(nama || "user").toLowerCase().replace(/[^a-z0-9_]/g, "").slice(0, 14)
  let body = ""
  lines.forEach((l, i) => { body += T(50, 260 + i * 40, 27, "#0f1419", l) })
  const svg = `<svg width="${TW}" height="${TH}" xmlns="http://www.w3.org/2000/svg">
  ${R(0, 0, TW, TH, "#ffffff")}
  ${avatar(72, 100, 34, nama, 30)}
  ${T(122, 92, 25, "#0f1419", String(nama || "User").slice(0, 22), { weight: "bold" })}
  ${T(122, 122, 22, "#536471", handle)}
  ${body}
  ${T(50, 190 + lines.length * 40, 22, "#536471", jam() + " • " + tanggal().replace(/\s\d{4}/, ""))}
  ${R(50, 210 + lines.length * 40, 600, 2, "#eff3f4")}
  ${T(60, 252 + lines.length * 40, 24, "#536471", "💬 " + rnd(3, 220))}
  ${T(200, 252 + lines.length * 40, 24, "#536471", "🔁 " + rnd(1, 900))}
  ${T(360, 252 + lines.length * 40, 24, "#536471", "❤️ " + rnd(5, 5000))}
  ${T(520, 252 + lines.length * 40, 24, "#536471", "📊 " + rnd(1, 90) + "K")}
  ${watermark(TW, TH)}
</svg>`
  return renderPng(svg, TW, TH)
}

/* ══════════════ FAKE WHATSAPP CHAT ══════════════ */
const fakeWa = async (nama, text, opts = {}) => {
  const WW = 720
  const lines = wrapLines(text, 38)
  const WH = 260 + lines.length * 42
  const time = jam()
  let body = ""
  /* bubble */
  body += R(30, 120, WW - 140, 80 + lines.length * 42, "#d9fdd3", 18)
  lines.forEach((l, i) => { body += T(60, 175 + i * 42, 26, "#111b21", l) })
  body += T(WW - 170, 130 + lines.length * 42, 20, "#667781", time + " ✓✓", { anchor: "end" })
  const svg = `<svg width="${WW}" height="${WH}" xmlns="http://www.w3.org/2000/svg">
  ${LG("wa", "#008069", "#017561")}
  ${R(0, 0, WW, WH, "#efeae2")}
  ${R(0, 0, WW, 90, "url(#wa)")}
  ${avatar(60, 45, 26, nama, 22)}
  ${T(105, 40, 24, "#ffffff", String(nama || "Chat").slice(0, 24), { weight: "bold" })}
  ${T(105, 68, 18, "#d6f5ee", "online")}
  ${body}
  ${watermark(WW, WH)}
</svg>`
  return renderPng(svg, WW, WH)
}

/* ══════════════ FAKE WA VOICE NOTE ══════════════ */
const fakeVn = async (nama, durSec) => {
  const VW = 720, VH = 360
  const dur = Math.max(1, parseInt(durSec) || rnd(10, 120))
  const mm = Math.floor(dur / 60), ss = String(dur % 60).padStart(2, "0")
  let waves = ""
  for (let i = 0; i < 40; i++) {
    const hgt = 6 + Math.abs(Math.sin(i * 0.9)) * 30 * (0.5 + Math.random() / 2)
    waves += R(250 + i * 9, 230 - hgt / 2, 5, hgt, i < 26 ? "#34b7f1" : "#cfd9de", 3)
  }
  const svg = `<svg width="${VW}" height="${VH}" xmlns="http://www.w3.org/2000/svg">
  ${LG("wa2", "#008069", "#017561")}
  ${R(0, 0, VW, VH, "#efeae2")}
  ${R(0, 0, VW, 90, "url(#wa2)")}
  ${avatar(60, 45, 26, nama, 22)}
  ${T(105, 40, 24, "#ffffff", String(nama || "Chat").slice(0, 24), { weight: "bold" })}
  ${R(30, 130, 640, 200, "#d9fdd3", 18)}
  ${C(95, 230, 30, "#34b7f1")}
  ${T(95, 242, 30, "#ffffff", "▶", { anchor: "middle" })}
  ${waves}
  ${T(250, 285, 22, "#667781", "0:00")}
  ${T(560, 285, 22, "#667781", mm + ":" + ss)}
  ${watermark(VW, VH)}
</svg>`
  return renderPng(svg, VW, VH)
}

/* ══════════════ FAKE WA DEV MESSAGE (pesan dari WhatsApp) ══════════════ */
const fakeDev = async (text) => {
  const DW = 720
  const lines = wrapLines(text || "This message is from the official WhatsApp team.", 36)
  const DH = 230 + lines.length * 40
  let body = ""
  lines.forEach((l, i) => { body += T(60, 200 + i * 40, 25, "#1f2c34", l) })
  const svg = `<svg width="${DW}" height="${DH}" xmlns="http://www.w3.org/2000/svg">
  ${R(0, 0, DW, DH, "#efeae2")}
  ${R(30, 100, DW - 60, 100 + lines.length * 40, "#fdf4c8", 16)}
  ${C(80, 140, 22, "#00a884")}
  ${T(80, 150, 24, "#ffffff", "✓", { anchor: "middle", weight: "bold" })}
  ${T(120, 148, 24, "#667781", "WhatsApp • " + jam())}
  ${body}
  ${watermark(DW, DH)}
</svg>`
  return renderPng(svg, DW, DH)
}

/* ══════════════ FAKE WA CHANNEL POST ══════════════ */
const fakeChannel = async (channel, text) => {
  const CW = 720
  const lines = wrapLines(text, 38)
  const CH = 240 + lines.length * 42
  let body = ""
  lines.forEach((l, i) => { body += T(60, 195 + i * 42, 26, "#111b21", l) })
  const svg = `<svg width="${CW}" height="${CH}" xmlns="http://www.w3.org/2000/svg">
  ${LG("wa3", "#008069", "#017561")}
  ${R(0, 0, CW, CH, "#ffffff")}
  ${R(0, 0, CW, 90, "url(#wa3)")}
  ${T(360, 55, 26, "#ffffff", "📢 CHANNEL", { anchor: "middle", weight: "bold" })}
  ${avatar(80, 140, 28, channel, 24)}
  ${T(125, 148, 24, "#111b21", String(channel || "Channel").slice(0, 26), { weight: "bold" })}
  ${T(125, 176, 18, "#667781", rnd(100, 50000).toLocaleString("id-ID") + " followers")}
  ${body}
  ${T(CW - 60, 205 + lines.length * 42, 20, "#667781", jam(), { anchor: "end" })}
  ${watermark(CW, CH)}
</svg>`
  return renderPng(svg, CW, CH)
}

/* ══════════════ FAKE WA GROUP (pesan grup + penulis) ══════════════ */
const fakeGc = async (group, author, text) => {
  const GW2 = 720
  const lines = wrapLines(text, 36)
  const GH2 = 280 + lines.length * 42
  let body = ""
  body += T(60, 205, 22, "#e542a3", String(author || "Member").slice(0, 18), { weight: "bold" })
  lines.forEach((l, i) => { body += T(60, 245 + i * 42, 26, "#111b21", l) })
  const svg = `<svg width="${GW2}" height="${GH2}" xmlns="http://www.w3.org/2000/svg">
  ${LG("wa4", "#008069", "#017561")}
  ${R(0, 0, GW2, GH2, "#efeae2")}
  ${R(0, 0, GW2, 90, "url(#wa4)")}
  ${avatar(60, 45, 26, group, 22)}
  ${T(105, 40, 24, "#ffffff", String(group || "Grup").slice(0, 24), { weight: "bold" })}
  ${T(105, 68, 18, "#d6f5ee", rnd(3, 500) + " members")}
  ${R(30, 140, GW2 - 140, 110 + lines.length * 42, "#ffffff", 18)}
  ${body}
  ${T(GW2 - 170, 220 + lines.length * 42, 20, "#667781", jam(), { anchor: "end" })}
  ${watermark(GW2, GH2)}
</svg>`
  return renderPng(svg, GW2, GH2)
}

/* ══════════════ FAKE NOTIF ANDROID ══════════════ */
const fakeNotif = async (app, title, text) => {
  const NW = 720
  const lines = wrapLines(text, 40)
  const NH = 280 + lines.length * 38
  const icons = { whatsapp: "#25d366", instagram: "#e1306c", tiktok: "#010101", youtube: "#ff0000", dana: "#118eea", gmail: "#ea4335" }
  const col = icons[String(app).toLowerCase()] || "#4f8ef7"
  let body = ""
  lines.forEach((l, i) => { body += T(150, 205 + i * 38, 24, "#3c4043", l) })
  const svg = `<svg width="${NW}" height="${NH}" xmlns="http://www.w3.org/2000/svg">
  ${R(0, 0, NW, NH, "#e8eaed")}
  ${R(20, 60, NW - 40, 160 + lines.length * 38, "#ffffff", 28)}
  ${C(90, 140, 34, col)}
  ${T(90, 152, 30, "#ffffff", String(app || "A").charAt(0).toUpperCase(), { anchor: "middle", weight: "bold" })}
  ${T(150, 130, 22, "#80868b", String(app || "App").slice(0, 20) + " • " + jam())}
  ${T(150, 168, 26, "#202124", String(title || "Notification").slice(0, 30), { weight: "bold" })}
  ${body}
  ${watermark(NW, NH)}
</svg>`
  return renderPng(svg, NW, NH)
}

/* ══════════════ FAKE CALL (iOS / Android / WA) ══════════════ */
const fakeCall = async (nama, style, secs) => {
  const CW2 = 720, CH2 = 1280
  const st = String(style).toLowerCase()
  const dur = Math.max(1, parseInt(secs) || 0)
  const durTxt = dur ? Math.floor(dur / 60) + ":" + String(dur % 60).padStart(2, "0") : (st === "ios" ? "calling..." : "Incoming call")
  const bgTop = st === "wa" ? "#075e54" : st === "ios" ? "#1c1c1e" : "#202124"
  const btns = [
    [st === "ios" ? "#4cd964" : "#34b7f1", "✆"],
    [st === "ios" ? "#ff3b30" : "#f15b6c", "✖"]
  ]
  const svg = `<svg width="${CW2}" height="${CH2}" xmlns="http://www.w3.org/2000/svg">
  ${LG("cal", bgTop, "#000000")}
  ${R(0, 0, CW2, CH2, "url(#cal)")}
  ${T(360, 90, 24, "#9aa4ad", durTxt, { anchor: "middle" })}
  ${avatar(360, 400, 130, nama, 100)}
  ${T(360, 620, 44, "#ffffff", String(nama || "Unknown").slice(0, 20), { anchor: "middle", weight: "bold" })}
  ${T(360, 670, 26, "#c8cdd2", st === "wa" ? "WhatsApp call" : (st === "ios" ? "iPhone" : "Android"), { anchor: "middle" })}
  ${R(170, 1060, 120, 120, btns[0][0], 60)}
  ${T(230, 1135, 52, "#ffffff", btns[0][1], { anchor: "middle" })}
  ${R(430, 1060, 120, 120, btns[1][0], 60)}
  ${T(490, 1135, 52, "#ffffff", btns[1][1], { anchor: "middle" })}
  ${watermark(CW2, CH2)}
</svg>`
  return renderPng(svg, CW2, CH2)
}

/* ══════════════ FAKE INSTAGRAM PROFILE ══════════════ */
const fakeIg = async (username, posts, followers, following, bio) => {
  const IW = 720
  const bioLines = wrapLines(bio || "", 44).slice(0, 3)
  const IH = 620 + bioLines.length * 36
  const f = (s) => String(s || "0").replace(/[^0-9.,KMkM]/g, "").slice(0, 8) || String(rnd(10, 900))
  let bioBody = ""
  bioLines.forEach((l, i) => { bioBody += T(40, 545 + i * 36, 25, "#262626", l) })
  const svg = `<svg width="${IW}" height="${IH}" xmlns="http://www.w3.org/2000/svg">
  ${R(0, 0, IW, IH, "#ffffff")}
  ${avatar(90, 160, 62, username, 52)}
  ${T(190, 110, 28, "#262626", String(username || "user").slice(0, 20), { weight: "bold" })}
  ${T(190, 155, 24, "#262626", f(posts) + " posts")}
  ${T(350, 155, 24, "#262626", f(followers) + " followers")}
  ${T(540, 155, 24, "#262626", f(following) + " following")}
  ${T(40, 230, 26, "#262626", String(username || "user").slice(0, 24), { weight: "bold" })}
  ${R(360, 200, 110, 34, "#efefef", 8)}
  ${T(415, 223, 20, "#262626", "Follow", { anchor: "middle", weight: "bold" })}
  ${R(30, 300, IW - 60, 2, "#dbdbdb")}
  ${T(90, 360, 22, "#8e8e8e", "🗺 " + pick(["Jakarta", "Bandung", "Surabaya", "Yogyakarta", "Medan"]))}
  ${T(90, 400, 22, "#8e8e8e", "🔗 linktr.ee/" + String(username || "user").toLowerCase().slice(0, 12))}
  ${bioBody}
  ${R(30, 580 + bioLines.length * 36, 210, 260, "#efefef", 4)}
  ${R(255, 580 + bioLines.length * 36, 210, 260, "#f7f7f7", 4)}
  ${R(480, 580 + bioLines.length * 36, 210, 260, "#efefef", 4)}
  ${watermark(IW, IH)}
</svg>`
  return renderPng(svg, IW, IH)
}

/* ══════════════ FAKE INSTAGRAM STORY ══════════════ */
const fakeIgStory = async (username, text) => {
  const SW = 720, SH = 1280
  const lines = wrapLines(text, 26)
  let body = ""
  lines.forEach((l, i) => { body += T(360, 700 + i * 48, 38, "#ffffff", l, { anchor: "middle", weight: "bold" }) })
  const svg = `<svg width="${SW}" height="${SH}" xmlns="http://www.w3.org/2000/svg">
  ${LG("igst", "#833ab4", "#fd1d1d", 0, 0, 1, 1)}
  ${R(0, 0, SW, SH, "url(#igst)")}
  ${C(505, 80, 30, "#4f8ef7")}
  ${avatar(80, 90, 30, username, 24)}
  ${T(125, 82, 24, "#ffffff", String(username || "user").slice(0, 18), { weight: "bold" })}
  ${T(125, 110, 19, "#e0e0e0", rnd(1, 23) + "h")}
  ${R(640, 60, 40, 8, "rgba(255,255,255,0.4)", 4)}
  ${R(590, 60, 40, 8, "rgba(255,255,255,0.9)", 4)}
  ${body}
  ${T(360, 1240, 22, "rgba(255,255,255,0.7)", "FAKE — " + (global.botname || "BOT"), { anchor: "middle" })}
</svg>`
  return renderPng(svg, SW, SH)
}

/* ══════════════ FAKE THREADS ══════════════ */
const fakeThreads = async (username, text) => {
  const TW2 = 700
  const lines = wrapLines(text, 42)
  const TH2 = 280 + lines.length * 40
  let body = ""
  lines.forEach((l, i) => { body += T(60, 250 + i * 40, 26, "#000000", l) })
  const svg = `<svg width="${TW2}" height="${TH2}" xmlns="http://www.w3.org/2000/svg">
  ${R(0, 0, TW2, TH2, "#ffffff")}
  ${avatar(85, 140, 40, username, 34)}
  ${T(150, 128, 25, "#000000", String(username || "user").slice(0, 20), { weight: "bold" })}
  ${T(150, 160, 21, "#999999", jam() + " • " + rnd(1, 99) + " views")}
  ${body}
  ${T(60, 220 + lines.length * 40, 30, "#000000", "♡  ⃝  💬", {})}
  ${T(140, 220 + lines.length * 40, 24, "#999999", rnd(1, 400) + " replies • " + rnd(10, 9000) + " likes")}
  ${watermark(TW2, TH2)}
</svg>`
  return renderPng(svg, TW2, TH2)
}

/* ══════════════ FAKE SURAT WAFAT ══════════════ */
const fakeWafat = async (nama, tglWafat) => {
  const WW2 = 800, WH2 = 1000
  const svg = `<svg width="${WW2}" height="${WH2}" xmlns="http://www.w3.org/2000/svg">
  ${R(0, 0, WW2, WH2, "#f4f1ea")}
  <rect x="25" y="25" width="${WW2 - 50}" height="${WH2 - 50}" fill="none" stroke="#2c3e50" stroke-width="6"/>
  <rect x="45" y="45" width="${WW2 - 90}" height="${WH2 - 90}" fill="none" stroke="#7f8c8d" stroke-width="2"/>
  ${T(400, 130, 46, "#2c3e50", "IN MEMORIAM", { anchor: "middle", weight: "bold" })}
  ${T(400, 190, 24, "#7f8c8d", "Dengan penuh kecintaan dan rasa kehilangan", { anchor: "middle" })}
  ${C(400, 330, 70, "#d5dbdb")}
  ${T(400, 352, 60, "#7f8c8d", "✝", { anchor: "middle" })}
  ${T(400, 470, 52, "#1a1a2e", String(nama || "-").slice(0, 26), { anchor: "middle", weight: "bold" })}
  ${T(400, 520, 26, "#566573", pick(["1948 — ", "1955 — ", "1960 — "]) + String(tglWafat || tanggal()), { anchor: "middle" })}
  ${T(400, 610, 24, "#566573", "Telah berpulang ke Rahmat Allah", { anchor: "middle" })}
  ${T(400, 660, 24, "#566573", "Tempat tinggal: " + pick(["Jakarta", "Bandung", "Semarang", "Solo", "Malang"]), { anchor: "middle" })}
  ${T(400, 760, 22, "#7f8c8d", "Semoga amal ibadahnya diterima dan keluarga", { anchor: "middle" })}
  ${T(400, 795, 22, "#7f8c8d", "yang ditinggalkan diberi ketabahan.", { anchor: "middle" })}
  ${T(400, 900, 24, "#2c3e50", "Keluarga yang berduka", { anchor: "middle", weight: "bold" })}
  ${watermark(WW2, WH2)}
</svg>`
  return renderPng(svg, WW2, WH2)
}

/* ══════════════ FAKE JUARA ML (victory screen) ══════════════ */
const fakeJuara = async (hero, nama) => {
  const JW = 860, JH = 540
  const svg = `<svg width="${JW}" height="${JH}" xmlns="http://www.w3.org/2000/svg">
  ${LG("win", "#c9962e", "#7a5a12")}
  ${R(0, 0, JW, JH, "url(#win)")}
  ${T(430, 110, 64, "#ffe08a", "VICTORY", { anchor: "middle", weight: "bold" })}
  ${T(430, 150, 24, "#f5e6c4", "Rank Match • " + jam(), { anchor: "middle" })}
  ${avatar(430, 280, 70, hero || nama, 56)}
  ${T(430, 400, 40, "#ffffff", String(hero || "Lancelot").slice(0, 16), { anchor: "middle", weight: "bold" })}
  ${T(430, 445, 26, "#ffe08a", "MVP ★ " + String(nama || "Player").slice(0, 18), { anchor: "middle" })}
  ${T(300, 495, 26, "#c8f7c5", rnd(6, 15) + "/" + rnd(0, 4) + "/" + rnd(4, 14), { anchor: "middle" })}
  ${T(430, 495, 22, "#e8e8e8", "K/D/A", { anchor: "middle" })}
  ${T(560, 495, 26, "#ffd54f", "⭐ " + rnd(80, 130) + " gold/min", { anchor: "middle" })}
  ${watermark(JW, JH)}
</svg>`
  return renderPng(svg, JW, JH)
}

/* ══════════════ FAKE MUSIC PLAYER (DJ card) ══════════════ */
const fakeDj = async (judul) => {
  const MW = 720, MH = 900
  const titleLines = wrapLines(judul, 26).slice(0, 2)
  let bars = ""
  for (let i = 0; i < 48; i++) {
    const hgt = 10 + Math.abs(Math.sin(i * 0.55)) * 90 * (0.4 + Math.random() / 2)
    bars += R(60 + i * 12.5, 560 - hgt, 8, hgt, i % 3 ? "#1db954" : "#1ed760", 4)
  }
  let t2 = ""
  titleLines.forEach((l, i) => { t2 += T(60, 660 + i * 44, 34, "#ffffff", l, { weight: "bold" }) })
  const svg = `<svg width="${MW}" height="${MH}" xmlns="http://www.w3.org/2000/svg">
  ${LG("dj", "#191414", "#0e0e0e")}
  ${R(0, 0, MW, MH, "url(#dj)")}
  ${R(60, 90, 600, 400, "#282828", 20)}
  ${C(360, 290, 120, "#1db954")}
  ${T(360, 320, 90, "#121212", "♫", { anchor: "middle" })}
  ${bars}
  ${t2}
  ${T(60, 760 + titleLines.length * 44, 24, "#b3b3b3", pick(["DJ RAFZ REMIX", "DJ KENTRUNG", "DJ BREAKBEAT", "DJ SANTUY"]) + " • " + rnd(100, 900) + "K plays")}
  ${R(60, 800 + titleLines.length * 44, 600, 10, "#4f4f4f", 5)}
  ${R(60, 800 + titleLines.length * 44, rnd(100, 500), 10, "#1db954", 5)}
  ${watermark(MW, MH)}
</svg>`
  return renderPng(svg, MW, MH)
}

/* ══════════════ FAKE E-KTP (upgrade — realistis) ══════════════ */
const fakeKtp = async ({ nama, kota, lahir, kerja, jenis, alamat, agama, photo }) => {
  const KW = 880, KH = 560
  const nik = String(rnd(31, 36)) + String(rnd(1, 99)).padStart(2, "0") + String(rnd(10, 99)) + String(rnd(1001, 9999))
  const prov = pick(["DKI JAKARTA", "JAWA BARAT", "JAWA TENGAH", "JAWA TIMUR", "SUMATERA UTARA", "BALI", "DI YOGYAKARTA"])
  const gol = pick(["A", "B", "AB", "O"])
  const st = pick(["BELUM KAWIN", "KAWIN", "CERAI HIDUP", "CERAI MATI"])
  const addr = String(alamat || "JL. " + pick(["MERDEKA", "SUDIRMAN", "A YANI", "GATOT SUBROTO", "DIPONEGORO"]) + " NO. " + rnd(1, 120)).toUpperCase()
  const jenisFull = String(jenis || "LAKI-LAKI").toUpperCase()
  const berlaku = pick(["SEUMUR HIDUP"])
  let photoEl = avatar(160, 330, 78, nama, 60)
  const svg = `<svg width="${KW}" height="${KH}" xmlns="http://www.w3.org/2000/svg">
  ${LG("ktp1", "#3a7bd5", "#2b5876")}
  ${LG("ktp2", "#eef2f7", "#dde6f0")}
  ${R(0, 0, KW, KH, "url(#ktp2)", 18)}
  ${R(0, 0, KW, 86, "url(#ktp1)", 18)}
  ${T(440, 42, 30, "#ffffff", "PROVINSI " + prov, { anchor: "middle", weight: "bold" })}
  ${T(440, 72, 20, "#cfe0f5", "REPUBLIC OF INDONESIA — KARTU TANDA PENDUDUK", { anchor: "middle" })}
  ${T(40, 128, 24, "#2b5876", "NIK", { weight: "bold" })}
  ${T(120, 128, 30, "#1a1a2e", nik, { weight: "bold" })}
  ${photoEl}
  <rect x="82" y="252" width="156" height="156" fill="none" stroke="#9fb3c8" stroke-width="2" rx="10"/>
  ${T(260, 190, 19, "#5a7086", "Nama")}
  ${T(470, 190, 23, "#111c2e", String(nama || "-").toUpperCase(), { weight: "bold" })}
  ${T(260, 226, 19, "#5a7086", "Tempat/Tgl Lahir")}
  ${T(470, 226, 22, "#111c2e", String(kota || "-").toUpperCase() + ", " + (lahir || "-"))}
  ${T(260, 262, 19, "#5a7086", "Jenis Kelamin")}
  ${T(470, 262, 22, "#111c2e", jenisFull + "    Gol. Darah: " + gol)}
  ${T(260, 298, 19, "#5a7086", "Alamat")}
  ${T(470, 298, 22, "#111c2e", addr.slice(0, 34))}
  ${T(260, 334, 19, "#5a7086", "Agama")}
  ${T(470, 334, 22, "#111c2e", String(agama || pick(["ISLAM", "KRISTEN", "KATOLIK", "HINDU", "BUDDHA"])))}
  ${T(260, 370, 19, "#5a7086", "Status Perkawinan")}
  ${T(470, 370, 22, "#111c2e", st)}
  ${T(260, 406, 19, "#5a7086", "Pekerjaan")}
  ${T(470, 406, 22, "#111c2e", String(kerja || "KARYAWAN").toUpperCase())}
  ${T(260, 442, 19, "#5a7086", "Berlaku Hingga")}
  ${T(470, 442, 22, "#111c2e", berlaku)}
  ${T(640, 500, 20, "#2b5876", "KOTA " + String(kota || "-").toUpperCase(), { anchor: "middle", weight: "bold" })}
  ${T(640, 528, 20, "#2b5876", tanggal(), { anchor: "middle" })}
  ${T(640, 552 - 34, 0, "#fff", "")}
  ${T(40, KH - 18, 15, "#8fa3b8", "FAKE — " + (global.botname || "BOT") + " • dokumen ini tidak asli, hanya untuk hiburan")}
</svg>`
  return renderPng(svg, KW, KH)
}

module.exports = {
  escapeXml, renderPng,
  fakePayment, fakeLobby, fakeTweet, fakeWa, fakeKtp,
  fakeVn, fakeDev, fakeChannel, fakeGc, fakeNotif,
  fakeCall, fakeIg, fakeIgStory, fakeThreads, fakeWafat, fakeJuara, fakeDj,
  wrapLines, rnd, pick, jam, tanggal
}
