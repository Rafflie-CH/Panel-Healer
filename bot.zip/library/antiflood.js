/* ─────────────────────────────────────────────────────────────────
   library/antiflood.js — ANTI "Too Many Requests" (HTTP 429)

   Dipasang SEKALI di index.js setelah bot dibuat:
     require("./library/antiflood").install(bot)

   Yang dilakukan:
   1. SEMUA method API bot (sendMessage, sendPhoto, editMessageText,
      deleteMessage, answerCallbackQuery, dst) di-wrap otomatis:
      kalau Telegram balas 429, bot MENUNGGU sesuai `retry_after`
      lalu retry otomatis sampai batas attempt.
   2. Throttle global (token-per-detik, FIFO) → waktu traffic ramai
      request di-pace max `global.flood.maxPerSec` per detik supaya
      bot tidak nembak API dan justru kena limit.
   3. Kalau satu request kena 429, request lain IKUT dijeda sebentar
      (global pause) supaya tidak numpuk error berantai.
   4. answerCallbackQuery yang kedaluwarsa setelah menunggu limit
      ("query is too old") dianggap sukses — tidak dilempar error.

   Semua plugin otomatis terlindungi karena memanggil method bot
   yang sama (Rafz.* / bot.*) — tidak perlu ubah plugin satu-satu.
   ───────────────────────────────────────────────────────────────── */

const TAG = "[ANTIFLOOD]"

/* config dari settings.js (global.flood) */
const cfg = () => global.flood || {}
const maxRetry = () => Math.max(0, Number(cfg().maxRetry ?? 5))
const maxPerSec = () => Math.max(1, Number(cfg().maxPerSec ?? 25))
const maxWaitSec = () => Math.max(1, Number(cfg().maxWaitSec ?? 60))
const jitterMs = () => Math.max(0, Number(cfg().jitterMs ?? 250))
const verbose = () => cfg().verbose !== false

const sleep = (ms) => new Promise((r) => setTimeout(r, ms))
const now = () => Date.now()

/* idempoten lintas hot-reload: symbol global, bukan per-module */
const RETRY_MARK = global.__antifloodMark || (global.__antifloodMark = Symbol("antiflood.retry"))

/* callback query Telegram kedaluwarsa (usia > ~15 dtk) → biarkan senyap */
const CALLBACK_GONE = /query is too old|query cannot be forwarded/i

/* ── deteksi error 429 + ambil `retry_after` (detik) ──
   Bentuk error node-telegram-bot-api:
     TelegramError "429 Too Many Requests: retry after 3"
     err.response.statusCode = 429
     err.response.body = { ok:false, error_code:429, parameters:{ retry_after:3 } } */
const parseRetryAfter = (err) => {
  try {
    if (!err) return null
    const msg = String((err && err.message) || err)
    const resp = err.response || null
    const body = resp && resp.body
    const code = Number((body && body.error_code) || (resp && resp.statusCode) || 0)

    let ra = 0
    const p = body && body.parameters
    if (p && Number.isFinite(Number(p.retry_after))) ra = Number(p.retry_after)
    if (!ra) {
      const m = msg.match(/retry\s*after\s*(\d+)/i)
      if (m) ra = Number(m[1])
    }

    const is429 =
      code === 429 ||
      /\b429\b/.test(msg) ||
      /too many requests/i.test(msg)

    if (!is429) return null
    if (!ra || ra < 1) ra = 1
    return Math.min(ra, maxWaitSec())
  } catch {
    return null
  }
}

const isFloodError = (err) => parseRetryAfter(err) != null

/* ── throttle global: max `maxPerSec` request per detik ──
   Desain timer-based (bukan rantai promise) supaya tidak bisa
   terjadi stack overflow saat traffic tinggi berjam-jam. */
let stamps = []
let pauseUntil = 0

const acquireSlot = () => new Promise((resolve) => {
  const attempt = () => {
    try {
      const t = now()
      /* baru saja kena 429 → tunda sampai pause lepas */
      if (t < pauseUntil) {
        setTimeout(attempt, pauseUntil - t + 10)
        return
      }
      const limit = maxPerSec()
      while (stamps.length && t - stamps[0] >= 1000) stamps.shift()
      if (stamps.length >= limit) {
        setTimeout(attempt, Math.min(1000 - (t - stamps[0]) + 25, 1100))
        return
      }
      stamps.push(t)
      if (stamps.length > 500) stamps = stamps.slice(-200)
      resolve()
    } catch {
      /* jangan pernah menggantung caller karena error throttle */
      resolve()
    }
  }
  attempt()
})

/* ── jalankan fn dengan auto-retry 429 (dipakai wrapper method bot,
      callback handler, case dispatch & plugin chain) ── */
const withRetry = async (fn, label = "call") => {
  await acquireSlot()
  for (let attempt = 0; ; attempt++) {
    try {
      return await fn()
    } catch (err) {
      /* callback kedaluwarsa karena menunggu limit → anggap sukses */
      if (
        String(label).startsWith("answerCallbackQuery") &&
        CALLBACK_GONE.test(String((err && err.message) || err))
      ) {
        if (verbose()) console.log(TAG, label + ": callback kedaluwarsa, dilewati")
        return undefined
      }

      const waitSec = parseRetryAfter(err)
      if (waitSec == null) throw err
      if (attempt >= maxRetry()) {
        console.log(TAG, `${label}: tetap 429 setelah ${attempt}x retry → error diteruskan ke caller`)
        throw err
      }

      /* request lain ikut dijeda (80% dari wait) supaya tidak nembak lagi */
      pauseUntil = Math.max(pauseUntil, now() + Math.floor(waitSec * 800))
      if (global.rafzFloodStats) {
        global.rafzFloodStats.retried++
        global.rafzFloodStats.last429 = now()
      }

      const ms = waitSec * 1000 + Math.floor(Math.random() * jitterMs())
      if (verbose()) {
        console.log(TAG, `⏳ 429 pada ${label} → tunggu ${(ms / 1000).toFixed(1)}s lalu retry ${attempt + 1}/${maxRetry()}`)
      }
      await sleep(ms)
    }
  }
}

/* ── wrap satu fungsi API dengan retry ── */
const wrapFn = (name, fn) => {
  if (typeof fn !== "function" || fn[RETRY_MARK]) return fn
  const wrapped = function (...args) {
    return withRetry(() => fn.apply(this, args), name)
  }
  try { wrapped[RETRY_MARK] = true } catch {}
  return wrapped
}

/* method non-API di prototype bot — jangan di-wrap */
const SKIP = new Set([
  "constructor",
  "processUpdate",
  "handleUpdate",
  "initPolling",
  "startPolling",
  "stopPolling",
  "openWebHook",
  "closeWebHook",
  "isPolling",
  "hasOpenWebHook",
  /* polling internal — JANGAN di-wrap, kalo di-throttle/retry
     bisa bikin polling_error beruntun + restart loop */
  "getUpdates",
  "_request",
  "request",
  "_buildURL",
  "_fixRequestOptions",
  "_requestOptions"
])

/* method bawaan Object.prototype — DILARANG di-wrap (bisa bikin
   rekursi tak berujung saat engine memanggil toString/valueOf) */
const OBJECT_PROTO_METHODS = new Set([
  "toString", "valueOf", "toLocaleString", "hasOwnProperty",
  "isPrototypeOf", "propertyIsEnumerable"
])

/* ── pasang ke bot: patch semua method API di prototype + instance ── */
const install = (bot) => {
  if (!bot) return { installed: false, methods: 0 }
  let n = 0
  try {
    const proto = Object.getPrototypeOf(bot)
    /* HANYA patch prototype khusus bot (mis. TelegramBot.prototype).
       Kalau object polos → proto-nya Object.prototype → jangan sentuh! */
    const isSpecialProto = proto && proto !== Object.prototype && proto.constructor?.name !== "Object"
    if (isSpecialProto) {
      for (const key of Object.getOwnPropertyNames(proto)) {
        if (key.startsWith("_") || SKIP.has(key) || OBJECT_PROTO_METHODS.has(key)) continue
        const desc = Object.getOwnPropertyDescriptor(proto, key)
        if (!desc || typeof desc.value !== "function") continue
        const wrapped = wrapFn(key, desc.value)
        if (wrapped !== desc.value) {
          Object.defineProperty(proto, key, { ...desc, value: wrapped })
          n++
        }
      }
    }
  } catch (e) {
    console.log(TAG, "install proto error:", e.message)
  }
  /* method yang ditempel langsung di instance (mis. stub di test) */
  try {
    for (const key of Object.keys(bot)) {
      if (key.startsWith("_") || SKIP.has(key) || OBJECT_PROTO_METHODS.has(key)) continue
      const v = bot[key]
      if (typeof v !== "function" || v[RETRY_MARK]) continue
      const desc = Object.getOwnPropertyDescriptor(bot, key)
      if (desc && desc.configurable) {
        Object.defineProperty(bot, key, { ...desc, value: wrapFn(key, v) })
        n++
      }
    }
  } catch {}

  global.rafzFloodStats = { retried: 0, last429: 0 }
  console.log(TAG, `aktif — ${n} method API dipasangi auto-retry 429 (throttle ${maxPerSec()}/dtk)`)
  return { installed: true, methods: n }
}

module.exports = { install, withRetry, parseRetryAfter, isFloodError, sleep }

/* hot-reload self — aman karena RETRY_MARK global (tidak dobel-wrap) */
try {
  const fs = require("fs")
  const file = require.resolve(__filename)
  fs.watchFile(file, () => {
    try { fs.unwatchFile(file); delete require.cache[file]; require(file) } catch {}
  })
} catch {}
