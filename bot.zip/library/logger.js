const chalk = require("chalk")

const box = (title, rows = []) => {
  try {
    const w = 46
    const top = "┌" + "─".repeat(w) + "┐"
    const mid = "├" + "─".repeat(w) + "┤"
    const bot = "└" + "─".repeat(w) + "┘"
    console.log(chalk.cyan(top))
    console.log(chalk.cyan("│ " + String(title).padEnd(w - 1) + "│"))
    console.log(chalk.cyan(mid))
    rows.forEach((v) => console.log("│ " + String(v).padEnd(w - 1) + "│"))
    console.log(chalk.cyan(bot))
  } catch (e) {
    console.log(title, rows)
  }
}

exports.msg = (m) => {
  try {
    box("MESSAGE", [
      "Time : " + new Date().toLocaleTimeString(),
      "User : " + (m.pushName || "-") + " (" + (m.sender || "-") + ")",
      "Chat : " + (m.isGroup ? "GROUP" : "PRIVATE"),
      "Text : " + (m.text || "-").slice(0, 80)
    ])
  } catch {}
}

exports.cmd = (m) => {
  try {
    box("COMMAND", [
      "Cmd  : " + (m.prefix || "") + (m.command || ""),
      "Args : " + ((m.args && m.args.join(" ")) || "-"),
      "User : " + (m.sender || "-")
    ])
  } catch {}
}

exports.err = (e, m) => {
  try {
    box("ERROR", [
      "User : " + (m?.sender || "-"),
      "Err  : " + (e && e.message ? e.message : String(e)).slice(0, 100)
    ])
  } catch {
    console.error(e)
  }
}

try {
  let fs = require("fs")
  let file = require.resolve(__filename)
  fs.watchFile(file, () => {
    try {
      fs.unwatchFile(file)
      delete require.cache[file]
      require(file)
    } catch {}
  })
} catch {}
