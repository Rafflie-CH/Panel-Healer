/* mediautil.js — util download media dari pesan Telegram (dipakai plugin porting WA).
   getMediaBuffer(m, Rafz) → Buffer foto/video/dokumen dari pesan ini atau pesan
   yang di-reply, atau null kalau tidak ada media. */

"use strict"

const getMediaBuffer = async (m, Rafz) => {
  try {
    const fileId = m.quoted?.fileId || m.fileId
    if (!fileId || !Rafz) return null
    const f = await Rafz.getFile(fileId)
    if (!f || !f.file_path) return null
    const url = "https://api.telegram.org/file/bot" + Rafz.token + "/" + f.file_path
    let antiflood = null
    try { antiflood = require("./antiflood") } catch {}
    const doFetch = () => fetch(url)
    const res = antiflood?.withRetry ? await antiflood.withRetry(doFetch, "mediautil") : await doFetch()
    if (!res || !res.ok) return null
    return Buffer.from(await res.arrayBuffer())
  } catch {
    return null
  }
}

module.exports = { getMediaBuffer }

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
