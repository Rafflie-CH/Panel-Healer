const sendMessage = async (bot, chat, content = {}, options = {}) => {
  try {
    if (typeof content === "string")
      return await bot.sendMessage(chat, content, {})

    if (content.text)
      return await bot.sendMessage(chat, content.text, options)

    if (content.react)
      return await bot.sendMessage(chat, content.react, {
        reply_to_message_id: options?.quoted?.id
      })

    return await bot.sendMessage(chat, JSON.stringify(content, null, 2))
  } catch (e) {
    console.log("client.sendMessage error:", e.message)
    return null
  }
}

module.exports = { sendMessage }

try {
  let fs = require("fs")
  let file = require.resolve(__filename)
  fs.watchFile(file, () => {
    try {
      fs.unwatchFile(file)
      delete require.cache[file]
      require(file)
    } catch {}
  })
} catch {}
