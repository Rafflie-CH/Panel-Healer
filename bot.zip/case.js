require("./autodb")
const util = require("util")
const { exec } = require("child_process")
const fs=require("fs")
const crypto=require("crypto")
const pendingEval = new Map()
const LANG = require("./library/language")

/* ================= SESI PICKER / KONFIRMASI =================
   Sesi ini dulu cuma hidup di memori. Efeknya: tiap bot restart (atau
   reload), semua sesi hilang -> user nge-tap tombol cuma dapat
   "session expired". Sekarang sesinya ditulis ke file, jadi masih ada
   setelah restart dan bisa dilanjutkan dari step terakhir. */
/* bisa digeser lewat env, jadi script tes/maintenance nggak nulis ke file
   sesi yang dipakai bot yang lagi jalan (bisa nimpa sesi user) */
const SESSION_DIR=process.env.RAFZ_SESSION_DIR||"./library/database/"
const SESSION_TTL=30*60*1000
const CONFIRM_TTL=5*60*1000

class FileMap{
 constructor(file,ttl){
  this.file=file
  this.ttl=ttl||0
  this.map=new Map()
  this.at=new Map()
  this.load()

  /* objek sesi sering diubah langsung (w.ram=.., w.awaiting=..) tanpa
     set(), jadi ditulis ulang berkala biar perubahannya ikut tersimpan */
  const timer=setInterval(()=>this.save(),5000)
  if(timer.unref) timer.unref()
 }

 load(){
  try{
   const raw=JSON.parse(fs.readFileSync(this.file,"utf8"))||{}
   const now=Date.now()
   for(const key of Object.keys(raw)){
    const row=raw[key]
    if(!row||row.v===undefined) continue
    /* sesi yang udah lama nggak dipakai jangan dihidupkan lagi */
    if(this.ttl && now-(row.at||0)>this.ttl) continue
    this.map.set(key,row.v)
    this.at.set(key,row.at||now)
   }
  }catch{}
 }

 save(){
  try{
   const out={}
   for(const [key,val] of this.map.entries())
    out[key]={at:this.at.get(key)||Date.now(),v:val}
   fs.mkdirSync(this.file.replace(/[^/]*$/,""),{recursive:true})
   fs.writeFileSync(this.file,JSON.stringify(out,null,2))
  }catch{}
 }

 get(key){
  if(!this.map.has(key)) return undefined
  /* kadaluarsa kena cek di sini juga, bukan cuma waktu load */
  if(this.ttl && Date.now()-(this.at.get(key)||0)>this.ttl){ this.delete(key); return undefined }
  /* sesi ini dipakai -> umurnya diperpanjang, jadi TTL-nya berarti
     "nggak disentuh sekian lama", bukan "dibuat sekian lama lalu mati" */
  this.at.set(key,Date.now())
  return this.map.get(key)
 }

 /* berapa lama sesi ini nggak disentuh (ms). infinity kalau nggak ada.
    Dipakai buat nentuin sesi lama udah "selesai" apa belum. */
 idle(key){
  if(!this.map.has(key)) return Infinity
  return Date.now()-(this.at.get(key)||0)
 }

 has(key){ return this.get(key)!==undefined }

 set(key,val){
  this.map.set(key,val)
  this.at.set(key,Date.now())
  this.save()
  return this
 }

 delete(key){
  this.map.delete(key)
  this.at.delete(key)
  this.save()
  return true
 }

 entries(){ return this.map.entries() }
}

/* tiap sesi punya file sendiri biar yang satu nggak nimpa yang lain */
const SESSION_FILE={
 panel:SESSION_DIR+"session-panel.json",
 admin:SESSION_DIR+"session-admin.json",
 delete:SESSION_DIR+"session-delete.json",
 lang:SESSION_DIR+"session-lang.json",
 confirm:SESSION_DIR+"session-confirm.json"
}

/* PENTING: instance-nya disimpan di global.
   case.js punya self-reload (fs.watchFile di bawah), jadi tiap file ini
   berubah, module-nya di-load ulang. Kalau tiap reload bikin instance
   baru, sesi yang lama (dan penulis file yang lama) ikut nyangkut hidup
   dan saling nimpa -> itulah kenapa sesi "hilang" tiap habis reload. */
global.sessionStore=global.sessionStore||{
 /* sesi picker /cpanel: sender -> {username,targetId,ram,disk,cpu,bulan,server,awaiting} */
 panel:new FileMap(SESSION_FILE.panel,SESSION_TTL),
 /* sesi picker /cadmin: sender -> {username,targetId,serverChoices,msgId} */
 admin:new FileMap(SESSION_FILE.admin,SESSION_TTL),
 /* sesi /delpanel: sender -> {serverName,awaiting,msgId} */
 delete:new FileMap(SESSION_FILE.delete,SESSION_TTL),
 /* pesan picker /lang: sender -> message_id */
 lang:new FileMap(SESSION_FILE.lang,SESSION_TTL),
 /* konfirmasi add (addowner/addseller/addsuper/addpv): sender -> {id,at,msgId,chat} */
 confirm:new FileMap(SESSION_FILE.confirm,CONFIRM_TTL)
}

const panelWizard = global.sessionStore.panel
const adminWizard = global.sessionStore.admin
const deleteWizard = global.sessionStore.delete
const langPicker = global.sessionStore.lang
const pendingConfirm = global.sessionStore.confirm

/* tulis semua sesi SEKARANG. Dipakai abis wizShow nge-set msgId, biar id
   pesan pickernya nggak nunggu autosave 5 detik (kalau bot restart cepet,
   sesinya bisa kehilangan id pesannya). */
function saveAllSessions(){
 for(const key of Object.keys(global.sessionStore)){
  const s=global.sessionStore[key]
  if(s && typeof s.save==="function") s.save()
 }
}


module.exports = async (m,bot)=> {
try {

async function sendPrivate(m,target,text){
try{
await conn.sendMessage(target,{
text:text,
parse_mode:"HTML",
disable_web_page_preview:true
})
if(m.isGroup) await m.reply(tr("common.checkPv"))
}catch{
await m.reply(tr("common.pvFailed"))
}
}

function safeReply(m,text){
 if(m.isGroup) return m.reply(text)
 return conn.sendMessage(m.chat,text)
}

const ownerDB = loadJSON("./library/database/owner.json",[])
const sellerDB = loadJSON("./library/database/seller.json",[])
const superDB  = loadJSON("./library/database/superseller.json",[])

const isCreator = global.owner.includes(String(m.sender))
const isOwner   = isCreator || ownerDB.includes(String(m.sender))
const isSuper   = superDB.includes(String(m.sender))
const isSeller  = sellerDB.includes(String(m.sender)) || isSuper || isOwner
const sender    = String(m.sender)

/* Baca json + paksa bentuknya sesuai default.
   PENTING: panel.json/admin.json key-nya user id (angka). Kalau file-nya
   array, arr["123456789"] = x bikin array melar jadi ratusan juta elemen
   dan JSON.stringify langsung mati (Invalid string length). */
function loadJSON(path,def){
 const wantArray=Array.isArray(def)
 const fix=()=>{ try{ fs.writeFileSync(path,JSON.stringify(def,null,2)) }catch{} ; return def }
 try{
  const raw=JSON.parse(fs.readFileSync(path))
  if(wantArray) return Array.isArray(raw)?raw:fix()
  if(Array.isArray(raw)||raw===null||typeof raw!=="object") return fix()
  return raw
 }catch{ return fix() }
}

const PANEL_PATH="./library/database/panel.json"
const ADMIN_PATH="./library/database/admin.json"
const PRIVATE_PATH="./library/database/private.json"

let panelDB=loadJSON(PANEL_PATH,{})
let adminDB=loadJSON(ADMIN_PATH,{})
let privateDB=loadJSON(PRIVATE_PATH,[])
let blClean = loadJSON("./library/database/blclean.json", [])

const savePanel=()=>fs.writeFileSync(PANEL_PATH,JSON.stringify(panelDB,null,2))
const saveAdmin=()=>fs.writeFileSync(ADMIN_PATH,JSON.stringify(adminDB,null,2))
const savePrivate=()=>fs.writeFileSync(PRIVATE_PATH,JSON.stringify(privateDB,null,2))
const isPrivateUser=(uid)=>isCreator || privateDB.includes(String(uid))
const saveBL = () =>
 fs.writeFileSync(
  "./library/database/blclean.json",
  JSON.stringify(blClean, null, 2)
 )

const getSrv=(name)=>{
 const cfg=global.panelServer[name||"1"]
 if(!cfg) throw "server ga ada"
 return cfg
}

/* ================= PANEL ================= */

const isPanelMine=(uid,id,srv)=>{
 if(isOwner) return true
 let my=panelDB[uid]||[]
 return my.find(x=>x.id===Number(id)&&x.srv===srv)
}

const addPanelOwner=(uid,id,srv)=>{
 if(!panelDB[uid]) panelDB[uid]=[]
 /* jangan dobel: command yang sama dijalanin lagi bikin id kepush terus */
 if(panelDB[uid].some(x=>x.id===Number(id)&&x.srv===srv)) return
 panelDB[uid].push({id:Number(id),srv})
 savePanel()
}

const delPanelOwner=(id)=>{
 for(const u in panelDB){
  panelDB[u]=panelDB[u].filter(x=>x.id!==Number(id))
 }
 savePanel()
}

const getPanelServer=(id)=>{
 for(const u in panelDB){
  for(const p of panelDB[u]){
   if(p.id===Number(id)) return p.srv
  }
 }
 return null
}

const getUserPanels=(uid)=>{
 return panelDB[uid]||[]
}

/* ================= ADMIN ================= */

const isAdminMine=(uid,id)=>{
 if(isOwner) return true
 let my=adminDB[uid]||[]
 return my.includes(Number(id))
}

const addAdminOwner=(uid,id)=>{
 if(!adminDB[uid]) adminDB[uid]=[]
 /* jangan dobel: /cadmin buat admin yang sama -> user panel-nya dipakai
   ulang, jadi id-nya bakal kepush lagi kalau nggak dicek */
 if(adminDB[uid].includes(Number(id))) return
 adminDB[uid].push(Number(id))
 saveAdmin()
}

const delAdminOwner=(id)=>{
 for(const u in adminDB){
  adminDB[u]=adminDB[u].filter(x=>x!==Number(id))
 }
 saveAdmin()
}

const getUserAdmins=(uid)=>{
 return adminDB[uid]||[]
}

/* ================= OWNER FETCH ================= */

const getAllServers=()=>Object.keys(global.panelServer)

async function fetchAllServers(endpoint){
 let results=[]
 for(const name of getAllServers()){
  const srv=getSrv(name)
  try{
   let f=await fetch(srv.domain+endpoint,{
    headers:{Authorization:"Bearer "+srv.apikey,Accept:"application/json"}
   })
   let j=await f.json()
   results.push({server:name,data:j.data||[]})
  }catch{}
 }
 return results
}
//=======================================================

const fetchAllPages = async (url, headers = {}) => {
 let page = 1
 let totalPages = 1
 let result = []

 while(page <= totalPages){

  try{

   const res = await fetch(
    `${url}?page=${page}`,
    {
     headers
    }
   )

   const json = await res.json()

   if(Array.isArray(json.data)){
    result.push(...json.data)
   }

   totalPages =
    json.meta?.pagination?.total_pages || 1

   page++

  }catch{
   break
  }

 }

 return result
}

const getServerTarget = (txt) => {

 let server = "1"

 if(txt.includes("|")){

  const s = txt.split("|")[1]?.trim()

  if(global.panelServer[s]){
   server = s
  }

 }

 return server
}

const getAllServerTargets = (txt) => {

 if(txt.includes("|")){

  const s = txt.split("|")[1]?.trim()

  if(global.panelServer[s]){
   return [s]
  }

 }

 return Object.keys(global.panelServer)
}

const safeUsers = [
 "rafz",
 "owner",
 "admin"
]

//=======================================================
/* let (bukan const): /cadmin bisa nerima input "nama|id" tanpa command */
let command = m.command
let text = m.text || ""

/* ===== LANGUAGE ===== */
const lang = m.lang || "id"
const tr = (key, vars) => (m.t ? m.t(key, vars) : key)
const prefix = (global.prefix && global.prefix[0]) || "/"
const prefixAll = (global.prefix && global.prefix.length) ? global.prefix.join(" ") : prefix
const example = (teks) => tr("common.example", { prefix: prefixAll, cmd: prefix + command, args: teks })

const raw = (m.raw || "").trim()

/* /cadmin lagi nunggu "nama|id": kalau user ngetik langsung tanpa command,
   lanjutin sebagai command cadmin - biar step pilih server tetap di pesan yang sama */
let adminResume=false
let deleteResume=false
if(!m.isCmd){
 const panelPending=panelWizard.get(sender)
 const awPending=adminWizard.get(sender)
 const dwPending=deleteWizard.get(sender)

 if(dwPending && dwPending.awaiting==="id" && raw){
  /* Setelah tombol Search ID ditekan, terima ID biasa tanpa perlu
     mengetik ulang command atau memakai pemisah |server. */
  deleteWizard.delete(sender)
  deleteResume=true
  const deleteCommand=dwPending.kind==="admin"?"deladmin":dwPending.kind==="seller"?"delseller":dwPending.kind==="owner"?"delowner":dwPending.kind==="super"?"delsuper":"delpanel"
  command=deleteCommand
  m.command=deleteCommand
  text=raw+(dwPending.serverName?"|"+dwPending.serverName:"")
 } else if(raw.includes("|") && !(panelPending && panelPending.awaiting) && awPending &&
    (awPending.awaiting==="start" || Array.isArray(awPending.serverChoices))){
  /* Terima input baru walau picker lama sudah terlanjur sampai ke langkah
     server. Input username|target harus memulai flow admin yang baru, bukan
     diabaikan karena sesi lama belum dibersihkan. */
  awPending.awaiting=null
  adminResume=true
  command="cadmin"
  m.command="cadmin"   /* switch-nya baca m.command */
  text=raw
 }
}

const USER_CACHE="./library/database/usercache.json"

const isNumericId=(v)=>/^-?\d+$/.test(String(v==null?"":v).trim())

const readUserCache=()=>{
 const cache=loadJSON(USER_CACHE,{})
 return (cache && typeof cache==="object" && !Array.isArray(cache))?cache:{}
}

/* simpan username -> id. id sengaja di-String biar nggak ketuker
   sama nomor message id waktu dibandingin. */
const rememberUser=(username,id)=>{
 if(!username||!id) return
 try{
  const cache=readUserCache()
  cache[String(username).replace(/^@/,"").toLowerCase()]=String(id)
  fs.writeFileSync(USER_CACHE,JSON.stringify(cache,null,2))
 }catch{}
}

const cachedUserID=(username)=>{
 if(!username) return null
 try{ return readUserCache()[String(username).replace(/^@/,"").toLowerCase()]||null }
 catch{ return null }
}

/* @username -> id. Cache dulu, kalau belum ada tanya telegram
   (getChat nerima @username, jadi tag orang yang belum pernah
   nge-chat bot pun tetap bisa diresolve). */
const resolveUsername=async (username)=>{
 const un=String(username||"").replace(/^@/,"").trim()
 if(!un) return null

 const cached=cachedUserID(un)
 if(cached) return String(cached)

 try{
  const ch=await bot.getChat("@"+un)
  if(ch&&ch.id){ rememberUser(un,ch.id); return String(ch.id) }
 }catch{}

 return null
}

/* target dari pesan yang di-reply. Kalau pesan yang di-reply itu hasil
   forward, yang diambil pemilik ASLINYA (bukan yang nge-forward). */
const quotedTarget=(m)=>{
 const q=m.quoted
 if(!q) return null
 if(q.forward&&q.forward.id) return String(q.forward.id)
 if(isNumericId(q.sender)) return String(q.sender)
 return null
}

/* ============ CARI TARGET (ID / @username / tag / reply / forward) ============
   Urutan: argumen dulu -> reply -> pesan yang di-forward.
   Jadi /addseller 123456 tetap kena 123456 walau sambil nge-reply orang lain,
   dan reply ke pesan forward kena pemilik aslinya.
   null = nggak ketemu, pemanggil yang ngasih pesan errornya. */
const getUserID=async (m,text)=>{

 const arg=String(text==null?"":text).trim()

 if(arg){

  /* tag "teks" (text_mention) = paling akurat */
  for(const ent of m.entities||[]){
   if(ent.type==="text_mention" && ent.user && ent.user.id)
    return String(ent.user.id)
  }

  /* @username */
  const mention=arg.match(/^@([A-Za-z0-9_]{4,32})/)
  if(mention) return await resolveUsername(mention[1])

  /* ID telegram langsung */
  if(isNumericId(arg)) return arg

  /* fallback angka (ID yang ketempelin teks lain) */
  const digits=arg.replace(/[^0-9]/g,"")
  if(digits) return digits
 }

 const reply=quotedTarget(m)
 if(reply) return reply

 if(m.forward&&m.forward.id) return String(m.forward.id)

 return null
}

/* pesan error yang pas buat target yang gagal diresolve */
const needTargetMsg=(text)=>{
 if(String(text==null?"":text).trim().startsWith("@")) return tr("common.usernameNotFound")
 return tr("common.needTargetShort")
}

/* label user buat tag: @username > nama dari reply > ID.
   usercache isinya username -> id, jadi id-nya dicari balik. */
const userNameOf=(id,nameHint)=>{
const uid=String(id||"")
let username=null
let name=nameHint||null

if(m.quoted && String(m.quoted.sender)===uid){
 username=m.quoted.username||username
 name=m.quoted.name||name
}

/* nama dari pesan forward (pesan ini atau pesan yang di-reply) */
for(const f of [m.quoted&&m.quoted.forward,m.forward]){
 if(f && f.id && String(f.id)===uid){
  username=f.username||username
  name=f.name||name
 }
}

try{
const cache=loadJSON("./library/database/usercache.json",{})
if(cache && typeof cache==="object" && !Array.isArray(cache)){
 for(const u of Object.keys(cache)){
  if(String(cache[u])===uid){ username=u; break }
 }
}
}catch{}

if(username) return "@"+username
if(name) return name
if(uid===String(m.sender)) return "@"+String(m.pushName||uid)
return "ID "+uid
}

/* tag yang bisa diklik (link mention) - jalan walau user-nya nggak punya username */
const userTag=(id,nameHint)=>{
const uid=String(id||"")
return '<a href="tg://user?id='+uid+'">'+userNameOf(uid,nameHint)+'</a>'
}

function loadDB(file){
try{return JSON.parse(fs.readFileSync(file))}
catch{return []}
}

const saveDB=(file,data)=>{
fs.writeFileSync(file,JSON.stringify(data,null,2))
}

/* ================= PASSWORD PANEL =================
   Password harus lolos validasi panel: minimal 8 karakter dan umumnya
   wajib campur huruf besar/kecil + angka + simbol. Generator lama
   (username + 4 karakter acak) bisa jadi cuma 6-7 karakter kalau
   username-nya pendek, dan panel nolak dengan
   "The password field must be at least 8 characters". */

const PW_LOWER="abcdefghijkmnopqrstuvwxyz"
const PW_UPPER="ABCDEFGHJKLMNPQRSTUVWXYZ"
const PW_DIGIT="23456789"
/* sengaja tanpa & < > " ' \\ biar aman di HTML/JSON pesan */
const PW_SYMBOL="!@#$%*?-_"
const PW_ALL=PW_LOWER+PW_UPPER+PW_DIGIT+PW_SYMBOL

const genPassword=(len=14)=>{
 const pick=(set)=>set[crypto.randomInt(set.length)]

 /* dijamin ada minimal satu dari tiap jenis karakter */
 const out=[pick(PW_LOWER),pick(PW_UPPER),pick(PW_DIGIT),pick(PW_SYMBOL)]
 while(out.length<len) out.push(pick(PW_ALL))

 /* acak urutan-nya biar polanya nggak ketebak */
 for(let i=out.length-1;i>0;i--){
  const j=crypto.randomInt(i+1)
  ;[out[i],out[j]]=[out[j],out[i]]
 }

 return out.join("")
}

/* bikin user panel. Aturan password tiap panel beda-beda -> kalau panel
   nolak karena password, generate password baru dan coba lagi. */
const createPanelUser=async ({srv,fields,password,attempts=3})=>{

 const headers={Accept:"application/json","Content-Type":"application/json",Authorization:"Bearer "+srv.apikey}

 let pass=password||genPassword()
 let data=null
 let reason=null

 for(let i=0;i<attempts;i++){

  try{
   const res=await fetch(srv.domain+"/api/application/users",{
    method:"POST",
    headers,
    body:JSON.stringify({...fields,password:pass})
   })

   data=await res.json()
   if(data && data.attributes) return {ok:true,data,password:pass}

   reason=apiReason(data&&data.errors)||("HTTP "+res.status+" dari "+srv.domain)
  }catch(e){
   reason=e.message||String(e)
  }

  /* cuma diulang kalau yang ditolak memang passwordnya */
  if(!/password/i.test(String(reason))) break
  pass=genPassword()
 }

 return {ok:false,data,password:pass,reason}
}

/* ================= CREATE PANEL (dipakai mode teks & mode picker) ================= */

async function createPanel(m,{username,targetId,serverName,ram,disk,cpu,bulan},wiz){

const srv=global.panelServer[serverName]
if(!srv) return failWith("panel.fail",tr("common.serverMissing")+" ("+serverName+")")

const email=username+"@gmail.com"
/* digenerate di sini, bisa diganti kalau panel nolak passwordnya */
let password=genPassword()

/* detail panel dikirim pakai bahasa si penerima, bukan bahasa seller */
const tl=LANG.getLang(targetId)
const tt=(key,vars)=>LANG.t(tl,key,vars)

const appHeaders={Accept:"application/json","Content-Type":"application/json",Authorization:"Bearer "+srv.apikey}

let userData=null
let eggData=null
let result=null

try{

 /* create user - password dicoba ulang otomatis kalau panel nolak */
 const made=await createPanelUser({
  srv,
  fields:{email,username,first_name:username,last_name:"Server",language:"en"},
  password
 })

 if(!made.ok) return failWith("panel.fail",made.reason)

 password=made.password
 userData=made.data

 /* get egg */
 const eggFetch=await fetch(`${srv.domain}/api/application/nests/${srv.nestid}/eggs/${srv.egg}`,{headers:{Authorization:"Bearer "+srv.apikey,Accept:"application/json"}})
 eggData=await eggFetch.json()

 if(!eggData.attributes?.startup)
  return failWith("panel.fail",tr("panel.eggFail"))

 /* create server */
 const serverFetch=await fetch(srv.domain+"/api/application/servers",{
  method:"POST",
  headers:appHeaders,
  body:JSON.stringify({
   name:username,
   user:userData.attributes.id,
   egg:parseInt(srv.egg),
   docker_image:"ghcr.io/parkervcp/yolks:nodejs_24",
   startup:eggData.attributes.startup,
   environment:{INST:"npm",USER_UPLOAD:"0",AUTO_UPDATE:"0",CMD_RUN:"npm start"},
   limits:{memory:ram,swap:0,disk:disk,io:500,cpu:cpu},
   feature_limits:{databases:5,backups:5,allocations:5},
   deploy:{locations:[parseInt(srv.loc)],dedicated_ip:false,port_range:[]}
  })
 })

 result=await serverFetch.json()

 if(!result || !result.attributes)
  return failWith("panel.fail",apiReason(result&&result.errors)||("HTTP "+serverFetch.status+" dari "+srv.domain))

}catch(e){
 return failWith("panel.fail",e.message||String(e))
}

addPanelOwner(String(targetId),result.attributes.id,serverName)

let teks = tt("panel.created",{username:username,password:password,domain:srv.domain,loginText:tt("panel.loginText"),ram:ram==0?tt("common.unlimited"):ram/1000+"GB",disk:disk==0?tt("common.unlimited"):disk/1000+"GB",cpu:cpu==0?tt("common.unlimited"):cpu+"%",id:result.attributes.id,months:bulan})

let dmOk=true
let dmErr=null
try{
 await conn.sendMessage(targetId,{
  text:teks,
  parse_mode:"HTML",
  disable_web_page_preview:true,
  reply_markup:{
   inline_keyboard:[
    [{text:"🌐 Login Panel",url:srv.domain}],
    [{text:"📋 Copy Username",switch_inline_query:username}],
    [{text:"🔑 Copy Password",switch_inline_query:password}]
   ]
  }
 })
}catch(e){ dmOk=false; dmErr=e.message||String(e) }

/* user belum pernah chat bot -> kasih datanya ke seller biar bisa dikirim manual */
if(!dmOk)
 return wizDone(wiz,tr("panel.doneDmFail",{tag:userTag(targetId),reason:dmErr||tr("common.unknown"),username:username,password:password,id:result.attributes.id}))

/* sukses: EDIT pesan picker jadi status DONE + tag pemilik panel */
/* notif grup */
try{
  const gid=global.notifGroupId
  if(gid){
    bot.sendMessage(gid,
      `🟢 <b>Panel Dibuat</b>\n`+
      `👤 User    : <code>${targetId}</code>\n`+
      `🖥️ Server  : ${serverName}\n`+
      `📦 Panel ID: <code>${result.attributes.id}</code>\n`+
      `👤 By      : <code>${sender}</code>\n`+
      `🕐 ${new Date().toLocaleString(global.locale || "id-ID",{timeZone:global.timeZone || "Asia/Jakarta"})}`,
      {parse_mode:"HTML"}
    ).catch(()=>{})
  }
}catch{}
return wizDone(wiz,tr("panel.done",{tag:userTag(targetId),username:username,srv:serverName,id:result.attributes.id}))
}

/* ================= PICKER RESOURCE ================= */

const WIZ_STEPS = ["ram","disk","cpu","bulan"]

/* emoji prefix tiap step, biar tombolnya visual & konsisten */
const STEP_EMOJI = {ram:"💾",disk:"💿",cpu:"⚙️",bulan:"📅"}

/* [nilai, label]. nilai 0 = unlimited, label null = pakai bahasa (i18n) */
const WIZ_CHOICES = {
ram:[[1,"1 GB"],[8,"8 GB"],[16,"16 GB"],[0,null]],
disk:[[1,"1 GB"],[50,"50 GB"],[100,"100 GB"],[0,null]],
cpu:[[50,"50%"],[100,"100%"],[400,"400%"],[0,null]],
bulan:[[1,null],[3,null],[6,null],[12,null]]
}

const WIZ_LABEL = {ram:"panel.ramLabel",disk:"panel.diskLabel",cpu:"panel.cpuLabel",bulan:"panel.durationLabel"}
const WIZ_UNIT = {ram:"GB",disk:"GB",cpu:"%",bulan:""}

const wizText=(step,n)=>{
 if(step==="bulan") return tr("panel.monthsOption",{n:n})
 if(n===0) return tr("common.unlimited")
 return n+WIZ_UNIT[step]
}

/* ram & disk disimpan dalam MB */
const wizShown=(step,val)=>{
 if(val===undefined) return "—"
 if(step==="ram"||step==="disk") return val===0?tr("common.unlimited"):(val/1000)+" GB"
 return wizText(step,val)
}

const wizNext=(w)=>{
 for(const s of WIZ_STEPS) if(w[s]===undefined) return s
 if(w.serverChoices.length>1 && !w.server) return "server"
 return null
}

const wizServerChoices=()=>{
 const all=Object.keys(global.panelServer||{})
 return (isSuper||isOwner)?all:["1"]
}

const wizScreen=(w,step)=>{
 let out=tr("panel.wizardTitle")+"\n\n"+
tr("panel.wizardUser")+": <code>"+w.username+"</code>\n"+
tr("panel.wizardTarget")+": <code>"+w.targetId+"</code>\n\n"+
tr("panel.ramLabel")+" : <b>"+wizShown("ram",w.ram)+"</b>\n"+
tr("panel.diskLabel")+" : <b>"+wizShown("disk",w.disk)+"</b>\n"+
tr("panel.cpuLabel")+" : <b>"+wizShown("cpu",w.cpu)+"</b>\n"+
tr("panel.durationLabel")+" : <b>"+wizShown("bulan",w.bulan)+"</b>"

 if(w.serverChoices.length>1)
  out+="\n"+tr("panel.wizardServerLabel")+" : <b>"+(w.server||"—")+"</b>"

 out+="\n\n"+(step==="server"?tr("panel.wizardSelectServer"):tr("panel.wizardAsk",{res:tr(WIZ_LABEL[step])}))
 return out
}

const wizRows=(w,step)=>{
 const rows=[]
 let line=[]

 if(step==="server") return serverPickRows(w.serverChoices,"cpanel")

 {
  for(const [n,txt] of WIZ_CHOICES[step]){
   line.push({text:STEP_EMOJI[step]+" "+(txt||wizText(step,n)),callback_data:`/cpanel ${step} ${n}`,style:n===0?"success":"primary"})
   if(line.length===2){ rows.push(line); line=[] }
  }
  if(line.length){ rows.push(line); line=[] }
  rows.push([{text:"✏️ "+tr("panel.custom"),callback_data:`/cpanel ${step} custom`,style:"primary"}])
 }

 if(line.length) rows.push(line)
 rows.push([{text:"⛔ "+tr("panel.cancel"),callback_data:"/cpanel cancel",style:"danger"}])
 return {inline_keyboard:rows}
}

const wizCancelRow=(cbCmd)=>({text:"⛔ "+tr("panel.cancel"),callback_data:"/"+(cbCmd||"cpanel")+" cancel",style:"danger"})

/* tombol pilih server, dipakai bareng oleh /cpanel dan /cadmin */
const serverPickRows=(choices,cbCmd)=>{
 const rows=[]
 let line=[]
 for(const name of choices){
  const s=global.panelServer[name]||{}
   line.push({text:"🖥️ "+name+". "+(s.name||name),callback_data:"/"+cbCmd+" server "+name,style:"primary"})
  if(line.length===2){ rows.push(line); line=[] }
 }
 if(line.length) rows.push(line)
 rows.push([{text:"⛔ "+tr("panel.cancel"),callback_data:"/"+cbCmd+" cancel",style:"danger"}])
 return {inline_keyboard:rows}
}

/* buang warna tombol (buat server yang belum kenal field style) */
const wizStrip=(k)=>({inline_keyboard:((k&&k.inline_keyboard)||[]).map(r=>r.map(({style,...b})=>b))})

/* tutup satu sesi: pesannya ditandai dibatalkan + tombolnya dicopot.
   chat_id-nya ikut pesan sesi, jadi sesi yang kebuka di chat lain pun
   tombolnya bener-bener mati (pesannya dikirim sama bot, jadi bisa diedit). */
const killSession=async (w)=>{
 if(!w||!w.msgId) return
 const opt={chat_id:w.chat||m.chat,message_id:w.msgId}
 try{
  await bot.editMessageText(tr("panel.cancelled"),{...opt,parse_mode:"HTML",reply_markup:{inline_keyboard:[]}})
 }catch{
  try{ await bot.editMessageReplyMarkup({inline_keyboard:[]},opt) }catch{}
 }
}

/* ===== CUMA BOLEH SATU SESI JALAN (cpanel / cadmin) =====
   Kalau command dipanggil lagi sementara sesi lamanya belum selesai,
   sesi lama DIBATALKAN dulu, bukan cuma ditimpa:
   - sesi yang mau dipakai ulang di chat ini -> pesannya dipakai buat picker
     baru (anti numpuk, tombolnya ketimpa)
   - selain itu -> pesannya ditandai dibatalkan + tombolnya dicopot
   reuse=false buat mode yang nggak bikin sesi (mode cepat).
   force=true (tombol "buat baru di sini" / cancel) buat maksa batalin
   sesi di chat lain juga. Tanpa force, sesi yang MASIH HIDUP di chat lain
   dibiarin: dia cukup dilaporin (sessionGuard), jangan dimatiin diam-diam
   gara-gara user ngerjain command lain di chat ini.
   hasil: {msgId} pesan lama yang masih boleh dipakai ulang, atau null. */
const dropSession=async (map,reuse=true,force=false)=>{

 /* idle dibaca dulu: get() sendiri memperpanjang umur sesi */
 const idle=map.idle(sender)
 const w=map.get(sender)
 if(!w) return null

 const sameChat=!w.chat||String(w.chat)===String(m.chat)
 const liveSomewhere=!sameChat && !!w.msgId && idle<=SESSION_IDLE
 if(liveSomewhere && !force) return null

 map.delete(sender)

 const canReuse=reuse!==false && sameChat && !!w.msgId

 if(!canReuse) await killSession(w)

 return canReuse?{msgId:w.msgId}:null
}

/* cpanel & cadmin nggak boleh jalan bareng di CHAT YANG SAMA: cuma sesi
   command yang lagi dipanggil yang boleh lanjut, sesi command lain
   dibatalkan (kecuali yang masih hidup di chat lain - lihat dropSession). */
const dropSessions=async (activeMap,reuse=true,force=false)=>{
 const other=(activeMap===panelWizard)?adminWizard:panelWizard
 await dropSession(other,false,force)
 return await dropSession(activeMap,reuse,force)
}

/* ===== SESI MASIH ADA DI CHAT LAIN =====
   Kalau sesi /cpanel atau /cadmin ada di chat lain, jangan langsung
   dibatalkan atau dibikin sesi baru: kasih tahu kalau sesinya "udah ada",
   sebut di mana, terus forward pesan sesinya ke chat ini. */
const sessionWhere=(w)=>{
 const chat=String(w.chat||"")

 /* link langsung ke pesannya (supergroup doang yang bisa dibikin beginian) */
 if(w.msgId && chat.startsWith("-100"))
  return {text:"pesan #"+w.msgId,link:"https://t.me/c/"+chat.replace("-100","")+"/"+w.msgId}
 if(w.msgId) return {text:"pesan #"+w.msgId,link:null}
 return {text:"chat "+chat,link:null}
}

/* sesi lama nggak boleh ngeblokir selamanya: picker yang ditinggalin user
   (nganggur SESSION_IDLE, bisa diatur lewat RAFZ_SESSION_IDLE dalam menit)
   atau yang pesannya udah nggak ada dianggap UDAH SELESAI -> dibatalkan,
   terus command barunya bikin sesi baru di chat ini. */
const SESSION_IDLE=(Number(process.env.RAFZ_SESSION_IDLE)||10)*60*1000

/* error yang artinya pesannya/chat-nya udah nggak bisa dipakai lagi */
const goneError=(e)=>{
 const msg=String((e&&e.message)||e||"").toLowerCase()
 return msg.includes("not found")||msg.includes("message_id_invalid")||
        msg.includes("chat not found")||msg.includes("peer_id_invalid")||
        msg.includes("kicked")||msg.includes("not a member")||
        msg.includes("bot was blocked")
}

/* forward pesan sesi ke chat ini. false = pesannya udah nggak ada,
   jadi sesinya nggak bisa dilanjutin lagi. */
const forwardSession=async (w)=>{
 if(!w||!w.msgId) return false
 try{ await bot.forwardMessage(m.chat,w.chat,w.msgId); return true }
 catch(e){ return !goneError(e) }
}

/* sesi lama masih hidup di chat lain: kasih tahu di mana, forward pesannya,
   plus tombol buat nge-end sesi itu dan mulai sesi baru di chat ini. */
const notifySession=async (w,cmd)=>{
 const where=sessionWhere(w)
 const info=where.link?('<a href="'+where.link+'">'+where.text+"</a>"):where.text

 await m.reply(tr("session.already",{cmd:prefix+cmd,where:info})+"\n\n"+tr("session.howto",{cmd:prefix+cmd}),{
  parse_mode:"HTML",
  reply_markup:{inline_keyboard:[
   [{text:tr("session.newBtn"),callback_data:"/"+cmd+" new",style:"primary"}],
   [{text:tr("panel.cancel"),callback_data:"/"+cmd+" cancel",style:"danger"}]
  ]}
 })
 return true
}

/* hasil pengecekan sesi lama:
   "alive" = masih jalan di chat lain, user udah dikasih tahu -> stop di sini
   "ended" = sesi lama udah selesai/kedaluwarsa/pesannya ilang -> dibatalkan,
             lanjut bikin sesi baru di chat ini
   null    = nggak ada sesi lain, jalan biasa */
const sessionGuard=async (activeMap,cmd)=>{
 const other=(activeMap===panelWizard)?adminWizard:panelWizard

 for(const [map,c] of [[activeMap,cmd],[other,(other===adminWizard)?"cadmin":"cpanel"]]){

  /* penting: baca idle DULU, karena get() memperpanjang umur sesi */
  const idle=map.idle(sender)
  const w=map.get(sender)
  if(!w) continue

  /* sesi di chat ini -> lanjut aja di pesan yang sama, tanpa notifikasi */
  if(!w.chat || String(w.chat)===String(m.chat)) continue

  const where=sessionWhere(w)
  const alive=!!w.msgId && idle<=SESSION_IDLE && await forwardSession(w)

  if(!alive){
   map.delete(sender)
   await killSession(w)
   await m.reply(tr("session.ended",{cmd:prefix+c,where:where.text}),{parse_mode:"HTML"})
   return "ended"
  }

  /* sesi lama masih hidup -> user udah dikasih tahu + tombol buat
     nge-end dan mulai baru; command-nya berhenti di sini dulu */
  await notifySession(w,c)
  return "alive"
 }

 return null
}

/* ---- ANTI SPAM: semua step cuma NGUEDIT satu pesan yang sama ---- */
const wizEdit=async (w,out,kb,warn)=>{

 const body=warn?("⚠️ "+warn+"\n\n"+out):out
  const opt={parse_mode:"HTML",disable_web_page_preview:true,reply_markup:kb}

 /* kirim pesan baru. Dipakai waktu pertama kali, dan waktu pesan lama
   sudah nggak bisa diedit (sesi dibuka di chat lain / pesannya kehapus),
   supaya sesi tetap jalan dan user nggak dikasih respon yang diem aja. */
 const fresh=async ()=>{
  try{
   return await bot.sendMessage(m.chat,body,{...opt,reply_to_message_id:m.id,allow_sending_without_reply:true})
  }catch{
   try{ return await bot.sendMessage(m.chat,body,{...opt,reply_markup:wizStrip(opt.reply_markup),reply_to_message_id:m.id,allow_sending_without_reply:true}) }catch{ return null }
  }
 }

 const editAt=async (mid,o)=>{
  try{
   return await bot.editMessageText(body,{chat_id:m.chat,message_id:mid,...o})
  }catch(e){
   const em=String(e.message||e)
   /* spam klik tombol: telegram balas "not modified" / rate limit -> diem aja */
   if(em.includes("not modified")) return null
   if(em.includes("Too Many Requests")) return null
   /* pesan lama udah nggak ada / beda chat -> kirim baru, jangan gagal diam-diam */
   if(em.includes("message to edit not found")) return fresh()
   if(em.includes("message can't be edited")) return fresh()
   if(em.includes("chat not found")) return fresh()
   try{ return await bot.editMessageText(body,{chat_id:m.chat,message_id:mid,...o,reply_markup:wizStrip(o.reply_markup)}) }catch{ return fresh() }
  }
 }

 /* 1. update dari tombol -> edit pesan tombolnya sendiri */
 if(m.callback) return editAt(m.callback.message.message_id,opt)

 /* 2. sudah punya pesan picker -> edit pesan itu, jangan kirim baru */
 if(w&&w.msgId) return editAt(w.msgId,opt)

 /* 3. pertama kali -> kirim sekali, id-nya disimpan buat edit step berikutnya */
 return fresh()
}

/* render + simpan id pesan biar step selanjutnya tinggal ngedit */
const wizShow=async (w,out,kb,warn)=>{
 const res=await wizEdit(w,out,kb,warn)
 if(w&&res&&res.message_id){ w.msgId=res.message_id; saveAllSessions() }
 return true
}

/* status akhir (DONE / gagal): kalau ada pesan wizard -> EDIT pesan itu,
   jadi cuma kelihatan di pesan kita sendiri, nggak nambah pesan baru.
   Kalau nggak ada (mode cepat) baru kirim pesan baru. */
const wizDone=async (w,out,kb)=>{
 if(w && (w.msgId || m.callback)){
  const res=await wizEdit(w,out,kb||{inline_keyboard:[]})
  if(res) return true
 }
 return m.reply(out,{parse_mode:"HTML"})
}

/* layar awal (tanpa argumen): minta nama|target, ada tombol Batal */
const wizAskStart=async (force=false)=>{
 /* sesi lama dibatalkan dulu, biar nggak ada dua picker jalan bareng.
    force cuma dipakai tombol "buat baru di sini" (/cpanel new) */
 const old=await dropSessions(panelWizard,true,force)
 const w={awaiting:"start",chat:String(m.chat),msgId:(old&&old.msgId)||null}
 panelWizard.set(sender,w)
 return wizShow(w,tr("panel.askStart",{prefix:prefix}),{inline_keyboard:[[wizCancelRow()]]})
}

/* layar awal /cadmin (tanpa argumen): tombol ➕ Buat Admin + Batal */
const adminAskStart=async (force=false)=>{
 /* Selalu buat pesan baru. Memakai ulang pesan picker lama memungkinkan
    callback Cancel yang tertunda membatalkan sesi baru. */
 await dropSessions(adminWizard,false,force)
 const w={awaiting:"start",chat:String(m.chat),msgId:null}
 adminWizard.set(sender,w)
 return wizShow(w,tr("admin.startPrompt",{prefix:prefix}),{inline_keyboard:[
  [{text:tr("admin.startBtn"),callback_data:"/"+command+" start",style:"primary"}],
  [wizCancelRow("cadmin")]
 ]})
}

/* tampilkan langkah berikutnya, atau langsung buat panel kalau sudah lengkap */
const wizGo=async (w)=>{

 const step=wizNext(w)

 if(!step){
  panelWizard.delete(sender)
  await wizEdit(w,tr("panel.wizardCreating"),{inline_keyboard:[]})
  return createPanel(m,{username:w.username,targetId:w.targetId,serverName:w.server||"1",ram:w.ram,disk:w.disk,cpu:w.cpu,bulan:w.bulan||1},w)
 }

 return wizShow(w,wizScreen(w,step),wizRows(w,step))
}

const wizStart=async (username,target)=>{

 const name=String(username||"").replace(/[^a-zA-Z0-9_-]/g,"").slice(0,24)
 if(!name) return m.reply(tr("panel.badName"))

 const targetId=String(target||"").toLowerCase()==="me"?String(m.sender):await getUserID(m,target||"")
 if(!targetId) return m.reply(tr("common.notFoundLong"))

 /* sesi lama dibatalkan dulu, terus pesannya dipakai ulang biar ga numpuk */
 const old=await dropSessions(panelWizard)
 const w={username:name,targetId:targetId,serverChoices:wizServerChoices(),awaiting:null,chat:String(m.chat),msgId:(old&&old.msgId)||null}
 panelWizard.set(sender,w)
 return wizGo(w)
}

/* simpan satu langkah picker. step = ram|disk|cpu|bulan|server
   nilai salah -> layar yang sama diedit ulang + peringatan, bukan kirim pesan baru */
const wizApply=async (w,step,raw)=>{

 const warn=tr("panel.wizardBadValue")

 if(step==="server"){
  if(!w.serverChoices.includes(String(raw))) return wizShow(w,wizScreen(w,"server"),wizRows(w,"server"),warn)
  w.server=String(raw)
  return wizGo(w)
 }

 const num=Number(raw)
 const max=step==="cpu"?1600:step==="bulan"?120:1024
 if(!Number.isFinite(num)||num<0||num>max){
  const back=wizNext(w)||step
  return wizShow(w,wizScreen(w,back),wizRows(w,back),warn)
 }

 w[step]=(step==="ram"||step==="disk")?num*1000:num
 return wizGo(w)
}

/* ===== INPUT NILAI CUSTOM (mode picker) ===== */

if(!adminResume && !m.isCmd && !raw.startsWith("=>") && !raw.startsWith(">") && !raw.startsWith("$")){

 const w=panelWizard.get(sender)

 if(w && w.awaiting){

  const step=w.awaiting

  /* lagi nunggu nama|target dari layar awal */
  if(step==="start"){
   const toks=raw.trim().replace(/[|]/g," ").trim().split(/\s+/)
   w.awaiting=null
   return wizStart(toks[0],toks[1]||"me")
  }

  const val=raw.trim().toLowerCase()
  const num=(val==="unli"||val==="unlimited")?0:Number(val.replace(/[^0-9.]/g,""))

  w.awaiting=null
  await wizApply(w,step,num)
  return true
 }

 /* belum ada sesi tapi user langsung ketik nama|target -> langsung buka picker */
 if(!w && (isSeller||isSuper||isOwner) && raw.includes("|")){
  const toks=raw.trim().replace(/[|]/g," ").trim().split(/\s+/)
  if(toks.length>=2 && toks[0]) return wizStart(toks[0],toks[1])
 }
}

/* ================= LAPORAN GAGAL ================= */

/* tiap kegagalan harus dibalas alasan-nya, jangan diem-diem */
const failWith=(key,reason)=>m.reply(tr(key,{reason:String(reason||tr("common.unknown"))}),{parse_mode:"HTML"})

/* respon buat TOMBOL: pakai alert Telegram (cuma kelihatan yang nge-tap),
   jangan kirim pesan baru ke chat */
const cbAlert=(text)=>{
 if(m.callback && typeof bot.answerCallbackQuery==="function"){
  m.callback.answered=true
  const plain=String(text||"").replace(/<[^>]+>/g,"").slice(0,190)
  try{ bot.answerCallbackQuery(m.callback.id,{text:plain,show_alert:true}).catch(()=>{}) }catch{}
  return true
 }
 m.reply(text)
 return true
}

/* cari pemilik pesan picker dari message_id-nya */
const pickerOwner=(map,mid)=>{
 if(!mid) return null
 for(const [uid,w] of map.entries()){
  if(w && String(w.msgId)===String(mid)) return String(uid)
 }
 return null
}

/* tombol ini milik sesi siapa (dicek dari semua map yang punya tombol) */
const buttonOwnerOf=(mid)=>{
 if(!mid) return null
 for(const map of [panelWizard,adminWizard,deleteWizard,pendingConfirm,langPicker]){
  const who=pickerOwner(map,mid)
  if(who) return who
 }
 return null
}

/* PENTING: tombol yang bukan punya sender ditolak DI SINI, sebelum cek role/akses.
   Jadi orang lain nge-tap tombol kita -> cuma dapat alert Telegram, chat tidak
   kena pesan "ACCESS DENIED" dan pesan kita tidak berubah sedikit pun. */
if(m.callback){
 const btnOwner=buttonOwnerOf(m.callback.message?.message_id)
 if(btnOwner && String(btnOwner)!==sender){
  cbAlert(tr("denied.buttons",{cmd:prefix+command}))
  return true
 }
}

/* tombol cuma boleh dipakai sama yang buka picker-nya.
   false = sudah ditolak (alert), jangan lanjut dan jangan ubah pesan apa pun */
const buttonGuard=(map,cmd)=>{
 if(!m.callback) return true

 const mid=m.callback.message?.message_id
 const owner=pickerOwner(map,mid)


 if(!owner) { cbAlert(tr("panel.wizardExpired",{cmd:cmd})) ; return false }
 if(owner!==sender) { cbAlert(tr("denied.buttons",{cmd:cmd})) ; return false }

 return true
}

/* ambil alasan paling enak dibaca dari error pterodactyl */
const apiReason=(errs)=>{
 const e0=Array.isArray(errs)?errs[0]:((errs&&errs[0])||errs)
 if(!e0) return tr("common.unknown")
 return e0.detail||e0.code||e0.message||JSON.stringify(e0)
}

/* ================= KONFIRMASI ADD (tombol YES / NO) ================= */

/* lengkapi data user: nama, username/tag, id telegram */
const resolveUser=async (id)=>{

 let username=null,name=null

 /* dari user yang di-reply */
 if(m.quoted && String(m.quoted.sender)===String(id)){
  name=m.quoted.name||null
  username=m.quoted.username||null
 }

 /* dari pesan forward (pesan ini atau pesan yang di-reply) */
 for(const f of [m.quoted&&m.quoted.forward,m.forward]){
  if(f && f.id && String(f.id)===String(id)){
   name=f.name||name
   username=f.username||username
  }
 }

 /* dari usercache (username -> id, dibaca balik) */
 if(!username){
  const cache=loadJSON("./library/database/usercache.json",{})
  if(cache && typeof cache==="object" && !Array.isArray(cache)){
   for(const [un,uid] of Object.entries(cache)){
    if(String(uid)===String(id)){ username=un; break }
   }
  }
 }

 /* tanya telegram (paling akurat kalau user pernah start bot) */
 try{
  const ch=await bot.getChat(id)
  if(ch){
   name=[ch.first_name,ch.last_name].filter(Boolean).join(" ")||name
   username=ch.username||username
  }
 }catch{}

 /* simpan hasil resolve, biar @username-nya kepakai buat command berikutnya */
 if(username) rememberUser(username,id)

 return {id:String(id),username:username?("@"+username):null,name:name||null}
}

const confirmText=async (ask,id)=>{
 const info=await resolveUser(id)
 return tr("confirm.title")+"\n\n"+ask+"\n\n"+
 tr("confirm.name")+": <b>"+(info.name||tr("confirm.none"))+"</b>\n"+
 tr("confirm.username")+": "+(info.username?("<code>"+info.username+"</code>"):tr("confirm.none"))+"\n"+
 tr("confirm.id")+": <code>"+info.id+"</code>"
}

const confirmKeyboard=(cmd)=>({
 inline_keyboard:[[
  {text:tr("confirm.yes"),callback_data:"/"+cmd+" yes",style:"success"},
  {text:tr("confirm.no"),callback_data:"/"+cmd+" no",style:"danger"}
 ]]
})

/* tanya konfirmasi. kalau sudah ada konfirmasi terbuka -> edit pesan itu (anti numpuk) */
const askConfirm=async (cmd,id,ask)=>{
 const prev=pendingConfirm.get(sender)
 const reuse=(prev && prev.type===cmd && prev.msgId)?{msgId:prev.msgId}:null
 const res=await wizEdit(reuse,await confirmText(ask,id),confirmKeyboard(cmd))
 pendingConfirm.set(sender,{type:cmd,id:String(id),at:Date.now(),chat:String(m.chat),msgId:(res&&res.message_id)?res.message_id:(prev?prev.msgId:null)})
 return true
}

/* ambil jawaban konfirmasi, sekaligus cek kadaluarsa.
   Konfirmasi cuma bisa dijawab di chat tempat dia dibuka - kalau user
   ngidupin sesi di chat lain, sesi lama jangan ketarik ke chat itu. */
const popConfirm=(cmd)=>{
 const p=pendingConfirm.get(sender)
 if(!p || p.type!==cmd) return {err:"none"}
 if(p.chat && String(p.chat)!==String(m.chat)) return {err:"none"}
 pendingConfirm.delete(sender)
 if(Date.now()-(p.at||0)>CONFIRM_TTL) return {err:"expired"}
 return {id:p.id,msgId:p.msgId}
}

/* daftar command yang wajib konfirmasi dulu */
const ADD_ACTIONS={

addowner:{
 db:"./library/database/owner.json",
 ask:()=>tr("confirm.askOwner"),
 already:()=>tr("owner.already"),
 done:(id)=>tr("owner.added",{id:id}),
 usage:()=>tr("owner.usage",{prefix:prefix})
},

addseller:{
 db:"./library/database/seller.json",
 ask:()=>tr("confirm.askSeller"),
 already:()=>tr("seller.already"),
 done:(id)=>tr("seller.added",{id:id}),
 usage:()=>tr("seller.usage",{prefix:prefix})
},

addsuperseller:{
 db:"./library/database/superseller.json",
 ask:()=>tr("confirm.askSuper"),
 already:()=>tr("super.already"),
 done:(id)=>tr("super.added",{id:id}),
 usage:()=>tr("super.usage",{prefix:prefix})
},

addpv:{
 ask:()=>tr("confirm.askPv"),
 already:()=>tr("pv.already"),
 done:(id)=>tr("pv.added",{id:id}),
 usage:()=>tr("pv.addUsage",{prefix:prefix})
}

}

/* isi command ADD: cek -> konfirmasi YES/NO -> baru simpan */
const handleAdd=async (cmd,rawText)=>{

 const A=ADD_ACTIONS[cmd]
 if(!A) return false
 if(!isOwner) return m.reply(tr("denied.owner"))

 const has=(id)=> A.db ? loadDB(A.db).includes(String(id)) : privateDB.includes(String(id))
 const add=(id)=>{
  if(!A.db){ privateDB.push(String(id)); savePrivate(); return }
  const db=loadDB(A.db)
  db.push(String(id))
  saveDB(A.db,db)
 }

 const key=String(rawText||"").trim().split(/\s+/)[0].toLowerCase()

 /* ---- jawaban dari tombol YES / NO ---- */
 if(key==="yes"||key==="no"){

  /* tombol bukan punya sender -> tolak pakai alert */
  if(!buttonGuard(pendingConfirm,prefix+cmd)) return true

  const res=popConfirm(cmd)

  if(res.err) return m.callback?cbAlert(tr("confirm.expired")):m.reply(tr("confirm.expired"))

  const id=res.id

  if(key==="no") return m.edit(tr("confirm.cancelled"),{inline_keyboard:[]})

  if(has(id)) return m.edit(A.already(),{inline_keyboard:[]})

  add(id)
  try{
   const gid=global.notifGroupId
   const roleLabel=cmd==="addowner"?"Owner":cmd==="addseller"?"Seller":cmd==="addsuperseller"?"Super Seller":"Private"
   if(gid)bot.sendMessage(gid,`🟢 <b>${roleLabel} Ditambahkan</b>\n🆔 ID: <code>${id}</code>\nBy: <code>${sender}</code>\n🕐 ${new Date().toLocaleString(global.locale || "id-ID",{timeZone:global.timeZone || "Asia/Jakarta"})}`,{parse_mode:"HTML"}).catch(()=>{})
  }catch{}
  return m.edit(A.done(id),{inline_keyboard:[]})
 }

 /* tanpa argumen masih boleh, asal sambil nge-reply / nge-forward pesan target */
 if(!rawText && !m.quoted && !m.forward) return m.reply(A.usage())

 const id=await getUserID(m,rawText)
 if(!id) return m.reply(needTargetMsg(rawText))

 if(has(id)) return m.reply(A.already())

 return askConfirm(cmd,id,A.ask())
}

/* ===== MULTILINE TELEGRAM EVAL =====
   FITUR EVAL/EXEC DIMATIKAN DI CLONE BOT (global.isClone) buat cegah
   penyalahgunaan — sesuai permintaan fitur clone. */
const evalDisabled = global.isClone === true

if (raw === "=>") {
if(!isCreator) return true
if(evalDisabled) return m.reply("⛔ Fitur eval dinonaktifkan di clone bot.")
pendingEval.set(m.sender, "async")
await m.reply(tr("eval.sendCode"))
return true
}

if (raw === ">") {
if(!isCreator) return true
if(evalDisabled) return m.reply("⛔ Fitur eval dinonaktifkan di clone bot.")
pendingEval.set(m.sender, "sync")
await m.reply(tr("eval.sendCode"))
return true
}

if (pendingEval.has(m.sender) && isCreator && !raw.startsWith(".") && !raw.startsWith("/")) {

if(evalDisabled){ pendingEval.delete(m.sender); return m.reply("⛔ Fitur eval dinonaktifkan di clone bot.") }
const type = pendingEval.get(m.sender)
pendingEval.delete(m.sender)

try{
let result

if(type==="async"){
result = await eval(`(async()=>{ return ${raw} })()`)
}else{
result = eval(raw)
}

if(typeof result!=="string")
result = util.inspect(result,{depth:1})

await m.reply(result||"undefined")
}catch(e){
await m.reply(String(e))
}
return true
}

/* ===== SINGLE LINE SUPPORT ===== */

if (raw.startsWith("=>")) {
if (!isCreator) return true
if(evalDisabled) return m.reply("⛔ Fitur eval dinonaktifkan di clone bot.")
try {
let evaled = await eval(`(async()=>{ ${raw.slice(2)} })()`)
if (typeof evaled !== "string") evaled = util.inspect(evaled,{depth:1})
await m.reply(evaled || "undefined")
} catch (err) {
await m.reply(String(err))
}
return true
}

if (raw.startsWith(">")) {
if (!isCreator) return true
if(evalDisabled) return m.reply("⛔ Fitur eval dinonaktifkan di clone bot.")
try {
let evaled = eval(raw.slice(1))
if (typeof evaled !== "string") evaled = util.inspect(evaled,{depth:1})
await m.reply(evaled || "undefined")
} catch (err) {
await m.reply(String(err))
}
return true
}

if (raw.startsWith("$")) {
if (!isCreator) return true
if(evalDisabled) return m.reply("⛔ Fitur exec ($) dinonaktifkan di clone bot.")
exec(raw.slice(1),(err,stdout,stderr)=>{
if(err) return m.reply(err.message)
if(stderr) return m.reply(stderr)
m.reply(stdout || "done")
})
return true
}

/* ================= DELETE IDENTITY PICKERS ================= */

const deleteIdentityFlow=async (kind)=>{
 const isAdminDelete=kind==="admin"
 const isOwnerDelete=kind==="owner"
 const isSuperDelete=kind==="super"
 const commandName=isAdminDelete?"deladmin":isOwnerDelete?"delowner":isSuperDelete?"delsuper":"delseller"
 if(isOwnerDelete ? !isCreator : !isOwner) return m.reply(tr(isOwnerDelete?"denied.creator":"denied.owner"))

 const parts=String(text||"").replace(/[|]/g," ").trim().split(/\s+/)
 const head=String(parts[0]||"").toLowerCase()
 const current=deleteWizard.get(sender)

 if(!text){
  const w={kind,serverChoices:isAdminDelete?Object.keys(global.panelServer||{}):[],awaiting:isAdminDelete?"server":"search",chat:String(m.chat),msgId:null}
  deleteWizard.set(sender,w)
  const keyboard=isAdminDelete
   ? serverPickRows(w.serverChoices,commandName)
   : {inline_keyboard:[
      [{text:"🔎 Search ID",callback_data:"/"+commandName+" search",style:"primary"}],
      [wizCancelRow(commandName)]
     ]}
  return wizShow(w,"<b>🗑️ DELETE "+kind.toUpperCase()+"</b>\n\n"+(isAdminDelete?"Pilih server:":"Tekan <b>Search ID</b> untuk mencari ID Telegram:"),keyboard)
 }

 if(head==="cancel"){
  if(!buttonGuard(deleteWizard,prefix+commandName)) return true
  const w=deleteWizard.get(sender)
  deleteWizard.delete(sender)
  return wizEdit(w,tr("panel.cancelled"),{inline_keyboard:[]})
 }

 if(head==="server" && isAdminDelete){
  if(!buttonGuard(deleteWizard,prefix+commandName)) return true
  const w=deleteWizard.get(sender)
  if(!w || !w.serverChoices.includes(String(parts[1]))) return cbAlert(tr("panel.wizardExpired",{cmd:prefix+commandName}))
  w.serverName=String(parts[1])
  w.awaiting="search"
  return wizEdit(w,"<b>🗑️ DELETE ADMIN</b>\n\nServer: <code>"+global.panelServer[w.serverName].name+"</code>\n\nTekan <b>Search ID</b> untuk mencari ID admin.",{inline_keyboard:[
   [{text:"🔎 Search ID",callback_data:"/"+commandName+" search",style:"primary"}],
   [wizCancelRow(commandName)]
  ]})
 }

 if(head==="search"){
  if(!buttonGuard(deleteWizard,prefix+commandName)) return true
  const w=deleteWizard.get(sender)
  if(!w || (!w.serverName && isAdminDelete)) return cbAlert(tr("panel.wizardExpired",{cmd:prefix+commandName}))
  w.awaiting="id"
  return wizEdit(w,"<b>🔎 SEARCH ID</b>\n\nKetik ID yang ingin dihapus.",{inline_keyboard:[[wizCancelRow(commandName)]]})
 }

 const id=Number(parts[0])
 if(!Number.isInteger(id)||id<=0) return m.reply(tr("panel.delFormat",{prefix:prefix}))

 const w=current || deleteWizard.get(sender)
 deleteWizard.delete(sender)

 if(isAdminDelete){
  let found=false
  const names=w?.serverName?[w.serverName]:getAllServers()
  for(const name of names){
   const srv=getSrv(name)
   try{
    const res=await fetch(`${srv.domain}/api/application/users/${id}`,{method:"DELETE",headers:{Authorization:"Bearer "+srv.apikey}})
    if(res.ok || res.status===204){ found=true; break }
   }catch{}
  }
  if(!found) return m.reply(tr("admin.delNotFound"))
  delAdminOwner(id)
  try{const gid=global.notifGroupId;if(gid)bot.sendMessage(gid,`🔴 <b>Admin Dihapus</b>\n🆔 ID: <code>${id}</code>\nBy: <code>${sender}</code>`,{parse_mode:"HTML"}).catch(()=>{})}catch{}
  return w?wizDone(w,tr("admin.deleted")):m.reply(tr("admin.deleted"))
 }

 const file=isOwnerDelete?"./library/database/owner.json":isSuperDelete?"./library/database/superseller.json":"./library/database/seller.json"
 const db=loadDB(file)
 const key=String(id)
 const index=db.indexOf(key)
 if(index<0) return m.reply(tr(isOwnerDelete?"owner.notExtra":isSuperDelete?"super.notSuper":"seller.notSeller"))
 db.splice(index,1)
 saveDB(file,db)
 try{
  const gid=global.notifGroupId
  const roleLabel=isOwnerDelete?"Owner":isSuperDelete?"Super Seller":"Seller"
  if(gid)bot.sendMessage(gid,`🔴 <b>${roleLabel} Dihapus</b>\n🆔 ID: <code>${id}</code>\nBy: <code>${sender}</code>\n🕐 ${new Date().toLocaleString(global.locale || "id-ID",{timeZone:global.timeZone || "Asia/Jakarta"})}`,{parse_mode:"HTML"}).catch(()=>{})
 }catch{}
 return w?wizDone(w,tr(isOwnerDelete?"owner.removed":isSuperDelete?"super.removed":"seller.removed")):m.reply(tr(isOwnerDelete?"owner.removed":isSuperDelete?"super.removed":"seller.removed"))
}

/* ================= NORMAL COMMAND ================= */

switch(m.command){

/* ===== /batal — DARURAT: bersihkan SEMUA sesi yang nge-stuck =====
   Dipakai kalau bot terlihat "menunggu input" padahal user tidak sengaja
   membuka wizard (cpanel/cadmin/delpanel/konfirmasi/afk/pager). */
case "batal":
case "cancel":
case "abort": {
 const cleaned = []

 /* sesi wizard milik user ini */
 const maps = [
  ["panel", global.sessionStore?.panel],
  ["admin", global.sessionStore?.admin],
  ["delete", global.sessionStore?.delete],
  ["lang", global.sessionStore?.lang],
  ["confirm", global.sessionStore?.confirm]
 ]
 for (const [name, map] of maps) {
  if (!map || typeof map.get !== "function") continue
  const w = map.get(sender)
  if (w) {
   map.delete(sender)
   cleaned.push(name)
   /* matikan juga tombol pesan wizard-nya biar tidak nyangkut */
   if (w.msgId) {
    try { await bot.editMessageReplyMarkup({ inline_keyboard: [] }, { chat_id: w.chat || m.chat, message_id: w.msgId }) } catch {}
   }
  }
 }

 /* sesi clone (kalau ada) */
 try {
  const clonePlugin = require("./plugins/clone.js")
  /* cloneSessions tidak diekspor — bersihkan via command bawaan */
 } catch {}

 /* pager pesan panjang milik user ini di chat ini */
 let pagerCount = 0
 try {
  for (const [mid, st] of (global._pagerStore || new Map()).entries()) {
   if (st.uid === sender && String(st.chat) === String(m.chat)) {
    global._pagerStore.delete(mid)
    pagerCount++
    try { await bot.editMessageReplyMarkup({ inline_keyboard: [] }, { chat_id: m.chat, message_id: Number(mid) }) } catch {}
   }
  }
  global._pagerSave && global._pagerSave()
 } catch {}

 if (!cleaned.length && !pagerCount)
  return m.reply(tr("batal.none"))

 return m.reply(
  `<b>${tr("batal.title")}</b>\n\n` +
  (cleaned.length ? `${tr("batal.sessions")} ${cleaned.join(", ")}\n` : "") +
  (pagerCount ? `${tr("batal.pager")} ${pagerCount}\n` : "") +
  `\n${tr("batal.done")}`,
  { parse_mode: "HTML" }
 )
}
break

case "ping": {
 const os=require("os")
 const escPing=(s)=>String(s||"").replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")
 const started=Date.now()
 const sent=await m.reply("🏓 " + tr("ping.checking"))
 const ms=Date.now()-started
 const up=process.uptime()
 const f=(s)=>{const d=Math.floor(s/86400),h=Math.floor(s%86400/3600),mn=Math.floor(s%3600/60),sc=Math.floor(s%60);return (d?d+"d ":"")+h+"h "+mn+"m "+sc+"s"}
 const gb=(b)=>(b/1073741824).toFixed(2)
 const tot=os.totalmem(),fre=os.freemem(),used=tot-fre
 const pus=process.memoryUsage()
 const cpus=os.cpus()
 const load=os.loadavg()
 const cpuModel=(cpus[0]?.model||"-").replace(/\(R\)|\(TM\)|CPU|@/g,"").replace(/\s+/g," ").trim()
 const cpuUsed=cpus.map(c=>{const t=c.times;return Math.round((t.user+t.system)/(t.user+t.system+t.idle)*100)})
 let out = "🏓 <b>PONG!</b>\n"
 out += "⏱ <b>"+tr("ping.latency")+"</b>: <code>"+ms+" ms</code>\n"
 out += "⏰ <b>"+tr("ping.uptime")+"</b>: <code>"+f(up)+"</code>\n"
 out += "🏷 <b>"+tr("ping.version")+"</b>: <code>"+(global.versi||"-")+"</code>\n\n"
 out += "🖥 <b>SERVER</b>\n"
 out += "• 🧠 CPU: <code>"+escPing(String(cpuModel).slice(0,40))+"</code>\n"
 out += "• 🔢 <b>"+tr("ping.cores")+"</b>: <code>"+cpus.length+"</code>\n"
 out += "• 📊 <b>"+tr("ping.cpuUse")+"</b>: <code>"+cpuUsed.join("%, ")+"%</code>\n"
 out += "• 📈 <b>"+tr("ping.load")+"</b>: <code>"+load.map(l=>l.toFixed(2)).join(" / ")+"</code>\n"
 out += "• 🏗 <b>"+tr("ping.arch")+"</b>: <code>"+os.arch()+" • "+os.platform()+"</code>\n"
 out += "• 🏠 <b>"+tr("ping.hostname")+"</b>: <code>"+escPing(os.hostname())+"</code>\n\n"
 out += "💾 <b>RAM</b>\n"
 out += "• 🟢 <b>"+tr("ping.ramUse")+"</b>: <code>"+gb(used)+" / "+gb(tot)+" GB ("+Math.round(used/tot*100)+"%)</code>\n"
 out += "• 🔵 <b>"+tr("ping.ramFree")+"</b>: <code>"+gb(fre)+" GB</code>\n"
 out += "• 🤖 <b>"+tr("ping.botUse")+"</b>: <code>"+gb(pus.rss)+" GB (heap "+gb(pus.heapUsed)+"/"+gb(pus.heapTotal)+")</code>\n"
 try{
  const fs=require("fs")
  const st=fs.statfsSync ? fs.statfsSync(__dirname) : null
  if(st){
   const diskTot=st.blocks*st.bsize, diskFree=st.bfree*st.bsize, diskUsed=diskTot-diskFree
   out += "\n💿 <b>"+tr("ping.disk")+"</b>\n"
   out += "• 🟢 <b>"+tr("ping.diskUse")+"</b>: <code>"+gb(diskUsed)+" / "+gb(diskTot)+" GB ("+Math.round(diskUsed/diskTot*100)+"%)</code>\n"
   out += "• 🔵 <b>"+tr("ping.diskFree")+"</b>: <code>"+gb(diskFree)+" GB</code>\n"
  }
 }catch{}
 try{
  const el=require("./library/errorlog")
  const errs=el.getErrors ? el.getErrors() : []
  if(errs.length) out += "\n⚠️ <b>"+tr("ping.activeErrors")+"</b>: <code>"+errs.length+"</code> — <code>/errorlist</code>"
 }catch{}
 if(sent?.message_id){
  try{
   await bot.editMessageText(out,{
    chat_id:m.chat,
    message_id:sent.message_id,
    parse_mode:"HTML"
   })
  }catch{}
 }
 return true
}
//=======================================================
case "copy":
if (!text){
await m.reply(example(tr("copy.usage")))
return true
}
await m.reply(text)
return true
//=======================================================
case "addpv": {
return handleAdd("addpv",text)
}
break

case "delpv": {
if(!isOwner) return m.reply(tr("denied.owner"))
let id=await getUserID(m,text)
if(!id) return m.reply(tr("common.needTarget"))
let i=privateDB.indexOf(String(id))
if(i<0) return m.reply(tr("pv.notListed"))
privateDB.splice(i,1); savePrivate()
return m.reply(tr("pv.removed",{id}),{parse_mode:"HTML"})
}
break

case "listpv": {
if(!isOwner) return m.reply(tr("denied.owner"))
if(!privateDB.length) return m.reply(tr("pv.listEmpty"))
return m.reply(tr("pv.listHeader")+"\n\n"+privateDB.map((id,i)=>`${i+1}. <code>${id}</code>`).join("\n"),{parse_mode:"HTML"})
}
break

case "pvhelp": {
if(!isPrivateUser(sender)) return m.reply(tr("pv.noAccess"))
return m.reply(tr("pv.help"),{parse_mode:"HTML"})
}
break

case "pvcreate": {
if(!isPrivateUser(sender)) return m.reply(tr("pv.noAccessContact"))
if(!text) return m.reply(example(tr("pv.usage")))

let [name,target,ramInput,cpuInput,diskInput]=text.split("|").map(x=>x?.trim())
if(!name||!target||ramInput===undefined||cpuInput===undefined||diskInput===undefined) {
return m.reply(tr("pv.format"))
}

let targetId
if(String(target).toLowerCase()==="me") targetId=String(sender)
else targetId=await getUserID(m,target)
if(!targetId) return m.reply(tr("common.notFoundLong"))

const parseResource=(value)=>{
const v=String(value).trim().toLowerCase()
if(v==="0" || v==="unli" || v==="unlimited") return 0
const n=Number(v)
return Number.isFinite(n) && n>=0 ? n : NaN
}

const ramGB=parseResource(ramInput)
const cpu=parseResource(cpuInput)
const diskGB=parseResource(diskInput)
if([ramGB,cpu,diskGB].some(Number.isNaN)) return m.reply(tr("pv.badResource"))

const srv=getSrv(global.privateServerId)
const cleanName=String(name).replace(/[^a-zA-Z0-9_-]/g,"").slice(0,24)
if(!cleanName) return m.reply(tr("pv.badName"))

const headers={Accept:"application/json", "Content-Type":"application/json", Authorization:"Bearer "+srv.apikey}
const email=`pv${String(targetId).replace(/[^0-9]/g,"")}@gmail.com`
const usernameBase=`pv${String(targetId).replace(/[^0-9]/g,"") || "user"}`.slice(0,24)
let password=genPassword()

// Gunakan user Pterodactyl yang sudah ada bila target pernah dibuat sebelumnya.
let panelUser=null
try {
let uf=await fetch(`${srv.domain}/api/application/users?filter[email]=${encodeURIComponent(email)}`,{headers})
let uj=await uf.json()
panelUser=uj.data?.find(x=>String(x.attributes?.email).toLowerCase()===email.toLowerCase())?.attributes || null
} catch {}

if(!panelUser){
/* password dicoba ulang otomatis kalau panel nolak */
let made=await createPanelUser({srv,fields:{email,username:usernameBase,first_name:cleanName,last_name:"Private",language:"en"},password})
if(!made.ok) return m.reply(tr("pv.userFail")+made.reason)
password=made.password
panelUser=made.data.attributes
}

let ef=await fetch(`${srv.domain}/api/application/nests/${srv.nestid}/eggs/${srv.egg}`,{headers:{Authorization:"Bearer "+srv.apikey,Accept:"application/json"}})
let ej=await ef.json()
if(!ef.ok || !ej.attributes?.startup) return m.reply(tr("pv.eggFail"))

let sf=await fetch(srv.domain+"/api/application/servers",{method:"POST",headers,body:JSON.stringify({
name:cleanName,
user:panelUser.id,
egg:parseInt(srv.egg),
docker_image:"ghcr.io/parkervcp/yolks:nodejs_24",
startup:ej.attributes.startup,
environment:{INST:"npm",USER_UPLOAD:"0",AUTO_UPDATE:"0",CMD_RUN:"npm start"},
limits:{memory:ramGB===0?0:ramGB*1000,swap:0,disk:diskGB===0?0:diskGB*1000,io:500,cpu:cpu===0?0:cpu},
feature_limits:{databases:5,backups:5,allocations:5},
deploy:{locations:[parseInt(srv.loc)],dedicated_ip:false,port_range:[]}
})})
let sj=await sf.json()
if(!sf.ok || sj.errors) return m.reply(tr("pv.createFail")+JSON.stringify(sj.errors?.[0]||sj,null,2))

// Kepemilikan bot dicatat ke target, bukan ke orang yang menjalankan command.
addPanelOwner(String(targetId),sj.attributes.id,global.privateServerId)

let teskCreated=tr("pv.created",{name:cleanName,id:sj.attributes.id,owner:targetId,ram:ramGB===0?tr("common.unlimited"):ramGB+" GB",cpu:cpu===0?tr("common.unlimited"):cpu+"%",disk:diskGB===0?tr("common.unlimited"):diskGB+" GB",domain:srv.domain,username:panelUser.username})
teskCreated+=panelUser.email?`\nEmail: <code>${panelUser.email}</code>`:""
teskCreated+=panelUser.username===usernameBase?`\nPassword: <code>${password}</code>`:`\nPassword: <i>${tr("pv.passExisting")}</i>`

return m.reply(teskCreated,{parse_mode:"HTML",disable_web_page_preview:true})
}
break

case "pvlist": {
if(!isPrivateUser(sender)) return m.reply(tr("pv.noAccess"))
const srv=getSrv(global.privateServerId)
let data=await fetchAllPages(`${srv.domain}/api/application/servers`,{Authorization:"Bearer "+srv.apikey,Accept:"application/json"})
let mine=isCreator?data:data.filter(x=>getUserPanels(sender).some(p=>p.id===x.attributes.id&&p.srv===global.privateServerId))
if(!mine.length) return m.reply(tr("pv.listEmptyAll"))
return m.reply(tr("pv.listHeader")+"\n\n"+mine.map(x=>{let a=x.attributes;return tr("pv.item",{id:a.id,name:a.name,ram:a.limits.memory||"∞",cpu:a.limits.cpu||"∞",disk:a.limits.disk||"∞"})}).join("\n\n"),{parse_mode:"HTML"})
}
break

case "pvinfo": {
if(!isPrivateUser(sender)) return m.reply(tr("pv.noAccess"))
let id=Number(text); if(!id) return m.reply(tr("pv.infoFormat"))
const srv=getSrv(global.privateServerId)
let f=await fetch(`${srv.domain}/api/application/servers/${id}`,{headers:{Authorization:"Bearer "+srv.apikey,Accept:"application/json"}})
let j=await f.json(); if(!f.ok||!j.attributes) return m.reply(tr("pv.notFound"))
if(!isCreator && !isPanelMine(sender,id,global.privateServerId)) return m.reply(tr("pv.notYours"))
let a=j.attributes
return m.reply(tr("pv.info",{id:a.id,name:a.name,identifier:a.identifier,ram:a.limits.memory||"∞",disk:a.limits.disk||"∞",cpu:a.limits.cpu||"∞"}),{parse_mode:"HTML"})
}
break

case "pvdelete": {
if(!isPrivateUser(sender)) return m.reply(tr("pv.noAccess"))
let id=Number(text); if(!id) return m.reply(tr("pv.delFormat"))
if(!isCreator && !isPanelMine(sender,id,global.privateServerId)) return m.reply(tr("pv.notYours"))
const srv=getSrv(global.privateServerId)
let f=await fetch(`${srv.domain}/api/application/servers/${id}`,{method:"DELETE",headers:{Authorization:"Bearer "+srv.apikey,Accept:"application/json"}})
if(!f.ok) return m.reply(tr("pv.delFail"))
delPanelOwner(id); return m.reply(tr("pv.deleted",{id}),{parse_mode:"HTML"})
}
break

case "pvstart":
case "pvstop": {
if(!isPrivateUser(sender)) return m.reply(tr("pv.noAccess"))
let id=Number(text); if(!id) return m.reply(tr("pv.powerFormat",{cmd:command}))
if(!isCreator && !isPanelMine(sender,id,global.privateServerId)) return m.reply(tr("pv.notYours"))
const srv=getSrv(global.privateServerId)
let sf=await fetch(`${srv.domain}/api/application/servers/${id}`,{headers:{Authorization:"Bearer "+srv.apikey,Accept:"application/json"}})
let sj=await sf.json(); let identifier=sj.attributes?.identifier
if(!identifier) return m.reply(tr("pv.notFound"))
let action=command==="pvstart"?"start":"stop"
let f=await fetch(`${srv.domain}/api/client/servers/${identifier}/power`,{method:"POST",headers:{Authorization:"Bearer "+srv.apikey,Accept:"application/json","Content-Type":"application/json"},body:JSON.stringify({signal:action})})
if(!f.ok) return m.reply(tr("pv.powerFail",{action}))
return m.reply(tr("pv.powerSent",{id,action:action.toUpperCase()}),{parse_mode:"HTML"})
}
break

case "cpanel": {
if(!isSeller && !isSuper && !isOwner) return m.reply(tr("denied.seller"))

/* sesi masih ada di chat lain -> bilang "udah ada" + forward pesannya.
   Sesi lama yang udah selesai/kedaluwarsa dibatalkan, sesi barunya lanjut
   dibuat di chat ini (sessionGuard balikin "ended").
   Yang DIKECUALIKAN (nggak ngecek sesi lain), karena bukan sesi baru:
   cancel / new, dan step wizard (ram/disk/cpu/bulan/server) yang ngedit
   pesan sesi yang lagi jalan -> jangan sampai step itu ngebatalin sesi
   command lain yang kebetulan kebuka di chat lain. */
const cTok0=String(text||"").replace(/[|]/g," ").trim().split(/\s+/)
const cHead0=String(cTok0[0]||"").toLowerCase()
const cStep0=WIZ_STEPS.includes(cHead0)||cHead0==="server"
const startsNewCpanel=cHead0!=="cancel" && cHead0!=="new" && !cStep0

/* Menjalankan /cpanel lagi selalu menutup sesi lama, termasuk sesi yang
   tersimpan di chat lain, supaya tidak ada picker lama yang mengambil alih. */
if(startsNewCpanel) await dropSessions(panelWizard,false,true)

/* tanpa argumen -> layar awal yang ada tombolnya, tinggal ketik nama|target */
if(!text) return wizAskStart(true)

const cParts=String(text).split("|")

/* ---- mode cepat: cpanel user|target|ram|bulan|server ---- */
if(cParts.length>=3){

let [username,target,ramInput,bulanInput,serverName]=cParts
if(!username || !target || !ramInput) return m.reply(tr("common.badParam"))

let id
if(target.toLowerCase()=="me") id=String(m.sender)
else id=await getUserID(m,target)

if(!id) return m.reply(tr("common.notFound"))

const bulan=parseInt(bulanInput)||1
const ram=ramInput.toLowerCase()=="unli"?0:parseInt(ramInput)*1000
const disk=ram==0?0:ram
const cpu=ram==0?0:Math.min(400,Math.floor(ram/50)+40)

if(!serverName) serverName="1"
if(!isSuper && !isOwner) serverName="1"
else if(!global.panelServer[serverName]) serverName="1"

/* mode cepat nggak bikin sesi baru -> sesi cpanel/cadmin yang masih
   nyangkut dibatalkan biar tombolnya nggak ketinggalan hidup */
await dropSessions(panelWizard,false)

return createPanel(m,{username:username,targetId:id,serverName:serverName,ram:ram,disk:disk,cpu:cpu,bulan:bulan})
}

/* ---- mode picker: cpanel nama|target lalu tombol RAM/Disk/CPU/Durasi ---- */
const cTok=String(text).replace(/[|]/g," ").trim().split(/\s+/)
const cHead=String(cTok[0]||"").toLowerCase()
const cVal=String(cTok[1]||"").toLowerCase()

/* tombol "buat baru di sini": sesi lama (di chat mana pun, termasuk sesi
   /cadmin) dibatalkan dulu, terus sesi baru mulai di chat ini.
   wizAskStart() yang ngurus pembatalannya (dropSessions). */
if(cHead==="new") return wizAskStart(true)

if(cHead==="cancel"){
 if(!buttonGuard(panelWizard,prefix+command)) return true
 const w0=panelWizard.get(sender)
 panelWizard.delete(sender)

 /* sesi-nya kebuka di chat lain -> matiin tombolnya di chat itu juga */
 if(w0 && w0.chat && String(w0.chat)!==String(m.chat)){
  await killSession(w0)
  return m.reply(tr("panel.cancelled"))
 }

 return wizEdit(w0,tr("panel.cancelled"),{inline_keyboard:[]})
}

if(WIZ_STEPS.includes(cHead)||cHead==="server"){

 const w=panelWizard.get(sender)

 /* tombol bukan punya sender -> tolak pakai alert, pesan jangan diubah */
 if(!buttonGuard(panelWizard,prefix+command)) return true
 if(!w) return m.reply(tr("panel.wizardExpired",{cmd:prefix+command}))

 /* sesi masih di layar awal (belum ada nama|target) -> tampilkan prompt lagi,
    jangan error diam-diam (tombol lama bisa ketinggalan di layar) */
 if(!w.username||w.awaiting==="start")
  return wizShow(w,tr("panel.askStart",{prefix:prefix}),{inline_keyboard:[[wizCancelRow()]]})


 if(cVal==="custom"){
  w.awaiting=cHead
  return wizEdit(w,tr("panel.customAsk",{res:tr(WIZ_LABEL[cHead]),unit:WIZ_UNIT[cHead]||"GB"}),{inline_keyboard:[[wizCancelRow()]]})
 }

 if(cVal==="") return m.reply(tr("panel.wizardBadValue"))

 return wizApply(w,cHead,cVal)
}

if(!cTok[0]) return wizAskStart()

return wizStart(cTok[0],cTok[1]||"me")

}
break


//=======================================================
case "addseller":{
return handleAdd("addseller",text)
}
//=======================================================        
case "listseller":{
if(!isOwner) return m.reply(tr("denied.owner"))
let db=loadDB("./library/database/seller.json")
if(!db.length) return m.reply(tr("seller.empty"))

let teks=tr("seller.header")+"\n\n"
for(let id of db) teks+=`• <code>${id}</code>\n`

m.reply(teks,{parse_mode:"HTML"})
return true
}
//=======================================================
case "delseller":{
return deleteIdentityFlow("seller")
}
//=======================================================
case "addsuperseller":
case "addsuper":{
return handleAdd("addsuperseller",text)
}
//=======================================================        
case "listsuperseller":
case "listsuper":
{
if(!isOwner) return m.reply(tr("denied.owner"))
let db=loadDB("./library/database/superseller.json")
if(!db.length) return m.reply(tr("super.empty"))

let teks=tr("super.header")+"\n\n"
for(let id of db) teks+=`• <code>${id}</code>\n`

m.reply(teks,{parse_mode:"HTML"})
return true
}
//=======================================================
case "delsuperseller":
case "delsuper":
{
return deleteIdentityFlow("super")
}
//=======================================================
case "addowner":{
return handleAdd("addowner",text)
}
break
//=======================================================
case "listowner":{
if(!isOwner) return m.reply(tr("denied.owner"))
let db=require("./library/database/owner.json")

let teks=tr("owner.header")+"\n\n"
teks+=tr("owner.main")+`\n<code>${global.owner.join("\n")}</code>\n\n`

if(db.length){
teks+=tr("owner.extra")+"\n"
for(let id of db) teks+=`<code>${id}</code>\n`
}

m.reply(teks,{parse_mode:"HTML"})
return true
}
//=======================================================
case "delowner":{
return deleteIdentityFlow("owner")
}
break
//=======================================================
case "listpanel": case "listp": case "listserver": {
if(!isSeller && !isOwner && !isSuper) return m.reply(tr("denied.seller"))

if(isOwner){
 let teks=tr("panel.allHeader")+"\n"
 let data=await fetchAllServers("/api/application/servers?page=1")
 for(const srv of data){
  teks+="\n"+tr("panel.serverHeader",{name:srv.server})+"\n"
  for(const s of srv.data){
   let a=s.attributes
   teks+=tr("panel.allItem",{id:a.id,name:a.name,ram:a.limits.memory||"∞",cpu:a.limits.cpu||"∞"})+"\n"
  }
 }
 return safeReply(m,teks)
}

let my=getUserPanels(sender)
if(!my.length) return m.reply(tr("panel.empty"))

let teks=tr("panel.yourHeader")+"\n"
for(const p of my){
 teks+=tr("panel.yourItem",{id:p.id,srv:p.srv})+"\n"
}

safeReply(m,teks)
}
break

//=======================================================

case "delpanel": {
if(!isSeller && !isOwner && !isSuper) return m.reply(tr("denied.seller"))

const dTok=String(text||"").replace(/[|]/g," ").trim().split(/\s+/)
const dHead=String(dTok[0]||"").toLowerCase()
/* /delpanel tanpa argumen: pilih dulu server, lalu cari ID. */
if(!text){
 const choices=Object.keys(global.panelServer||{})
 const w={kind:"panel",serverChoices:choices,awaiting:"server",chat:String(m.chat),msgId:null}
 deleteWizard.set(sender,w)
 return wizShow(w,tr("panel.deleteChooseServer"),serverPickRows(choices,"delpanel"))
}

if(dHead==="cancel"){
 if(!buttonGuard(deleteWizard,prefix+command)) return true
 const w=deleteWizard.get(sender)
 deleteWizard.delete(sender)
 return wizEdit(w,tr("panel.cancelled"),{inline_keyboard:[]})
}

if(dHead==="server"){
 if(!buttonGuard(deleteWizard,prefix+command)) return true
 const w=deleteWizard.get(sender)
 if(!w || !w.serverChoices.includes(String(dTok[1]))) return cbAlert(tr("panel.wizardExpired",{cmd:prefix+command}))
 w.serverName=String(dTok[1])
 w.awaiting="search"
 return wizEdit(w,tr("panel.deleteSearchPrompt",{server:global.panelServer[w.serverName].name}),{inline_keyboard:[
  [{text:"🔎 Search ID",callback_data:"/delpanel search",style:"primary"}],
  [wizCancelRow("delpanel")]
 ]})
}

if(dHead==="search"){
 if(!buttonGuard(deleteWizard,prefix+command)) return true
 const w=deleteWizard.get(sender)
 if(!w || !w.serverName) return cbAlert(tr("panel.wizardExpired",{cmd:prefix+command}))
 w.awaiting="id"
 return wizEdit(w,tr("panel.deleteIdPrompt",{server:global.panelServer[w.serverName].name}),{inline_keyboard:[[wizCancelRow("delpanel")]]})
}

let [idInput,serverName]=text.split("|")
const id=Number(idInput)

if(!id || !serverName) return m.reply(tr("panel.delFormat",{prefix:prefix}))

const srv=getSrv(serverName)
if(!srv) return m.reply(tr("common.serverMissing"))

if(isOwner){

 await fetch(`${srv.domain}/api/application/servers/${id}`,{
  method:"DELETE",
  headers:{Authorization:"Bearer "+srv.apikey}
 })

 delPanelOwner(id)
 return m.reply(tr("panel.deleted",{id:id,srv:serverName}))
}

if(!isPanelMine(sender,id,serverName))
 return m.reply(tr("panel.notYours"))

await fetch(`${srv.domain}/api/application/servers/${id}`,{
 method:"DELETE",
 headers:{Authorization:"Bearer "+srv.apikey}
})

delPanelOwner(id)
m.reply(tr("panel.deleted",{id:id,srv:serverName}))
}
break

//=======================================================

case "cadmin": {
if(!isOwner) return m.reply(tr("denied.owner"))

/* sesi masih ada di chat lain -> bilang "udah ada" + forward pesannya.
   Sesi lama yang udah selesai atau pesannya ilang dibatalkan biar /cadmin
   tetap bisa mulai sesi baru. cancel / new / step wizard dikecualikan,
   sama seperti /cpanel (lihat catatan di case cpanel). */
const aToken0=String(text||"").replace(/[|]/g," ").trim().split(/\s+/)
const aHead0=String(aToken0[0]||"").toLowerCase()
const aStep0=aHead0==="start" || (aHead0==="server" && !String(text||"").split("|")[1])
if(text && aHead0!=="cancel" && aHead0!=="new" && !aStep0 && await sessionGuard(adminWizard,command)=="alive") return true

/* tanpa argumen selalu membuka sesi admin baru, sehingga picker lama tidak
   bisa menimpa atau membatalkan command yang baru saja dikirim. */
if(!text) return adminAskStart(true)

const aParts=String(text).split("|")
const aTok=String(text).replace(/[|]/g," ").trim().split(/\s+/)
const aHead=String(aTok[0]||"").toLowerCase()
const fromPicker=(aHead==="server" && !aParts[1])

/* tombol ➕ Buat Admin dari layar awal -> minta nama|id di pesan yang sama */
if(aHead==="start"){
 if(!buttonGuard(adminWizard,prefix+command)) return true
 /* pesan yang ditap dipakai ulang buat prompt nama|id */
 const old=await dropSessions(adminWizard)
 const w={awaiting:"start",chat:String(m.chat),msgId:(old&&old.msgId)||null}
 adminWizard.set(sender,w)
 return wizEdit(w,tr("admin.askStart",{prefix:prefix}),{inline_keyboard:[[wizCancelRow("cadmin")]]})
}

/* tombol Batal */
if(aHead==="cancel"){
 if(!buttonGuard(adminWizard,prefix+command)) return true
 const w0=adminWizard.get(sender)
 adminWizard.delete(sender)

 /* sesi-nya kebuka di chat lain -> matiin tombolnya di chat itu juga */
 if(w0 && w0.chat && String(w0.chat)!==String(m.chat)){
  await killSession(w0)
  return m.reply(tr("panel.cancelled"))
 }

 return wizEdit(w0,tr("panel.cancelled"),{inline_keyboard:[]})
}

/* tombol "buat baru di sini": sesi lama dibatalkan (di chat mana pun,
   termasuk sesi /cpanel), terus layar awal /cadmin muncul di chat ini */
if(aHead==="new") return adminAskStart(true)

let username,target,serverName
let id
let resolveId=null
/* sesi picker yang lagi dipakai, buat ngedit pesannya jadi DONE */
let aw=null
/* pesan sesi cadmin lama yang boleh dipakai ulang */
let oldWiz=null

if(fromPicker){

 /* server dipilih dari tombol */
 const w=adminWizard.get(sender)
 aw=w

 /* tombol bukan punya sender -> tolak pakai alert, pesan jangan diubah */
 if(!buttonGuard(adminWizard,prefix+command)) return true
 if(!w) return m.reply(tr("panel.wizardExpired",{cmd:prefix+command}))

 /* sesi masih di layar awal -> balikin ke prompt, jangan error diam-diam */
 if(!w.serverChoices)
  return wizEdit(w,tr("admin.askStart",{prefix:prefix}),{inline_keyboard:[[wizCancelRow("cadmin")]]})

 const picked=String(aTok[1]||"")
 if(!w.serverChoices.includes(picked)) return m.reply(tr("panel.wizardBadValue"))

 adminWizard.delete(sender)
 username=w.username
 id=w.targetId
 serverName=picked

}else{

 ;[username,target,serverName]=aParts
if(!username||!target) return m.reply(tr("admin.usage",{prefix:prefix}))

/* sesi cadmin lama dibatalkan dulu, biar cuma ada satu picker jalan */
oldWiz=await dropSessions(adminWizard)

/* hasil resolve disimpan di variabel luar, karena `id` di blok ini ke-shadow */
resolveId=String(target).toLowerCase()==="me"?String(m.sender):await getUserID(m,target)
if(!resolveId) return m.reply(tr("common.notFound"))

/* samakan dengan variabel luar biar sisa kode di bawah tetap jalan */
id=resolveId

}

/* seller cuma boleh server 1, super/owner bebas */
const choices=(isSuper||isOwner)?Object.keys(global.panelServer||{}):["1"]

/* belum pilih server -> kasih tombol picker */
if(!serverName){

 if(choices.length<2){
  serverName=choices[0]
  /* sesi dari layar awal (kalau ada) -> pesannya dipakai buat status DONE */
  if(oldWiz&&oldWiz.msgId) aw=oldWiz
 }else{
  const awSess={username:String(username).toLowerCase(),targetId:resolveId||id,serverChoices:choices,chat:String(m.chat),msgId:(oldWiz&&oldWiz.msgId)||null}
  adminWizard.set(sender,awSess)
  return wizShow(awSess,tr("admin.pickServer",{name:awSess.username}),serverPickRows(choices,"cadmin"))
 }
}

if(!choices.includes(serverName)) return failWith("admin.fail",tr("common.serverMissing")+" ("+serverName+")")

const srv=global.panelServer[serverName]
if(!srv) return failWith("admin.fail",tr("common.serverMissing")+" ("+serverName+")")

username=username.toLowerCase()
const email=username+"@gmail.com"
/* digenerate + diulang otomatis kalau panel nolak passwordnya */
let password=genPassword()

const headers={Accept:"application/json","Content-Type":"application/json",Authorization:"Bearer "+srv.apikey}

let j=null
let existing=null

try{

 const made=await createPanelUser({
  srv,
  fields:{email,username,first_name:username,last_name:"Admin",root_admin:true},
  password
 })

 password=made.password
 j=made.data

 /* ---- kalau admin-nya sudah pernah dibuat: pakai user panel yang ada, jangan gagal ---- */
 if(!made.ok || (j&&j.errors)){
  try{
   const uf=await fetch(`${srv.domain}/api/application/users?filter[email]=${encodeURIComponent(email)}`,{headers})
   const uj=await uf.json()
   existing=uj.data?.find(x=>String(x.attributes?.email).toLowerCase()===email.toLowerCase())?.attributes||null

   /* user lama belum admin -> naikkan jadi root admin */
   if(existing && !existing.root_admin){
    await fetch(`${srv.domain}/api/application/users/${existing.id}`,{method:"PATCH",headers,body:JSON.stringify({root_admin:true})})
   }
  }catch{}
 }

 if(!existing && (!j || !j.attributes))
  return failWith("admin.fail",made.reason||tr("common.unknown"))

}catch(e){
 return failWith("admin.fail",e.message||String(e))
}

const aUsername=existing?existing.username:username
const aId=existing?existing.id:j.attributes.id
const passShown=existing?tr("admin.existingPass"):password
const passInfo=existing?tr("admin.existingPass"):tr("admin.passLine",{password:password})

addAdminOwner(resolveId||id,aId)

let teks = tr("admin.created",{username:aUsername,password:passShown,id:aId,domain:srv.domain})

let dmOk=true
let dmErr=null
try{
 await conn.sendMessage(resolveId||id,{
  text:teks,
  parse_mode:"HTML",
  disable_web_page_preview:true,
  reply_markup:{
   inline_keyboard:existing
    ?[
     [{text:"🌐 Login Panel",url:srv.domain}],
     [{text:"📋 Copy Username",switch_inline_query:aUsername}]
    ]
    :[
     [{text:"🌐 Login Panel",url:srv.domain}],
     [{text:"📋 Copy Username",switch_inline_query:aUsername}],
     [{text:"🔑 Copy Password",switch_inline_query:password}]
    ]
  }
 })
}catch(e){ dmOk=false; dmErr=e.message||String(e) }

/* laporan balik ke yang jalanin command: pesan picker di-EDIT jadi DONE + tag user */
const tag=userTag(resolveId||id)

let out = dmOk
 ? tr("admin.done",{tag:tag,username:aUsername,srv:serverName,id:aId})
 : tr("admin.doneDmFail",{tag:tag,reason:dmErr||tr("common.unknown"),username:aUsername,passinfo:passInfo,id:aId})

if(existing) out+="\n\n"+tr("admin.doneExisting")

return wizDone(aw,out)
}
break

//=======================================================

case "deladmin": {
return deleteIdentityFlow("admin")
}
break

//=======================================================

case "listadmin": {

if(!isOwner) return m.reply(tr("denied.owner"))

if(isOwner){
 let teks=tr("admin.globalHeader")+"\n"
 let data=await fetchAllServers("/api/application/users?page=1")

 for(const srv of data){
  teks+="\n"+tr("panel.serverHeader",{name:srv.server})+"\n"
  for(const u of srv.data){
   if(!u.attributes.root_admin) continue
   teks+=tr("admin.item",{id:u.attributes.id,username:u.attributes.username})+"\n"
  }
 }
 return safeReply(m,teks)
}

let my=getUserAdmins(sender)
if(!my.length) return m.reply(tr("admin.empty"))

safeReply(m,tr("admin.yourHeader")+"\n"+my.join("\n"))
}
break
//=======================================================
case "cdomain":{
if(!isOwner) return m.reply(tr("denied.owner"))
if(!text) return m.reply(example(tr("domain.usageAdd")))

let [sub,ip,proxy,domain]=text.split("|")
if(!sub||!ip||!domain) return m.reply(tr("common.badParam")+"\n"+example(tr("domain.usageAdd")))

let cfg=global.cf.domains[domain]
if(!cfg) return m.reply(tr("domain.notAvailable")+example(tr("domain.usageAdd")))

let proxied=proxy=="on"
let host=`${sub}.${domain}`

let cek=await fetch(`https://api.cloudflare.com/client/v4/zones/${cfg.zone}/dns_records?type=A&name=${host}`,{
headers:{Authorization:"Bearer "+cfg.apikey}
})
let cekj=await cek.json()
if(cekj.result?.length) return m.reply(tr("domain.exists"))

let res=await fetch(`https://api.cloudflare.com/client/v4/zones/${cfg.zone}/dns_records`,{
method:"POST",
headers:{Authorization:"Bearer "+cfg.apikey,"Content-Type":"application/json"},
body:JSON.stringify({type:"A",name:host,content:ip,ttl:120,proxied})
})
let r=await res.json()
if(!r.success) return m.reply(JSON.stringify(r.errors,null,2))

let teks=tr("domain.created",{host:host,ip:ip,proxy:proxied?tr("domain.proxyOn"):tr("domain.proxyOff"),status:tr("domain.statusActive")})

if(m.isGroup){
await m.reply(tr("common.checkPv"))
return conn.sendMessage(m.sender,{text:teks,parse_mode:"HTML"})
}

m.reply(teks)
}
break
//=======================================================
case "cdomainpanel":{
if(!isOwner) return m.reply(tr("denied.owner"))
if(!text) return m.reply(example(tr("domain.usagePanel")))

let [sub,ip,domain]=text.split("|")
if(!sub||!ip||!domain) return m.reply(tr("common.badParam")+"\n"+example(tr("domain.usagePanel")))

let cfg=global.cf.domains[domain]
if(!cfg) return m.reply(tr("domain.notAvailable")+example(tr("domain.usagePanel")))

let panel=`${sub}.${domain}`
let node=`node-${sub}.${domain}`

async function buat(host,proxied){
let f=await fetch(`https://api.cloudflare.com/client/v4/zones/${cfg.zone}/dns_records`,{
method:"POST",
headers:{Authorization:"Bearer "+cfg.apikey,"Content-Type":"application/json"},
body:JSON.stringify({type:"A",name:host,content:ip,ttl:120,proxied})
})
return await f.json()
}

let a=await buat(panel,false)
if(!a.success) return m.reply(JSON.stringify(a.errors,null,2))
let b=await buat(node,false)
if(!b.success) return m.reply(JSON.stringify(b.errors,null,2))

let teks=tr("domain.panelCreated",{panel:panel,node:node,ip:ip,status:tr("domain.deployReady")})

if(m.isGroup){
await m.reply(tr("common.checkPv"))
return conn.sendMessage(m.sender,{text:teks,parse_mode:"HTML"})
}

m.reply(teks)
}
break
//=======================================================
case "listsubdo":{
if(!isOwner) return m.reply(tr("denied.owner"))
if(!text) return m.reply(example(tr("domain.usageList")))

let cfg=global.cf.domains[text]
if(!cfg) return m.reply(tr("domain.notAvailable")+example(tr("domain.usageList")))

let f=await fetch(`https://api.cloudflare.com/client/v4/zones/${cfg.zone}/dns_records?type=A&per_page=100`,{
headers:{Authorization:"Bearer "+cfg.apikey}
})
let j=await f.json()

let teks=tr("domain.listHeader")+"\n\n"
for(let r of j.result){
teks+=`🌍 <code>${r.name}</code>\n`
}

if(!j.result.length) teks+=tr("domain.listEmpty")

m.reply(teks)
}
break
//=======================================================
case "delsubdo":{
if(!isOwner) return m.reply(tr("denied.owner"))
if(!text) return m.reply(example(tr("domain.usageDel")))

let [host,domain]=text.split("|")
if(!host||!domain) return m.reply(tr("common.badParam")+"\n"+example(tr("domain.usageDel")))

let cfg=global.cf.domains[domain]
if(!cfg) return m.reply(tr("domain.notAvailable")+example(tr("domain.usageDel")))

let list=await fetch(`https://api.cloudflare.com/client/v4/zones/${cfg.zone}/dns_records?type=A&name=${host}`,{
headers:{Authorization:"Bearer "+cfg.apikey}
})
let j=await list.json()
if(!j.result.length) return m.reply(tr("domain.delNotFound"))

let id=j.result[0].id

await fetch(`https://api.cloudflare.com/client/v4/zones/${cfg.zone}/dns_records/${id}`,{
method:"DELETE",
headers:{Authorization:"Bearer "+cfg.apikey}
})

let teks=tr("domain.deleted",{host:host,status:tr("domain.statusRemoved")})

m.reply(teks)
}
break
//=======================================================
case "blclean": {
if(!isOwner) return m.reply(tr("denied.owner"))

if(!text){
 return m.reply("\n"+tr("blclean.usage",{prefix:prefix}))
}

let args = text.split("|")

let option = String(args[0] || "").toLowerCase()
let id = Number(args[1])
let srv = String(args[2] || "1")

if(!["bl","unbl"].includes(option)){
 return m.reply(tr("blclean.badOption"))
}

if(isNaN(id)){
 return m.reply(tr("blclean.badId"))
}

if(!global.panelServer[srv]){
 return m.reply(tr("blclean.serverMissing"))
}

if(!Array.isArray(blClean)){
 blClean = []
}

const exist = blClean.find(v =>
 Number(v.id) === Number(id) &&
 String(v.srv) === String(srv)
)

if(option === "bl"){

 if(exist){
  return m.reply(tr("blclean.exists",{id:id}))
 }

 blClean.push({
  id,
  srv
 })

 saveBL()

 return m.reply(tr("blclean.added",{id:id,srv:srv}))
}

if(option === "unbl"){

 if(!exist){
  return m.reply(tr("blclean.missing",{id:id}))
 }

 blClean = blClean.filter(v =>
 !(
  Number(v.id) === Number(id) &&
  String(v.srv) === String(srv)
 )
 )

 saveBL()

 return m.reply(tr("blclean.removed",{id:id,srv:srv}))
}
}
break
//=======================================================
case "cleanpanel": {
if(!isOwner) return m.reply(tr("denied.owner"))

if(!text){
 return m.reply("\n"+tr("cleanpanel.usage",{prefix:prefix}))
}

let actions = text
 .split("|")[0]
 .replace(/[^123]/g,"")
 .split("")

actions = [...new Set(actions)]

if(!actions.length){
 return m.reply(tr("cleanpanel.badMode"))
}

const targets = getAllServerTargets(text)

let hasil = []

for(const srvName of targets){

 try{

  const srv = getSrv(srvName)

  const appHeaders = {
   Authorization: `Bearer ${srv.apikey}`,
   Accept: "application/json"
  }

  const clientHeaders = {
   Authorization: `Bearer ${srv.capikey}`,
   "Content-Type": "application/json",
   Accept: "application/json"
  }

  const users = await fetchAllPages(
   `${srv.domain}/api/application/users`,
   appHeaders
  )

  const servers = await fetchAllPages(
   `${srv.domain}/api/application/servers`,
   appHeaders
  )

  if(actions.includes("1")){

   let deleted = 0

   for(const u of users){

    try{

     const usr = u.attributes

     if(
      usr.root_admin ||
      safeUsers.includes(
       String(usr.username).toLowerCase()
      )
     ) continue

     const punyaServer = servers.find(s =>
      Number(s.attributes.user) === Number(usr.id)
     )

     if(punyaServer) continue

     const del = await fetch(
      `${srv.domain}/api/application/users/${usr.id}`,
      {
       method: "DELETE",
       headers: appHeaders
      }
     )

     if(del.ok){
      deleted++
     }

    }catch{}

   }

   hasil.push(tr("cleanpanel.userDeleted",{srv:srvName,n:deleted}))

  }

  if(actions.includes("2")){

   let deleted = 0

   for(const s of servers){

    try{

     const a = s.attributes

     const disk =
      Number(a.limits?.disk || 0)

     if(disk >= 1) continue

     const isBL = blClean.find(v =>
      Number(v.id) === Number(a.id) &&
      String(v.srv) === String(srvName)
     )

     if(isBL) continue

     const name =
      String(a.name || "").toLowerCase()

     const desc =
      String(a.description || "").toLowerCase()

     if(
      name.includes("rafzbot") ||
      desc.includes("rafzbot")
     ) continue

     const del = await fetch(
      `${srv.domain}/api/application/servers/${a.id}`,
      {
       method: "DELETE",
       headers: appHeaders
      }
     )

     if(del.ok){
      deleted++
     }

    }catch{}

   }

   hasil.push(tr("cleanpanel.serverDeleted",{srv:srvName,n:deleted}))

  }

  if(actions.includes("3")){

   let stopped = 0

   for(const s of servers){

    try{

     const a = s.attributes

     const isBL = blClean.find(v =>
      Number(v.id) === Number(a.id) &&
      String(v.srv) === String(srvName)
     )

     if(isBL) continue

     const name =
      String(a.name || "").toLowerCase()

     const desc =
      String(a.description || "").toLowerCase()

     if(
      name.includes("rafzbot") ||
      desc.includes("rafzbot")
     ) continue

     const resource = await fetch(
      `${srv.domain}/api/client/servers/${a.identifier}/resources`,
      {
       method: "GET",
       headers: {
        Authorization: `Bearer ${srv.capikey}`,
        Accept: "application/json"
       }
      }
     )

     let state = "offline"

     try{

      const resourceJson =
       await resource.json()

      state =
       resourceJson.attributes?.current_state ||
       "offline"

     }catch{}

     if(state === "offline") continue

     const power = await fetch(
      `${srv.domain}/api/client/servers/${a.identifier}/power`,
      {
       method: "POST",
       headers: clientHeaders,
       body: JSON.stringify({
        signal: "stop"
       })
      }
     )

     if(power.ok){
      stopped++
     }

    }catch{}

   }

   hasil.push(tr("cleanpanel.serverStopped",{srv:srvName,n:stopped}))

  }

 }catch(e){

  hasil.push(tr("cleanpanel.serverError",{srv:srvName,msg:e.message}))

 }

}

m.reply(hasil.join("\n\n"))
}
break
//=======================================================
/* ===== MONITOR PANEL (multi-server) ===== */
case "monitor":
case "mon": {
if(!isOwner) return m.reply(tr("denied.owner"))
const mon = global.monitorModule
if(!mon) return m.reply("◈ <b>Monitor</b>\n\n<blockquote>" + tr("monitor.notLoaded") + "</blockquote>")

const arg = String(text||"").trim().toLowerCase().split(/\s+/)[0]

if(arg === "on" || arg === "start"){
 try{
  if(mon.isRunning()) return m.reply("◈ <b>Monitor</b>\n\n<blockquote>" + tr("monitor.alreadyOn") + "</blockquote>")
  mon.start(bot)
  return m.reply("◈ <b>Monitor ON</b>\n\n<blockquote>" + tr("monitor.turnedOn") + "</blockquote>")
 }catch(e){
  return m.reply(`◈ <b>Error</b>\n\n<blockquote>${String(e.message||e)}</blockquote>`)
 }
}

if(arg === "off" || arg === "stop"){
 try{
  mon.stop()
  return m.reply("◈ <b>Monitor OFF</b>\n\n<blockquote>" + tr("monitor.turnedOff") + "</blockquote>")
 }catch(e){
  return m.reply(`◈ <b>Error</b>\n\n<blockquote>${String(e.message||e)}</blockquote>`)
 }
}

/* default: status */
try{
 const st = mon.getStatus()
 const conf = global.monitor || {}
 const txt = `
◈ <b>Monitor Status</b>

<blockquote>⌲ <b>${tr("monitor.status")}:</b> ${st.running ? "✅ ON" : "❌ OFF"}
⌲ <b>Uptime:</b> ${st.uptime}
⌲ <b>${tr("monitor.suspended")}:</b> ${st.suspended}
⌲ <b>${tr("monitor.tracking")}:</b> ${st.tracking}
⌲ <b>${tr("monitor.panelsLabel")}:</b> ${st.panels.length ? st.panels.join(", ") : "-"}
⌲ <b>RAM:</b> ${st.config.ram}%
⌲ <b>Disk:</b> ${st.config.disk}%
⌲ <b>${tr("monitor.interval")}:</b> ${st.config.interval}s
⌲ <b>Auto Delete:</b> ${st.config.autoDelete ? "ON" : "OFF"}
⌲ <b>Chat:</b> ${conf.chatId || tr("monitor.allOwners")}</blockquote>

<code>/monitor on</code> · <code>/monitor off</code>
<code>/top10</code> · <code>/unsuspend id|server</code>
<code>/monhelp</code>
`.trim()
 return m.reply(txt)
}catch(e){
 return m.reply(`◈ <b>Error</b>\n\n<blockquote>${String(e.message||e)}</blockquote>`)
}
}
break

case "top10":
case "montop": {
if(!isOwner && !isSuper) return m.reply(tr("denied.owner"))
const mon = global.monitorModule
if(!mon) return m.reply("◈ <b>Monitor</b>\n\n<blockquote>" + tr("monitor.notLoaded") + "</blockquote>")
try{
 const db = mon.getTop10()
 if(!db.lastUpdated) return m.reply("◈ <b>Top 10</b>\n\n<blockquote>" + tr("monitor.noData") + "</blockquote>")
 return m.reply(mon.buildTop10Message(db))
}catch(e){
 return m.reply(`◈ <b>Error</b>\n\n<blockquote>${String(e.message||e)}</blockquote>`)
}
}
break

case "unsuspend": {
if(!isOwner && !isSuper) return m.reply(tr("denied.owner"))
const mon = global.monitorModule
if(!mon) return m.reply("◈ <b>ᴍᴏɴɪᴛᴏʀ</b>\n\n<blockquote>ᴍᴏᴅᴜʟᴇ ʙᴇʟᴜᴍ ᴛᴇʀʟᴏᴀᴅ.</blockquote>")

const rawArg = String(text||"").trim()
if(!rawArg) return m.reply(`◈ <b>${tr("use.usage")}</b>\n\n<blockquote><code>/unsuspend id|server</code>\n${tr("use.example")}: <code>/unsuspend 12|1</code></blockquote>`)

let [idPart, srvPart] = rawArg.split("|").map(s => s.trim())
const serverId = Number(idPart)
const srvKey = srvPart || "1"

if(!serverId) return m.reply("◈ <b>ID</b>\n\n<blockquote>" + tr("monitor.idMustNumber") + "</blockquote>")
if(!global.panelServer[srvKey]) return m.reply(tr("common.serverMissing"))

try{
 const r = await mon.doUnsuspend(srvKey, serverId)
 return m.reply(`◈ <b>Unsuspend OK</b>\n\n<blockquote>Server <code>${r.name}</code>\nID: <code>${r.id}</code>\nUUID: <code>${r.uuid}</code>\n${tr("monitor.panelsLabel")}: ${global.panelServer[srvKey].name}</blockquote>`)
}catch(e){
 return m.reply(`◈ <b>${tr("use.failed")}</b>\n\n<blockquote>${String(e.message||e)}</blockquote>`)
}
}
break

case "monhelp":
case "monitorhelp": {
if(!isOwner && !isSuper) return m.reply(tr("denied.owner"))
const txt = `
◈ <b>Monitor Help</b>

<blockquote>⌗ <code>/monitor</code> ⌲ ${tr("monitor.status")}
⌗ <code>/monitor on</code> ⌲ ${tr("monitor.turnOn")}
⌗ <code>/monitor off</code> ⌲ ${tr("monitor.turnOff")}
⌗ <code>/top10</code> ⌲ Top Disk & CPU
⌗ <code>/unsuspend id|server</code> ⌲ ${tr("monitor.releaseSuspend")}
⌗ <code>/monhelp</code> ⌲ ${tr("menu.btnHelp")}</blockquote>

◈ <b>${tr("monitor.notes")}</b>
<blockquote>• ${tr("monitor.noteAuto")}
• ${tr("monitor.noteConfig")}
• ${tr("monitor.noteNotif")}
• ${tr("monitor.noteAutoDelete")}</blockquote>
`.trim()
return m.reply(txt)
}
break
//=======================================================
/* ===== BAHASA / LANGUAGE (picker tombol) ===== */
case "lang": {

const L = require("./library/language")

/* tombol cuma boleh dipakai sama yang buka picker-nya */
if(!buttonGuard(langPicker,prefix+command)) return true

/* keyboard dibangun ulang tiap kali supaya tanda ✅ ikut bahasa terbaru */
const keyboards = (active)=>{
 const btns = L.langKeyboard(active)
 const rows = []
 for(let i=0;i<btns.length;i+=2) rows.push(btns.slice(i,i+2))
 return {
  kb: {inline_keyboard:rows},
  kbPlain: {inline_keyboard:rows}
 }
}

const pick = async (out, active)=>{

const {kb,kbPlain} = keyboards(active)

 if(m.callback){
  try{
   return await bot.editMessageText(out,{
    chat_id:m.chat,
    message_id:m.callback.message.message_id,
    parse_mode:"HTML",
    disable_web_page_preview:true,
    reply_markup:kb
   })
  }catch(e){
   if(String(e.message||e).includes("not modified")) return null
  }
 }
 let res=null
 try{
  res=await bot.sendMessage(m.chat,out,{
   parse_mode:"HTML",
   disable_web_page_preview:true,
   reply_markup:kb
  })
 }catch{
  try{
   res=await bot.sendMessage(m.chat,out,{
    parse_mode:"HTML",
    disable_web_page_preview:true,
    reply_markup:kbPlain
   })
  }catch{}
 }

 /* simpan id pesan picker biar tombol cuma bisa dipakai pemiliknya */
 if(res&&res.message_id) langPicker.set(sender,{msgId:res.message_id})
 return true
}

const arg = String(text||"").trim().toLowerCase().split(/\s+/)[0]

if(!arg) return pick(tr("lang.title",{active:L.label(m.lang,m.lang)}),m.lang)

if(!m.setLang(arg)){
 return pick(tr("lang.unsupported",{list:L.list(),prefix:prefix}),m.lang)
}

return pick(tr("lang.set",{active:L.label(m.lang,m.lang)}),m.lang)
}
break
//==========================[ Akhir Case ]=============================
}

return false
} catch(e) {
  console.error("[CASE FATAL]", e && e.stack ? e.stack : e)
  try {
    if (m && typeof m.reply === "function") {
      await m.reply(m.t ? m.t("pager.internalError") : "⚠️ Terjadi error internal pada command. Silakan coba lagi.")
    }
  } catch {}
  return false
}
}

let file=require.resolve(__filename)
fs.watchFile(file,()=>{
fs.unwatchFile(file)
delete require.cache[file]
require(file)
})