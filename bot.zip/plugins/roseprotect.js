/* roseprotect.js — Rose warn-core (refactor batch-5).
   warn/dwarn/swarn + warns/mywarns + unwarn/rmwarn/resetwarn + kickme.
   Counter via gstore("warns"), limit & mode dari gstore("warnconfig") (rosesys).
   Mode: kick ban tban TIME mute tmute TIME. Varian s=silent (balas ke PM admin),
   d=delete pesan. Semua reply i18n (m.t) + tombol berstyle.
   (purge/del/report/adminlist/rules/lock/mute-gc/pin pindah ke rosesys/roseextra.) */

"use strict"
const gstore = require("../library/gstore")

const esc = (s) => String(s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
const parseTime = (s) => {
  const m = String(s || "").trim().match(/^(\d+)([smhdw])$/i)
  if (!m) return null
  const mult = { s: 1, m: 60, h: 3600, d: 86400, w: 604800 }[m[2].toLowerCase()]
  return parseInt(m[1]) * mult
}

const isAdminChat = async (m, Rafz, uid) => {
  try {
    if ((global.owner || []).includes(uid)) return true
    const admins = await Rafz.getChatAdministrators(m.chat)
    return admins.some(a => String(a.user?.id) === String(uid))
  } catch { return false }
}

const isBotAdmin = async (m, Rafz) => {
  try {
    const me = await Rafz.getMe()
    const admins = await Rafz.getChatAdministrators(m.chat)
    return admins.some(a => String(a.user?.id) === String(me.id))
  } catch { return false }
}

const targetOf = (m, text) => {
  if (m.quoted?.sender) return String(m.quoted.sender)
  const t = String(text || "").trim()
  if (/^\d{5,}$/.test(t)) return t
  const ent = (m.entities || []).find(e => e.type === "text_mention" && e.user)
  if (ent) return String(ent.user.id)
  const um = t.match(/@([a-zA-Z0-9_]{4,})/)
  if (um) return "@" + um[1]
  return null
}

/* eksekusi aksi warnmode terhadap user */
const applyWarnMode = async (m, Rafz, chat, uid, mode) => {
  const mt = String(mode || "").match(/^(tban|tmute)\s+(\d+[smhdw])$/i)
  const base = mt ? mt[1].toLowerCase() : String(mode || "ban").toLowerCase().split(/\s+/)[0]
  const dur = mt ? parseTime(mt[2]) : null
  const until = dur ? Math.floor(Date.now() / 1000) + dur : undefined
  try {
    if (base === "ban") return await Rafz.banChatMember(chat, uid)
    if (base === "kick") { await Rafz.banChatMember(chat, uid); await Rafz.unbanChatMember(chat, uid); return true }
    if (base === "mute") return await Rafz.restrictChatMember(chat, uid, { permissions: { can_send_messages: false } })
    if (base === "tmute") return await Rafz.restrictChatMember(chat, uid, { permissions: { can_send_messages: false }, until_date: until })
    if (base === "tban") { await Rafz.unbanChatMember(chat, uid, { only_if_banned: true }).catch(() => {}); return await Rafz.banChatMember(chat, uid, { until_date: until }) }
  } catch {}
  return false
}

const handler = async (m, { Rafz, command, text }) => {
  try {
    const tr = (key, vars) => (m.t ? m.t(key, vars) : key)
    const uid = String(m.sender)
    const chat = String(m.chat)
    const q = String(text || "").trim()
    if (!m.isGroup) return m.reply("⚠️ " + tr("rose.groupOnly"), { parse_mode: "HTML" })

    const silent = command === "swarn"

    /* ═══ warn / dwarn / swarn ═══ */
    if (["warn", "dwarn", "swarn"].includes(command)) {
      if (!await isAdminChat(m, Rafz, uid)) return m.reply("⚠️ " + tr("rose.adminOnly"), { parse_mode: "HTML" })
      const tgt = targetOf(m, q)
      if (!tgt || !/^\d+$/.test(tgt)) return m.reply("⚠️ " + tr("rose.needTarget") + "\n<code>/warn @user " + tr("rose.reason") + "</code>", { parse_mode: "HTML" })
      if (tgt === uid) return m.reply("😅 " + tr("rose.warnSelf"), { parse_mode: "HTML" })
      if (command === "dwarn") { try { await Rafz.deleteMessage(chat, m.quoted?.id || m.id) } catch {} }

      const key = chat + ":" + tgt
      const n = (gstore.get("warns", key, 0) || 0) + 1
      gstore.set("warns", key, n)
      const limit = gstore.get("warnconfig", chat + ":limit", 3)
      const mode = gstore.get("warnconfig", chat + ":mode", "ban")
      const reason = q.replace(/@\w+/g, "").replace(/^\d+\s*/, "").trim() || "-"
      const reasonTxt = q.replace(/@\w+|\d{5,}/g, "").trim() || "-"

      if (n >= limit) {
        gstore.set("warns", key, 0)
        const ok = await applyWarnMode(m, Rafz, chat, tgt, mode)
        const msg = "🚨 <b>" + tr("rose.warnLimitHit") + "</b> (" + n + "/" + limit + ")\n👤 <code>" + esc(tgt) + "</code>\n⚡ <b>" + tr("rose.action") + "</b>: <b>" + esc(String(mode).toUpperCase()) + "</b>" + (ok ? " ✅" : " ⚠️")
        return m.reply(msg, { parse_mode: "HTML" })
      }

      const msg = "⚠️ <b>WARN</b> (" + n + "/" + limit + ")\n👤 <a href=\"tg://user?id=" + tgt + "\">" + esc(tgt) + "</a>\n📝 <b>" + tr("rose.reason") + "</b>: " + esc(reasonTxt.slice(0, 120))
      if (silent) {
        /* silent: kirim jejak ke PM admin */
        try { await Rafz.sendMessage(uid, msg, { parse_mode: "HTML" }) } catch {}
        return true
      }
      return m.reply(msg, { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "❌ " + tr("rose.unwarnBtn"), callback_data: "/unwarn " + tgt, style: "danger" }]] } })
    }

    /* ═══ warns / mywarns ═══ */
    if (command === "warns" || command === "mywarns") {
      const tgt = command === "mywarns" ? uid : (targetOf(m, q) || uid)
      const n = gstore.get("warns", chat + ":" + tgt, 0) || 0
      const limit = gstore.get("warnconfig", chat + ":limit", 3)
      const who = tgt === uid ? tr("rose.you") : "<code>" + esc(tgt) + "</code>"
      return m.reply("⚠️ <b>WARNS</b>\n\n👤 " + who + "\n📊 <b>" + n + "</b>/" + limit, { parse_mode: "HTML" })
    }

    /* ═══ unwarn / rmwarn / resetwarn ═══ */
    if (["unwarn", "rmwarn", "resetwarn"].includes(command)) {
      if (!await isAdminChat(m, Rafz, uid)) return m.reply("⚠️ " + tr("rose.adminOnly"), { parse_mode: "HTML" })
      const tgt = command === "resetwarn" ? (targetOf(m, q) || uid) : targetOf(m, q)
      if (!tgt || !/^\d+$/.test(tgt)) return m.reply("⚠️ " + tr("rose.needTarget"), { parse_mode: "HTML" })
      const key = chat + ":" + tgt
      if (command === "resetwarn") {
        gstore.set("warns", key, 0)
        return m.reply("♻️ " + tr("rose.warnReset") + " <code>" + esc(tgt) + "</code>", { parse_mode: "HTML" })
      }
      const cur = gstore.get("warns", key, 0) || 0
      if (cur <= 0) return m.reply("✅ " + tr("rose.warnZero"), { parse_mode: "HTML" })
      gstore.set("warns", key, cur - 1)
      return m.reply("➖ " + tr("rose.warnMinus") + " (<b>" + (cur - 1) + "</b>)", { parse_mode: "HTML" })
    }

    /* ═══ kickme ═══ */
    if (command === "kickme") {
      if (!await isBotAdmin(m, Rafz)) return m.reply("⚠️ " + tr("rose.botAdmin"), { parse_mode: "HTML" })
      try {
        await Rafz.banChatMember(chat, uid)
        await Rafz.unbanChatMember(chat, uid)
        return true
      } catch { return m.reply("❌ " + tr("common.failed"), { parse_mode: "HTML" }) }
    }

    return false
  } catch (e) {
    console.error("[roseprotect]", command, e?.message)
    try { await m.reply("❌ " + esc(String(e?.message || e).slice(0, 120)), { parse_mode: "HTML" }) } catch {}
    return false
  }
}

handler.command = ["warn", "dwarn", "swarn", "warns", "mywarns", "unwarn", "rmwarn", "resetwarn", "kickme"]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
