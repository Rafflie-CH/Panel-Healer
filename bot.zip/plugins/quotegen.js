/* quotegen.js — generator teks: pantun, renungan, kata cinta, wangy, siapa/kapan/dimana.
   Port dari WA bot (Rafzbotz/Prabowo/Furina). Data lokal (fallback permanen) →
   BochilTeam/database (kata-kata) → pesan error (dilaporkan errorlog via testall). */

"use strict"

const esc = (s) => String(s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
const pick = (a) => a[Math.floor(Math.random() * a.length)]
const norm = (s) => String(s || "").toLowerCase().trim().replace(/[^a-z0-9 ]/g, "")

/* ── data lokal fallback (anti error kalau GitHub mati) ── */
const LOCAL = {
  pantun: [
    "Jalan-jalan ke Kota Blitar,\njangan lupa membeli sukun.\nKalau kamu ingin bahagia,\njangan sombong dan jangan lupa dirimu.",
    "Buah mangga buah kedondong,\ndibelah dua manis rasanya.\nTeman seperjalanan itu tak berlalu,\nselalu dihati hingga akhirnya.",
    "Pergi ke pasar membeli duku,\nduku manis dijual bersama.\nSiapa yang rajin dalam belajar,\nakan menjadi orang yang bijaksana.",
    "Air telaga jernih beningnya,\ndi permukaan tampak kilauannya.\nBahu-membahu berjuang bersama,\nakan tercapai semua usahanya."
  ],
  renungan: [
    "Hidup ini seperti sepeda. Supaya tetap seimbang, kamu harus terus bergerak. Setiap langkah kecil hari ini adalah kemajuan besar untuk esok.",
    "Tidak semua hal berjalan sesuai rencana, tapi semua terjadi dengan alasannya. Percayalah, rencana Tuhan lebih indah dari rencanamu.",
    "Kepercayaan diri bukan berarti merasa sempurna, tapi berani mencoba meski merasa tak sempurna.",
    "Jangan bandingkan bab 1 hidupmu dengan bab 20 hidup orang lain. Fokus menulis ceritamu sendiri."
  ],
  katacinta: [
    "Kalau mencintaimu adalah pekerjaan, aku akan jadi karyawan teladan yang tidak pernah minta cuti.",
    "Aku tidak sedang pilih-pilih, aku hanya sudah menemukan yang terbaik: kamu.",
    "Bukan bulan yang membuatku bisa tidur, tapi bayanganmu yang selalu menemani sebelum aku terlelap.",
    "Cintaku padamu seperti detak jantung — diam-diam tapi tak pernah berhenti."
  ],
  gombal: [
    "Kamu tahu tidak bedanya kamu sama bintang? Kalau bintang di langit, kamu di hatiku.",
    "Papa saya tukang loak, mama saya tukang bangku. Lantas aku tukang suka sama kamu.",
    "Bukan takut jalan berliku, takutnya kalau tersesat tidak bersamamu.",
    "Aku boleh pinjam HP kamu? Soalnya nomor daruratku belum ada kamu."
  ],
  bucin2: [
    "Aku rela jadi bucin, asal yang dibucin-in kamu. Satu kalimat itu saja sudah cukup buatku semangat seumur hidup.",
    "Yang namanya cinta tak pernah buta. Cuma kadang memilih untuk tidak melihat kekurangan orang yang dicintainya.",
    "Bermalas-malasan di ranjang itu indah, tapi bermalas-malasan bersamamu itu luar biasa.",
    "Kamu tahu apa yang lebih indah dari cinta? Cinta yang bersambut, apalagi kesambut sama kamu."
  ],
  motivasi2: [
    "Sukses bukan akhir, kegagalan bukan akhir dunia. Yang penting adalah keberanian untuk melanjutkan.",
    "Jangan menunggu momen yang tepat. Ambil momen itu dan jadikan tepat.",
    "Disiplin adalah jembatan antara tujuan dan pencapaian. Mulai hari ini, mulai dari yang kecil.",
    "Kalau kamu lelah, istirahatlah. Tapi jangan berhenti."
  ],
  bijak2: [
    "Sebesar apapun penyesalanmu, masa lalu tidak akan kembali. Yang bisa kamu ubah adalah hari ini dan esok.",
    "Mulutmu adalah singa, tabiatmu adalah harimau, tapi bisakah kamu juga baik di dalam hatimu?",
    "Berani berbuat salah bukanlah hal yang memalukan. Yang memalukan adalah tidak berani mengakui kesalahan.",
    "Sesalah apapun dirimu, kamu tetap manusia yang berhak atas hidup yang baik."
  ],
  fakta2: [
    "Hiu sudah ada sebelum pohon muncul di bumi — sekitar 100 juta tahun lebih awal.",
    "Madu tidak pernah basi. Madu berusia 3000 tahun masih bisa dimakan.",
    "Tubuh manusia mengandung cukup karbon untuk membuat sekitar 900 batu pensil.",
    "Indonesia punya lebih dari 17.000 pulau — hanya sekitar 16.000 yang resmi bernama."
  ]
}

/* fetch JSON dari GitHub BochilTeam (non-blocking, silent fail → LOCAL) */
const github = async (path) => {
  const url = "https://raw.githubusercontent.com/BochilTeam/database/master/" + path
  const r = await fetch(url, { signal: AbortSignal.timeout(12000) })
  if (!r.ok) throw new Error("HTTP " + r.status)
  return r.json()
}
const SOURCE_DB = { dare: "kata-kata/dare.json", truth: "kata-kata/truth.json", bucin: "kata-kata/bucin.json", renungan: "kata-kata/renungan.json" }

/* ── tebak-tebakan (siapa/kapan/dimana/wangy) ── */
const TEBAKANS = {
  siapa: { title: "SIAPAKAH AKU", items: [
    ["Aku punya leher panjang tapi tidak bisa bersuara. Aku?", "jerapah"],
    ["Aku hidup di laut, punya 8 lengan. Aku?", "gurita"],
    ["Aku terbang malam hari dan punya sonar. Aku?", "kelelawar"]
  ]},
  kapan: { title: "KAPANKAH", items: [
    ["Indonesia merdeka, kapan?", "17 agustus 1945"],
    ["Manusia pertama mendarat di bulan, kapan?", "1969"]
  ]},
  dimana: { title: "DIMANAKAH", items: [
    ["Menara Eiffel berada di?", "paris"],
    ["Candi Borobudur ada di?", "magelang"]
  ]}
}

const handler = async (m, { Rafz, command, text }) => {
  try {
    const tr = (key, vars) => (m.t ? m.t(key, vars) : key)
    const px = (global.prefix && global.prefix[0]) || "/"

    /* ── random text dari LOCAL (selalu jalan) ── */
    if (LOCAL[command]) return m.reply("📝 <b>" + esc(command.toUpperCase()) + "</b>\n\n" + esc(pick(LOCAL[command])), { parse_mode: "HTML" })

    /* ── dare/truth/bucin/renungan: BochilTeam → LOCAL fallback ── */
    if (SOURCE_DB[command]) {
      let item = null
      try {
        const db = await github(SOURCE_DB[command])
        if (Array.isArray(db) && db.length) item = pick(db)
      } catch {}
      if (!item) item = pick(LOCAL[command] || ["."])
      const label = command === "bucin" ? "KATA BUCIN" : command.toUpperCase()
      return m.reply("💭 <b>" + esc(label) + "</b>\n\n" + esc(item), { parse_mode: "HTML" })
    }

    /* ── wangy — spam teks wangy (fun) ── */
    if (command === "wangy") {
      const name = String(text || "").trim().split(/\s+/)[0]
      if (!name) return m.reply("⚠️ " + tr("qt.needName") + "\n<code>" + px + "wangy namakamu</code>", { parse_mode: "HTML" })
      const s = `${name} WANGY WANGY WANGY 🌸\nWANGY WANGY WANGY WANGY WANGY\nGIMOCHI GIMOCHI GIMOCHI 💕\n${name} WANGY SANGAT WANGY 🥰`
      return m.reply(esc(s))
    }

    /* ── siapa/kapan/dimana — mini quiz tanpa state ── */
    if (TEBAKANS[command]) {
      const t = TEBAKANS[command]
      const [q, a] = pick(t.items)
      let out = "❓ <b>" + t.title + "</b>\n\n" + esc(q) + "\n\n💡 " + esc(a.split(" ")[0]) + "..."
      return m.reply(out, { parse_mode: "HTML" })
    }

    return false
  } catch (e) {
    console.error("[quotegen]", command, e?.message)
    try { await m.reply("❌ " + esc(String(e?.message || e).slice(0, 120)), { parse_mode: "HTML" }) } catch {}
    return false
  }
}

handler.command = [
  "pantun", "renungan", "katacinta", "gombal2", "bucin2", "motivasi2", "bijak2", "fakta2",
  "dare", "truth", "bucin", "wangy", "siapa", "kapan", "dimana"
]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
