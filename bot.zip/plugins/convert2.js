"use strict"
const https = require("https")
const http = require("http")
const sharp = require("sharp")

const UA = "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/130 Mobile Safari/537.36"

const getBuffer = (url) =>
  new Promise((resolve, reject) => {
    try {
      const follow = (u, depth = 0) => {
        if (depth > 5) return reject(new Error("Too many redirects"))
        const parsed = new URL(u)
        const mod = parsed.protocol === "https:" ? https : http
        mod.get({ hostname: parsed.hostname, path: parsed.pathname + parsed.search, timeout: 60000, headers: { "User-Agent": UA } }, (res) => {
          if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) return follow(new URL(res.headers.location, u).href, depth + 1)
          if (res.statusCode !== 200) return reject(new Error("HTTP " + res.statusCode))
          const c = []
          res.on("data", d => c.push(d))
          res.on("end", () => resolve(Buffer.concat(c)))
        }).on("error", reject).on("timeout", function () { this.destroy(); reject(new Error("Timeout")) })
      }
      follow(url)
    } catch (e) { reject(e) }
  })

const tgBuffer = async (Rafz, fileId) => {
  const info = await Rafz.getFile(fileId)
  return getBuffer("https://api.telegram.org/file/bot" + Rafz.token + "/" + info.file_path)
}

const handler = async (m, { Rafz, command, text }) => {
  try {
    const px = (global.prefix && global.prefix[0]) || "/"
    const q = (text || "").trim()

    // ===== TOIMG (sticker to image) =====
    if (command === "toimg" || command === "img") {
      const src = (m.quoted && m.quoted.fileId) ? m.quoted : (m.fileId ? m : null)
      if (!src || !src.fileId || src.mediaType !== "sticker")
        return m.reply("Reply stiker dengan " + px + "toimg")
      const wait = await m.reply("Mengkonversi...")
      try {
        let buf = await tgBuffer(Rafz, src.fileId)
        if (src.sticker?.isAnimated || src.sticker?.isVideo) throw new Error("Stiker animasi/video tidak bisa dikonversi")
        if (buf.length < 3 || (buf[0] === 0x52 && buf[1] === 0x49)) {
          buf = await sharp(buf).png().toBuffer()
        }
        await Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {})
        await Rafz.sendPhoto(m.chat, buf, { caption: "Hasil konversi stiker ke gambar", reply_to_message_id: m.id, allow_sending_without_reply: true })
        return true
      } catch (e) {
        try { await Rafz.deleteMessage(m.chat, wait.message_id) } catch {}
        return m.reply("Gagal: " + e.message)
      }
    }

    // ===== EMOJI MIX =====
    if (command === "emojimix") {
      const emojis = q.split("+").map(s => s.trim())
      if (emojis.length !== 2) return m.reply("Penggunaan: " + px + "emojimix \U0001F600+\U0001F680")
      try {
        const buf = await getBuffer("https://api.siputzx.my.id/api/maker/emojimix?emoji1=" + encodeURIComponent(emojis[0]) + "&emoji2=" + encodeURIComponent(emojis[1]))
        if (!buf || buf.length < 500) throw new Error("gagal")
        await Rafz.sendPhoto(m.chat, buf, { caption: "EMOJI MIX: " + emojis[0] + " + " + emojis[1], reply_to_message_id: m.id })
        return true
      } catch (e) {
        return m.reply("Gagal mix emoji: " + e.message)
      }
    }

    // ===== REMOVE BG =====
    if (command === "removebg" || command === "rmbg") {
      const src = (m.quoted && m.quoted.fileId) ? m.quoted : (m.fileId ? m : null)
      if (!src || !src.fileId) return m.reply("Reply/kirim foto dengan caption " + px + "removebg")
      if (!["photo", "image"].includes(src.mediaType)) return m.reply("Harus foto!")
      const wait = await m.reply("Menghapus background...")
      try {
        const buf = await tgBuffer(Rafz, src.fileId)
        const res = await fetch("https://api.siputzx.my.id/api/tools/removebg", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ image: "data:image/jpeg;base64," + buf.toString("base64") })
        })
        const j = await res.json()
        if (j && j.status && j.data) {
          const imgBuf = await getBuffer(j.data)
          await Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {})
          await Rafz.sendDocument(m.chat, imgBuf, { filename: "no-bg.png", caption: "BACKGROUND DIHAPUS", reply_to_message_id: m.id })
          return true
        }
        throw new Error("API error")
      } catch (e) {
        try { await Rafz.deleteMessage(m.chat, wait.message_id) } catch {}
        return m.reply("Gagal remove bg: " + e.message)
      }
    }

    // ===== TOVN / TOAUDIO (voice note) =====
    if (["tovn", "toptt", "toaud", "tomp3", "toaudio"].includes(command)) {
      const src = (m.quoted && m.quoted.fileId) ? m.quoted : (m.fileId ? m : null)
      if (!src || !src.fileId) return m.reply("Reply audio/video dengan " + px + command)
      if (!["audio", "voice", "video", "video_note", "document", "animation"].includes(src.mediaType)) return m.reply("Harus audio/video!")
      const wait = await m.reply("Mengkonversi...")
      try {
        const buf = await tgBuffer(Rafz, src.fileId)
        await Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {})
        if (command === "tovn" || command === "toptt") {
          await Rafz.sendVoice(m.chat, buf, { reply_to_message_id: m.id, allow_sending_without_reply: true })
        } else {
          await Rafz.sendAudio(m.chat, buf, { title: "Audio", reply_to_message_id: m.id, allow_sending_without_reply: true })
        }
        return true
      } catch (e) {
        try { await Rafz.deleteMessage(m.chat, wait.message_id) } catch {}
        return m.reply("Gagal: " + e.message)
      }
    }

    // ===== TOVIDEO (video note to video) =====
    if (command === "tovideo" || command === "tomp4") {
      const src = (m.quoted && m.quoted.fileId) ? m.quoted : (m.fileId ? m : null)
      if (!src || !src.fileId) return m.reply("Reply video dengan " + px + "tovideo")
      if (!["video", "animation", "video_note"].includes(src.mediaType)) return m.reply("Harus video!")
      const wait = await m.reply("Mengirim...")
      try {
        const buf = await tgBuffer(Rafz, src.fileId)
        await Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {})
        await Rafz.sendVideo(m.chat, buf, { caption: "Video", reply_to_message_id: m.id, allow_sending_without_reply: true })
        return true
      } catch (e) {
        try { await Rafz.deleteMessage(m.chat, wait.message_id) } catch {}
        return m.reply("Gagal: " + e.message)
      }
    }

    return false
  } catch (e) {
    console.error("[convert2]", e?.message)
    try { await m.reply("Error: " + (e?.message || e)) } catch {}
    return false
  }
}

handler.command = ["toimg", "img", "emojimix", "removebg", "rmbg", "tovn", "toptt", "toaud", "tomp3", "toaudio", "tovideo", "tomp4"]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
