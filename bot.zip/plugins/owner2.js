/* plugin: owner2.js — porting fitur owner-management dari bot WA (Prabowo)
   /addseller2 /delseller2 /listseller2  — seller via reply/mention/id
   /addsuper2 /delsuper2 /listsuper2     — super seller
   /addowner2 /delowner2 /listowner2     — owner tambahan
   /cekwarn /warn2 /resetwarn2           — warning system per user
   Duplikat dari plugin lain → otomatis jadi fallback chain.
*/
"use strict"
const fs = require("fs")
const path = require("path")

const DB = (f) => path.join("library", "database", f)
const readArr = (f) => { try { const j = JSON.parse(fs.readFileSync(DB(f), "utf8")); return Array.isArray(j) ? j : [] } catch { return [] } }
const writeArr = (f, arr) => { try { fs.mkdirSync("library/database", { recursive: true }); fs.writeFileSync(DB(f), JSON.stringify(arr, null, 2)) } catch {} }

/* resolve target user: reply > mention > id langsung */
const targetOf = (m, text) => {
  if (m.quoted?.from?.id) return { id: String(m.quoted.from.id), name: m.quoted.from.first_name || "" }
  if (m.quoted?.sender) return { id: String(m.quoted.sender), name: "" }
  if (m.mentioned?.length) return { id: String(m.mentioned[0].id || m.mentioned[0]), name: m.mentioned[0].first_name || "" }
  const t = (text || "").trim().replace(/^@/, "")
  if (/^\d{5,}$/.test(t)) return { id: t, name: "" }
  return null
}

const WARN_FILE = "warn2.json"
const loadWarn = () => { try { const j = JSON.parse(fs.readFileSync(DB(WARN_FILE), "utf8")); return j && typeof j === "object" ? j : {} } catch { return {} } }
const saveWarn = (d) => { try { fs.writeFileSync(DB(WARN_FILE), JSON.stringify(d, null, 2)) } catch {} }

const MAX_WARN = 3

const handler = async (m, { command, text }) => {
  try {
    const tr = (key, vars) => (m.t ? m.t(key, vars) : key)
    const sender = String(m.sender)
    const isCreator = (global.owner || []).includes(sender) || readArr("owner.json").includes(sender)
    const px = (global.prefix && global.prefix[0]) || "/"

    const manage = (cmd, file, labelKey) => {
      if (!isCreator) return m.reply(tr("denied.owner"))
      if (cmd.startsWith("add") || cmd.startsWith("tambah")) {
        const t = targetOf(m, text)
        if (!t) return m.reply(tr("use.usage") + ": <code>" + px + cmd + " id|@user|reply</code>", { parse_mode: "HTML" })
        const arr = readArr(file)
        if (arr.includes(t.id)) return m.reply(tr("owner2.already", { id: t.id }))
        arr.push(t.id); writeArr(file, arr)
        return m.reply("✅ " + tr(labelKey) + " → <code>" + t.id + "</code>", { parse_mode: "HTML" })
      }
      if (cmd.startsWith("del") || cmd.startsWith("hapus")) {
        const t = targetOf(m, text) || { id: (text || "").trim().replace(/^@/, "") }
        if (!t.id) return m.reply(tr("use.usage") + ": <code>" + px + cmd + " id|@user|reply</code>", { parse_mode: "HTML" })
        const arr = readArr(file).filter(x => x !== t.id)
        writeArr(file, arr)
        return m.reply("🗑️ " + tr(labelKey) + " <code>" + t.id + "</code> " + tr("owner2.removed"), { parse_mode: "HTML" })
      }
      /* list */
      const arr = readArr(file)
      if (!arr.length) return m.reply(tr("owner2.listEmpty", { label: tr(labelKey) }))
      let out = "📋 <b>" + tr(labelKey) + " (" + arr.length + ")</b>\n\n"
      arr.forEach((id, i) => { out += (i + 1) + ". <code>" + id + "</code>\n" })
      return m.reply(out, { parse_mode: "HTML" })
    }

    if (command === "addseller2" || command === "delseller2" || command === "listseller2")
      return manage(command, "seller.json", "owner2.seller")

    if (command === "addsuper2" || command === "addsuperseller2" || command === "delsuper2" || command === "listsuper2")
      return manage(command, "superseller.json", "owner2.super")

    if (command === "addowner2" || command === "tambahowner2" || command === "delowner2" || command === "listowner2")
      return manage(command, "owner.json", "owner2.owner")

    /* ── WARNING ── */
    if (command === "warn2") {
      if (!m.isGroup) return m.reply(tr("grp2.groupOnly"))
      const t = targetOf(m, text)
      if (!t) return m.reply(tr("use.usage") + ": <code>" + px + "warn2 @user alasan</code>", { parse_mode: "HTML" })
      const db = loadWarn()
      const key = m.chat + ":" + t.id
      db[key] = db[key] || { count: 0, reasons: [] }
      db[key].count++
      db[key].reasons.push({ by: sender, reason: text || "-", ts: Date.now() })
      saveWarn(db)
      if (db[key].count >= MAX_WARN) {
        delete db[key]; saveWarn(db)
        try { await m.reply("🚨 " + tr("owner2.warnMax", { name: t.name || t.id })) } catch {}
        return true
      }
      return m.reply("⚠️ " + tr("owner2.warned", { name: t.name || t.id, n: db[key].count, max: MAX_WARN }), { parse_mode: "HTML" })
    }

    if (command === "cekwarn" || command === "mywarns2") {
      const t = targetOf(m, text) || { id: sender, name: m.pushName }
      const db = loadWarn()
      const w = db[m.chat + ":" + t.id]
      if (!w) return m.reply("✅ " + tr("owner2.noWarn", { name: t.name || t.id }))
      return m.reply("⚠️ " + tr("owner2.warned", { name: t.name || t.id, n: w.count, max: MAX_WARN }), { parse_mode: "HTML" })
    }

    if (command === "resetwarn2" || command === "unwarn2") {
      if (!isCreator && !m.isAdmin) return m.reply(tr("denied.admin"))
      const t = targetOf(m, text) || { id: sender }
      const db = loadWarn()
      delete db[m.chat + ":" + t.id]; saveWarn(db)
      return m.reply("♻️ " + tr("owner2.warnReset", { name: t.name || t.id }), { parse_mode: "HTML" })
    }

    return false
  } catch (e) {
    console.error("[owner2]", command, e?.message)
    try { await m.reply("❌ " + e.message) } catch {}
    return false
  }
}

handler.command = [
  "addseller2", "delseller2", "listseller2",
  "addsuper2", "addsuperseller2", "delsuper2", "listsuper2",
  "addowner2", "tambahowner2", "delowner2", "listowner2",
  "warn2", "cekwarn", "mywarns2", "resetwarn2", "unwarn2"
]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
