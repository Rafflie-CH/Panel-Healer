/* nekos3.js — anime image SFW (nekos.life — 11 endpoint terverifikasi, 2026-09).
   Port dari WA bot (ratusan command anime WA → subset SFW yang API-nya hidup).
   Fitur dewasa/NSFW SENGAJA TIDAK DIPORT (permintaan owner).
   Semua endpoint diverifikasi hidup: neko, waifu, hug, pat, kiss, cuddle,
   feed, slap, tickle, smug, goose, avatar, wallpaper, fox_girl, woof, meow. */

"use strict"

const SFW = {
  neko: "Neko 🐱", neko2: "Neko 2 🐱", waifu: "Waifu 🌸", waifu2: "Waifu 2 🌸",
  avatar: "Anime Avatar 👤", avatar2: "Anime Avatar 2 👤", wallpaper: "Anime Wallpaper 🖼️", wallpaper2: "Anime Wallpaper 2 🖼️",
  foxgirl: "Fox Girl 🦊", woof: "Inu 🐶", meow: "Meow 🐈",
  hug: "Hug 🤗", hug2: "Hug 2 🤗", pat: "Pat 🫳", kiss: "Kiss 😘", cuddle: "Cuddle 🤝",
  feed: "Feed 🍜", slap: "Slap 👋", tickle: "Tickle 😆", smug: "Smug 😏", goose: "Goose 🪿", lizard: "Lizard 🦎",
  gecg: "Genetically Engineered Cat Girl 🧬"
}

const NEKOS_EP = {
  neko: "neko", neko2: "neko", waifu: "waifu", waifu2: "waifu",
  avatar: "avatar", avatar2: "avatar", wallpaper: "wallpaper", wallpaper2: "wallpaper",
  foxgirl: "fox_girl", woof: "woof", meow: "meow",
  hug: "hug", hug2: "hug", pat: "pat", kiss: "kiss", cuddle: "cuddle",
  feed: "feed", slap: "slap", tickle: "tickle", smug: "smug", goose: "goose", lizard: "lizard",
  gecg: "gecg"
}

const handler = async (m, { Rafz, command }) => {
  const ep = NEKOS_EP[command]
  if (!ep) return false
  try {
    const tr = (key) => (m.t ? m.t(key) : key)
    const r = await fetch("https://nekos.life/api/v2/img/" + ep, {
      signal: AbortSignal.timeout(15000),
      headers: { "accept": "application/json", "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)" }
    })
    if (!r.ok) throw new Error("HTTP " + r.status)
    const j = await r.json()
    if (!j.url) throw new Error("no url")
    const caption = "🐱 <b>" + (SFW[command] || command).replace(/[0-9]/g, "") + "</b> — " + tr("common.enjoy")
    try {
      if (String(j.url).endsWith(".gif")) await Rafz.sendDocument(m.chat, j.url, { caption, reply_to_message_id: m.id, allow_sending_without_reply: true })
      else await Rafz.sendPhoto(m.chat, j.url, { caption, reply_to_message_id: m.id, allow_sending_without_reply: true })
      return true
    } catch {
      /* fallback: kirim link saja */
      return m.reply("🔗 " + j.url)
    }
  } catch (e) {
    console.error("[nekos3]", command, e?.message)
    try { await m.reply("❌ " + String(e?.message || e).slice(0, 100)) } catch {}
    return false
  }
}

handler.command = Object.keys(NEKOS_EP)
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
