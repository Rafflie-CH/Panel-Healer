/* plugin: smeme.js — stiker meme dengan teks (porting RafzBotz stickmeme)
   Reply foto dengan:
   /smeme teks-atas , teks-bawah
   /smeme , teks-bawah
   /smeme teks-atas */

"use strict"
const sharp = require("sharp")

const escapeXml = (s) =>
  String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;")

const wrapText = (text, maxChars) => {
  const words = String(text).split(/\s+/).filter(Boolean)
  const lines = []
  let line = ""
  for (const w of words) {
    if ((line + " " + w).trim().length > maxChars) {
      if (line) lines.push(line.trim())
      line = w
    } else {
      line = (line + " " + w).trim()
    }
  }
  if (line) lines.push(line.trim())
  return lines
}

const textBlock = (lines, startY, fontSize) =>
  lines.map((ln, i) =>
    `<text x="256" y="${startY + i * (fontSize + 8)}" font-family="sans-serif" font-size="${fontSize}" font-weight="bold" fill="white" stroke="black" stroke-width="${Math.max(2, fontSize / 14)}" paint-order="stroke" text-anchor="middle">${escapeXml(ln)}</text>`
  ).join("")

const handler = async (m, { Rafz, command, text }) => {
  try {
    if (command !== "smeme" && command !== "stickmeme" && command !== "stikermeme") return false

    const px = (global.prefix && global.prefix[0]) || "/"
    const tr = (key, vars) => (m.t ? m.t(key, vars) : key)
    const src = (m.quoted && m.quoted.fileId) ? m.quoted : (m.fileId ? m : null)
    if (!src || !src.fileId)
      return m.reply(`${tr("use.usage")} <code>${px}smeme ${tr("smeme.usage")}</code>`, { parse_mode: "HTML" })
    if (src.mediaType === "sticker" && (src.sticker?.isAnimated || src.sticker?.isVideo))
      return m.reply(tr("sticker.animatedNo"))

    const body = (text || "").trim()
    if (!body) return m.reply(`${tr("use.usage")} <code>${px}smeme ${tr("smeme.usage")}</code>`, { parse_mode: "HTML" })
    const [topRaw, bottomRaw] = body.split(",").map(s => s.trim())

    const wait = await m.reply(tr("smeme.making"), { parse_mode: "HTML" })
    try {
      /* download foto */
      const info = await Rafz.getFile(src.fileId)
      const res = await fetch(`https://api.telegram.org/file/bot${Rafz.token}/${info.file_path}`)
      const imgBuf = Buffer.from(await res.arrayBuffer())

      /* resize ke lebar 512 (stiker) */
      const base = await sharp(imgBuf).resize(512, 512, { fit: "inside" }).png().toBuffer()
      const meta = await sharp(base).metadata()

      const W = meta.width
      const H = meta.height
      const fs_ = 36
      const topLines = topRaw ? wrapText(topRaw, 20).slice(0, 3) : []
      const bottomLines = bottomRaw ? wrapText(bottomRaw, 20).slice(0, 3) : []

      let svg = `<svg width="${W}" height="${H}" xmlns="http://www.w3.org/2000/svg">`
      if (topLines.length) svg += textBlock(topLines, fs_ + 10, fs_)
      if (bottomLines.length) svg += textBlock(bottomLines, H - (bottomLines.length * (fs_ + 8)) - 14, fs_)
      svg += `</svg>`

      const out = await sharp(base).composite([{ input: Buffer.from(svg), top: 0, left: 0 }]).png({ compressionLevel: 9 }).toBuffer()

      try { Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {}) } catch {}
      await Rafz.sendSticker(m.chat, out, {
        reply_to_message_id: m.id, allow_sending_without_reply: true
      })
      return true
    } catch (e) {
      try { Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {}) } catch {}
      return m.reply(tr("smeme.fail") + ": " + (e?.message || e))
    }
  } catch (e) {
    console.error("[smeme]", e?.message)
    try { await m.reply("⚠️ Error: " + (e?.message || e)) } catch {}
    return false
  }
}

handler.command = ["smeme", "stickmeme", "stikermeme"]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
