/* primbon2.js — 24 command primbon tambahan (scrape-primbon, backend primbon.com).
   Port dari WA bot (Furina). Method existing di primbon.js TIDAK diduplikasi —
   hanya method baru. Gagal API → pesan error jelas (dilaporkan errorlog). */

"use strict"
const { Primbon } = require("scrape-primbon")
const primbon = new Primbon()

const esc = (s) => String(s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")

const MET = {
  ramalannasib: { m: "ramalan_nasib", s: 2, t: "Ramalan Nasib" },
  sifatusaha: { m: "sifat_usaha_bisnis", s: 2, t: "Sifat Usaha & Bisnis" },
  rejekihoki: { m: "rejeki_hoki_weton", s: 2, t: "Rejeki Hoki Weton" },
  pekerjaanweton: { m: "pekerjaan_weton_lahir", s: 2, t: "Pekerjaan Weton Lahir" },
  potensipenyakit: { m: "cek_potensi_penyakit", s: 2, t: "Potensi Penyakit" },
  kartutarot: { m: "arti_kartu_tarot", s: 2, t: "Arti Kartu Tarot" },
  tanggaljadian: { m: "tanggal_jadian_pernikahan", s: 2, t: "Tanggal Jadian & Pernikahan" },
  ramalannasibbali: { m: "ramalan_jodoh_bali", s: 2, t: "Ramalan Jodoh (Bali)" },
  fengshui: { m: "perhitungan_feng_shui", s: 4, t: "Perhitungan Feng Shui" },
  sifatkarakter: { m: "sifat_karakter_tanggal_lahir", s: 3, t: "Sifat Karakter Tanggal Lahir" },
  potensikeberuntungan: { m: "potensi_keberuntungan", s: 3, t: "Potensi Keberuntungan" },
  haribaik: { m: "petung_hari_baik", s: 2, t: "Petung Hari Baik" },
  harisangar: { m: "hari_sangar_taliwangke", s: 2, t: "Hari Sangar Taliwangke" },
  harinaas: { m: "primbon_hari_naas", s: 2, t: "Primbon Hari Naas" },
  nagahari: { m: "rahasia_naga_hari", s: 2, t: "Rahasia Naga Hari" },
  arahrejeki: { m: "primbon_arah_rejeki", s: 2, t: "Primbon Arah Rejeki" },
  ramalanperuntungan: { m: "ramalan_peruntungan", s: 2, t: "Ramalan Peruntungan" },
  masasubur: { m: "masa_subur", s: 8, t: "Masa Subur" },
  zodiakcek: { m: "zodiak", s: 5, t: "Cek Zodiak" },
  shiocek: { m: "shio", s: 6, t: "Cek Shio" },
  nomorhoki: { m: "nomer_hoki", s: 7, t: "Nomor Hoki (Bagua Shuzi)" },
  wetonjawa: { m: "weton_jawa", s: 2, t: "Weton Jawa" },
  memancingikan: { m: "primbon_memancing_ikan", s: 2, t: "Hari Baik Memancing" },
  cocoknama: { m: "kecocokan_nama", s: 3, t: "Kecocokan Nama" },
}

const fmt = (r) => {
  try {
    if (!r || r.status === false) throw new Error(r?.message || "no data")
    const o = r.message || r.result || r
    if (typeof o === "string") return "<pre>" + esc(o.slice(0, 3000)) + "</pre>"
    let out = ""
    const walk = (obj, pre) => {
      for (const [k, v] of Object.entries(obj || {})) {
        if (v && typeof v === "object") walk(v, pre)
        else if (v !== "" && v !== null && v !== undefined && typeof v !== "function")
          out += "<b>" + esc(k.replace(/_/g, " ")) + ":</b> " + esc(String(v).slice(0, 300)) + "\n"
      }
    }
    walk(o, "")
    return out.slice(0, 3800) || "<pre>" + esc(JSON.stringify(o).slice(0, 2500)) + "</pre>"
  } catch (e) { throw e }
}

const MONTHS = ["januari","februari","maret","april","mei","juni","juli","agustus","september","oktober","november","desember"]

const parseDate = (text) => {
  /* terima "14 2 2000", "14-2-2000", "14/2/2000", "14,2,2000", "14|2|2000" */
  const p = String(text || "").split(/[\s\/,\-|]+/).filter(Boolean)
  if (p.length < 3) return null
  return { tgl: p[0], bln: p[1], thn: p[2] }
}

const usageOf = (px, cmd, s) => {
  const M = {
    2: "<code>" + px + cmd + " 14 2 2000</code>",
    3: "<code>" + px + cmd + " Budi 14 2 2000</code>",
    4: "<code>" + px + cmd + " Budi l 2000</code> (l=pria, p=wanita)",
    5: "<code>" + px + cmd + " aquarius</code>",
    6: "<code>" + px + cmd + " naga</code>",
    7: "<code>" + px + cmd + " 62812xxxxxxx</code>",
    8: "<code>" + px + cmd + " 14 2 2000 28</code>"
  }
  return M[s] || M[2]
}

const handler = async (m, { Rafz, command, text }) => {
  const meta = MET[command]
  if (!meta) return false
  const px = (global.prefix && global.prefix[0]) || "/"
  const tr = (key, vars) => (m.t ? m.t(key, vars) : key)

  if (!String(text || "").trim())
    return m.reply("⚠️ " + tr("prim2.usage") + "\n" + usageOf(px, command, meta.s), { parse_mode: "HTML" })

  let res
  try {
    switch (meta.s) {
      case 2: {
        const d = parseDate(text); if (!d) throw new Error("bad date")
        res = await primbon[meta.m](d.tgl, d.bln, d.thn); break
      }
      case 3: {
        const p = String(text).trim().split(/\s+/)
        if (p.length < 4) throw new Error("bad input")
        const d = { tgl: p[p.length - 3], bln: p[p.length - 2], thn: p[p.length - 1] }
        res = await primbon[meta.m](p.slice(0, -3).join(" "), d.tgl, d.bln, d.thn); break
      }
      case 4: {
        const p = String(text).trim().split(/\s+/)
        if (p.length < 3) throw new Error("bad input")
        res = await primbon[meta.m](p[0], p[1], p[2]); break
      }
      case 5: res = await primbon[meta.m](String(text).trim().toLowerCase()); break
      case 6: res = await primbon[meta.m](String(text).trim().toLowerCase()); break
      case 7: res = await primbon[meta.m](String(text).trim()); break
      case 8: {
        const p = String(text).trim().split(/\s+/)
        if (p.length < 4) throw new Error("bad input")
        res = await primbon[meta.m](p[0], p[1], p[2], p[3]); break
      }
      default: throw new Error("bad spec")
    }
    const out = "<b>🔮 " + esc(meta.t.toUpperCase()) + "</b>\n\n" + fmt(res)
    return m.reply(out, { parse_mode: "HTML" })
  } catch (e) {
    const msg = String(e?.message || e)
    if (/bad (date|input)/.test(msg))
      return m.reply("⚠️ " + tr("prim2.usage") + "\n" + usageOf(px, command, meta.s), { parse_mode: "HTML" })
    return m.reply(tr("common.failed") + " (" + esc(msg.slice(0, 100)) + ")", { parse_mode: "HTML" })
  }
}

handler.command = ["ramalannasib","sifatusaha","rejekihoki","pekerjaanweton","potensipenyakit","kartutarot","tanggaljadian","ramalannasibbali","fengshui","sifatkarakter","potensikeberuntungan","haribaik","harisangar","harinaas","nagahari","arahrejeki","ramalanperuntungan","masasubur","zodiakcek","shiocek","nomorhoki","wetonjawa","memancingikan","cocoknama"]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
