"use strict"
const https = require("https")
const http = require("http")

const UA = "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/130 Mobile Safari/537.36"

const getBuffer = (url, hdrs = {}) =>
  new Promise((resolve, reject) => {
    try {
      const follow = (u, depth = 0) => {
        if (depth > 5) return reject(new Error("Too many redirects"))
        const parsed = new URL(u)
        const mod = parsed.protocol === "https:" ? https : http
        mod.get({ hostname: parsed.hostname, path: parsed.pathname + parsed.search, timeout: 60000, headers: { "User-Agent": UA, "Accept-Language": "en-US,en;q=0.9", ...hdrs } }, (res) => {
          if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) return follow(new URL(res.headers.location, u).href, depth + 1)
          if (res.statusCode !== 200) return reject(new Error("HTTP " + res.statusCode))
          const c = []
          res.on("data", d => c.push(d))
          res.on("end", () => resolve(Buffer.concat(c)))
        }).on("error", reject).on("timeout", function () { this.destroy(); reject(new Error("Timeout")) })
      }
      follow(url)
    } catch (e) { reject(e) }
  })

const getJSON = (url) =>
  new Promise((resolve, reject) => {
    try {
      const parsed = new URL(url)
      const mod = parsed.protocol === "https:" ? https : http
      mod.get({ hostname: parsed.hostname, path: parsed.pathname + parsed.search, timeout: 30000, headers: { "User-Agent": UA, "Accept": "application/json" } }, (res) => {
        let d = ""
        res.on("data", c => d += c)
        res.on("end", () => { try { resolve(JSON.parse(d)) } catch { resolve(null) } })
      }).on("error", reject).on("timeout", function () { this.destroy(); reject(new Error("Timeout")) })
    } catch (e) { reject(e) }
  })

/* BING WEB SEARCH via RSS — paling stabil dari IP datacenter
   (DDG memblokir dengan anomaly challenge, API lama sudah mati) */
const cleanText = (s) => String(s || "").replace(/<[^>]+>/g, "").replace(/&amp;/g, "&").replace(/&#x27;/g, "'").replace(/&quot;/g, '"').replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&nbsp;/g, " ").replace(/\s+/g, " ").trim()

const webSearch = async (query) => {
  /* Bing RSS kadang rate-limit → retry 2x dengan jeda */
  let items = []
  for (let attempt = 0; attempt < 2 && !items.length; attempt++) {
    if (attempt) await new Promise(r => setTimeout(r, 1500))
    try {
      const buf = await getBuffer("https://www.bing.com/search?q=" + encodeURIComponent(query) + "&format=rss&count=20")
      const xml = buf.toString("utf8")
      items = xml.match(/<item>[\s\S]*?<\/item>/g) || []
    } catch (e) {
      if (attempt) throw e
    }
  }
  const results = []
  for (const it of items.slice(0, 8)) {
    const title = cleanText((it.match(/<title>([\s\S]*?)<\/title>/) || [])[1])
    const url = ((it.match(/<link>([\s\S]*?)<\/link>/) || [])[1] || "").trim()
    const snippet = cleanText((it.match(/<description>([\s\S]*?)<\/description>/) || [])[1])
    if (title && url.startsWith("http")) results.push({ title, url, snippet: snippet.slice(0, 160) })
  }
  return results
}

const handler = async (m, { Rafz, command, text }) => {
  try {
    const px = (global.prefix && global.prefix[0]) || "/"
    const q = (text || "").trim()
    const usage = (u) => "Penggunaan: " + px + u

    // ===== GOOGLE SEARCH (DDG fallback — API lama mati) =====
    if (command === "google" || command === "gsearch") {
      if (!q) return m.reply(usage("google pertanyaan"))
      const tr = (key, vars) => (m.t ? m.t(key, vars) : key)
      try {
        const results = await webSearch(q)
        if (results.length) {
          let out = "<b>🔎 " + tr("s2.googleSearch") + "</b>\n" + tr("s2.query") + ": " + q + "\n\n"
          for (const r of results.slice(0, 5)) {
            out += "• <a href=\"" + r.url + "\">" + r.title + "</a>\n"
            if (r.snippet) out += "  " + r.snippet + "\n"
            out += "  " + r.url + "\n\n"
          }
          return m.reply(out.slice(0, 3500), { parse_mode: "HTML", disable_web_page_preview: true })
        }
        throw new Error("no data")
      } catch {
        return m.reply(tr("s2.searchFail"))
      }
    }

    // ===== PINTEREST =====
    if (command === "pinterest" || command === "pin") {
      if (!q) return m.reply(usage("pinterest kata kunci"))
      const tr = (key, vars) => (m.t ? m.t(key, vars) : key)
      const wait = await m.reply(tr("s2.searching"))
      try {
        const j = await getJSON("https://api.siputzx.my.id/api/s/pinterest?query=" + encodeURIComponent(q))
        /* API balas URL pin → ambil gambar langsung dari pin page via data API gambar */
        if (j && j.status && j.data && j.data.length) {
          const item = j.data[0]
          const imgUrl = typeof item === "string" ? item : (item.image || item.img || item.url)
          let buf = null
          try { if (/^https?:\/\/.*(\.(jpg|jpeg|png|webp)|i\.pinimg)/i.test(imgUrl)) buf = await getBuffer(imgUrl) } catch {}
          try { Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {}) } catch {}
          if (buf) {
            await Rafz.sendPhoto(m.chat, buf, { caption: "PINTEREST: " + q, reply_to_message_id: m.id, allow_sending_without_reply: true })
            return true
          }
          /* fallback: kirim daftar link pin */
          let out = "<b>📌 PINTEREST</b>\n" + q + "\n\n"
          for (const it of j.data.slice(0, 5)) {
            const link = typeof it === "string" ? it : (it.pin || it.link || it.url)
            if (link) out += "• " + link + "\n"
          }
          return m.reply(out, { parse_mode: "HTML", disable_web_page_preview: true })
        }
        throw new Error("not found")
      } catch (e) {
        try { await Rafz.deleteMessage(m.chat, wait.message_id) } catch {}
        return m.reply(tr("s2.imageNotFound") + ": " + e.message)
      }
    }

    // ===== WALLPAPER SEARCH =====
    if (command === "wallpaper2" || command === "wpsearch") {
      if (!q) return m.reply(usage("wallpaper2 kata kunci"))
      const tr = (key, vars) => (m.t ? m.t(key, vars) : key)
      const wait = await m.reply(tr("s2.searching"))
      try {
        const buf = await getBuffer("https://pic.re/image")
        try { Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {}) } catch {}
        await Rafz.sendPhoto(m.chat, buf, { caption: "WALLPAPER: " + q, reply_to_message_id: m.id, allow_sending_without_reply: true })
        return true
      } catch (e) {
        try { await Rafz.deleteMessage(m.chat, wait.message_id) } catch {}
        return m.reply(tr("use.failed") + ": " + e.message)
      }
    }

    // ===== LIRIK LAGU (lrclib.net — gratis tanpa key) =====
    if (command === "lirik" || command === "lyrics") {
      if (!q) return m.reply(usage("lirik judul lagu"))
      const tr = (key, vars) => (m.t ? m.t(key, vars) : key)
      try {
        const j = await getJSON("https://lrclib.net/api/search?q=" + encodeURIComponent(q))
        if (Array.isArray(j) && j.length) {
          const best = j.find(s => s.plainLyrics) || j[0]
          const lyric = best.plainLyrics || best.syncedLyrics || "-"
          return m.reply("<b>🎵 " + tr("s2.lyricsTitle") + "</b>\n" + (best.artistName || "") + " — " + (best.trackName || q) + "\n\n" + String(lyric).slice(0, 2800), { parse_mode: "HTML" })
        }
        throw new Error("not found")
      } catch {
        return m.reply(tr("s2.lyricsNotFound"))
      }
    }

    // ===== CHORD =====
    if (command === "chord") {
      if (!q) return m.reply(usage("chord judul lagu"))
      try {
        const j = await getJSON("https://api.siputzx.my.id/api/s/chord?q=" + encodeURIComponent(q))
        if (j && j.status && j.data) {
          return m.reply("CHORD\n\n" + String(j.data).slice(0, 3000))
        }
        throw new Error("not found")
      } catch {
        return m.reply("Chord tidak ditemukan")
      }
    }

    // ===== KAMUS BESAR (scrape kbbi.web.id — API lama mati) =====
    if (command === "kbbi") {
      if (!q) return m.reply(usage("kbbi kata"))
      const tr = (key, vars) => (m.t ? m.t(key, vars) : key)
      try {
        const buf = await getBuffer("https://kbbi.web.id/" + encodeURIComponent(q.replace(/[^a-zA-Z0-9\-]/g, "")))
        const html = buf.toString("utf8")
        if (/Arti kata/i.test(html)) {
          /* ambil entri definisi (li + para setelah heading) */
          const defs = []
          const re = /<li[^>]*>([\s\S]*?)<\/li>|<p[^>]*class="def"[^>]*>([\s\S]*?)<\/p>/g
          let m
          while ((m = re.exec(html)) !== null && defs.length < 12) {
            const t = (m[1] || m[2] || "").replace(/<[^>]+>/g, "").replace(/&amp;/g, "&").replace(/&nbsp;/g, " ").trim()
            if (t && t.length > 2 && !defs.includes(t)) defs.push(t)
          }
          const word = (html.match(/<title>Arti kata ([^<\s]+)/) || [])[1] || q
          let out = "<b>📚 KBBI — " + word + "</b>\n\n"
          out += defs.length ? defs.slice(0, 8).map(d => "• " + d.slice(0, 200)).join("\n") : "-"
          return m.reply(out.slice(0, 3000), { parse_mode: "HTML" })
        }
        throw new Error("not found")
      } catch {
        return m.reply(tr("s2.kbbiNotFound"))
      }
    }

    // ===== YOUTUBE SEARCH — DIHAPUS: duplikat /yts (tools.js innertube + yt-search fallback).
    // Versi lama pakai API siputzx yang sudah mati (404) dan menimpa /yts yang sehat
    // karena file ini dimuat duluan (urutan abjad) — ini penyebab error yts.

    // ===== GSMArena — API lama mati; fallback: cari via DDG (spesifikasi + link) =====
    if (command === "gsmarena" || command === "hp") {
      if (!q) return m.reply(usage("gsmarena nama hp"))
      const tr = (key, vars) => (m.t ? m.t(key, vars) : key)
      try {
        const results = (await webSearch(q + " gsmarena specs")).filter(r => /gsmarena\.com/i.test(r.url))
        const list = results.length ? results : await webSearch(q + " spesifikasi hp")
        if (list.length) {
          let out = "<b>📱 " + tr("s2.gsmTitle") + "</b>\n" + q + "\n\n"
          for (const r of list.slice(0, 5)) {
            out += "• <a href=\"" + r.url + "\">" + r.title + "</a>\n"
            if (r.snippet) out += "  " + r.snippet + "\n\n"
          }
          return m.reply(out.slice(0, 3500), { parse_mode: "HTML", disable_web_page_preview: true })
        }
        throw new Error("no data")
      } catch {
        return m.reply(tr("s2.phoneNotFound"))
      }
    }

    return false
  } catch (e) {
    console.error("[search2]", e?.message)
    try { await m.reply("Error: " + (e?.message || e)) } catch {}
    return false
  }
}

handler.command = ["google", "gsearch", "pinterest", "pin", "wallpaper2", "wpsearch", "lirik", "lyrics", "chord", "kbbi", "gsmarena", "hp"]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
