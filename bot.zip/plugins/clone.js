/* plugin: clone.js - clone bot dengan database terpisah */
"use strict"
const path = require("path")
const fs = require("fs")

const CLONE_DB_PATH = "./library/database/clones.json"

const loadClones = () => {
  try { const j = JSON.parse(fs.readFileSync(CLONE_DB_PATH, "utf8")); return Array.isArray(j) ? j : [] }
  catch { return [] }
}
const saveClones = (data) => {
  try { fs.mkdirSync(path.dirname(CLONE_DB_PATH), { recursive: true }); fs.writeFileSync(CLONE_DB_PATH, JSON.stringify(data, null, 2)) } catch {}
}

const cloneSessions = new Map()

const handler = async (m, { Rafz, command, text }) => {
  try {
    const sender = String(m.sender)
    const isCreator = (global.owner || []).includes(sender)
    if (!isCreator) return m.reply(m.t ? m.t("denied.owner") : "Hanya Creator yang bisa clone bot.")
    const px = (global.prefix && global.prefix[0]) || "/"
    const tr = (key, vars) => (m.t ? m.t(key, vars) : key)

    if (command === "clone") {
      if (cloneSessions.has(sender)) return m.reply("Sesi clone sudah ada. " + px + "clonecancel untuk batal.")
      cloneSessions.set(sender, { step: "token" })
      return m.reply(
        "<b>CLONE BOT</b>\n\nFitur ini membuat bot clone dengan database terpisah.\nFitur yang dihapus dari clone: eval, backup, owner management.\n\nLangkah 1: Kirim token bot baru (dari @BotFather):",
        { parse_mode: "HTML" }
      )
    }

    if (command === "clonecancel") {
      cloneSessions.delete(sender)
      return m.reply("Sesi clone dibatalkan.")
    }

    if (command === "clonelist") {
      const clones = loadClones()
      if (!clones.length) return m.reply("Belum ada clone.")
      let out = "<b>DAFTAR CLONE</b>\n\n"
      for (const c of clones) {
        let alive = false
        try { alive = c.pid && process.kill(c.pid, 0) } catch { alive = false }
        out += "Bot: " + c.botname + " | Owner: " + c.ownerId + " | PID: " + (c.pid || "-") + " | " + (alive ? "🟢 jalan" : "🔴 mati") + "\n"
      }
      return m.reply(out, { parse_mode: "HTML" })
    }

    if (command === "stopclone" || command === "cloneoff") {
      const clones = loadClones()
      if (!clones.length) return m.reply("Belum ada clone yang berjalan.")
      if (!text) {
        let out = "<b>STOP CLONE</b>\n\n" + px + "stopclone <index>\n\n"
        for (let i = 0; i < clones.length; i++) {
          const c = clones[i]
          let alive = false
          try { alive = c.pid && process.kill(c.pid, 0) } catch { alive = false }
          out += i + ". " + c.botname + " (" + (alive ? "🟢 jalan" : "🔴 mati") + ")\n"
        }
        return m.reply(out, { parse_mode: "HTML" })
      }
      const idx = parseInt(text.trim())
      if (isNaN(idx) || idx < 0 || idx >= clones.length) return m.reply("Index tidak valid. " + px + "stopclone (tanpa argumen) buat lihat daftar.")
      const c = clones[idx]
      let stopped = false
      try { process.kill(c.pid, "SIGTERM"); stopped = true } catch {}
      c.pid = null
      saveClones(clones)
      return m.reply(
        stopped
          ? tr("clone.stopped", { name: c.botname })
          : tr("clone.alreadyDead", { name: c.botname }),
        { parse_mode: "HTML" }
      )
    }

    if (command === "clonedel") {
      if (!text) return m.reply("Penggunaan: " + px + "clonedel <index>")
      const clones = loadClones()
      const idx = parseInt(text)
      if (isNaN(idx) || idx < 0 || idx >= clones.length) return m.reply("Index tidak valid.")
      const c = clones[idx]
      if (c.pid) { try { process.kill(c.pid, "SIGTERM") } catch {} }
      clones.splice(idx, 1)
      saveClones(clones)
      return m.reply("Clone dihapus.")
    }

    // Handle session input (non-command messages during clone setup)
    if (cloneSessions.has(sender)) {
      const session = cloneSessions.get(sender)
      const t = (text || "").trim()

      if (session.step === "token") {
        if (!t || !/^\d+:[A-Za-z0-9_-]{20,}$/.test(t)) return m.reply("Token tidak valid. Format: 123456789:ABCdef...")
        session.token = t
        session.step = "owner"
        cloneSessions.set(sender, session)
        return m.reply("Token diterima!\n\nLangkah 2: Kirim ID owner utama clone ini:")
      }

      if (session.step === "owner") {
        if (!/^\d+$/.test(t)) return m.reply("ID owner harus angka.")
        session.ownerId = t
        session.step = "botname"
        cloneSessions.set(sender, session)
        return m.reply("Owner ID diterima!\n\nLangkah 3: Kirim nama bot clone:")
      }

      if (session.step === "botname") {
        session.botname = t || "Clone Bot"
        session.step = "confirm"
        cloneSessions.set(sender, session)
        return m.reply(
          "<b>KONFIRMASI CLONE</b>\n\n" +
          "Token: <code>" + session.token.slice(0, 20) + "...</code>\n" +
          "Owner: <code>" + session.ownerId + "</code>\n" +
          "Bot Name: <b>" + session.botname + "</b>\n\n" +
          "Ketik <code>" + px + "cloneconfirm</code> untuk mulai, atau " + px + "clonecancel untuk batal.",
          { parse_mode: "HTML" }
        )
      }
    }

    if (command === "cloneconfirm") {
      const session = cloneSessions.get(sender)
      if (!session || session.step !== "confirm") return m.reply("Tidak ada sesi clone. Ketik " + px + "clone")
      cloneSessions.delete(sender)

      const cloneId = Date.now().toString(36)
      const cloneDir = "./clones/" + cloneId

      try {
        fs.mkdirSync(cloneDir + "/library/database", { recursive: true })
        fs.mkdirSync(cloneDir + "/plugins", { recursive: true })
        fs.mkdirSync(cloneDir + "/session", { recursive: true })

        const filesToCopy = ["index.js", "case.js", "autodb.js", "package.json"]
        for (const f of filesToCopy) { try { fs.copyFileSync(f, cloneDir + "/" + f) } catch {} }

        /* node_modules clone = symlink ke node_modules utama (hemat disk & load cepat) */
        try {
          if (fs.existsSync("./node_modules") && !fs.existsSync(cloneDir + "/node_modules")) {
            fs.symlinkSync(path.resolve("./node_modules"), cloneDir + "/node_modules", "junction")
          }
        } catch (e) { console.log("clone symlink node_modules:", e.message) }

        if (fs.existsSync("./plugins")) {
          for (const f of fs.readdirSync("./plugins")) {
            if (f.endsWith(".js")) { try { fs.copyFileSync("./plugins/" + f, cloneDir + "/plugins/" + f) } catch {} }
          }
        }
        if (fs.existsSync("./library")) {
          for (const f of fs.readdirSync("./library")) {
            if (f.endsWith(".js")) { try { fs.copyFileSync("./library/" + f, cloneDir + "/library/" + f) } catch {} }
          }
        }

        const cloneSettings = [
          'const fs = require("fs")',
          'const chalk = require("chalk")',
          'global.owner = ["' + session.ownerId + '"]',
          'global.namaOwner = "Clone Owner"',
          'global.botname = "' + session.botname + '"',
          'global.botname2 = "' + session.botname + '"',
          'global.packname = "CLONE"',
          'global.author = "CloneBot"',
          'global.prefix = ["/"]',
          'global.noPrefix = false',
          'global.linkOwner = "https://t.me/"',
          'global.SOUND_URLS = []',
          'global.WELCOME_PHOTO = ""',
          'global.notifGroupId = null',
          'global.backup = { enabled: false, intervalMs: 21600000, sendToOwner: false }',
          'global.cf = { domains: {} }',
          'global.panelServer = ' + JSON.stringify(global.panelServer || {}),
          'global.privateServerId = "1"',
          'global.monitor = { enabled: false }',
          'global.image = { menu: "", reply: "", logo: "" }',
          'global.defaultLang = "id"',
          /* ── PENANDA CLONE: eval, exec ($), dan backup otomatis dimatikan ── */
          'global.isClone = true',
        ].join("\n")
        fs.writeFileSync(cloneDir + "/settings.js", cloneSettings)

        // Save session for clone
        fs.writeFileSync(cloneDir + "/session/creds.json", JSON.stringify({ token: session.token }))

        // Start clone bot process
        const { spawn } = require("child_process")
        const child = spawn("node", ["index.js"], { cwd: cloneDir, detached: true, stdio: "ignore" })
        child.unref()

        const clones = loadClones()
        clones.push({ id: cloneId, token: session.token, ownerId: session.ownerId, botname: session.botname, pid: child.pid, dir: cloneDir, createdAt: Date.now() })
        saveClones(clones)

        return m.reply(
          "<b>CLONE BERHASIL DIBUAT!</b>\n\n" +
          "Bot Name: <b>" + session.botname + "</b>\n" +
          "Owner: <code>" + session.ownerId + "</code>\n" +
          "PID: <code>" + child.pid + "</code>\n" +
          "Dir: <code>" + cloneDir + "</code>\n\n" +
          "Clone bot sudah berjalan dengan database terpisah.\n" +
          "Eval & backup dinonaktifkan di clone.",
          { parse_mode: "HTML" }
        )
      } catch (e) {
        return m.reply("Gagal membuat clone: " + e.message)
      }
    }

    return false
  } catch (e) {
    console.error("[clone]", e?.message)
    try { await m.reply("Error: " + (e?.message || e)) } catch {}
    return false
  }
}

handler.command = ["clone", "clonecancel", "cloneconfirm", "clonelist", "clonedel", "stopclone", "cloneoff"]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
