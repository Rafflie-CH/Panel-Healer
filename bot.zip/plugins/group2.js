/* plugin: group2.js — porting fitur grup dari bot WA (Prabowo)
   Command grup:
     /pengumuman /hidetag2  — pengumuman + mention semua member
     /absen                 — mulai sesi absen (member ketik /absen lagi utk ikut)
     /absenlist             — lihat daftar hadir
     /absenreset            — tutup & bersihkan sesi absen
     /votemulai             — mulai vote: /votemulai pertanyaan|opsi1|opsi2
     /votehasil             — lihat hasil vote berjalan
     /voteselesai           — tutup vote
   Admin-only untuk mulai; member biasa bisa /absen & vote.
*/
"use strict"
const fs = require("fs")

const DB = "./library/database/group2.json"
const load = () => { try { const j = JSON.parse(fs.readFileSync(DB, "utf8")); return j && typeof j === "object" ? j : {} } catch { return {} } }
const save = (d) => { try { fs.mkdirSync("library/database", { recursive: true }); fs.writeFileSync(DB, JSON.stringify(d, null, 2)) } catch {} }

const isAdminCache = new Map() /* chatId -> { admins:Set, ts } */
const isAdminMsg = async (m, Rafz) => {
  if (!m.isGroup) return false
  if ((global.owner || []).includes(String(m.sender))) return true
  try {
    let c = isAdminCache.get(String(m.chat))
    if (!c || Date.now() - c.ts > 120000) {
      const admins = await Rafz.getChatAdministrators(m.chat).catch(() => [])
      c = { admins: new Set(admins.map(a => String(a.user?.id))), ts: Date.now() }
      isAdminCache.set(String(m.chat), c)
    }
    return c.admins.has(String(m.sender))
  } catch { return false }
}

const handler = async (m, { Rafz, command, text }) => {
  try {
    const tr = (key, vars) => (m.t ? m.t(key, vars) : key)
    if (!m.isGroup) return m.reply(tr("grp2.groupOnly"))

    const db = load()
    const chatId = String(m.chat)
    const px = (global.prefix && global.prefix[0]) || "/"

    /* ─────────── /pengumuman & /hidetag2 ─────────── */
    if (command === "pengumuman" || command === "hidetag2" || command === "announce") {
      if (!(await isAdminMsg(m, Rafz))) return m.reply(tr("denied.admin"))
      if (!text) return m.reply(tr("use.usage") + ": <code>" + px + "pengumuman teks</code>", { parse_mode: "HTML" })
      /* notif mention: kirim dengan @admin via /tagall2, atau plain announce */
      const body = "📢 <b>" + tr("grp2.announce") + "</b>\n\n" + text
      try {
        await Rafz.sendMessage(m.chat, body, { parse_mode: "HTML", disable_web_page_preview: true })
      } catch { await m.reply(body, { parse_mode: "HTML" }) }
      return true
    }

    /* ─────────── /tagall2 — mention via reply (notif semua admin) ─────────── */
    if (command === "tagall2") {
      const admins = await Rafz.getChatAdministrators(m.chat).catch(() => [])
      const mentions = admins.map(a => "@" + (a.user.username || a.user.id)).join(" ")
      return m.reply("📣 " + (text || tr("grp2.announce")) + "\n\n" + mentions, { parse_mode: "HTML" })
    }

    /* ─────────── /absen ─────────── */
    if (command === "absen") {
      db[chatId] = db[chatId] || {}
      if (!db[chatId].absen) {
        if (!(await isAdminMsg(m, Rafz))) return m.reply(tr("denied.admin"))
        db[chatId].absen = { opened: Date.now(), list: [], title: text || "" }
        save(db)
        return m.reply("📋 <b>" + tr("grp2.absenOpen") + "</b>\n\n" + tr("grp2.absenHint", { px }), { parse_mode: "HTML" })
      }
      /* sudah buka → user absen */
      const uid = String(m.sender)
      const name = m.pushName || uid
      if (db[chatId].absen.list.some(u => u.id === uid)) return m.reply(tr("grp2.absenDup"))
      db[chatId].absen.list.push({ id: uid, name, ts: Date.now() })
      save(db)
      return m.reply("✅ " + tr("grp2.absenOk", { n: db[chatId].absen.list.length, name: name }))
    }

    /* ─────────── /absenlist ─────────── */
    if (command === "absenlist" || command === "rekapabsen") {
      const a = db[chatId]?.absen
      if (!a) return m.reply(tr("grp2.absenNone"))
      let out = "📋 <b>" + tr("grp2.absenList", { n: a.list.length }) + "</b>\n"
      if (a.title) out += "📌 " + a.title + "\n"
      out += "\n"
      a.list.forEach((u, i) => { out += (i + 1) + ". " + u.name + "\n" })
      return m.reply(out, { parse_mode: "HTML" })
    }

    /* ─────────── /absenreset ─────────── */
    if (command === "absenreset" || command === "absenend") {
      if (!(await isAdminMsg(m, Rafz))) return m.reply(tr("denied.admin"))
      const a = db[chatId]?.absen
      const n = a ? a.list.length : 0
      if (db[chatId]) { delete db[chatId].absen; save(db) }
      return m.reply("🧹 " + tr("grp2.absenClosed", { n }))
    }

    /* ─────────── VOTE ─────────── */
    if (command === "votemulai" || command === "startvote") {
      if (!(await isAdminMsg(m, Rafz))) return m.reply(tr("denied.admin"))
      const sp = (text || "").split("|").map(s => s.trim())
      if (sp.length < 3) return m.reply(tr("use.usage") + ": <code>" + px + "votemulai " + tr("grp2.voteUsage") + "</code>", { parse_mode: "HTML" })
      db[chatId] = db[chatId] || {}
      if (db[chatId].vote) return m.reply(tr("grp2.voteActive"))
      db[chatId].vote = {
        q: sp[0],
        options: sp.slice(1),
        votes: {}, /* uid -> option index */
        opened: Date.now()
      }
      save(db)
      let out = "🗳️ <b>" + tr("grp2.voteOpen") + "</b>\n\n❓ " + sp[0] + "\n\n"
      sp.slice(1).forEach((o, i) => { out += "/" + (i + 1) + " — " + o + "\n" })
      out += "\n" + tr("grp2.voteHint")
      return m.reply(out, { parse_mode: "HTML" })
    }

    /* vote casting: /1 /2 /3 ... ditangani di sini */
    if (/^[1-9]$/.test(command) && db[chatId]?.vote) {
      const v = db[chatId].vote
      const idx = parseInt(command, 10) - 1
      if (idx >= v.options.length) return false
      v.votes[String(m.sender)] = idx
      save(db)
      return m.reply("🗳️ " + tr("grp2.voteCast", { opt: v.options[idx] }))
    }

    /* ─────────── /votehasil ─────────── */
    if (command === "votehasil" || command === "voteresult") {
      const v = db[chatId]?.vote
      if (!v) return m.reply(tr("grp2.voteNone"))
      const counts = v.options.map(() => 0)
      Object.values(v.votes).forEach(i => { if (counts[i] != null) counts[i]++ })
      let out = "🗳️ <b>" + tr("grp2.voteResult") + "</b>\n\n❓ " + v.q + "\n\n"
      v.options.forEach((o, i) => {
        const pct = Object.keys(v.votes).length ? Math.round((counts[i] / Object.keys(v.votes).length) * 100) : 0
        out += (i + 1) + ". " + o + " — <b>" + counts[i] + "</b> (" + pct + "%)\n"
      })
      return m.reply(out, { parse_mode: "HTML" })
    }

    /* ─────────── /voteselesai ─────────── */
    if (command === "voteselesai" || command === "endvote") {
      if (!(await isAdminMsg(m, Rafz))) return m.reply(tr("denied.admin"))
      const v = db[chatId]?.vote
      if (!v) return m.reply(tr("grp2.voteNone"))
      const counts = v.options.map(() => 0)
      Object.values(v.votes).forEach(i => { if (counts[i] != null) counts[i]++ })
      const maxIdx = counts.indexOf(Math.max(...counts))
      let out = "🏁 <b>" + tr("grp2.voteDone") + "</b>\n\n❓ " + v.q + "\n\n"
      v.options.forEach((o, i) => { out += (i + 1) + ". " + o + " — <b>" + counts[i] + "</b>\n" })
      out += "\n🏆 " + tr("grp2.voteWinner", { opt: v.options[maxIdx] })
      if (db[chatId]) { delete db[chatId].vote; save(db) }
      return m.reply(out, { parse_mode: "HTML" })
    }

    return false
  } catch (e) {
    console.error("[group2]", command, e?.message)
    try { await m.reply("❌ " + e.message) } catch {}
    return false
  }
}

handler.command = [
  "pengumuman", "hidetag2", "announce", "tagall2",
  "absen", "absenlist", "rekapabsen", "absenreset", "absenend",
  "votemulai", "startvote", "votehasil", "voteresult", "voteselesai", "endvote"
]
/* vote casting via /1../9 ditangani lewat alias dinamis di handler command ["1".."9"]
   — tapi biar tidak bentrok command lain, casting hanya jalan saat vote aktif; kalau
   tidak, plugin return false supaya command lain tetap jalan. */
for (let i = 1; i <= 9; i++) handler.command.push(String(i))
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
