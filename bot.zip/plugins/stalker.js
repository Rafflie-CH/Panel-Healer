"use strict"
const https = require("https")
const http = require("http")

const UA = "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/130 Mobile Safari/537.36"

const getJSON = (url, hdrs = {}) =>
  new Promise((resolve, reject) => {
    try {
      const parsed = new URL(url)
      const mod = parsed.protocol === "https:" ? https : http
      mod.get({ hostname: parsed.hostname, path: parsed.pathname + parsed.search, timeout: 20000, headers: { "User-Agent": UA, "Accept": "application/json", ...hdrs } }, (res) => {
        let d = ""
        res.on("data", c => d += c)
        res.on("end", () => { try { resolve(JSON.parse(d)) } catch { resolve(null) } })
      }).on("error", reject).on("timeout", function () { this.destroy(); reject(new Error("Timeout")) })
    } catch (e) { reject(e) }
  })

const getBuffer = (url) =>
  new Promise((resolve, reject) => {
    try {
      const parsed = new URL(url)
      const mod = parsed.protocol === "https:" ? https : http
      mod.get({ hostname: parsed.hostname, path: parsed.pathname + parsed.search, timeout: 30000, headers: { "User-Agent": UA } }, (res) => {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) return resolve(getBuffer(res.headers.location))
        if (res.statusCode !== 200) return reject(new Error("HTTP " + res.statusCode))
        const c = []
        res.on("data", d => c.push(d))
        res.on("end", () => resolve(Buffer.concat(c)))
      }).on("error", reject)
    } catch (e) { reject(e) }
  })

const handler = async (m, { Rafz, command, text }) => {
  try {
    const px = (global.prefix && global.prefix[0]) || "/"
    const q = (text || "").trim()
    const usage = (u) => "Penggunaan: " + px + u

    if (command === "githubstalk" || command === "ghstalk") {
      if (!q) return m.reply(usage("githubstalk username"))
      const j = await getJSON("https://api.github.com/users/" + encodeURIComponent(q))
      if (!j || j.message) return m.reply("User tidak ditemukan")
      try {
        const av = await getBuffer(j.avatar_url)
        await Rafz.sendPhoto(m.chat, av, {
          caption: "GITHUB STALK\n\nNama: " + (j.name || j.login) + "\nUsername: @" + j.login + "\nBio: " + (j.bio || "-") + "\nRepo: " + j.public_repos + "\nFollowers: " + j.followers + "\nFollowing: " + j.following + "\nLokasi: " + (j.location || "-") + "\nLink: " + j.html_url,
          reply_to_message_id: m.id, allow_sending_without_reply: true
        })
        return true
      } catch {
        return m.reply("GITHUB STALK\n\nNama: " + (j.name || j.login) + "\nUsername: @" + j.login + "\nRepo: " + j.public_repos + "\nLink: " + j.html_url)
      }
    }

    if (command === "npmstalk" || command === "stalknpm") {
      if (!q) return m.reply(usage("npmstalk packagename"))
      const j = await getJSON("https://registry.npmjs.org/" + encodeURIComponent(q))
      if (!j || j.error) return m.reply("Paket tidak ditemukan")
      const latest = j["dist-tags"]?.latest || "?"
      const v = j.versions?.[latest] || {}
      return m.reply("NPM STALK\n\nNama: " + j.name + "\nVersi: " + latest + "\nDeskripsi: " + (v.description || "-") + "\nAuthor: " + (v.author?.name || "-") + "\nLicense: " + (v.license || "-"))
    }

    if (command === "igstalk" || command === "instagramstalk") {
      if (!q) return m.reply(usage("igstalk username"))
      try {
        const j = await getJSON("https://api.siputzx.my.id/api/stalk/ig?user=" + encodeURIComponent(q))
        if (j && j.status && j.data) {
          const d = j.data
          return m.reply("INSTAGRAM STALK\n\nUsername: " + d.username + "\nNama: " + (d.full_name || "-") + "\nBio: " + (d.biography || "-") + "\nPrivate: " + (d.is_private ? "Ya" : "Tidak") + "\nFollowers: " + (d.followers || 0) + "\nFollowing: " + (d.following || 0))
        }
        throw new Error("no data")
      } catch {
        return m.reply("Username: " + q + "\nInstagram stalk tidak tersedia saat ini. Coba /tiktokstalk")
      }
    }

    if (command === "tiktokstalk" || command === "ttstalk") {
      if (!q) return m.reply(usage("tiktokstalk username"))
      try {
        const j = await getJSON("https://api.siputzx.my.id/api/stalk/tiktok?user=" + encodeURIComponent(q))
        if (j && j.status) {
          const d = j.data || {}
          return m.reply("TIKTOK STALK\n\nUsername: @" + (d.username || q) + "\nNama: " + (d.nickname || "-") + "\nBio: " + (d.signature || "-") + "\nFollowers: " + (d.followers || 0) + "\nFollowing: " + (d.following || 0) + "\nLikes: " + (d.likes || 0))
        }
        throw new Error("no data")
      } catch {
        return m.reply("Username: @" + q + "\nTikTok stalk tidak tersedia saat ini.")
      }
    }

    if (command === "ffstalk" || command === "freefirestalk") {
      if (!q) return m.reply(usage("ffstalk playerid"))
      try {
        const j = await getJSON("https://api.siputzx.my.id/api/stalk/nick-freefire?userid=" + encodeURIComponent(q))
        if (j && j.status) return m.reply("FREE FIRE STALK\n\nID: " + q + "\nNickname: " + (j.data?.username || j.data?.nick || "-"))
        throw new Error("no data")
      } catch {
        return m.reply("ID: " + q + "\nFF stalk tidak tersedia saat ini.")
      }
    }

    if (command === "robloxstalk" || command === "rblxstalk") {
      if (!q) return m.reply(usage("robloxstalk username"))
      try {
        const j = await getJSON("https://users.roblox.com/v1/users/search?keyword=" + encodeURIComponent(q) + "&limit=1")
        const u = j?.data?.[0]
        if (!u) throw new Error("not found")
        return m.reply("ROBLOX STALK\n\nUsername: " + u.name + "\nID: " + u.id + "\nDisplay: " + (u.displayName || "-"))
      } catch {
        return m.reply("User Roblox tidak ditemukan")
      }
    }

    if (command === "ytstalk" || command === "youtubestalk") {
      if (!q) return m.reply(usage("ytstalk channelname"))
      return m.reply("YouTube stalk: " + q + "\nFitur ini memerlukan API key YouTube. Gunakan /yts untuk search.")
    }

    if (command === "discordstalk" || command === "stalkdc") {
      if (!q) return m.reply(usage("discordstalk username"))
      return m.reply("Discord stalk tidak tersedia untuk user biasa (privacy).")
    }

    if (command === "cekgempa" || command === "gempa") {
      try {
        const j = await getJSON("https://data.bmkg.go.id/DataMKG/TEWS/gempaterkini.json")
        const g = j?.Infogempa?.gempa
        if (!g) throw new Error("no data")
        return m.reply("INFO GEMPA\n\nTanggal: " + g.Tanggal + "\nJam: " + g.Jam + "\nMagnitudo: " + g.Magnitude + "\nKedalaman: " + g.Kedalaman + "\nLokasi: " + g.Wilayah + "\nPotensi: " + (g.Potensi || "-"))
      } catch {
        return m.reply("Data gempa tidak tersedia")
      }
    }

    return false
  } catch (e) {
    console.error("[stalker]", e?.message)
    try { await m.reply("Error: " + (e?.message || e)) } catch {}
    return false
  }
}

handler.command = ["githubstalk", "ghstalk", "npmstalk", "stalknpm", "igstalk", "instagramstalk", "tiktokstalk", "ttstalk", "ffstalk", "freefirestalk", "robloxstalk", "rblxstalk", "ytstalk", "youtubestalk", "discordstalk", "stalkdc", "cekgempa", "gempa"]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
