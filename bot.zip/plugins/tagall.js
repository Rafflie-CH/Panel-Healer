/* plugin: tagall.js - /tagall (mention semua member grup) */
"use strict"

const handler = async (m, { Rafz, command, text }) => {
  try {
    const px = (global.prefix && global.prefix[0]) || "/"
    const sender = String(m.sender)

    const isGroup = String(m.chat).startsWith("-")
    if (!isGroup) return m.reply("Hanya bisa di grup.")

    const isAdmin = m.isAdmin
    const isOwner = (global.owner || []).includes(sender)
    if (!isAdmin && !isOwner) return m.reply("Hanya admin yang bisa pakai.")

    const q = (text || "").replace(/@/g, "").trim()
    const mention = q ? q + "\n\n" : ""

    const members = await Rafz.getChatAdministrators(m.chat).catch(() => [])
    let out = mention
    let count = 0
    for (const mem of members) {
      if (mem.user?.id) {
        out += '<a href="tg://user?id=' + mem.user.id + '">' + (mem.user.first_name || "User") + '</a> '
        count++
      }
    }

    return m.reply("<b>" + out + "</b>\n\nTotal: " + count + " admin", { parse_mode: "HTML" })
  } catch (e) {
    console.error("[tagall]", e?.message)
    try { await m.reply("Error: " + (e?.message || e)) } catch {}
    return false
  }
}

handler.command = ["tagall", "tag", "mentionall"]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
