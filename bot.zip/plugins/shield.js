/* shield.js — Protectron (porting @protectronbot).
   Toggles filter tipe pesan (nolinks/noforwards/dll — enforcement di roseadv msgHook),
   /antispam, /imagefilter (NSFW detection nyckel — API asli terverifikasi hidup),
   /profanity, /warningbans, /blacklist_*, /whitelist_*, /status (cek permission bot).
   Semua enforcement toggle tersimpan di gstore("shield") dan dieksekusi roseadv.js. */

"use strict"
const gstore = require("../library/gstore")

const esc = (s) => String(s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")

const TOGGLES = {
  nolinks: "🔗", noforwards: "↪️", nolocations: "📍", nocontacts: "👤", nocommands: "⌨️",
  nohashtags: "#️⃣", novoice: "🎙️", noevents: "📋", nobots: "🤖", antispam: "🛡️",
  profanity: "🤬", imagefilter: "🖼️"
}

const isAdmin = async (Rafz, chat, uid) => {
  try {
    if ((global.owner || []).includes(String(uid))) return true
    const admins = await Rafz.getChatAdministrators(chat)
    return admins.some(a => String(a.user?.id) === String(uid))
  } catch { return false }
}

/* NSFW checker — scrape/nsfw-checker.js (nyckel.com, terverifikasi hidup 2026-09) */
const nsfwChecker = async (buf) => {
  const fn = require("../scrape/nsfw-checker")
  return fn(buf)
}

const handler = async (m, { Rafz, command, text }) => {
  try {
    const tr = (key, vars) => (m.t ? m.t(key, vars) : key)
    const px = (global.prefix && global.prefix[0]) || "/"
    const chat = String(m.chat)

    /* ═══ /status — permission check (3 ikon) ═══ */
    if (command === "status" || command === "shieldstatus") {
      if (!m.isGroup) return m.reply(tr("rose.groupOnly"), { parse_mode: "HTML" })
      const checks = []
      let me
      try { me = await Rafz.getMe() } catch {}
      try {
        const admins = await Rafz.getChatAdministrators(m.chat)
        const meA = admins.find(a => String(a.user?.id) === String(me?.id))
        checks.push(["👁️ " + tr("shield.readMsgs"), !!meA])
        checks.push(["🗑️ " + tr("shield.delMsgs"), !!(meA && (meA.can_delete_messages || meA.can_restrict_members))])
        checks.push(["🔨 " + tr("shield.banUsers"), !!(meA && meA.can_restrict_members)])
        const sh = gstore.get("shield", chat, {})
        const active = Object.entries(TOGGLES).filter(([k]) => sh[k]).map(([k, e]) => e + " " + k).join(", ")
        return m.reply(
          "🛡️ <b>SHIELD STATUS</b>\n\n" +
          checks.map(([n, ok]) => n + ": " + (ok ? "✅" : "❌")).join("\n") + "\n\n" +
          "⚙️ " + tr("shield.activeFeatures") + ":\n" + (active || "—") + "\n\n" +
          tr("shield.setupHint") + " <code>" + px + "nolinks</code>",
          { parse_mode: "HTML" }
        )
      } catch (e) {
        return m.reply(tr("common.failed"), { parse_mode: "HTML" })
      }
    }

    if (!m.isGroup) return m.reply(tr("rose.groupOnly"), { parse_mode: "HTML" })
    if (!await isAdmin(Rafz, m.chat, m.sender)) return m.reply(tr("rose.adminOnly"), { parse_mode: "HTML" })

    /* ═══ toggle fitur (semua nolinks dll + antispam/profanity/imagefilter) ═══ */
    const tgl = TOGGLES[command]
    if (tgl) {
      const sh = gstore.get("shield", chat, {})
      sh[command] = !sh[command]
      gstore.set("shield", chat, sh)
      return m.reply(
        tgl + " <b>" + command.toUpperCase() + "</b>: " + (sh[command] ? "✅ ON" : "❌ OFF") +
        (sh[command] && command === "imagefilter" ? "\nℹ️ " + tr("shield.imageHint") : ""),
        { parse_mode: "HTML" }
      )
    }

    /* ═══ blacklist (protectron) ═══ */
    if (command === "blacklist" || command === "shieldbl") {
      const cur = gstore.arrGet("shieldbl", chat)
      if (!cur.length) return m.reply("🚫 <b>BLACKLIST</b> — " + tr("rose.empty"), { parse_mode: "HTML" })
      return m.reply("🚫 <b>BLACKLIST</b> (" + cur.length + ")\n\n" + cur.map((x, i) => `<code>${i + 1}</code>. ${esc(x.w)}${x.exact ? " (exact)" : ""}`).join("\n"), { parse_mode: "HTML" })
    }
    if (command === "blacklist_add" || command === "shieldbladd") {
      const items = String(text || "").split(",").map(s => s.trim()).filter(Boolean)
      const cur = gstore.arrGet("shieldbl", chat)
      for (const it of items) {
        const exact = /^".*"$/.test(it)
        cur.push({ w: exact ? it.slice(1, -1).toLowerCase() : it.toLowerCase(), exact })
      }
      gstore.set("shieldbl", chat, cur)
      return m.reply("🚫 " + tr("rose.blAdded") + " <b>" + items.length + "</b>", { parse_mode: "HTML" })
    }
    if (command === "blacklist_remove" || command === "shieldblrm") {
      const w = String(text || "").trim().replace(/^"|"$/g, "").toLowerCase()
      gstore.set("shieldbl", chat, gstore.arrGet("shieldbl", chat).filter(x => x.w !== w))
      return m.reply("✅ " + tr("rose.blRemoved") + " <code>" + esc(w) + "</code>", { parse_mode: "HTML" })
    }
    if (command === "blacklist_clear" || command === "shieldblclear") {
      gstore.set("shieldbl", chat, [])
      return m.reply("✅ " + tr("rose.blCleared"), { parse_mode: "HTML" })
    }

    /* ═══ whitelist ═══ */
    if (command === "whitelist" || command === "shieldwl") {
      const cur = gstore.arrGet("shieldwl", chat)
      return m.reply("✅ <b>WHITELIST</b>\n" + (cur.length ? cur.map(x => "• <code>" + esc(x) + "</code>").join("\n") : "—"), { parse_mode: "HTML" })
    }
    if (command === "whitelist_add" || command === "shieldwladd") {
      gstore.arrAdd("shieldwl", chat, String(text || "").trim().toLowerCase())
      return m.reply("✅ " + tr("rose.done"), { parse_mode: "HTML" })
    }
    if (command === "whitelist_remove" || command === "shieldwlrm") {
      gstore.arrRemove("shieldwl", chat, String(text || "").trim().toLowerCase())
      return m.reply("✅ " + tr("rose.done"), { parse_mode: "HTML" })
    }
    if (command === "whitelist_clear" || command === "shieldwlclear") {
      gstore.set("shieldwl", chat, [])
      return m.reply("✅ " + tr("rose.done"), { parse_mode: "HTML" })
    }

    /* ═══ warningbans (lintas grup) ═══ */
    if (command === "warningbans") {
      const tgt = m.quoted?.sender || String(text || "").replace(/\D/g, "")
      if (!tgt) {
        return m.reply(
          "⚖️ <b>WARNINGBANS</b>\n\n" + tr("shield.wbInfo") + "\n\n" +
          tr("shield.wbCheck") + ": <code>" + px + "warningbans 123456789</code>",
          { parse_mode: "HTML" }
        )
      }
      const n = gstore.get("warningbans", tgt, 0)
      return m.reply("⚖️ <code>" + esc(tgt) + "</code> — " + tr("shield.wbCount") + ": <b>" + n + "</b>/10", { parse_mode: "HTML" })
    }
    if (command === "warningbans_reset") {
      const tgt = m.quoted?.sender || String(text || "").replace(/\D/g, "")
      if (!tgt) return m.reply(tr("rose.needTarget"), { parse_mode: "HTML" })
      gstore.set("warningbans", tgt, 0)
      return m.reply("✅ " + tr("rose.done"), { parse_mode: "HTML" })
    }

    /* ═══ antispam_mode ═══ */
    if (command === "antispam_mode") {
      const mode = String(text || "").trim().toLowerCase()
      if (!["normal", "strict"].includes(mode)) return m.reply("⚠️ <code>" + px + "antispam_mode strict</code> (normal | strict)", { parse_mode: "HTML" })
      const sh = gstore.get("shield", chat, {})
      sh.antispamMode = mode
      gstore.set("shield", chat, sh)
      return m.reply("✅ " + tr("shield.antispamMode") + ": <b>" + esc(mode) + "</b>", { parse_mode: "HTML" })
    }

    /* ═══ /report2shield — reply spam → lapor + hapus ═══ */
    if (command === "reportspam") {
      if (!m.quoted?.id) return m.reply(tr("rose.replyMsg"), { parse_mode: "HTML" })
      const spammer = String(m.quoted.sender || "")
      if (spammer) {
        const n = gstore.counterInc("shieldwb", spammer, 0)
        if (n >= 3) {
          const cur = gstore.get("warningbans", spammer, 0)
          gstore.set("warningbans", spammer, cur + 1)
          gstore.counterReset("shieldwb", spammer)
        }
      }
      try { await Rafz.deleteMessage(m.chat, m.quoted.id) } catch {}
      const admins = await Rafz.getChatAdministrators(m.chat).catch(() => [])
      const tags = admins.filter(a => !a.user?.is_bot).map(a => "<a href=\"tg://user?id=" + a.user.id + "\">·</a>").join("")
      await m.reply("🛡️ " + tr("shield.reported") + " " + tags, { parse_mode: "HTML" })
      return true
    }

    /* ═══ nobots enforcement helper: kick bot baru ═══ */
    if (command === "kickbot") {
      const tgt = m.quoted?.sender || String(text || "").replace(/\D/g, "")
      if (!tgt) return m.reply(tr("rose.needTarget"), { parse_mode: "HTML" })
      try { await Rafz.banChatMember(m.chat, tgt); await Rafz.unbanChatMember(m.chat, tgt) } catch {}
      return m.reply("🤖 " + tr("rose.done"), { parse_mode: "HTML" })
    }

    return false
  } catch (e) {
    console.error("[shield]", command, e?.message)
    try { await m.reply("❌ " + esc(String(e?.message || e).slice(0, 120)), { parse_mode: "HTML" }) } catch {}
    return false
  }
}

/* imagefilter enforcement: reply foto → /checknsfw (admin) */
const checkHandler = async (m, { Rafz }) => {
  try {
    if (command_check(m) !== "checknsfw") return false
    const chat = String(m.chat)
    if (!m.isGroup) return m.reply("group only")
    if (!await isAdmin(Rafz, m.chat, m.sender)) return m.reply("admin only")
    const fileId = m.quoted?.fileId || m.fileId
    if (!fileId) return m.reply(m.t ? m.t("shield.replyPhoto") : "reply photo")
    const f = await Rafz.getFile(fileId)
    const url = "https://api.telegram.org/file/bot" + Rafz.token + "/" + f.file_path
    const res = await fetch(url)
    const buf = Buffer.from(await res.arrayBuffer())
    const wait = await m.reply(m.t ? m.t("common.searching") : "checking...", { parse_mode: "HTML" })
    try {
      const r = await nsfwChecker(buf)
      const isPorn = /porn|hentai|nsfw|adult/i.test(r.labelName || "")
      await m.reply(
        "🖼️ <b>NSFW CHECK</b>\n\n" + tr("shield.nsfwLabel") + ": <b>" + esc(r.labelName) + "</b>\n" +
        tr("shield.confidence") + ": <b>" + (r.confidence * 100).toFixed(1) + "%</b>" +
        (isPorn ? "\n🚨 " + tr("shield.nsfwDetected") : "\n✅ " + tr("shield.safe")),
        { parse_mode: "HTML" }
      )
    } catch (e) {
      await m.reply("❌ " + esc(String(e.message || e).slice(0, 90)), { parse_mode: "HTML" })
    }
    try { Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {}) } catch {}
    return true
  } catch (e) {
    try { await m.reply("❌ " + esc(String(e?.message || e).slice(0, 90))) } catch {}
    return false
  }
}
const command_check = (m) => String(m.command || "")

const combined = async (m, opts) => {
  const r = await checkHandler(m, opts)
  if (r !== false && r !== undefined && r !== null) return r
  return handler(m, opts)
}
combined.command = [
  "status", "shieldstatus", "antispam_mode", "reportspam", "kickbot", "checknsfw",
  "nolinks", "noforwards", "nolocations", "nocontacts", "nocommands", "nohashtags", "novoice", "noevents", "nobots",
  "antispam", "profanity", "imagefilter",
  "blacklist", "shieldbl", "blacklist_add", "shieldbladd", "blacklist_remove", "shieldblrm", "blacklist_clear", "shieldblclear",
  "whitelist", "shieldwl", "whitelist_add", "shieldwladd", "whitelist_remove", "shieldwlrm", "whitelist_clear", "shieldwlclear",
  "warningbans", "warningbans_reset"
]
module.exports = combined

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
