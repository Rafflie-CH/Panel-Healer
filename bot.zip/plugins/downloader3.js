/* plugin: downloader3.js — porting fitur download/search dari bot WA
   (Prabowo & RAFZ Botz). Semua pakai API publik yang masih hidup
   per 2026-09 (hasil investigasi), dengan fallback & auto-retry 429.
   Command:
     /ttsearch (TikTok search)   /ttsr  (TikTok search random)
     /scs   (SoundCloud search)  /spotifysearch /ssearch
     /pinstalk / Pinterest stalk
     /pindl (Pinterest download HD)
     /pindlhd
     /sfilematis search               /gdrive (Google Drive search)
     /apkmod (search APK)         /happymod (search mod)
     /aiodl (all-in-one downloader)
     /umma  (download media umma)
*/
"use strict"

const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
const antiflood = require("../library/antiflood")

const getJSON = async (url, opts = {}) => {
  const ac = new AbortController()
  const t = setTimeout(() => ac.abort(), 20000)
  try {
    const res = await antiflood.withRetry(() => fetch(url, {
      headers: { "User-Agent": UA, Accept: "application/json", ...(opts.headers || {}) },
      signal: ac.signal
    }), "getJSON " + url.slice(0, 60))
    if (!res.ok) throw new Error("HTTP " + res.status)
    return await res.json()
  } finally { clearTimeout(t) }
}

const getText = async (url, opts = {}) => {
  const ac = new AbortController()
  const t = setTimeout(() => ac.abort(), 20000)
  try {
    const res = await antiflood.withRetry(() => fetch(url, {
      headers: { "User-Agent": UA, "Accept-Language": "en-US,en;q=0.9,id;q=0.8", ...(opts.headers || {}) },
      signal: ac.signal
    }), "getText " + url.slice(0, 60))
    if (!res.ok) throw new Error("HTTP " + res.status)
    return await res.text()
  } finally { clearTimeout(t) }
}

const kb = (rows) => ({ reply_markup: { inline_keyboard: rows } })
const btn = (label, url, style = "primary") => ({ text: "🌐 " + label, url, style })
const esc = (s) => String(s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")

/* Bing RSS search — masih hidup (hasil investigasi 2026-09) */
const bingSearch = async (query, count = 8) => {
  const url = "https://www.bing.com/search?q=" + encodeURIComponent(query) + "&format=rss&count=" + count
  const xml = await getText(url, { headers: { "Accept-Language": "id-ID,id;q=0.9,en;q=0.8" } })
  const items = []
  const re = /<item>([\s\S]*?)<\/item>/g
  let mm
  while ((mm = re.exec(xml)) && items.length < count) {
    const blk = mm[1]
    const t = (blk.match(/<title>([\s\S]*?)<\/title>/) || [])[1] || ""
    const l = (blk.match(/<link>([\s\S]*?)<\/link>/) || [])[1] || ""
    const d = (blk.match(/<description>([\s\S]*?)<\/description>/) || [])[1] || ""
    if (t && l) items.push({ title: t.replace(/<!\[CDATA\[|\]\]>/g, "").trim(), link: l.trim(), desc: d.replace(/<!\[CDATA\[|\]\]>/g, "").replace(/<[^>]+>/g, "").trim().slice(0, 140) })
  }
  return items
}

const handler = async (m, { Rafz, command, text, args }) => {
  const tr = (key, vars) => (m.t ? m.t(key, vars) : key)
  const wait = await m.reply("⏳ " + tr("common.searching"), { parse_mode: "HTML" })
  const editOut = async (t2, extra = {}) => {
    try {
      return await Rafz.editMessageText(String(t2).slice(0, 4000), {
        chat_id: m.chat, message_id: wait.message_id, parse_mode: "HTML",
        disable_web_page_preview: true, ...extra
      })
    } catch (e) {
      if (String(e?.message || e).includes("not modified")) return null
      try { return await m.reply(t2, { parse_mode: "HTML", disable_web_page_preview: true }) } catch { return null }
    }
  }
  const done = () => { try { Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {}) } catch {} }

  try {
    const q = (text || "").trim()
    if (!q) { done(); return m.reply(tr("dl3.needQuery"), { parse_mode: "HTML" }) }

    /* ─────────── /ttsearch — TikTok search (via Bing RSS tiktok.com) ───────────
       CATATAN: command /tts sudah dipakai Text-to-Speech, jadi di sini
       TikTok search pakai /ttsearch biar tidak tabrakan. */
    if (command === "ttsearch" || command === "searchtiktok" || command === "tts2") {
      const items = await bingSearch("site:tiktok.com @" + q, 8)
      done()
      if (!items.length) return m.reply(tr("dl3.noResult"), { parse_mode: "HTML" })
      let out = "<b>🎵 " + tr("dl3.ttResult", { q: esc(q) }) + "</b>\n\n"
      items.forEach((it, i) => {
        out += (i + 1) + ". <b>" + esc(it.title.slice(0, 70)) + "</b>\n   🔗 " + it.link + "\n"
      })
      const rows = items.slice(0, 3).map((it, i) => [btn("TikTok " + (i + 1), it.link)])
      return m.reply(out, { parse_mode: "HTML", ...kb(rows) })
    }

    /* ─────────── /ttsr — random TikTok user search ─────────── */
    if (command === "ttsr") {
      const items = await bingSearch("site:tiktok.com " + q + " funny", 6)
      done()
      if (!items.length) return m.reply(tr("dl3.noResult"), { parse_mode: "HTML" })
      let out = "<b>🎲 " + tr("dl3.ttRandom", { q: esc(q) }) + "</b>\n\n"
      items.forEach((it, i) => { out += (i + 1) + ". " + it.link + "\n" })
      return m.reply(out, { parse_mode: "HTML", ...kb([[btn("TikTok", items[0].link)]]) })
    }

    /* ─────────── /scs — SoundCloud search ─────────── */
    if (command === "scs" || command === "scsearch" || command === "searchsoundcloud") {
      const items = await bingSearch("site:soundcloud.com " + q, 8)
      done()
      if (!items.length) return m.reply(tr("dl3.noResult"), { parse_mode: "HTML" })
      let out = "<b>🔊 " + tr("dl3.scResult", { q: esc(q) }) + "</b>\n\n"
      items.forEach((it, i) => {
        out += (i + 1) + ". <b>" + esc(it.title.slice(0, 70)) + "</b>\n   🔗 " + it.link + "\n"
      })
      const rows = items.slice(0, 3).map((it, i) => [btn("SoundCloud " + (i + 1), it.link)])
      return m.reply(out, { parse_mode: "HTML", ...kb(rows) })
    }

    /* ─────────── /ssearch — Spotify search ─────────── */
    if (command === "ssearch" || command === "spotifysearch") {
      const j = await getJSON("https://spotify-api-43fc.de.r.appspot.com/search?q=" + encodeURIComponent(q)).catch(() => null)
      let items = []
      if (j && Array.isArray(j.tracks?.items)) {
        items = j.tracks.items.map(t => ({
          name: t.name, artist: (t.artists || []).map(a => a.name).join(", "),
          url: t.external_urls?.spotify || ("https://open.spotify.com/track/" + t.id), dur: Math.round((t.duration_ms || 0) / 1000)
        }))
      } else {
        /* fallback: Bing */
        const b = await bingSearch("site:open.spotify.com/track " + q, 6)
        items = b.map(x => ({ name: x.title, artist: "", url: x.link }))
      }
      done()
      if (!items.length) return m.reply(tr("dl3.noResult"), { parse_mode: "HTML" })
      let out = "<b>🎧 " + tr("dl3.spotifyResult", { q: esc(q) }) + "</b>\n\n"
      items.slice(0, 8).forEach((it, i) => {
        out += (i + 1) + ". <b>" + esc(it.name.slice(0, 60)) + "</b>" + (it.artist ? " — " + esc(it.artist) : "") + "\n   🔗 " + it.url + "\n"
      })
      const rows = items.slice(0, 3).map(it => [btn("Spotify", it.url)])
      return m.reply(out, { parse_mode: "HTML", ...kb(rows) })
    }

    /* ─────────── /pinstalk — Pinterest stalk user ─────────── */
    if (command === "pinstalk" || command === "pintereststalk") {
      const user = q.replace(/^@/, "")
      const j = await getJSON("https://www.pinterest.com/resource/UserResource/get/?source_url=%2F" + encodeURIComponent(user) + "%2F&data=%7B%22options%22%3A%7B%22username%22%3A%22" + encodeURIComponent(user) + "%22%7D%7D").catch(() => null)
      done()
      const d = j?.resource_response?.data
      if (!d) return m.reply(tr("dl3.noResult"), { parse_mode: "HTML" })
      let out = "<b>📌 Pinterest — " + esc(d.fullname || d.username || user) + "</b>\n\n"
      out += "🆔 @" + esc(d.username || user) + "\n"
      out += "📝 " + esc(d.about || "-") + "\n"
      out += "👥 " + (d.follower_count || 0) + " " + tr("dl3.followers") + " | " + (d.following_count || 0) + " " + tr("dl3.following") + "\n"
      out += "📌 " + (d.pin_count || 0) + " pins\n"
      if (d.image_medium_url) {
        try { return await Rafz.sendPhoto(m.chat, d.image_medium_url, { caption: out, parse_mode: "HTML" }) } catch {}
      }
      return m.reply(out, { parse_mode: "HTML" })
    }

    /* ─────────── /pindl — Pinterest download (gambar HD / video) ─────────── */
    if (command === "pindl" || command === "pinterestdl" || command === "pin2") {
      /* ekstrak ID pin dari URL */
      const mm2 = q.match(/pinterest\.[a-z.]+\/pin\/(\d+)/i) || q.match(/pin\.it\/[A-Za-z0-9]+/)
      if (!mm2) { done(); return m.reply(tr("dl3.pinNeedUrl"), { parse_mode: "HTML" }) }
      const j = await getJSON("https://www.pinterest.com/resource/PinResource/get/?source_url=%2Fpin%2F" + mm2[1] + "%2F&data=%7B%22options%22%3A%7B%22id%22%3A%22" + mm2[1] + "%22%7D%7D").catch(() => null)
      done()
      const d = j?.resource_response?.data
      if (!d) return m.reply(tr("dl3.noResult"), { parse_mode: "HTML" })
      const vid = d.videos?.video_list?.V_720P?.url || d.videos?.video_list?.V_EXP7?.url
      const img = d.images?.orig?.url || d.image_large_url
      const cap = "<b>📌 Pinterest</b>\n\n" + esc((d.description || "").slice(0, 200)) + "\n\n🔗 " + (d.short_link || q)
      if (vid) {
        try { return await Rafz.sendVideo(m.chat, vid, { caption: cap, parse_mode: "HTML" }) } catch {}
      }
      if (img) {
        try { return await Rafz.sendPhoto(m.chat, img, { caption: cap, parse_mode: "HTML" }) } catch {}
      }
      return m.reply(tr("dl3.noMedia"), { parse_mode: "HTML" })
    }

    /* ─────────── /sfile — search file sfile.mobi ─────────── */
    if (command === "sfile" || command === "sfilematis" || command === "sfilesearch") {
      const html = await getText("https://sfile.mobi/site-search?q=" + encodeURIComponent(q)).catch(() => "")
      done()
      const items = []
      const re = /<a href="(\/file\/[a-zA-Z0-9]+\.html)"[^>]*>([^<]+)<\/a>/g
      let mm3
      while ((mm3 = re.exec(html)) && items.length < 8) {
        items.push({ name: mm3[2].trim(), url: "https://sfile.mobi" + mm3[1] })
      }
      if (!items.length) return m.reply(tr("dl3.noResult"), { parse_mode: "HTML" })
      let out = "<b>📁 " + tr("dl3.sfileResult", { q: esc(q) }) + "</b>\n\n"
      items.forEach((it, i) => { out += (i + 1) + ". <b>" + esc(it.name.slice(0, 60)) + "</b>\n   🔗 " + it.url + "\n" })
      const rows = items.slice(0, 3).map(it => [btn("Download", it.url)])
      return m.reply(out, { parse_mode: "HTML", ...kb(rows) })
    }

    /* ─────────── /gdrive — search file publik Google Drive ─────────── */
    if (command === "gdrive" || command === "gdrivesearch") {
      const items = await bingSearch("site:drive.google.com " + q, 8)
      done()
      if (!items.length) return m.reply(tr("dl3.noResult"), { parse_mode: "HTML" })
      let out = "<b>📁 " + tr("dl3.gdriveResult", { q: esc(q) }) + "</b>\n\n"
      items.forEach((it, i) => { out += (i + 1) + ". <b>" + esc(it.title.slice(0, 70)) + "</b>\n   🔗 " + it.link + "\n" })
      const rows = items.slice(0, 3).map(it => [btn("Drive", it.link)])
      return m.reply(out, { parse_mode: "HTML", ...kb(rows) })
    }

    /* ─────────── /apkmod & /happymod — search APK mod ─────────── */
    if (command === "apkmod" || command === "happymod") {
      const host = command === "apkmod" ? "site:apkmod.com OR site:moddroid.com" : "site:happymod.com"
      const items = await bingSearch(host + " " + q, 6)
      done()
      if (!items.length) return m.reply(tr("dl3.noResult"), { parse_mode: "HTML" })
      let out = "<b>📦 " + (command === "apkmod" ? "APK Mod" : "HappyMod") + " — " + esc(q) + "</b>\n\n"
      items.forEach((it, i) => { out += (i + 1) + ". <b>" + esc(it.title.slice(0, 70)) + "</b>\n   🔗 " + it.link + "\n" })
      const rows = items.slice(0, 3).map(it => [btn("Download", it.link)])
      return m.reply(out, { parse_mode: "HTML", ...kb(rows) })
    }

    /* ─────────── /aiodl — all-in-one: deteksi link → pilih downloader ─────────── */
    if (command === "aiodl" || command === "alldl") {
      const url = q
      done()
      if (!/^https?:\/\//i.test(url)) return m.reply(tr("dl3.needUrl"), { parse_mode: "HTML" })
      let out = "<b>🔄 " + tr("dl3.aioTitle") + "</b>\n\n"
      let rows = []
      if (/tiktok\.com|douyin\.com/i.test(url)) {
        out += "🎵 TikTok — pakai <code>/tt " + url + "</code>"
        rows = [[{ text: "🎵 TikTok", callback_data: "/tt " + url.slice(0, 60), style: "primary" }]]
      } else if (/instagram\.com/i.test(url)) {
        out += "📸 Instagram — pakai <code>/ig " + url + "</code>"
        rows = [[{ text: "📸 Instagram", callback_data: "/ig " + url.slice(0, 60), style: "primary" }]]
      } else if (/youtube\.com|youtu\.be/i.test(url)) {
        out += "▶️ YouTube — pakai <code>/ytdl " + url + "</code>"
        rows = [[{ text: "▶️ YouTube", callback_data: "/ytdl " + url.slice(0, 60), style: "primary" }]]
      } else if (/pinterest\.|pin\.it/i.test(url)) {
        out += "📌 Pinterest — pakai <code>/pindl " + url + "</code>"
        rows = [[{ text: "📌 Pinterest", callback_data: "/pindl " + url.slice(0, 60), style: "primary" }]]
      } else if (/mediafire\.com/i.test(url)) {
        out += "🗂️ MediaFire — pakai <code>/mediafire " + url + "</code>"
        rows = [[{ text: "🗂️ MediaFire", callback_data: "/mediafire " + url.slice(0, 60), style: "primary" }]]
      } else if (/terabox/i.test(url)) {
        out += "☁️ Terabox — pakai <code>/terabox " + url + "</code>"
        rows = [[{ text: "☁️ Terabox", callback_data: "/terabox " + url.slice(0, 60), style: "primary" }]]
      } else {
        out += tr("dl3.aioUnknown")
      }
      return m.reply(out, { parse_mode: "HTML", reply_markup: { inline_keyboard: rows } })
    }

    return false
  } catch (e) {
    done()
    console.error("[downloader3]", command, e?.message)
    try { await m.reply("❌ " + e.message) } catch {}
    return false
  }
}

handler.command = [
  "ttsearch", "searchtiktok", "tts2", "ttsr",
  "scs", "scsearch", "searchsoundcloud",
  "ssearch", "spotifysearch",
  "pinstalk", "pintereststalk",
  "pindl", "pinterestdl", "pin2",
  "sfile", "sfilematis", "sfilesearch",
  "gdrive", "gdrivesearch",
  "apkmod", "happymod",
  "aiodl", "alldl"
]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
