/* roseadv.js — Rose advanced protection (porting @MissRose_bot).
   Locks (28 tipe), blocklist (+exact/lookalike + custom punishment),
   antiflood per grup (setflood/setfloodmode/setfloodtimer), antiraid + autoantiraid,
   captcha (button/math mode + kick kalau gagal).
   ENFORCEMENT lewat global.roseMsgHook — hook dipasang di handler.js
   sehingga SEMUA pesan (cmd & non-cmd) dicek sebelum diproses. */

"use strict"
const gstore = require("../library/gstore")

const esc = (s) => String(s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
const parseTime = (s) => {
  const m = String(s || "").trim().match(/^(\d+)([smhdw])$/i)
  if (!m) return null
  const mult = { s: 1, m: 60, h: 3600, d: 86400, w: 604800 }[m[2].toLowerCase()]
  return parseInt(m[1]) * mult
}

const LOCKTYPES = ["all", "album", "anonchannel", "audio", "bot", "button", "cashtag", "checklist", "cjk", "command", "comment", "contact", "cyrillic", "document", "email", "emoji", "forward", "game", "gif", "inline", "invitelink", "location", "media", "photo", "poll", "preview", "sticker", "text", "url", "video", "voice", "outsidereaction"]

const isAdmin = async (Rafz, chat, uid) => {
  try {
    if ((global.owner || []).includes(String(uid))) return true
    const admins = await Rafz.getChatAdministrators(chat)
    return admins.some(a => String(a.user?.id) === String(uid))
  } catch { return false }
}
const isBotAdmin = async (Rafz, chat) => {
  try {
    const me = await Rafz.getMe()
    const admins = await Rafz.getChatAdministrators(chat)
    return admins.some(a => String(a.user?.id) === String(me.id))
  } catch { return false }
}
const punish = async (Rafz, chat, uid, action, customTime) => {
  try {
    const t = String(action || "").toLowerCase()
    const tm = parseTime(customTime || "")
    if (t === "ban") await Rafz.banChatMember(chat, uid)
    else if (t === "kick") { await Rafz.banChatMember(chat, uid); await Rafz.unbanChatMember(chat, uid) }
    else if (t === "mute") await Rafz.restrictChatMember(chat, uid, { permissions: { can_send_messages: false } })
    else if (t === "tmute" || t === "tban") {
      const until = Math.floor(Date.now() / 1000) + (tm || 3600)
      if (t === "tban") await Rafz.banChatMember(chat, uid, { until_date: until })
      else await Rafz.restrictChatMember(chat, uid, { permissions: { can_send_messages: false }, until_date: until })
    }
    if (t !== "nothing") { try { await Rafz.unbanChatMember(chat, uid, { only_if_banned: true }) } catch {} }
  } catch {}
}

/* ── deteksi tipe pesan untuk locks ── */
const detectTypes = (m) => {
  const t = new Set()
  const msg = m.raw || {}
  const text = String(m.body || "")
  if (m.mediaType) {
    t.add(m.mediaType)
    if (m.mediaType === "photo") t.add("media")
    if (m.mediaType === "video") { t.add("media"); if (m.raw?.video?.mime_type === "video/mp4" && m.raw?.video?.duration < 60) t.add("gif") }
    if (m.mediaType === "audio" || m.mediaType === "voice") t.add("media")
    if (m.mediaType === "document") { t.add("media"); if (String(m.mimetype || "").startsWith("image/")) t.add("photo") }
    if (m.mediaType === "sticker") t.add("sticker")
  }
  if (msg.sticker) t.add("sticker")
  if (msg.forward_origin || msg.forward_from || msg.forward_from_chat) t.add("forward")
  if (msg.contact) t.add("contact")
  if (msg.location || msg.venue) t.add("location")
  if (msg.poll) t.add("poll")
  if (msg.dice) t.add("game")
  if (msg.via_bot) t.add("inline")
  if (/^[\/!.]'?[a-z0-9_]+/i.test(text)) t.add("command")
  if (/https?:\/\/|t\.me\/|telegram\.me\//i.test(text)) t.add("url")
  if (/t\.me\/\+|t\.me\/joinchat/i.test(text)) t.add("invitelink")
  if (/\$[A-Z]{3,6}\b/.test(text)) t.add("cashtag")
  if (/[\w.+-]+@[\w-]+\.[\w.]+/.test(text)) t.add("email")
  if (/[\u4e00-\u9fff]/.test(text)) t.add("cjk")
  if (/[\u0400-\u04FF]/.test(text)) t.add("cyrillic")
  if (/[\u{1F300}-\u{1FAFF}\u{2600}-\u{27BF}]/u.test(text)) t.add("emoji")
  if (msg.caption) t.add("comment")
  if (msg.reply_markup?.inline_keyboard || (msg.entities || []).some(e => e.type === "text_link")) t.add("button")
  if ((msg.entities || []).some(e => e.type === "url")) t.add("preview")
  if (msg.is_automatic_forward || msg.sender_chat) t.add("anonchannel")
  if (msg.media_group_id) t.add("album")
  return t
}

/* ══════════════════ MESSAGE HOOK (enforcement) ══════════════════ */
const msgHook = async (m, { Rafz }) => {
  try {
    if (!m.isGroup || !Rafz) return false
    const chat = String(m.chat)
    const uid = String(m.sender)

    /* admins tidak pernah dihukum */
    if (await isAdmin(Rafz, m.chat, uid)) {
      /* captcha tetap dicek di bawah utk user lain; admin skip semua */
      return false
    }
    if (!await isBotAdmin(Rafz, m.chat)) return false

    /* ── CAPTCHA: user baru harus verifikasi ── */
    const capOn = gstore.get("captcha", chat + ":on", false)
    if (capOn) {
      const pending = gstore.get("captcha", chat + ":u" + uid, null)
      if (pending) {
        const answer = String(m.body || "").trim()
        const okAns = pending.mode === "button" ? answer === String(pending.answer) : String(parseInt(answer)) === String(pending.answer)
        if (okAns) {
          gstore.del("captcha", chat + ":u" + uid)
          try {
            await Rafz.restrictChatMember(m.chat, uid, { permissions: { can_send_messages: true, can_send_polls: true, can_send_other_messages: true, can_add_web_page_previews: true, can_invite_users: true } })
          } catch {}
          await m.reply("✅ " + (m.t ? m.t("rose.captchaOk") : "Terverifikasi!"), { parse_mode: "HTML" })
          return true
        }
        /* salah → hapus pesan, tetap mute */
        try { await Rafz.deleteMessage(m.chat, m.id) } catch {}
        return true
      }
    }

    /* ── ANTIRAID aktif → hapus pesan member baru (bukan admin) ── */
    const raid = gstore.get("antiraid", chat, null)
    if (raid && raid.on && Date.now() < (raid.until || 0)) {
      const joined = gstore.get("antiraid", chat + ":j" + uid, false)
      if (joined) {
        try { await Rafz.deleteMessage(m.chat, m.id) } catch {}
        return true
      }
    }

    /* ── ANTIFLOOD grup ── */
    const floodCfg = gstore.get("antiflood", chat, null)
    if (floodCfg && floodCfg.limit && floodCfg.on !== false) {
      const key = chat + ":" + uid
      const windowSec = floodCfg.timer ? floodCfg.timerSec || 15 : 10
      const n = gstore.counterInc("roseflood", key, windowSec)
      if (n >= floodCfg.limit) {
        gstore.counterReset("roseflood", key)
        try { await Rafz.deleteMessage(m.chat, m.id) } catch {}
        await punish(Rafz, m.chat, uid, floodCfg.mode || "tmute", floodCfg.time)
        await m.reply("🌊 " + (m.t ? m.t("rose.floodHit") : "Flood!") + " @" + (m.username || uid), { parse_mode: "HTML" })
        return true
      }
    }

    /* ── LOCKS ── */
    const locks = gstore.arrGet("locks", chat)
    if (locks.length) {
      const types = detectTypes(m)
      const hit = locks.find(l => l === "all" ? types.size > 0 : types.has(l))
      if (hit) {
        const cfg = gstore.get("lockpunish", chat, {})
        const act = cfg[hit] || "delete"
        try { await Rafz.deleteMessage(m.chat, m.id) } catch {}
        if (act !== "delete" && act !== "nothing") await punish(Rafz, m.chat, uid, act)
        /* lockwarns */
        if (gstore.get("locks", chat + ":warns", false)) {
          const n = gstore.counterInc("rosewarn", chat + ":lock:" + uid, 0)
          if (n >= (gstore.get("warnconfig", chat + ":limit", 3) || 3)) {
            gstore.counterReset("rosewarn", chat + ":lock:" + uid)
            await punish(Rafz, m.chat, uid, gstore.get("warnconfig", chat + ":mode", "ban"))
          }
        }
        return true
      }
    }

    /* ── BLOCKLIST ── */
    const bl = gstore.arrGet("blocklist", chat)
    if (bl.length) {
      const body = String(m.body || "").toLowerCase()
      for (const item of bl) {
        const trig = String(item.t || "").toLowerCase()
        let hit = false
        if (item.mode === "exact") hit = body === trig || body.split(/\s+/).includes(trig)
        else if (item.mode === "lookalike") hit = body.replace(/[0@]/g, "o").replace(/[1!|]/g, "i").replace(/\$/g, "s").includes(trig.replace(/[0@]/g, "o").replace(/[1!|]/g, "i").replace(/\$/g, "s"))
        else hit = body.includes(trig)
        if (hit) {
          if (item.delete !== false) { try { await Rafz.deleteMessage(m.chat, m.id) } catch {} }
          if (item.action && item.action !== "nothing") await punish(Rafz, m.chat, uid, item.action, item.time)
          return true
        }
      }
    }

    /* ── SHIELD (protectron) toggles ── */
    const sh = gstore.get("shield", chat, {})
    if (sh.nolinks && /https?:\/\/|t\.me\//i.test(m.body || "")) { try { await Rafz.deleteMessage(m.chat, m.id) } catch {}; return true }
    if (sh.noforwards && (m.raw?.forward_origin || m.raw?.forward_from)) { try { await Rafz.deleteMessage(m.chat, m.id) } catch {}; return true }
    if (sh.nolocations && (m.raw?.location || m.raw?.venue)) { try { await Rafz.deleteMessage(m.chat, m.id) } catch {}; return true }
    if (sh.nocontacts && m.raw?.contact) { try { await Rafz.deleteMessage(m.chat, m.id) } catch {}; return true }
    if (sh.nocommands && /^[\/!.]/.test(String(m.body || ""))) { try { await Rafz.deleteMessage(m.chat, m.id) } catch {}; return true }
    if (sh.nohashtags && /#\w+/.test(m.body || "")) { try { await Rafz.deleteMessage(m.chat, m.id) } catch {}; return true }
    if (sh.novoice && (m.raw?.voice || m.raw?.video_note)) { try { await Rafz.deleteMessage(m.chat, m.id) } catch {}; return true }
    if (sh.noevents && (m.raw?.new_chat_members || m.raw?.left_chat_member)) { try { await Rafz.deleteMessage(m.chat, m.id) } catch {}; return true }

    /* ── profanity (EN) ── */
    if (sh.profanity) {
      const bad = /\b(f+u+c+k+|sh[i1*]t+|b[i1*]tch|a[s5]{2}h[o0]l[e3]|d[i1]ck|c[o0]ck|p[u*]ssy|wh[o0]re|sl[u*]t|c[u*]nt)\b/i
      if (bad.test(m.body || "")) { try { await Rafz.deleteMessage(m.chat, m.id) } catch {}; return true }
    }

    /* ── blacklist kata (protectron) ── */
    const bl2 = gstore.arrGet("shieldbl", chat)
    if (bl2.length) {
      const body = String(m.body || "").toLowerCase()
      const hit = bl2.find(item => item.exact ? body === item.w || body.split(/\s+/).includes(item.w) : body.includes(item.w))
      if (hit) { try { await Rafz.deleteMessage(m.chat, m.id) } catch {}; return true }
    }

    /* ── AI antispam (heuristic + rate) ── */
    if (sh.antispam) {
      const n = gstore.counterInc("roseantispam", chat + ":" + uid, 60)
      const linky = /https?:\/\/|t\.me\/|@\w+|\$/i.test(m.body || "")
      if ((n > 10 && linky) || n > 25) {
        try { await Rafz.deleteMessage(m.chat, m.id) } catch {}
        await punish(Rafz, m.chat, uid, "tmute", "1h")
        await m.reply("🛡️ " + (m.t ? m.t("rose.spamHit") : "Anti-spam!") + " @" + (m.username || uid), { parse_mode: "HTML" })
        return true
      }
    }

    /* ── warningbans (protectron): pelanggar berulang lintas grup → ban ── */
    const wb = gstore.get("warningbans", uid, 0)
    if (wb && wb >= 10) {
      try { await Rafz.banChatMember(m.chat, uid) } catch {}
      return true
    }

    return false
  } catch (e) {
    console.error("[roseadv hook]", e?.message)
    return false
  }
}

/* pasang hook global (chain) */
try {
  const prev = global.roseMsgHook
  global.roseMsgHook = async (m, ctx) => {
    if (prev) { const r = await prev(m, ctx); if (r) return r }
    return msgHook(m, ctx)
  }
} catch {}

/* ══════════════════ COMMAND HANDLER ══════════════════ */
const handler = async (m, { Rafz, command, text }) => {
  try {
    const tr = (key, vars) => (m.t ? m.t(key, vars) : key)
    const px = (global.prefix && global.prefix[0]) || "/"
    if (!m.isGroup) return m.reply(tr("rose.groupOnly"), { parse_mode: "HTML" })
    const chat = String(m.chat)
    const uid = String(m.sender)
    const admin = await isAdmin(Rafz, m.chat, uid)
    if (!admin) return m.reply(tr("rose.adminOnly"), { parse_mode: "HTML" })
    const args = String(text || "").trim()
    const tgl = (name, val) => "<b>" + esc(name) + "</b>: " + (val ? "✅ ON" : "❌ OFF")

    /* ═══ 1.10 LOCKS ═══ */
    if (command === "locktypes") {
      return m.reply("🔒 <b>LOCKTYPES</b>\n\n<code>" + LOCKTYPES.join("</code>, <code>") + "</code>", { parse_mode: "HTML" })
    }
    if (command === "lock" || command === "unlock") {
      if (!args) return m.reply("⚠️ <code>" + px + command + " gif video sticker</code>", { parse_mode: "HTML" })
      /* custom punishment: /lock invitelink ### alasan {tmute 1h} */
      const parts = args.split("###")
      const types = parts[0].trim().split(/\s+/).map(s => s.toLowerCase()).filter(Boolean)
      const reason = parts[1] ? parts[1].split(/\{|\}/)[0].trim() : ""
      const customAct = parts[1] && /\{(.+)\}/.exec(parts[1])
      const invalid = types.filter(t => !LOCKTYPES.includes(t))
      if (invalid.length) return m.reply("❌ " + tr("rose.unknownLock") + ": <code>" + esc(invalid.join(", ")) + "</code>\n" + tr("rose.seeLocktypes") + " <code>" + px + "locktypes</code>", { parse_mode: "HTML" })
      const cur = new Set(gstore.arrGet("locks", chat))
      for (const t of types) {
        if (command === "lock") {
          cur.add(t)
          if (customAct) {
            const cfg = gstore.get("lockpunish", chat, {})
            cfg[t] = customAct[1].trim().split(/\s+/)[0]
            gstore.set("lockpunish", chat, cfg)
          }
        } else cur.delete(t)
      }
      gstore.set("locks", chat, [...cur])
      return m.reply((command === "lock" ? "🔒 " : "🔓 ") + tr("rose.lockDone") + ": <code>" + esc(types.join(", ")) + "</code>" + (reason ? "\n📝 " + esc(reason) : ""), { parse_mode: "HTML" })
    }
    if (command === "locks") {
      const cur = gstore.arrGet("locks", chat)
      const warns = gstore.get("locks", chat + ":warns", false)
      return m.reply(
        "🔒 <b>LOCKS</b>\n\n" + tr("rose.active") + ": " + (cur.length ? "<code>" + esc(cur.join(", ")) + "</code>" : "—") + "\n" +
        tgl(tr("rose.lockWarns"), warns) + "\n\n💡 <code>" + px + "locktypes</code>",
        { parse_mode: "HTML", reply_markup: { inline_keyboard: [[
          { text: warns ? "🔕 " + tr("rose.lockWarnsOff") : "🔔 " + tr("rose.lockWarnsOn"), callback_data: "/lockwarns " + (warns ? "off" : "on"), style: warns ? "secondary" : "primary" }
        ]] } }
      )
    }
    if (command === "lockwarns") {
      const on = /^(on|1|true|ya)$/i.test(args)
      gstore.set("locks", chat + ":warns", on)
      return m.reply("✅ " + tr("rose.lockWarns") + " " + (on ? "ON" : "OFF"), { parse_mode: "HTML" })
    }
    if (command === "allowlist") {
      if (!args) {
        const list = gstore.arrGet("allowlist", chat)
        return m.reply("📋 <b>ALLOWLIST</b>\n" + (list.length ? list.map(a => "• " + esc(a)).join("\n") : "—"), { parse_mode: "HTML" })
      }
      gstore.arrAdd("allowlist", chat, args.trim())
      return m.reply("✅ " + tr("rose.done"), { parse_mode: "HTML" })
    }
    if (command === "rmallowlist") {
      gstore.arrRemove("allowlist", chat, args.trim())
      return m.reply("✅ " + tr("rose.done"), { parse_mode: "HTML" })
    }

    /* ═══ 1.11 BLOCKLIST ═══ */
    if (command === "addblocklist" || command === "blocklistadd") {
      if (!args) return m.reply("⚠️ <code>" + px + "addblocklist spam, scam Jangan spam {tmute 1m}</code>", { parse_mode: "HTML" })
      const mm = args.match(/^(.*?)\s+(?:###\s*)?(.*)$/)
      let triggers = mm ? mm[1] : args
      let rest = mm ? mm[2] : ""
      const actM = rest && /\{(.+)\}/.exec(rest)
      const action = actM ? actM[1].trim().split(/\s+/)[0] : "nothing"
      const actTime = actM ? actM[1].trim().split(/\s+/)[1] : null
      const reason = rest.replace(/\{.+\}/, "").trim()
      const items = triggers.replace(/^\(|\)$/g, "").split(",").map(s => s.trim().replace(/^["']|["']$/g, "")).filter(Boolean)
      const cur = gstore.arrGet("blocklist", chat)
      for (const it of items) {
        let mode = null, t = it
        const pm = it.match(/^(exact|lookalike):(.*)$/)
        if (pm) { mode = pm[1]; t = pm[2] }
        cur.push({ t, mode, reason, action, time: actTime, delete: true })
      }
      gstore.set("blocklist", chat, cur)
      return m.reply("🚫 " + tr("rose.blAdded") + " <b>" + items.length + "</b>", { parse_mode: "HTML" })
    }
    if (command === "blocklist" || command === "blocklistlist") {
      const cur = gstore.arrGet("blocklist", chat)
      if (!cur.length) return m.reply("🚫 <b>BLOCKLIST</b> — " + tr("rose.empty"), { parse_mode: "HTML" })
      let out = "🚫 <b>BLOCKLIST</b> (" + cur.length + ")\n\n"
      cur.forEach((x, i) => { out += `<code>${i + 1}</code>. ${esc(x.t)}${x.mode ? " (" + x.mode + ")" : ""}${x.action && x.action !== "nothing" ? " → " + esc(x.action) : ""}${x.reason ? " — " + esc(x.reason) : ""}\n` })
      return m.reply(out, { parse_mode: "HTML" })
    }
    if (command === "rmblocklist") {
      const cur = gstore.arrGet("blocklist", chat)
      const n = parseInt(args)
      const item = cur[n - 1]
      const t = item ? item.t : args.trim()
      gstore.set("blocklist", chat, cur.filter(x => x.t !== t))
      return m.reply("✅ " + tr("rose.blRemoved") + " <code>" + esc(t) + "</code>", { parse_mode: "HTML" })
    }
    if (command === "rmblocklistall") {
      gstore.set("blocklist", chat, [])
      return m.reply("✅ " + tr("rose.blCleared"), { parse_mode: "HTML" })
    }
    if (command === "blocklistmode") {
      const mode = args.toLowerCase().split(/\s+/)[0]
      if (!["nothing", "warn", "kick", "ban", "mute", "tmute", "tban"].includes(mode)) return m.reply("⚠️ nothing|warn|kick|ban|mute|tmute|tban", { parse_mode: "HTML" })
      const cur = gstore.arrGet("blocklist", chat).map(x => ({ ...x, action: mode }))
      gstore.set("blocklist", chat, cur)
      return m.reply("✅ " + tr("rose.blMode") + " <b>" + esc(mode) + "</b>", { parse_mode: "HTML" })
    }
    if (command === "blocklistdelete") {
      /* apakah pesan pelanggar blocklist dihapus (default: ya) */
      const on = !/^off$/i.test(args)
      gstore.set("blocklist", chat + ":delete", on)
      return m.reply("🗑 <b>blocklistdelete</b>: " + (on ? "ON ✅" : "OFF ❌"), { parse_mode: "HTML" })
    }
    if (command === "raidactiontime") {
      /* durasi aksi antiraid (mute/ban saat raid) */
      const t = parseTime(args)
      if (!t) return m.reply("⚠️ <code>" + px + "raidactiontime 1h</code>", { parse_mode: "HTML" })
      gstore.set("antiraid", chat + ":actiontime", args.trim())
      return m.reply("✅ RAID ACTION TIME: <b>" + esc(args.trim()) + "</b>", { parse_mode: "HTML" })
    }

    /* ═══ 1.12 ANTIFLOOD ═══ */
    if (command === "setflood") {
      const n = parseInt(args)
      if (!n || n < 3) return m.reply("⚠️ <code>" + px + "setflood 5</code>", { parse_mode: "HTML" })
      const cfg = gstore.get("antiflood", chat, {})
      cfg.limit = n; cfg.mode = cfg.mode || "tmute"
      gstore.set("antiflood", chat, cfg)
      return m.reply("🌊 " + tr("rose.floodSet") + " <b>" + n + "</b>", { parse_mode: "HTML" })
    }
    if (command === "setfloodtimer") {
      const p = args.split(/\s+/)
      const n = parseInt(p[0]), t = parseTime(p[1])
      if (!n || !t) return m.reply("⚠️ <code>" + px + "setfloodtimer 5 10s</code>", { parse_mode: "HTML" })
      const cfg = gstore.get("antiflood", chat, {})
      cfg.limit = n; cfg.timer = true; cfg.timerSec = t
      gstore.set("antiflood", chat, cfg)
      return m.reply("🌊 " + tr("rose.floodTimerSet") + " <b>" + n + "/" + t + "s</b>", { parse_mode: "HTML" })
    }
    if (command === "setfloodmode") {
      const p = args.split(/\s+/)
      const mode = (p[0] || "").replace(/^s/, "").toLowerCase()
      if (!["kick", "ban", "mute", "tmute", "tban"].includes(mode)) return m.reply("⚠️ kick|ban|mute|tmute|tban", { parse_mode: "HTML" })
      const cfg = gstore.get("antiflood", chat, {})
      cfg.mode = mode; cfg.time = p[1] || null
      gstore.set("antiflood", chat, cfg)
      return m.reply("✅ " + tr("rose.floodMode") + " <b>" + esc(mode) + "</b>", { parse_mode: "HTML" })
    }
    if (command === "flood") {
      const cfg = gstore.get("antiflood", chat, {})
      return m.reply("🌊 <b>ANTIFLOOD</b>\n\n" + (cfg.limit ? tr("rose.floodLimit") + ": <b>" + cfg.limit + "</b>" + (cfg.timer ? " / " + cfg.timerSec + "s" : "") + "\n" + tr("rose.floodMode") + ": <b>" + esc(cfg.mode || "tmute") + "</b>" : tr("rose.off")), { parse_mode: "HTML" })
    }
    if (command === "antiflood") {
      if (/^(on|off)$/i.test(args)) {
        const cfg = gstore.get("antiflood", chat, {})
        cfg.on = args.toLowerCase() === "on"
        if (cfg.on && !cfg.limit) cfg.limit = 10
        gstore.set("antiflood", chat, cfg)
        return m.reply("🌊 <b>antiflood</b>: " + (cfg.on ? "ON ✅" : "OFF ❌"), { parse_mode: "HTML" })
      }
      const cfg = gstore.get("antiflood", chat, {})
      return m.reply("🌊 <b>ANTIFLOOD</b>\n" + tr("rose.status") + ": <b>" + (cfg.on === false ? "OFF ❌" : "ON ✅") + "</b>", { parse_mode: "HTML" })
    }

    /* ═══ 1.13 ANTIRAID ═══ */
    if (command === "antiraid") {
      if (/^(on|off)$/i.test(args)) {
        if (args.toLowerCase() === "on") gstore.set("antiraid", chat, { on: true, until: 0 })
        else gstore.set("antiraid", chat, { on: false, until: 0 })
        return m.reply("🛡️ ANTIRAID " + (args.toLowerCase() === "on" ? "ON" : "OFF"), { parse_mode: "HTML" })
      }
      const t = parseTime(args)
      if (!t) return m.reply("⚠️ <code>" + px + "antiraid on | " + px + "antiraid 3h</code>", { parse_mode: "HTML" })
      gstore.set("antiraid", chat, { on: true, until: Date.now() + t * 1000 })
      return m.reply("🛡️ ANTIRAID ON (" + esc(args) + ")", { parse_mode: "HTML" })
    }
    if (command === "raidtime") {
      const t = parseTime(args)
      if (!t) return m.reply("⚠️ <code>" + px + "raidtime 3h</code>", { parse_mode: "HTML" })
      const cfg = gstore.get("antiraid", chat, { on: true })
      cfg.until = Date.now() + t * 1000
      gstore.set("antiraid", chat, cfg)
      return m.reply("✅ " + tr("rose.done"), { parse_mode: "HTML" })
    }
    if (command === "autoantiraid") {
      if (/^off$/i.test(args)) { gstore.del("antiraid", chat + ":auto"); return m.reply("✅ AUTO-ANTIRAID OFF", { parse_mode: "HTML" }) }
      const n = parseInt(args)
      if (!n) return m.reply("⚠️ <code>" + px + "autoantiraid 10</code>", { parse_mode: "HTML" })
      gstore.set("antiraid", chat + ":auto", n)
      return m.reply("✅ AUTO-ANTIRAID: >" + n + " join → ON", { parse_mode: "HTML" })
    }

    /* ═══ 1.14 CAPTCHA ═══ */
    if (command === "captcha") {
      if (/^(on|off)$/i.test(args)) {
        gstore.set("captcha", chat + ":on", args.toLowerCase() === "on")
        return m.reply("🤖 CAPTCHA " + args.toUpperCase() + "\n" + tr("rose.captchaHint"), { parse_mode: "HTML" })
      }
      const mode = args.toLowerCase()
      if (["button", "text", "math", "text2"].includes(mode)) {
        gstore.set("captcha", chat + ":mode", mode)
        return m.reply("✅ CAPTCHA mode: <b>" + esc(mode) + "</b>", { parse_mode: "HTML" })
      }
      const on = gstore.get("captcha", chat + ":on", false)
      const mode2 = gstore.get("captcha", chat + ":mode", "button")
      return m.reply("🤖 <b>CAPTCHA</b>\n\n" + tgl(tr("rose.status"), on) + "\n" + tr("rose.mode") + ": <b>" + esc(mode2) + "</b>", { parse_mode: "HTML" })
    }
    if (command === "captchamode") {
      const mode = args.toLowerCase()
      if (!["button", "text", "math", "text2"].includes(mode)) return m.reply("⚠️ button | text | math | text2", { parse_mode: "HTML" })
      gstore.set("captcha", chat + ":mode", mode)
      return m.reply("✅ CAPTCHA mode: <b>" + esc(mode) + "</b>", { parse_mode: "HTML" })
    }
    if (command === "captchakick") {
      gstore.set("captcha", chat + ":kick", /^(on|1|true)$/i.test(args))
      return m.reply("✅ " + tr("rose.done"), { parse_mode: "HTML" })
    }

    return false
  } catch (e) {
    console.error("[roseadv]", command, e?.message)
    try { await m.reply("❌ " + esc(String(e?.message || e).slice(0, 120)), { parse_mode: "HTML" }) } catch {}
    return false
  }
}

handler.command = [
  "lock", "unlock", "locks", "locktypes", "lockwarns", "allowlist", "rmallowlist",
  "addblocklist", "blocklistadd", "blocklist", "blocklistlist", "rmblocklist", "rmblocklistall", "blocklistmode", "blocklistdelete",
  "antiflood",
  "setflood", "setfloodtimer", "setfloodmode", "flood",
  "antiraid", "raidtime", "raidactiontime", "autoantiraid",
  "captcha", "captchamode", "captchakick"
]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
