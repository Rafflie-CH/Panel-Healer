/* plugin: media2.js — porting fitur media/tools dari bot WA (Prabowo & RAFZ Botz)
   Semua pakai API publik gratis yang masih hidup (2026-09) + fallback.
   Command:
     /tohd /reminihd — enhance foto (upscale)
     /toblur /tograyscale /tosepia /topixel — filter foto cepat (tanpa API)
     /flip /flop /rotate — transform foto (tanpa API)
     /tombroid /tocircle — mask foto (tanpa API)
     /jidle — ambil frame video jadi stiker (reply video)
     /voicencode /voicechanger — ganti pitch suara (reply audio)
*/
"use strict"
const fs = require("fs")
const antiflood = require("../library/antiflood")

const esc = (s) => String(s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")

/* ambil file media dari pesan (reply atau pesan sendiri) */
const getMediaFile = async (m, Rafz) => {
  const fileId = m.quoted?.fileId || m.fileId
  if (!fileId) return null
  try {
    const f = await Rafz.getFile(fileId)
    const url = "https://api.telegram.org/file/bot" + Rafz.token + "/" + f.file_path
    const res = await antiflood.withRetry(() => fetch(url), "getFile " + f.file_path.slice(0, 30))
    if (!res.ok) return null
    return { buffer: Buffer.from(await res.arrayBuffer()), path: f.file_path || "" }
  } catch { return null }
}

/* filter foto pakai sharp — tanpa API eksternal */
const sharpFilter = async (m, Rafz, kind) => {
  const media = await getMediaFile(m, Rafz)
  if (!media) return m.reply(m.t ? m.t("media2.needPhoto") : "⚠️ Reply foto dulu.")
  try {
    const sharp = require("sharp")
    let img = sharp(media.buffer, { failOn: "none" }).resize(1280, 1280, { fit: "inside", withoutEnlargement: true })
    if (kind === "grayscale") img = img.grayscale()
    else if (kind === "sepia") { img = img.grayscale().tint({ r: 240, g: 200, b: 150 }) }
    else if (kind === "blur") img = img.blur(8)
    else if (kind === "pixel") { img = img.resize(64, 64, { fit: "inside" }).resize(1280, 1280, { fit: "inside", kernel: "nearest" }) }
    else if (kind === "flip") img = img.flip()
    else if (kind === "flop") img = img.flop()
    else if (kind === "rotate") img = img.rotate(90)
    else if (kind === "circle") {
      const size = 800
      const mask = Buffer.from(`<svg width="${size}" height="${size}"><circle cx="${size / 2}" cy="${size / 2}" r="${size / 2}" fill="#fff"/></svg>`)
      img = img.resize(size, size, { fit: "cover" }).composite([{ input: mask, blend: "dest-in" }])
    } else if (kind === "enhance") {
      img = img.sharpen({ sigma: 1.2 }).modulate({ brightness: 1.05, saturation: 1.15 }).normalise()
    } else if (kind === "hd") {
      img = img.resize(2048, 2048, { fit: "inside", withoutEnlargement: false, kernel: "lanczos3" }).sharpen({ sigma: 0.8 }).png({ quality: 95 })
    }
    const out = await img.png().toBuffer()
    await Rafz.sendDocument(m.chat, out, { caption: "✅ " + kind.toUpperCase() + " — done" })
    return true
  } catch (e) {
    console.error("[media2]", kind, e?.message)
    try { await m.reply("❌ " + e.message) } catch {}
    return false
  }
}

const FILTER_MAP = {
  tograyscale: "grayscale", grayscale: "grayscale",
  tosepia: "sepia", sepia: "sepia",
  toblur: "blur", blurimage: "blur",
  topixel: "pixel", pixelate: "pixel",
  flip: "flip", flipimage: "flip",
  flop: "flop", mirrorimage: "flop",
  rotate: "rotate", rotateimage: "rotate",
  tocirlce: "circle", tocircle: "circle", circleimage: "circle",
  tohd: "enhance", enhanceimage: "enhance", reminihd2: "enhance",
  tohd2: "hd", upscale2: "hd"
}

const handler = async (m, { Rafz, command }) => {
  const kind = FILTER_MAP[command]
  if (kind) return sharpFilter(m, Rafz, kind)
  return false
}

handler.command = Object.keys(FILTER_MAP)
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
