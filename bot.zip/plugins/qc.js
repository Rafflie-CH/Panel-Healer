/* plugin: qc.js — quote chat sticker (porting Prabowo MD / RafzBotz)
   /qc teks → gambar chat bubble jadi stiker
   /qc teks | nama → dengan nama
   /qc reply pesan → pakai teks pesan yang di-reply */

"use strict"
const https = require("https")
const http = require("http")
const sharp = require("sharp")

const getBuffer = (url, hdrs = {}) =>
  new Promise((resolve, reject) => {
    try {
      const follow = (u, depth = 0) => {
        if (depth > 5) return reject(new Error("Too many redirects"))
        const mod = u.startsWith("https") ? https : http
        const parsed = new URL(u)
        const req = mod.get({
          hostname: parsed.hostname,
          path: parsed.pathname + parsed.search,
          timeout: 60000,
          headers: { "User-Agent": "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/130 Mobile Safari/537.36", ...hdrs }
        }, (res) => {
          if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location)
            return follow(new URL(res.headers.location, u).href, depth + 1)
          if (res.statusCode !== 200) return reject(new Error(`HTTP ${res.statusCode}`))
          const chunks = []
          res.on("data", c => chunks.push(c))
          res.on("end", () => resolve(Buffer.concat(chunks)))
          res.on("error", reject)
        })
        req.on("error", reject)
        req.on("timeout", () => { req.destroy(); reject(new Error("Timeout")) })
      }
      follow(url)
    } catch (e) { reject(e) }
  })

const escapeXml = (s) =>
  String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;")

const wrapText = (text, maxChars) => {
  const words = String(text).split(/\s+/).filter(Boolean)
  const lines = []
  let line = ""
  for (const w of words) {
    if ((line + " " + w).trim().length > maxChars) {
      if (line) lines.push(line.trim())
      line = w
    } else {
      line = (line + " " + w).trim()
    }
  }
  if (line) lines.push(line.trim())
  return lines.length ? lines.slice(0, 12) : [""]
}

/* render bubble chat lokal via sharp+SVG (selalu jalan, tanpa API) */
const makeQcCanvas = async (text, name, color) => {
  const lines = wrapText(text, 22)
  const fontSize = 34
  const lineHeight = fontSize + 12
  const W = 512
  const pad = 30
  const nameH = name ? 44 : 0
  const H = Math.max(220, nameH + lines.length * lineHeight + pad * 2 + 30)

  let tspans = ""
  lines.forEach((ln, i) => {
    tspans += `<text x="${pad + 20}" y="${nameH + pad + fontSize + i * lineHeight}" font-family="sans-serif" font-size="${fontSize}" fill="white">${escapeXml(ln)}</text>`
  })

  const avatarInitial = (name || "R").trim().charAt(0).toUpperCase()
  const svg =
    `<svg width="${W}" height="${H}" xmlns="http://www.w3.org/2000/svg">` +
    `<rect width="${W}" height="${H}" fill="#1a1a2e"/>` +
    (name ? `<circle cx="${pad + 20}" cy="${pad + 10}" r="18" fill="${color}"/>` +
      `<text x="${pad + 20}" y="${pad + 17}" font-family="sans-serif" font-size="20" font-weight="bold" fill="white" text-anchor="middle">${escapeXml(avatarInitial)}</text>` +
      `<text x="${pad + 50}" y="${pad + 18}" font-family="sans-serif" font-size="26" font-weight="bold" fill="${color}">${escapeXml(name)}</text>` : "") +
    `<rect x="${pad}" y="${nameH + pad - 14}" width="${W - pad * 2}" height="${lines.length * lineHeight + 24}" rx="18" fill="${color}"/>` +
    tspans +
    `<text x="${W - pad - 6}" y="${H - 12}" font-family="sans-serif" font-size="16" fill="#ffffff88" text-anchor="end">${new Date().toLocaleTimeString("id-ID", { hour: "2-digit", minute: "2-digit" })} ✓✓</text>` +
    `</svg>`

  return sharp({
    create: { width: W, height: H, channels: 4, background: { r: 26, g: 26, b: 46, alpha: 1 } }
  }).composite([{ input: Buffer.from(svg), top: 0, left: 0 }]).png().toBuffer()
}

const COLORS = ["#7c4dff", "#00bfa5", "#ff7043", "#42a5f5", "#ec407a", "#66bb6a", "#ffa726"]

const handler = async (m, { Rafz, command, text }) => {
  try {
    if (command !== "qc" && command !== "quotec" && command !== "chatquote") return false

    const px = (global.prefix && global.prefix[0]) || "/"
    const tr = (key, vars) => (m.t ? m.t(key, vars) : key)
    let body = (text || "").trim()
    let name = null
    if (!body && m.quoted?.text) body = m.quoted.text
    if (!body)
      return m.reply(`${tr("use.usage")} <code>${px}qc ${tr("qc.usage")}</code>`, { parse_mode: "HTML" })

    const parts = body.split("|").map(s => s.trim())
    if (parts.length >= 2 && parts[1]) { name = parts[1].slice(0, 20); body = parts[0] }
    body = body.slice(0, 300)
    const color = COLORS[Math.floor(Math.random() * COLORS.length)]

    const wait = await m.reply(tr("qc.making"), { parse_mode: "HTML" })
    try {
      let png = await makeQcCanvas(body, name, color)
      /* jadi stiker: pastikan 512 max (extend kalau tinggi > 512) */
      const meta = await sharp(png).metadata()
      if (meta.height > 512) {
        png = await sharp(png)
          .resize(512, 512, { fit: "contain", background: { r: 26, g: 26, b: 46, alpha: 0 } })
          .png({ compressionLevel: 9 }).toBuffer()
      } else if (meta.width !== 512) {
        png = await sharp(png)
          .resize(512, null, { withoutEnlargement: false })
          .png({ compressionLevel: 9 }).toBuffer()
      }

      try { Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {}) } catch {}
      await Rafz.sendSticker(m.chat, png, {
        reply_to_message_id: m.id, allow_sending_without_reply: true
      })
      return true
    } catch (e) {
      try { Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {}) } catch {}
      return m.reply(tr("qc.fail") + ": " + (e?.message || e))
    }
  } catch (e) {
    console.error("[qc]", e?.message)
    try { await m.reply("⚠️ Error: " + (e?.message || e)) } catch {}
    return false
  }
}

handler.command = ["qc", "quotec", "chatquote"]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
