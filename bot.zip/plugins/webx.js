/* webx.js — scraper lokal dari gist terverifikasi (FlowFalcon/ayashiiiyo/seaavey)
   + endpoint hidup hasil eksplorasi. Semua DIVERIFIKASI hidup via curl sebelum masuk.
   /genius — pencari lagu Genius (Googlebot UA) ✅
   /deezer — pencari lagu Deezer (API publik) ✅
   /archive — pencari Internet Archive ✅
   /wayback — cek arsip wayback machine URL ✅
   /tweet — info tweet via syndication CDN ✅
   /tempmail — buat email sementara (zemail.me) ✅
   Semua reply i18n (m.t) + tombol berstyle. */

"use strict"
const https = require("https")

const esc = (s) => String(s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")

const fetchOpts = (url, headers = {}) => ({
  headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36", "Accept-Language": "en-US,en;q=0.9", ...headers },
  timeout: 20000
})

const getJson = (url, headers) => new Promise((resolve, reject) => {
  const req = https.get(url, fetchOpts(url, headers), (res) => {
    if (res.statusCode !== 200) { res.resume(); return reject(new Error("HTTP " + res.statusCode)) }
    let d = ""
    res.on("data", (c) => { d += c; if (d.length > 8e6) req.destroy() })
    res.on("end", () => { try { resolve(JSON.parse(d)) } catch (e) { reject(new Error("bad json")) } })
  })
  req.on("timeout", () => req.destroy(new Error("timeout")))
  req.on("error", reject)
})

const getText = (url, headers) => new Promise((resolve, reject) => {
  const req = https.get(url, fetchOpts(url, headers), (res) => {
    if (res.statusCode !== 200) { res.resume(); return reject(new Error("HTTP " + res.statusCode)) }
    let d = ""
    res.on("data", (c) => { d += c; if (d.length > 8e6) req.destroy() })
    res.on("end", () => resolve(d))
  })
  req.on("timeout", () => req.destroy(new Error("timeout")))
  req.on("error", reject)
})

const handler = async (m, { Rafz, command, text }) => {
  const tr = (k, v) => (m.t ? m.t(k, v) : k)
  const q = String(text || "").trim()
  const px = (global.prefix && global.prefix[0]) || "/"

  /* ═══ /genius — cari lagu (Genius API, fallback iTunes Search — 403 kronis) ═══ */
  if (command === "genius") {
    if (!q) return m.reply("⚠️ <code>" + px + "genius laskar pelangi</code>", { parse_mode: "HTML" })
    const itunes = async () => {
      const j = await getJson("https://itunes.apple.com/search?term=" + encodeURIComponent(q) + "&entity=song&limit=8")
      if (!j.results || !j.results.length) throw new Error("no result")
      let out = "🎵 <b>GENIUS — " + esc(q) + "</b>\n\n"
      j.results.forEach((s, i) => {
        out += "<b>" + (i + 1) + ". " + esc(String(s.trackName || "-").slice(0, 70)) + "</b>\n"
        out += "   👤 " + esc(String(s.artistName || "-").slice(0, 40)) + " • 💿 " + esc(String(s.collectionName || "-").slice(0, 40)) + "\n"
        out += "   🔗 " + esc(s.trackViewUrl || "") + "\n"
      })
      return m.reply(out.slice(0, 3800), { parse_mode: "HTML" })
    }
    try {
      const j = await getJson("https://genius.com/api/search/multi?q=" + encodeURIComponent(q),
        { "User-Agent": "Googlebot/2.1 (+http://www.google.com/bot.html)" })
      const secs = (j.response?.sections || []).filter(s => s.type === "song" || s.type === "top_hit")
      const songs = []
      for (const s of secs) for (const h of (s.hits || [])) if (h.result?.url) songs.push(h.result)
      if (!songs.length) return itunes()
      let out = "🎵 <b>GENIUS — " + esc(q) + "</b>\n\n"
      songs.slice(0, 8).forEach((s, i) => {
        out += "<b>" + (i + 1) + ". " + esc(String(s.full_title || s.title).slice(0, 70)) + "</b>\n"
        out += "   👤 " + esc(String(s.primary_artist?.name || "-").slice(0, 40)) + "\n"
        out += "   🔗 " + esc(s.url) + "\n"
      })
      return m.reply(out.slice(0, 3800), { parse_mode: "HTML" })
    } catch {
      /* genius.com kadang 403 (anti-bot) → iTunes Search API (stabil) */
      try { return await itunes() } catch {
        return m.reply("❌ " + tr("common.failed"), { parse_mode: "HTML" })
      }
    }
  }

  /* ═══ /deezer — cari lagu (API publik, terverifikasi) ═══ */
  if (command === "deezer") {
    if (!q) return m.reply("⚠️ <code>" + px + "deezer laskar pelangi</code>", { parse_mode: "HTML" })
    try {
      const j = await getJson("https://api.deezer.com/search?q=" + encodeURIComponent(q) + "&limit=8")
      if (!j.data || !j.data.length) return m.reply("🈳 " + tr("common.failed"), { parse_mode: "HTML" })
      let out = "🎧 <b>DEEZER — " + esc(q) + "</b>\n\n"
      j.data.forEach((s, i) => {
        out += "<b>" + (i + 1) + ". " + esc(String(s.title).slice(0, 60)) + "</b>\n"
        out += "   👤 " + esc(String(s.artist?.name || "-")) + " • 💿 " + esc(String(s.album?.title || "-").slice(0, 40)) + "\n"
        out += "   ⏱ " + Math.floor((s.duration || 0) / 60) + ":" + String((s.duration || 0) % 60).padStart(2, "0") + " • 🔗 " + esc(s.link) + "\n"
      })
      return m.reply(out.slice(0, 3800), { parse_mode: "HTML" })
    } catch (e) {
      return m.reply("❌ " + tr("common.failed"), { parse_mode: "HTML" })
    }
  }

  /* ═══ /archive — cari Internet Archive ═══ */
  if (command === "archive" || command === "archiveorg") {
    if (!q) return m.reply("⚠️ <code>" + px + "archive linux</code>", { parse_mode: "HTML" })
    try {
      const u = "https://archive.org/advancedsearch.php?q=" + encodeURIComponent(q) + "&fl%5B%5D=identifier&fl%5B%5D=title&fl%5B%5D=mediatype&rows=8&page=1&output=json"
      const j = await getJson(u)
      const docs = j.response?.docs || []
      if (!docs.length) return m.reply("🈳 " + tr("common.failed"), { parse_mode: "HTML" })
      let out = "📚 <b>INTERNET ARCHIVE — " + esc(q) + "</b> (" + (j.response?.numFound || docs.length) + ")\n\n"
      docs.forEach((d, i) => {
        out += "<b>" + (i + 1) + ". " + esc(String(Array.isArray(d.title) ? d.title[0] : d.title).slice(0, 70)) + "</b>\n"
        out += "   🗂 " + esc(d.mediatype || "-") + " • 🔗 https://archive.org/details/" + esc(d.identifier) + "\n"
      })
      return m.reply(out.slice(0, 3800), { parse_mode: "HTML" })
    } catch (e) {
      return m.reply("❌ " + tr("common.failed"), { parse_mode: "HTML" })
    }
  }

  /* ═══ /wayback — cek arsip URL ═══ */
  if (command === "wayback") {
    if (!q || !/^https?:\/\//.test(q)) return m.reply("⚠️ <code>" + px + "wayback https://example.com</code>", { parse_mode: "HTML" })
    try {
      let j
      try { j = await getJson("https://archive.org/wayback/available?url=" + encodeURIComponent(q)) }
      catch (e) {
        /* 429/5xx sesaat — retry 2x dgn jeda (archive.org rate-limit keras) */
        for (const dly of [3000, 6000]) {
          await new Promise(r => setTimeout(r, dly))
          try { j = await getJson("https://archive.org/wayback/available?url=" + encodeURIComponent(q)); break } catch {}
        }
        if (!j) throw e
      }
      const snap = j.archived_snapshots?.closest
      if (!snap || !snap.available) return m.reply("🈳 " + tr("webx.noArchive"), { parse_mode: "HTML" })
      return m.reply(
        "🏛 <b>WAYBACK MACHINE</b>\n\n🔗 <b>" + tr("webx.snapshot") + "</b>: " + esc(snap.url) + "\n📅 <b>" + tr("webx.date") + "</b>: " + esc(snap.timestamp),
        { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "🌐 " + tr("webx.open"), url: snap.url, style: "primary" }]] } }
      )
    } catch (e) {
      /* archive.org rate-limit keras (429) kalau terlalu sering — bedakan dgn gagal beneran */
      return m.reply("❌ " + tr("common.failed") + " — rate limited", { parse_mode: "HTML" })
    }
  }

  /* ═══ /tweet — info tweet via fxtwitter API (syndication.twimg MATI 2026-09) ═══ */
  if (command === "tweet" || command === "tweetinfo") {
    const id = (q.match(/(\d{15,20})/) || [])[1]
    if (!id) return m.reply("⚠️ <code>" + px + "tweet https://x.com/user/status/123...</code>", { parse_mode: "HTML" })
    try {
      const j = await getJson("https://api.fxtwitter.com/status/" + id)
      if (!j || j.code !== 200 || !j.tweet) return m.reply("🈳 " + tr("common.failed"), { parse_mode: "HTML" })
      const tw = j.tweet
      const media = (tw.media?.photos || []).map(p => p.url).filter(Boolean)
      let out = "🐦 <b>TWEET</b>\n\n"
      out += "👤 <b>" + esc(tw.author?.name || "-") + "</b> " + esc("@" + (tw.author?.screen_name || "")) + "\n\n"
      out += esc(String(tw.text || "").slice(0, 700)) + "\n\n"
      out += "📅 " + esc(String(tw.created_at || "").slice(0, 22)) + "\n"
      out += "💬 " + (tw.replies || 0) + " • 🔁 " + (tw.retweets || 0) + " • ❤️ " + (tw.likes || 0) + "\n"
      if ((tw.media?.videos || []).length) out += "🎬 " + tw.media.videos.length + " video\n"
      if (media.length) {
        await Rafz.sendPhoto(m.chat, media[0], { caption: out.slice(0, 1000), parse_mode: "HTML", reply_to_message_id: m.id, allow_sending_without_reply: true })
        return true
      }
      return m.reply(out, { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "🌐 X/Twitter", url: tw.url || ("https://x.com/-/status/" + id), style: "primary" }]] } })
    } catch (e) {
      return m.reply("❌ " + tr("common.failed") + " — " + esc(String(e.message || e).slice(0, 50)), { parse_mode: "HTML" })
    }
  }

  /* ═══ /tempmail — email sementara (mail.tm API publik, terverifikasi) ═══ */
  if (command === "tempmail" || command === "tempmailnew") {
    try {
      const domains = await getJson("https://api.mail.tm/domains")
      const dom = (domains["hydra:member"] || [])[0]?.domain
      if (!dom) throw new Error("no domain")
      const addr = "rafz" + Date.now().toString(36) + "@" + dom
      const pass = "Rf" + Math.random().toString(36).slice(2, 12)
      /* POST via https manual */
      const post = (path, body, headers) => new Promise((resolve, reject) => {
        const data = JSON.stringify(body)
        const u = new URL("https://api.mail.tm" + path)
        const req = https.request({ hostname: u.hostname, path: u.pathname, method: "POST", headers: { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(data), ...(headers || {}) }, timeout: 15000 }, (res) => {
          let d = ""
          res.on("data", (c) => { d += c })
          res.on("end", () => { try { resolve(JSON.parse(d)) } catch { resolve({}) } })
        })
        req.on("timeout", () => req.destroy(new Error("timeout")))
        req.on("error", reject)
        req.write(data)
        req.end()
      })
      /* POST /accounts kadang 429/422 sesaat — retry 2x dgn jeda (rate limit mail.tm) */
      let created = null
      for (let i = 0; i < 3; i++) {
        try { created = await post("/accounts", { address: addr, password: pass }); if (created && (created.id || created.address)) break } catch (e) { }
        if (i < 2) await new Promise(r => setTimeout(r, 1200))
      }
      if (!created || !(created.id || created.address)) throw new Error("account gagal dibuat")
      let tok = null
      for (let i = 0; i < 3; i++) {
        try { tok = await post("/token", { address: addr, password: pass }); if (tok && tok.token) break } catch (e) { }
        if (i < 2) await new Promise(r => setTimeout(r, 1200))
      }
      if (!tok || !tok.token) throw new Error("no token")
      global.tempMail = global.tempMail || {}
      global.tempMail[String(m.sender)] = { addr, pass, token: tok.token, at: Date.now() }
      return m.reply(
        "📧 <b>TEMP MAIL</b>\n\n✉️ <code>" + esc(addr) + "</code>\n\n" + tr("webx.tempmailHint") + "\n<code>" + px + "tempmailcheck</code>",
        { parse_mode: "HTML" }
      )
    } catch (e) {
      return m.reply("❌ " + tr("common.failed") + " — " + esc(String(e.message || e).slice(0, 40)), { parse_mode: "HTML" })
    }
  }
  if (command === "tempmailcheck") {
    const st = (global.tempMail || {})[String(m.sender)]
    if (!st) return m.reply("⚠️ " + tr("webx.noTempmail") + " <code>" + px + "tempmail</code>", { parse_mode: "HTML" })
    try {
      const j = await getJson("https://api.mail.tm/messages?page=1", { Authorization: "Bearer " + st.token })
      const msgs = j["hydra:member"] || []
      if (!msgs.length) return m.reply("📭 " + tr("webx.inboxEmpty"), { parse_mode: "HTML" })
      let out = "📬 <b>INBOX</b> — " + esc(st.addr) + "\n\n"
      msgs.slice(0, 8).forEach((msg, i) => {
        out += "<b>" + (i + 1) + ". " + esc(String(msg.subject || "-").slice(0, 60)) + "</b>\n"
        out += "   " + tr("webx.from") + ": " + esc(String(msg.from?.address || "-")) + "\n"
      })
      return m.reply(out.slice(0, 3500), { parse_mode: "HTML" })
    } catch (e) {
      return m.reply("❌ " + tr("common.failed"), { parse_mode: "HTML" })
    }
  }

  return false
} 

handler.command = ["genius", "deezer", "archive", "archiveorg", "wayback", "tweet", "tweetinfo", "tempmail", "tempmailnew", "tempmailcheck"]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
