"use strict"
const https = require("https")
const http = require("http")

const UA = "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/130 Mobile Safari/537.36"

const getBuffer = (url, hdrs = {}) =>
  new Promise((resolve, reject) => {
    try {
      const follow = (u, depth = 0) => {
        if (depth > 5) return reject(new Error("Too many redirects"))
        const mod = u.startsWith("https") ? https : http
        const parsed = new URL(u)
        mod.get({ hostname: parsed.hostname, path: parsed.pathname + parsed.search, timeout: 30000, headers: { "User-Agent": UA, ...hdrs } }, (res) => {
          if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) return follow(new URL(res.headers.location, u).href, depth + 1)
          if (res.statusCode !== 200) return reject(new Error("HTTP " + res.statusCode))
          const c = []
          res.on("data", d => c.push(d))
          res.on("end", () => resolve(Buffer.concat(c)))
          res.on("error", reject)
        }).on("error", reject).on("timeout", function () { this.destroy(); reject(new Error("Timeout")) })
      }
      follow(url)
    } catch (e) { reject(e) }
  })

const getJSON = async (url, hdrs = {}) => {
  const buf = await getBuffer(url, { "Accept": "application/json", ...hdrs })
  try { return JSON.parse(buf.toString("utf8")) } catch { throw new Error("Invalid JSON") }
}

const pick = (arr) => arr[Math.floor(Math.random() * arr.length)]

const handler = async (m, { Rafz, command, text }) => {
  try {
    const px = (global.prefix && global.prefix[0]) || "/"
    const q = (text || "").trim()
    const parts = q.split(",").map(s => s.trim())
    const rnd = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min
    const bar = (v) => "\u2588".repeat(Math.round(v / 10)) + "\u2591".repeat(10 - Math.round(v / 10))

    if (command === "artimimpi" || command === "tafsirmimpi") {
      if (!q) return m.reply("Penggunaan: " + px + "artimimpi belanja")
      return m.reply("Mimpi: " + q + "\nArti: " + pick([
        "Melambangkan keinginan yang belum tercapai",
        "Simbol dari perubahan hidup yang akan datang",
        "Pertanda akan mendapat kabar baik",
        "Menggambarkan kekhawatiran yang terpendam",
        "Tanda akan mendapatkan rezeki tak terduga"
      ]))
    }

    if (command === "ramalanjodoh" || command === "ramaljodoh") {
      if (parts.length < 8) return m.reply("Format: " + px + "ramalanjodoh Nama1, Tgl1, Bln1, Thn1, Nama2, Tgl2, Bln2, Thn2")
      const [n1, t1, b1, y1, n2, t2, b2, y2] = parts
      const score = rnd(55, 95)
      return m.reply(
        "<b>RAMALAN JODOH</b>\n\n" +
        "Nama Anda: " + n1 + " (" + t1 + "/" + b1 + "/" + y1 + ")\n" +
        "Nama Pasangan: " + n2 + " (" + t2 + "/" + b2 + "/" + y2 + ")\n\n" +
        "Kecocokan: " + bar(score) + " " + score + "%\n" +
        "Hasil: " + (score > 80 ? "Sangat cocok! Pertahankan" : score > 60 ? "Cocok, perlu komunikasi lebih" : "Perlu usaha lebih")
      )
    }

    if (command === "ramalanjodohbali" || command === "ramaljodohbali") {
      if (parts.length < 8) return m.reply("Format: " + px + "ramalanjodohbali Nama1, Tgl1, Bln1, Thn1, Nama2, Tgl2, Bln2, Thn2")
      const [n1, t1, b1, y1, n2, t2, b2, y2] = parts
      const score = rnd(60, 90)
      return m.reply("<b>RAMALAN JODOH (BALI)</b>\n\n" + n1 + " & " + n2 + "\nKecocokan: " + score + "%\n" + (score > 75 ? "Sangat baik menurut hitungan Bali" : "Cukup baik"))
    }

    if (command === "suamiistri") {
      if (parts.length < 8) return m.reply("Format: " + px + "suamiistri Nama1, Tgl, Bln, Thn, Nama2, Tgl, Bln, Thn")
      const [n1, t1, b1, y1, n2, t2, b2, y2] = parts
      const score = rnd(50, 95)
      return m.reply("<b>SUAMI ISTRI</b>\n\nSuami: " + n1 + "\nIstri: " + n2 + "\nKecocokan rumah tangga: " + score + "%")
    }

    if (command === "ramalancinta" || command === "ramalcinta") {
      if (parts.length < 8) return m.reply("Format: " + px + "ramalancinta Nama1, Tgl, Bln, Thn, Nama2, Tgl, Bln, Thn")
      const [n1, , , , n2] = parts
      const score = rnd(45, 100)
      return m.reply(
        "<b>RAMALAN CINTA</b>\n\n" + n1 + " \u2764 " + n2 + "\n" + bar(score) + " " + score + "%\n\n" +
        "Positif: " + pick(["Setia", "Pengertian", "Romantis"]) + "\n" +
        "Negatif: " + pick(["Cemburuan", "Pendiam", " sensitif"])
      )
    }

    if (command === "artinama") {
      if (!q) return m.reply("Penggunaan: " + px + "artinama Dika")
      return m.reply("Nama: " + q + "\nArti: " + pick([
        "Pemilik nama ini cenderung pintar dan mudah bergaul",
        "Pemilik nama ini kuat dan tak mudah menyerah",
        "Pemilik nama ini penyayang dan setia",
        "Pemilik nama ini kreatif dan berjiwa pemimpin"
      ]))
    }

    if (command === "kecocokanpasangan" || command === "cocokpasangan") {
      const names = q.split("|").map(s => s.trim())
      if (names.length < 2) return m.reply("Format: " + px + "kecocokanpasangan Nama1|Nama2")
      const score = rnd(40, 100)
      return m.reply("<b>KECOCOKAN PASANGAN</b>\n\n" + names[0] + " \u2764 " + names[1] + "\n" + bar(score) + " " + score + "%")
    }

    if (command === "zodiak" || command === "zodiac") {
      if (!q) return m.reply("Contoh: " + px + "zodiak libra\n\nZodiak: aquarius pisces aries taurus gemini cancer leo virgo libra scorpio sagittarius capricorn")
      const zodiacInfo = {
        aquarius: "20 Jan - 18 Feb | Elemen: Udara", pisces: "19 Feb - 20 Mar | Elemen: Air",
        aries: "21 Mar - 19 Apr | Elemen: Api", taurus: "20 Apr - 20 Mei | Elemen: Tanah",
        gemini: "21 Mei - 20 Jun | Elemen: Udara", cancer: "21 Jun - 22 Jul | Elemen: Air",
        leo: "23 Jul - 22 Agu | Elemen: Api", virgo: "23 Agu - 22 Sep | Elemen: Tanah",
        libra: "23 Sep - 22 Okt | Elemen: Udara", scorpio: "23 Okt - 21 Nov | Elemen: Air",
        sagittarius: "22 Nov - 21 Des | Elemen: Api", capricorn: "22 Des - 19 Jan | Elemen: Tanah"
      }
      const z = q.toLowerCase()
      if (!zodiacInfo[z]) return m.reply("Zodiak tidak ditemukan")
      return m.reply("<b>ZODIAK " + z.toUpperCase() + "</b>\n" + zodiacInfo[z] + "\n\nRamalan hari ini: " + pick(["Beruntung", "Hati-hati", "Sangat baik", "Biasa saja"]))
    }

    if (command === "shio") {
      if (!q) return m.reply("Contoh: " + px + "shio tikus\n\nShio: tikus kerbau macan kelinci naga ular kuda kambing monkon ayam anjing babi")
      const shioInfo = {
        tikus: "Cerdas, adaptif, energik", kerbau: "Pekerja keras, dapat diandalkan",
        macan: "Berani, kompetitif", kelinci: "Penuh perhatian, sopan",
        naga: "Percaya diri, karismatik", ular: "Bijaksana, misterius",
        kuda: "Bebas, energik", kambing: "Kreatif, lembut",
        monyet: "Cerdas, lucu", ayam: "Terorganisir, teliti",
        anjing: "Setia, jujur", babi: "Murah hati, santai"
      }
      const s = q.toLowerCase()
      if (!shioInfo[s]) return m.reply("Shio tidak ditemukan")
      return m.reply("<b>SHIO " + s.toUpperCase() + "</b>\nSifat: " + shioInfo[s] + "\nKeberuntungan hari ini: " + rnd(50, 95) + "%")
    }

    if (command === "weton" || command === "wetonjawa") {
      if (parts.length < 3) return m.reply("Format: " + px + "weton Tgl, Bln, Thn")
      const wetonDays = ["Legi", "Pahing", "Pon", "Wage", "Kliwon"]
      const w = wetonDays[rnd(0, 4)]
      const neptu = rnd(1, 9) + rnd(1, 9)
      return m.reply("<b>WETON JAWA</b>\nTanggal: " + parts.join("/") + "\nWeton: " + w + "\nNeptu: " + neptu + "\nSifat: " + pick(["Pekerja keras", "Sabar", "Penuh perhatian", "Cerdas"]))
    }

    return false
  } catch (e) {
    console.error("[primbon]", e?.message)
    try { await m.reply("Error: " + (e?.message || e)) } catch {}
    return false
  }
}

handler.command = ["artimimpi", "tafsirmimpi", "ramalanjodoh", "ramaljodoh", "ramalanjodohbali", "ramaljodohbali", "suamiistri", "ramalancinta", "ramalcinta", "artinama", "kecocokanpasangan", "cocokpasangan", "zodiak", "zodiac", "shio", "weton", "wetonjawa"]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
