/* plugin: uploader.js - upload file ke host */
"use strict"
const fs = require("fs")
const path = require("path")
const https = require("https")
const http = require("http")
const FormData = require("form-data")
const axios = require("axios")
const { fromBuffer } = require("file-type")

const uploadCatbox = async (buf) => {
  try {
    const { ext } = await fromBuffer(buf)
    const formData = new FormData()
    formData.append("reqtype", "fileupload")
    formData.append("fileToUpload", buf, { filename: "file." + (ext || "bin") })
    const res = await axios.post("https://catbox.moe/user/api.php", formData, {
      headers: formData.getHeaders(), timeout: 30000
    })
    return res.data
  } catch (e) { return null }
}

const handler = async (m, { Rafz, command, text }) => {
  try {
    const sender = String(m.sender)
    const isOwner = (global.owner || []).includes(sender)
    if (!isOwner) return m.reply("Hanya owner yang bisa upload.")

    if (command === "uploadscript" || command === "upl") {
      const archiver = require("archiver")
      const tmpPath = "./tmp_bot_backup_" + Date.now() + ".zip"
      try {
        await new Promise((resolve, reject) => {
          const output = fs.createWriteStream(tmpPath)
          const archive = archiver("zip", { zlib: { level: 9 } })
          output.on("close", resolve)
          archive.on("error", reject)
          archive.pipe(output)
          archive.directory("./", false, (entry) => {
            if (entry.name.startsWith("node_modules/") || entry.name.startsWith("session/") || entry.name.startsWith("tmp_") || entry.name.includes("clones/")) return false
            return entry
          })
          archive.finalize()
        })

        const buf = fs.readFileSync(tmpPath)
        const link = await uploadCatbox(buf)
        fs.unlinkSync(tmpPath)

        if (link) return m.reply("Script uploaded: <code>" + link + "</code>", { parse_mode: "HTML" })
        return m.reply("Upload gagal.")
      } catch (e) {
        try { fs.unlinkSync(tmpPath) } catch {}
        return m.reply("Error: " + e.message)
      }
    }

    return false
  } catch (e) {
    console.error("[uploader]", e?.message)
    try { await m.reply("Error: " + (e?.message || e)) } catch {}
    return false
  }
}

handler.command = ["uploadscript", "upl"]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
