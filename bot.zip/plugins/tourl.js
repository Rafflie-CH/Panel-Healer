/* plugin: tourl.js — upload media ke 10 host (multi-uploader)
   Urutan hasil: Qu.ax, TmpFiles, Put.icu, Termai, Uguu, Upload.ee,
   ImgBB, Pone.rs, Litterbox, Catbox.
   Semua uploader jalan paralel (Promise.allSettled) → cepat & anti gagal. */

"use strict"
const fs = require("fs")
const path = require("path")
const https = require("https")
const http = require("http")
const FormData = require("form-data")
const axios = require("axios")
const mimeTypes = require("mime-types")
const { fromBuffer } = require("file-type")
const cheerio = require("cheerio")

const termaiKey = "AIzaBj7z2z3xBjsk"
const termaiDomain = "https://c.termai.cc"
const imgbbApiKey = "06fd47f20c573d4795a47af91f081932"

/* ── download buffer dari URL (Telegram file) ── */
const getBuffer = (url) =>
  new Promise((resolve, reject) => {
    const follow = (u) => {
      try {
        const mod = u.startsWith("https") ? https : http
        const parsed = new URL(u)
        const req = mod.get({
          hostname: parsed.hostname,
          path: parsed.pathname + parsed.search,
          timeout: 90000,
          headers: {
            "User-Agent": "Mozilla/5.0 (Linux; Android 15; SM-F958) AppleWebKit/537.36 Chrome/130 Mobile Safari/537.36",
            "Accept": "*/*"
          }
        }, (res) => {
          if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location)
            return follow(new URL(res.headers.location, u).href)
          if (res.statusCode !== 200)
            return reject(new Error(`HTTP ${res.statusCode} dari ${parsed.hostname}`))
          const chunks = []
          res.on("data", c => chunks.push(c))
          res.on("end", () => resolve(Buffer.concat(chunks)))
          res.on("error", reject)
        })
        req.on("error", reject)
        req.on("timeout", () => { req.destroy(); reject(new Error("Download timeout")) })
      } catch (e) { reject(e) }
    }
    follow(url)
  })

/* ─────────── UPLOADER 1: Termai ─────────── */
async function uploadTermai(fileBuffer) {
  try {
    const { ext } = await fromBuffer(fileBuffer)
    const formData = new FormData()
    formData.append('file', fileBuffer, { filename: 'file.' + ext })
    const res = await axios.post(`${termaiDomain}/api/upload?key=${termaiKey}`, formData, {
      headers: formData.getHeaders(),
      timeout: 30000
    })
    if (res.data && res.data.status && res.data.path) return res.data.path
    throw new Error("Upload ke Termai gagal")
  } catch (err) {
    return null
  }
}

/* ─────────── UPLOADER 2: Pone.rs ─────────── */
async function uploadToPoneRs(fileBuffer) {
  try {
    const form = new FormData()
    form.append('files[]', fileBuffer, { filename: 'file.jpg' })
    const res = await axios.post('https://pone.rs/upload.php', form, {
      headers: {
        ...form.getHeaders(),
        'User-Agent': 'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36',
        'Referer': 'https://pone.rs/',
        'Origin': 'https://pone.rs'
      },
      maxBodyLength: Infinity,
      maxContentLength: Infinity,
      timeout: 30000
    })
    if (res.data?.success && res.data?.files?.[0]?.url) {
      return res.data.files[0].url.replace(/\\\//g, '/')
    }
    throw new Error("Upload ke pone.rs gagal")
  } catch (err) {
    return null
  }
}

/* ─────────── UPLOADER 3: Qu.ax ─────────── */
async function pomf2(filePath) {
  try {
    if (!fs.existsSync(filePath)) throw new Error("File tidak ditemukan")
    const contentType = mimeTypes.lookup(filePath) || "application/octet-stream"
    const fileName = path.basename(filePath)
    const form = new FormData()
    form.append("files[]", fs.createReadStream(filePath), {
      contentType,
      filename: fileName,
    })
    const response = await axios.post("https://qu.ax/upload.php", form, {
      headers: { ...form.getHeaders() },
      timeout: 30000
    })
    if (!response.data.success || !response.data.files?.length) throw new Error("Upload ke qu.ax gagal")
    return response.data.files[0].url
  } catch (err) {
    return null
  }
}

/* ─────────── UPLOADER 4: TmpFiles.org ─────────── */
async function uploadTmpFiles(filePath, expire = 172800) {
  try {
    if (!fs.existsSync(filePath)) throw new Error("File tidak ditemukan")
    const form = new FormData()
    form.append("file", fs.createReadStream(filePath))
    form.append("expire", expire)
    const res = await axios.post("https://tmpfiles.org/api/v1/upload", form, {
      headers: form.getHeaders(),
      timeout: 30000
    })
    if (res.data && res.data.status === "success") return res.data?.data?.url || null
    throw new Error("Upload ke tmpfiles.org gagal")
  } catch (err) {
    return null
  }
}

/* ─────────── UPLOADER 5: Put.icu ─────────── */
async function uploadPutIcu(filePath) {
  try {
    if (!fs.existsSync(filePath)) throw new Error("File tidak ditemukan")
    const contentType = mimeTypes.lookup(filePath) || "application/octet-stream"
    const res = await axios.put(`https://put.icu/upload/`, fs.createReadStream(filePath), {
      headers: {
        'Accept': 'application/json',
        'Content-Type': contentType
      },
      maxBodyLength: Infinity,
      maxContentLength: Infinity,
      timeout: 30000
    })
    if (res.data && res.data.direct_url) return res.data.direct_url
    if (res.data && res.data.url) return res.data.url
    throw new Error("Upload ke put.icu gagal")
  } catch (err) {
    return null
  }
}

/* ─────────── UPLOADER 6: Uguu.se ─────────── */
async function uploadUgu(filePath) {
  try {
    const form = new FormData()
    form.append("files[]", fs.createReadStream(filePath))
    const response = await axios.post("https://uguu.se/upload.php", form, {
      headers: {
        ...form.getHeaders(),
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
      },
      timeout: 30000
    })
    if (response.data && response.data.success && response.data.files && response.data.files[0]) {
      return response.data.files[0].url
    }
    throw new Error("Upload ke uguu.se gagal")
  } catch (err) {
    return null
  }
}

/* ─────────── UPLOADER 7: Upload.ee ─────────── */
async function uploadUploadEE(filePath) {
  try {
    const baseUrl = "https://www.upload.ee"
    const response = await axios.get(`${baseUrl}/ubr_link_upload.php?rnd_id=${Date.now()}`, { timeout: 30000 })
    const uploadId = (response.data.match(/startUpload\("(.+?)"/) || [])[1]
    if (!uploadId) throw new Error("Unable to obtain Upload ID")

    const formData = new FormData()
    formData.append("upfile_0", fs.createReadStream(filePath))
    formData.append("link", "")
    formData.append("email", "")
    formData.append("category", "cat_file")
    formData.append("big_resize", "none")
    formData.append("small_resize", "120x90")

    const uploadResponse = await axios.post(`${baseUrl}/cgi-bin/ubr_upload.pl?X-Progress-ID=${encodeURIComponent(uploadId)}&upload_id=${encodeURIComponent(uploadId)}`, formData, {
      headers: { ...formData.getHeaders(), Referer: baseUrl },
      timeout: 30000
    })

    const $ = cheerio.load(uploadResponse.data)
    const viewUrl = $("input#file_src").val() || ""
    if (!viewUrl) throw new Error("File upload failed")

    const viewResponse = await axios.get(viewUrl, { timeout: 30000 })
    const downUrl = cheerio.load(viewResponse.data)("#d_l").attr("href") || ""
    if (!downUrl) throw new Error("File upload failed")

    return downUrl
  } catch (error) {
    return null
  }
}

/* ─────────── UPLOADER 8: ImgBB ─────────── */
async function uploadToImgBB(filePath) {
  try {
    if (!fs.existsSync(filePath)) throw new Error("File not found")
    const form = new FormData()
    form.append('image', fs.createReadStream(filePath))
    const response = await axios.post(`https://api.imgbb.com/1/upload?key=${imgbbApiKey}`, form, {
      headers: { ...form.getHeaders() },
      timeout: 30000
    })
    if (response.status === 200 && response.data.data && response.data.data.url) {
      return response.data.data.url
    }
    throw new Error(`Upload failed with status: ${response.status}`)
  } catch (err) {
    return null
  }
}

/* ─────────── UPLOADER 9: Litterbox (72 jam) ─────────── */
async function uploadToLitterbox(fileBuffer, filename) {
  try {
    const form = new FormData()
    form.append('reqtype', 'fileupload')
    form.append('time', '72h')
    form.append('fileToUpload', fileBuffer, {
      filename: filename,
      contentType: mimeTypes.lookup(filename) || 'application/octet-stream'
    })
    const response = await axios.post('https://litterbox.catbox.moe/resources/internals/api.php', form, {
      headers: form.getHeaders(),
      timeout: 30000
    })
    if (response.status !== 200) throw new Error('Litterbox gagal')
    const url = response.data
    if (!url.startsWith('http')) throw new Error('Invalid response')
    return { host: 'Litterbox', url, expires: '72 jam' }
  } catch (err) {
    return null
  }
}

/* ─────────── UPLOADER 10: Catbox ( permanen, fallback terakhir ) ── */
const catboxUpload = async (buffer, filename, mimetype) => {
  let cookie = ""
  try {
    await new Promise((res) => {
      https.get({ hostname: "catbox.moe", path: "/", timeout: 10000,
        headers: { "User-Agent": "Mozilla/5.0 (Linux; Android 15; SM-F958) AppleWebKit/537.36 Chrome/130 Mobile Safari/537.36" }
      }, (r) => {
        cookie = (r.headers["set-cookie"] || []).join("; ")
        r.resume(); r.on("end", res)
      }).on("error", res)
    })
  } catch {}

  const boundary = "----FormBoundaryRAFZ" + Date.now().toString(36)
  const CRLF = "\r\n"
  const preamble = Buffer.from(
    `--${boundary}${CRLF}` +
    `Content-Disposition: form-data; name="userhash"${CRLF}${CRLF}${CRLF}` +
    `--${boundary}${CRLF}` +
    `Content-Disposition: form-data; name="reqtype"${CRLF}${CRLF}fileupload${CRLF}` +
    `--${boundary}${CRLF}` +
    `Content-Disposition: form-data; name="fileToUpload"; filename="${filename}"${CRLF}` +
    `Content-Type: ${mimetype}${CRLF}${CRLF}`
  )
  const epilogue = Buffer.from(`${CRLF}--${boundary}--${CRLF}`)
  const body = Buffer.concat([preamble, buffer, epilogue])

  return new Promise((resolve, reject) => {
    const req = https.request({
      hostname: "catbox.moe",
      path: "/user/api.php",
      method: "POST",
      timeout: 120000,
      headers: {
        "Content-Type": `multipart/form-data; boundary=${boundary}`,
        "Content-Length": body.length,
        "User-Agent": "Mozilla/5.0 (Linux; Android 15; SM-F958) AppleWebKit/537.36 Chrome/130 Mobile Safari/537.36",
        "origin": "https://catbox.moe",
        "referer": "https://catbox.moe/",
        ...(cookie ? { "cookie": cookie } : {})
      }
    }, (res) => {
      let d = ""
      res.on("data", c => d += c)
      res.on("end", () => {
        if (d.startsWith("https://")) resolve(d.trim())
        else reject(new Error("Catbox response: " + d.trim().slice(0, 100)))
      })
    })
    req.on("error", reject)
    req.on("timeout", () => { req.destroy(); reject(new Error("Upload timeout")) })
    req.write(body)
    req.end()
  })
}
const uploadCatbox = async (fileBuffer, filename, mimetype) => {
  try {
    return await catboxUpload(fileBuffer, filename || "file", mimetype || "application/octet-stream")
  } catch {
    return null
  }
}

/* ═════════════ MAIN HANDLER ═════════════ */
const handler = async (m, { Rafz }) => {
  try {
    const px = (global.prefix && global.prefix[0]) || "/"

    /* media bisa dari pesan sendiri (kirim file + caption /tourl) ATAU reply */
    const media = m.quoted?.fileId
      ? m.quoted
      : m.fileId
        ? { fileId: m.fileId, filename: m.filename, mimetype: m.mimetype, mediaType: m.mediaType }
        : null

    if (!media) {
      return m.reply(
        `⚠️ <b>Penggunaan:</b>\n` +
        `• Kirim foto/video/audio/file dengan caption <code>${px}tourl</code>\n` +
        `• Atau reply media dengan <code>${px}tourl</code>`,
        { parse_mode: "HTML" }
      )
    }

    const { fileId, filename, mimetype, mediaType } = media

    /* EDIT-ONLY: pesan "mengupload" diedit jadi hasil, tidak ada pesan baru */
    const wait = await m.reply(`⏳ Mengupload <b>${filename || "file"}</b> ke 10 host...`, { parse_mode: "HTML" })
    const editResult = async (text, opt = {}) => {
      try {
        if (wait?.message_id) {
          return await Rafz.editMessageText(text, {
            chat_id: m.chat,
            message_id: wait.message_id,
            parse_mode: "HTML",
            disable_web_page_preview: true,
            ...opt
          })
        }
      } catch (e) {
        if (String(e?.message || e).includes("not modified")) return null
      }
      return m.reply(text, opt)
    }
    const del = () => { try { Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {}) } catch {} }

    try {
      /* download dari Telegram */
      const fileInfo = await Rafz.getFile(fileId)
      const tgUrl = `https://api.telegram.org/file/bot${Rafz.token}/${fileInfo.file_path}`
      const buf = await getBuffer(tgUrl)

      const { ext: bufExt } = (await fromBuffer(buf)) || {}
      const fname = filename || `file_${Date.now()}`
      const finalName = /\.[a-z0-9]{2,5}$/i.test(fname) ? fname : `${fname}.${bufExt || "bin"}`
      const tmpPath = "./tmp_tourl_" + Date.now() + "_" + (bufExt || "bin")
      try { fs.writeFileSync(tmpPath, buf) } catch {}

      const filenameBuf = finalName

      /* 10 uploader paralel */
      const results = await Promise.allSettled([
        pomf2(tmpPath),
        uploadTmpFiles(tmpPath),
        uploadPutIcu(tmpPath),
        uploadTermai(buf),
        uploadUgu(tmpPath),
        uploadUploadEE(tmpPath),
        uploadToImgBB(tmpPath),
        uploadToPoneRs(buf),
        uploadToLitterbox(buf, filenameBuf),
        uploadCatbox(buf, finalName, mimetype)
      ])
      const [
        quaxResult, tmpFilesResult, putIcuResult, termaiResult, uguResult,
        uploadEEResult, imgbbResult, poneRsResult, litterboxResult, catboxResult
      ] = results

      const quaxLink        = quaxResult.status === "fulfilled" ? quaxResult.value : null
      const tmpFilesLink    = tmpFilesResult.status === "fulfilled" ? tmpFilesResult.value : null
      const putIcuLink      = putIcuResult.status === "fulfilled" ? putIcuResult.value : null
      const termaiLink      = termaiResult.status === "fulfilled" ? termaiResult.value : null
      const uguLink         = uguResult.status === "fulfilled" ? uguResult.value : null
      const uploadEELink    = uploadEEResult.status === "fulfilled" ? uploadEEResult.value : null
      const imgbbLink       = imgbbResult.status === "fulfilled" ? imgbbResult.value : null
      const poneRsLink      = poneRsResult.status === "fulfilled" ? poneRsResult.value : null
      const litterboxVal    = litterboxResult.status === "fulfilled" ? litterboxResult.value : null
      const litterboxLink   = litterboxVal?.url || null
      const litterboxExpiry = litterboxVal?.expires || null
      const catboxLink      = catboxResult.status === "fulfilled" ? catboxResult.value : null

      try { fs.unlinkSync(tmpPath) } catch {}

      const successLinks = [
        quaxLink, tmpFilesLink, putIcuLink, termaiLink, uguLink,
        uploadEELink, imgbbLink, poneRsLink, litterboxLink, catboxLink
      ].filter(Boolean)

      if (successLinks.length === 0) {
        del()
        return m.reply(`❌ Semua uploader gagal. Coba lagi nanti atau pakai file lain.`, { parse_mode: "HTML" })
      }

      const fmt = (link) => link ? link : "Gagal"
      let caption = `✅ <b>UPLOAD SUCCESS</b>\n\n`
      caption += `📁 Nama   : <code>${finalName}</code>\n`
      caption += `📦 Tipe   : ${mediaType || "file"}\n`
      caption += `📏 Ukuran : ${(buf.length / 1024).toFixed(2)} KB\n`
      caption += `🎨 Format : ${bufExt || "unknown"}\n`
      caption += `🌍 Berhasil: <b>${successLinks.length} dari 10</b> uploader\n`
      caption += `─────────────────\n`
      caption += `• Qu.ax      : ${fmt(quaxLink)}\n`
      caption += `• TmpFiles   : ${fmt(tmpFilesLink)} (2 Days)\n`
      caption += `• Put.icu    : ${fmt(putIcuLink)} (1 Day)\n`
      caption += `• Termai     : ${fmt(termaiLink)}\n`
      caption += `• Uguu.se    : ${fmt(uguLink)}\n`
      caption += `• Upload.ee  : ${fmt(uploadEELink)}\n`
      caption += `• ImgBB      : ${fmt(imgbbLink)}\n`
      caption += `• Pone.rs    : ${fmt(poneRsLink)}\n`
      caption += `• Litterbox  : ${fmt(litterboxLink)} ${litterboxExpiry ? `(${litterboxExpiry})` : ""}\n`
      caption += `• Catbox     : ${fmt(catboxLink)}`

      return editResult(caption, { disable_web_page_preview: true })
    } catch (e) {
      del()
      return m.reply("❌ Gagal upload: " + (e?.message || e))
    }
  } catch (e) {
    console.error("[tourl]", e?.message)
    try { await m.reply("⚠️ Error: " + (e?.message || e)) } catch {}
    return false
  }
}

handler.command = ["tourl", "catbox", "upload", "tourl2", "geturl"]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
