/* searchfit.js — /searchfit <kata> : cari fitur dari SEMUA command terdaftar.
   Hasil = tombol yang bisa ditekan untuk langsung jalanin command-nya
   (callback → handler message, sama seperti pola pager/menu).
   Semua reply i18n (m.t) + tombol berstyle. */

"use strict"
const fs = require("fs")
const path = require("path")

/* index: command → plugin file (di-cache 60s) */
let _idx = null, _idxAt = 0
const buildIndex = () => {
  if (_idx && Date.now() - _idxAt < 60000) return _idx
  const dir = path.join(__dirname, "..", "plugins")
  const idx = []
  for (const f of fs.readdirSync(dir)) {
    if (!f.endsWith(".js")) continue
    try {
      delete require.cache[require.resolve(path.join(dir, f))]
      const mod = require(path.join(dir, f))
      if (typeof mod !== "function" || !Array.isArray(mod.command)) continue
      for (const c of mod.command) {
        if (typeof c !== "string" || !/^[a-z0-9_]+$/i.test(c)) continue
        idx.push({ cmd: c.toLowerCase(), file: f })
      }
    } catch {}
  }
  _idx = idx
  _idxAt = Date.now()
  return idx
}

const handler = async (m, { Rafz, command, text }) => {
  const tr = (k, v) => (m.t ? m.t(k, v) : (k, v) => k)
  const q = String(text || "").trim().toLowerCase()
  const px = (global.prefix && global.prefix[0]) || "/"

  if (command !== "searchfit" && command !== "cariFitur" && command !== "cari Fitur") return false

  if (!q) {
    const total = buildIndex().length
    return m.reply(
      "🔍 <b>SEARCH FITUR</b>\n\n" + (m.t ? m.t("searchfit.hint", { n: total }) : "Cari dari " + total + " command.") + "\n<code>" + px + "searchfit sticker</code>\n<code>" + px + "searchfit tebak</code>\n<code>" + px + "searchfit ktp</code>",
      { parse_mode: "HTML" }
    )
  }

  const idx = buildIndex()
  /* skor: prefix match > substring */
  const scored = []
  for (const it of idx) {
    if (it.cmd === q) scored.push({ ...it, s: 100 })
    else if (it.cmd.startsWith(q)) scored.push({ ...it, s: 60 })
    else if (it.cmd.includes(q)) scored.push({ ...it, s: 30 })
  }
  scored.sort((a, b) => b.s - a.s || a.cmd.localeCompare(b.cmd))
  /* dedup per command, ambil 14 */
  const seen = new Set()
  const top = []
  for (const s of scored) {
    if (seen.has(s.cmd)) continue
    seen.add(s.cmd)
    top.push(s)
    if (top.length >= 14) break
  }

  if (!top.length) {
    return m.reply("🈳 " + (m.t ? m.t("searchfit.none", { q }) : "Tidak ada fitur untuk: " + q), { parse_mode: "HTML" })
  }

  /* tombol 2 kolom — tap → jalankan command (callback "/cmd") */
  const rows = []
  for (let i = 0; i < top.length; i += 2) {
    const row = []
    row.push({ text: "/" + top[i].cmd, callback_data: "/" + top[i].cmd, style: "primary" })
    if (top[i + 1]) row.push({ text: "/" + top[i + 1].cmd, callback_data: "/" + top[i + 1].cmd, style: "primary" })
    rows.push(row)
  }
  rows.push([{ text: "🏠 Menu", callback_data: "/menu home", style: "danger" }])

  const total = idx.length
  const out =
    "🔍 <b>SEARCH FITUR</b> — “" + escQ(q) + "”\n\n" +
    (m.t ? m.t("searchfit.found", { n: scored.length, total }) : scored.length + " dari " + total + " fitur:") +
    "\n\n💡 " + (m.t ? m.t("searchfit.tap") : "Tap tombol untuk langsung menjalankan.")

  return m.reply(out, { parse_mode: "HTML", reply_markup: { inline_keyboard: rows } })
}

const escQ = (s) => String(s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")

handler.command = ["searchfit", "cariFitur", "cari Fitur"]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
