/* plugin: sticker.js — /brat, /sticker, /stickerinfo
   Semua stiker dibuat berbentuk PACK (createNewStickerSet) sehingga bisa
   disimpan ke Favorit / Sticker Suggestions Telegram, bukan stiker lepas.

   FIX STICKER_PNG_DIMENSIONS:
   - PNG di-resize DULU (resize → png), jadi dimensi hasil PASTI 512x512
   - brat digambar langsung di canvas 512x512 (SVG text), bukan resize tiket
   - video sticker dikonversi ke webm VP9 via ffmpeg-static (bukan webp mentah)
   - verifikasi metadata sebelum kirim; kalau pack gagal → kirim stiker biasa

   /brat teks        → stiker brat + masuk pack personal user
   /bratpack teks    → alias /brat (merged, sesuai saran)
   /sticker          → reply stiker/foto/video → tambah ke pack personal user
   /stickerinfo      → info pack stiker user                            */

"use strict"
const https = require("https")
const http = require("http")
const sharp = require("sharp")

/* ═════════════ HTTP helper ═════════════ */
const getBuffer = (url, hdrs = {}) =>
  new Promise((resolve, reject) => {
    try {
      const follow = (u, depth = 0) => {
        if (depth > 5) return reject(new Error("Too many redirects"))
        const mod = u.startsWith("https") ? https : http
        const parsed = new URL(u)
        const req = mod.get({
          hostname: parsed.hostname,
          path: parsed.pathname + parsed.search,
          timeout: 60000,
          headers: { "User-Agent": "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/130 Mobile Safari/537.36", ...hdrs }
        }, (res) => {
          if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location)
            return follow(new URL(res.headers.location, u).href, depth + 1)
          if (res.statusCode !== 200) return reject(new Error(`HTTP ${res.statusCode}`))
          const chunks = []
          res.on("data", c => chunks.push(c))
          res.on("end", () => resolve(Buffer.concat(chunks)))
          res.on("error", reject)
        })
        req.on("error", reject)
        req.on("timeout", () => { req.destroy(); reject(new Error("Timeout")) })
      }
      follow(url)
    } catch (e) { reject(e) }
  })

/* ═════════════ BRAT RENDER (canvas 512 langsung) ═════════════
   Teks digambar langsung di canvas 512x512 dengan SVG <text>.
   Font pakai "sans-serif" (DejaVu tersedia di server), bukan font web
   yang mungkin tidak ada → ukuran teks terprediksi & dimensi pas. */
const escapeXml = (s) =>
  String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;")

const wrapText = (text, maxChars) => {
  const words = String(text).split(/\s+/).filter(Boolean)
  const lines = []
  let line = ""
  for (const w of words) {
    if ((line + " " + w).trim().length > maxChars) {
      if (line) lines.push(line.trim())
      line = w
    } else {
      line = (line + " " + w).trim()
    }
  }
  if (line) lines.push(line.trim())
  return lines.length ? lines : [""]
}

const makeBratCanvas = async (text) => {
  const clean = String(text).replace(/[<>]/g, "").slice(0, 220)
  const lines = wrapText(clean, 14).slice(0, 14)
  const fontSize = lines.length <= 4 ? 72 : lines.length <= 8 ? 52 : lines.length <= 11 ? 42 : 34
  const lineHeight = fontSize + 8
  const startY = Math.max(fontSize + 20, Math.round((512 - lines.length * lineHeight) / 2) + fontSize)

  let tspans = ""
  lines.forEach((ln, i) => {
    tspans += `<text x="26" y="${startY + i * lineHeight}" font-family="sans-serif" font-weight="bold" font-size="${fontSize}" fill="black">${escapeXml(ln)}</text>`
  })

  const svg = `<svg width="512" height="512" xmlns="http://www.w3.org/2000/svg"><rect width="512" height="512" fill="white"/>${tspans}</svg>`

  /* dirender PERSIS 512x512 — tidak ada resize berikutnya yang bisa salah */
  const png = await sharp({
    create: { width: 512, height: 512, channels: 4, background: { r: 255, g: 255, b: 255, alpha: 1 } }
  }).composite([{ input: Buffer.from(svg), top: 0, left: 0 }]).png().toBuffer()

  return png
}

/* ═════════════ TTP/ATTP RENDER LOKAL (pengganti textpro 404) ═════════════
   /ttp2 — teks hitam di canvas putih 512x512 (PNG)
   /attp2 — teks warna-warni animasi 8 frame (GIF, sharp pageHeight) */
const ATTP_COLORS = ["#ff3838", "#ff8c00", "#ffee00", "#32cd32", "#00c8ff", "#8a2be2", "#ff69b4", "#ffffff"]
const makeTtpPng = async (text) => {
  const lines = wrapText(String(text).replace(/[<>]/g, "").slice(0, 160), 14).slice(0, 10)
  const fontSize = lines.length <= 3 ? 64 : lines.length <= 6 ? 48 : 38
  const lineHeight = fontSize + 10
  const startY = Math.max(fontSize + 20, Math.round((512 - lines.length * lineHeight) / 2) + fontSize)
  let tspans = ""
  lines.forEach((ln, i) => {
    tspans += `<text x="256" y="${startY + i * lineHeight}" text-anchor="middle" font-family="sans-serif" font-weight="bold" font-size="${fontSize}" fill="black">${escapeXml(ln)}</text>`
  })
  const svg = `<svg width="512" height="512" xmlns="http://www.w3.org/2000/svg"><rect width="512" height="512" fill="white"/>${tspans}</svg>`
  return sharp({ create: { width: 512, height: 512, channels: 4, background: { r: 255, g: 255, b: 255, alpha: 1 } } })
    .composite([{ input: Buffer.from(svg), top: 0, left: 0 }]).png().toBuffer()
}
const makeAttpGif = async (text) => {
  const lines = wrapText(String(text).replace(/[<>]/g, "").slice(0, 120), 13).slice(0, 8)
  const fontSize = lines.length <= 3 ? 60 : lines.length <= 6 ? 46 : 36
  const lineHeight = fontSize + 10
  const startY = Math.max(fontSize + 20, Math.round((512 - lines.length * lineHeight) / 2) + fontSize)
  /* render tiap frame → raw pixel → concat → GIF multi-page (sharp pageHeight) */
  const raws = []
  for (let f = 0; f < ATTP_COLORS.length; f++) {
    let tspans = ""
    lines.forEach((ln, i) => {
      tspans += `<text x="256" y="${startY + i * lineHeight}" text-anchor="middle" font-family="sans-serif" font-weight="bold" font-size="${fontSize}" fill="${ATTP_COLORS[f]}">${escapeXml(ln)}</text>`
    })
    const svg = `<svg width="512" height="512" xmlns="http://www.w3.org/2000/svg"><rect width="512" height="512" fill="black"/>${tspans}</svg>`
    raws.push(await sharp({ create: { width: 512, height: 512, channels: 4, background: { r: 0, g: 0, b: 0, alpha: 1 } } })
      .composite([{ input: Buffer.from(svg), top: 0, left: 0 }]).raw().toBuffer())
  }
  return sharp(Buffer.concat(raws), { raw: { width: 512, height: 512, channels: 4, pageHeight: 512 } })
    .gif({ delay: ATTP_COLORS.map(() => 120), loop: 0 }).toBuffer()
}
const makeBratApi = (text) =>
  getBuffer(`https://brat.siputzx.my.id/image?text=${encodeURIComponent(text)}`)

/* ═════════════ STICKER PNG PIPELINE (anti STICKER_PNG_DIMENSIONS) ═════════════ */
const toStickerPng = async (buf) => {
  /* 1. resize DULU ke 512x512 contain (width & height max 512) */
  const resized = await sharp(buf)
    .resize(512, 512, { fit: "contain", background: { r: 0, g: 0, b: 0, alpha: 0 } })
    .toBuffer()
  /* 2. setelah resize BARU jadi png */
  let out = await sharp(resized).png({ compressionLevel: 9 }).toBuffer()
  /* 3. verifikasi metadata; kalau bukan 512x512, paksa lagi (double check) */
  const meta = await sharp(out).metadata()
  if (meta.width !== 512 || meta.height !== 512) {
    out = await sharp(out)
      .resize(512, 512, { fit: "contain", background: { r: 0, g: 0, b: 0, alpha: 0 } })
      .png({ compressionLevel: 9 })
      .toBuffer()
  }
  return out
}

/* ═════════════ VIDEO → WEBM (VP9) via ffmpeg-static ═════════════ */
const toStickerWebm = (buf) => {
  const fs = require("fs")
  const path = require("path")
  const { execFileSync } = require("child_process")
  const ffmpegPath = require("ffmpeg-static")
  if (!ffmpegPath || !fs.existsSync(ffmpegPath)) throw new Error("ffmpeg tidak tersedia")

  const inFile = path.join(require("os").tmpdir(), "stk_in_" + Date.now() + ".bin")
  const outFile = path.join(require("os").tmpdir(), "stk_out_" + Date.now() + ".webm")
  try {
    fs.writeFileSync(inFile, buf)
    /* webm stiker Telegram: VP9, max 512x512, max 3 detik, tanpa audio */
    execFileSync(ffmpegPath, [
      "-y", "-loglevel", "error", "-t", "3", "-i", inFile,
      "-vf", "scale='min(512,iw)':'min(512,ih)':force_original_aspect_ratio=decrease,scale=512:512:force_original_aspect_ratio=increase,crop=512:512,fps=15",
      "-c:v", "libvpx-vp9", "-b:v", "256k", "-crf", "30", "-an", outFile
    ], { timeout: 60000 })
    const out = fs.readFileSync(outFile)
    if (!out.length) throw new Error("webm kosong")
    return out
  } finally {
    try { fs.unlinkSync(inFile) } catch {}
    try { fs.unlinkSync(outFile) } catch {}
  }
}

/* ═════════════ PACK HELPERS ═════════════ */
const packName = (userId, botUsername, kind) =>
  ("rnd" + (kind || "u") + "_" + String(userId).replace(/[^0-9]/g, "") + "_by_" + String(botUsername || "").replace(/[^a-zA-Z0-9_]/g, "")).toLowerCase()

const sanitizeTitle = (s) => String(s || "").replace(/[^\w\s-]/g, " ").trim().slice(0, 60) || "My Pack"

/* Ambil file Telegram → buffer */
const tgBuffer = async (Rafz, fileId) => {
  const info = await Rafz.getFile(fileId)
  return getBuffer(`https://api.telegram.org/file/bot${Rafz.token}/${info.file_path}`)
}

/* ═════════════ RAW API ═════════════ */
const createStickerSet = async (Rafz, userId, name, title, buf, field, emoji) => {
  const [formData, ref] = Rafz._formatSendData(field, buf, { filename: "sticker_" + Date.now() })
  const qs = { user_id: userId, name, title, emojis: emoji, sticker_type: "regular" }
  if (ref) qs[field] = ref
  return Rafz._request("createNewStickerSet", { qs, formData })
}
const addSticker = async (Rafz, userId, name, buf, field, emoji) => {
  const [formData, ref] = Rafz._formatSendData(field, buf, { filename: "sticker_" + Date.now() })
  const qs = { user_id: userId, name, emojis: emoji }
  if (ref) qs[field] = ref
  return Rafz._request("addStickerToSet", { qs, formData })
}

/* kirim ke pack: coba tambah dulu, kalau pack belum ada → buat baru.
   kalau dua-duanya gagal → kirim stiker biasa (output tetap ada). */
const sendToPack = async (Rafz, sender, pName, title, buf, field, emoji) => {
  try {
    await addSticker(Rafz, sender, pName, buf, field, emoji)
    return "added"
  } catch (e1) {
    try {
      await createStickerSet(Rafz, sender, pName, sanitizeTitle(title), buf, field, emoji)
      return "created"
    } catch (e2) {
      console.log("[sticker] pack fail:", (e2?.description || e2?.message || "").slice(0, 120), "| add fail:", (e1?.description || e1?.message || "").slice(0, 80))
      throw e2
    }
  }
}

/* ═════════════ MAIN ═════════════ */
const handler = async (m, { Rafz, command, text }) => {
  try {
    const px = (global.prefix && global.prefix[0]) || "/"
    const sender = String(m.sender)
    const tr = (key, vars) => (m.t ? m.t(key, vars) : key)

    /* username bot untuk suffix pack name (cache di global) */
    let botUsername = global._botUsername
    if (!botUsername) {
      try {
        const me = await Rafz.getMe()
        botUsername = me.username || me.result?.username
        global._botUsername = botUsername
      } catch {}
    }

    /* ─────────── /brat teks ─────────── */
    if (command === "brat" || command === "bratgen" || command === "bratpack") {
      const q = m.quoted?.text || ""
      const content = (text || "").trim() || q.trim()
      if (!content)
        return m.reply(`${tr("use.usage")} <code>${px}brat ${tr("use.textHint")}</code>`, { parse_mode: "HTML" })
      if (content.length > 220) return m.reply(tr("sticker.tooLong"))
      if (!botUsername) return m.reply(tr("sticker.noBotUser"))

      const wait = await m.reply(tr("sticker.making"), { parse_mode: "HTML" })
      const editOut = async (t2, opt = {}) => {
        try {
          return await Rafz.editMessageText(t2, {
            chat_id: m.chat, message_id: wait.message_id, parse_mode: "HTML",
            disable_web_page_preview: true, ...opt
          })
        } catch (e) {
          if (String(e?.message || e).includes("not modified")) return null
          return m.reply(t2, opt)
        }
      }

      try {
        /* render lokal dulu (dimensi pasti benar), API sebagai fallback */
        let buf
        try { buf = await makeBratCanvas(content) }
        catch (e) { console.log("[brat] canvas fail, pakai API:", e.message); buf = await toStickerPng(await makeBratApi(content)) }

        const pName = packName(sender, botUsername, "u")
        const title = global.botname ? `${global.botname} • ${sender}` : `Brat Pack • ${sender}`

        let packState
        try {
          packState = await sendToPack(Rafz, sender, pName, title, buf, "png_sticker", "🙂")
        } catch (packErr) {
          /* pack gagal → kirim stiker biasa, jangan kosong */
          await Rafz.sendSticker(m.chat, buf, { reply_to_message_id: m.id, allow_sending_without_reply: true }).catch(() => {})
          return editOut(`✅ ${tr("sticker.asSticker")}\n⚠️ ${tr("sticker.packFail")}: ` + String(packErr?.description || packErr?.message || "unknown").slice(0, 100))
        }

        const packLink = `https://t.me/addstickers/${pName}`
        await Rafz.sendSticker(m.chat, buf, {
          reply_to_message_id: m.id, allow_sending_without_reply: true
        }).catch(() => {})
        return editOut(
          `✅ <b>${tr("sticker.done")}</b>\n\n` +
          `📦 <a href="${packLink}">${tr("sticker.openPack")}</a>\n` +
          (packState === "created" ? `🆕 ${tr("sticker.packCreated")}\n` : `➕ ${tr("sticker.packAdded")}\n`) +
          `💾 <i>${tr("sticker.saveHint")}</i>`,
          { disable_web_page_preview: true }
        )
      } catch (e) {
        try { await Rafz.deleteMessage(m.chat, wait.message_id) } catch {}
        return m.reply("❌ " + (e?.message || "Gagal buat stiker"))
      }
    }

    /* ─────────── /ttp2 — sticker teks putih (render lokal, pengganti textpro 404) ─────────── */
    if (command === "ttp2") {
      const content = (text || "").trim()
      if (!content) return m.reply(`${tr("use.usage")} <code>${px}ttp2 ${tr("use.textHint")}</code>`, { parse_mode: "HTML" })
      const wait = await m.reply(tr("sticker.making"), { parse_mode: "HTML" })
      try {
        const buf = await makeTtpPng(content)
        await Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {})
        await Rafz.sendDocument(m.chat, buf, { filename: "ttp.png", caption: "✨ TTP: " + content.slice(0, 50), reply_to_message_id: m.id, allow_sending_without_reply: true })
        return true
      } catch (e) {
        try { await Rafz.deleteMessage(m.chat, wait.message_id) } catch {}
        return m.reply("❌ Gagal: " + (e?.message || e).slice(0, 80))
      }
    }

    /* ─────────── /attp2 — sticker teks warna animasi GIF (render lokal) ─────────── */
    if (command === "attp2") {
      const content = (text || "").trim()
      if (!content) return m.reply(`${tr("use.usage")} <code>${px}attp2 ${tr("use.textHint")}</code>`, { parse_mode: "HTML" })
      const wait = await m.reply(tr("sticker.making"), { parse_mode: "HTML" })
      try {
        const buf = await makeAttpGif(content)
        await Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {})
        await Rafz.sendDocument(m.chat, buf, { filename: "attp.gif", caption: "✨ ATTP: " + content.slice(0, 50), reply_to_message_id: m.id, allow_sending_without_reply: true })
        return true
      } catch (e) {
        try { await Rafz.deleteMessage(m.chat, wait.message_id) } catch {}
        return m.reply("❌ Gagal: " + (e?.message || e).slice(0, 80))
      }
    }

    /* ─────────── /sticker — reply media → masuk pack personal ─────────── */
    if (command === "sticker" || command === "s" || command === "stiker") {
      if (!botUsername) return m.reply(tr("sticker.noBotUser"))

      const src = (m.quoted && m.quoted.fileId) ? m.quoted : (m.fileId ? m : null)
      if (!src || !src.fileId)
        return m.reply(`${tr("use.usage")}\n${tr("sticker.usage", { cmd: px + "sticker" })}`, { parse_mode: "HTML" })

      /* stiker animasi .tgs tidak bisa diproses ulang */
      if (src.mediaType === "sticker" && src.sticker?.isAnimated)
        return m.reply(tr("sticker.animatedNo"))

      const wait = await m.reply(tr("sticker.making"), { parse_mode: "HTML" })
      const editOut = async (t2, opt = {}) => {
        try {
          return await Rafz.editMessageText(t2, {
            chat_id: m.chat, message_id: wait.message_id, parse_mode: "HTML",
            disable_web_page_preview: true, ...opt
          })
        } catch (e) {
          if (String(e?.message || e).includes("not modified")) return null
          return m.reply(t2, opt)
        }
      }

      try {
        let buf = await tgBuffer(Rafz, src.fileId)
        const isVideoSticker = (src.mediaType === "video" || src.mediaType === "animation" || src.mediaType === "video_note" || (src.mediaType === "sticker" && src.sticker?.isVideo))
        const emoji = (text || "").trim().match(/^[\p{Emoji}\u200d\ufe0f]{1,3}$/u)?.[0] || (src.sticker?.emoji) || "🙂"
        const pName = packName(sender, botUsername, "u")
        const title = global.botname ? `${global.botname} • ${sender}` : `My Pack • ${sender}`

        let stickField
        if (isVideoSticker) {
          stickField = "webm_sticker"
          buf = await toStickerWebm(buf)
        } else {
          stickField = "png_sticker"
          buf = await toStickerPng(buf)
        }

        let packState
        try {
          packState = await sendToPack(Rafz, sender, pName, title, buf, stickField, emoji)
        } catch (packErr) {
          await Rafz.sendSticker(m.chat, buf, { reply_to_message_id: m.id, allow_sending_without_reply: true }).catch(() => {})
          return editOut(`✅ ${tr("sticker.asSticker")}\n⚠️ ${tr("sticker.packFail")}: ` + String(packErr?.description || packErr?.message || "unknown").slice(0, 100))
        }

        await Rafz.sendSticker(m.chat, buf, {
          reply_to_message_id: m.id, allow_sending_without_reply: true
        }).catch(() => {})

        const packLink = `https://t.me/addstickers/${pName}`
        return editOut(
          `✅ <b>${tr("sticker.done")}</b>\n\n` +
          `📦 <a href="${packLink}">${tr("sticker.openPack")}</a>\n` +
          (packState === "created" ? `🆕 ${tr("sticker.packCreated")}\n` : `➕ ${tr("sticker.packAdded")}\n`) +
          `💾 <i>${tr("sticker.saveHint")}</i>`,
          { disable_web_page_preview: true }
        )
      } catch (e) {
        try { await Rafz.deleteMessage(m.chat, wait.message_id) } catch {}
        return m.reply("❌ " + (e?.message || "Gagal buat stiker"))
      }
    }

    /* ─────────── /stickerinfo — info pack user ─────────── */
    if (command === "stickerinfo") {
      if (!botUsername) return m.reply(tr("sticker.noBotUser"))
      const pName = packName(sender, botUsername, "u")
      try {
        const raw = await Rafz.getStickerSet(pName)
        const set = raw?.result || raw || {}
        return m.reply(
          `📦 <b>${tr("sticker.packInfo")}</b>\n\n` +
          `🏷️ ${set.name || pName}\n` +
          `🧩 ${tr("sticker.packCount")}: <b>${(set.stickers || []).length}</b>\n` +
          `🔗 https://t.me/addstickers/${pName}`,
          { parse_mode: "HTML", disable_web_page_preview: true }
        )
      } catch {
        return m.reply(tr("sticker.packEmpty"), { parse_mode: "HTML" })
      }
    }

    return false
  } catch (e) {
    console.error("[sticker]", e?.message)
    try { await m.reply("⚠️ Error: " + (e?.message || e)) } catch {}
    return false
  }
}

handler.command = ["brat", "bratgen", "bratpack", "sticker", "stiker", "s", "stickerinfo", "ttp2", "attp2"]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
