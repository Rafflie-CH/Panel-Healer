/* islamic3.js — porting fitur islami dari WA bot (Rafzbotz/Furina/Prabowo).
   Sumber API TERVERIFIKASI hidup (2026-09):
   - api.alquran.cloud  (surah/ayat + terjemah)
   - api.aladhan.com    (jadwal sholat, qibla, kalender hijriah)
   - cdn.islamic.network (murotal audio per ayat)
   Data lokal: doaharian.json + tahlil.json (dari database WA Furina).
   Semua reply pakai i18n (m.t) + tombol berstyle. */

"use strict"
const fs = require("fs")
const path = require("path")

const esc = (s) => String(s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
const pick = (a) => a[Math.floor(Math.random() * a.length)]

const jget = (f) => {
  try { return JSON.parse(fs.readFileSync(f, "utf8")) } catch { return null }
}

/* data lokal dari WA source (sudah dibawa ke botproject) */
const DOA_FILE = path.join(__dirname, "..", "library", "database", "doaharian.json")
const TAHLIL_FILE = path.join(__dirname, "..", "library", "database", "tahlil.json")

const API = async (u, opt) => {
  const r = await fetch(u, { signal: AbortSignal.timeout(20000), headers: { "accept": "application/json" } })
  if (!r.ok) throw new Error("HTTP " + r.status)
  const j = await r.json()
  if (j.code && j.code !== 200) throw new Error("API " + j.code)
  return j
}

/* Fallback API — beberapa ISP/server blokir api.alquran.cloud (owner 2026-09:
   "Failed to fetch data Al-Quran") → api.quran.com + mp3quran.net sumber kedua */
const API2 = async (u) => {
  const r = await fetch(u, { signal: AbortSignal.timeout(20000), headers: { "accept": "application/json", "User-Agent": "curl/8.5.0" } })
  if (!r.ok) throw new Error("HTTP " + r.status)
  return r.json()
}
/* ambil surah: alquran.cloud dulu, quran.com fallback (format beda → normalisasi) */
const surahData = async (no) => {
  try {
    const j = await API("https://api.alquran.cloud/v1/surah/" + no)
    const s = j.data
    return {
      number: s.number, name: s.name, englishName: s.englishName,
      revelationType: s.revelationType, numberOfAyahs: s.numberOfAyahs,
      ayahs: (s.ayahs || []).map(a => ({ numberInSurah: a.numberInSurah, text: a.text }))
    }
  } catch {
    const j2 = await API2("https://api.quran.com/api/v4/quran/verses/uthmani?chapter_number=" + no)
    const meta = await API2("https://api.quran.com/api/v4/chapters/" + no + "?language=id")
    const ch = meta.chapter || {}
    return {
      number: ch.id || no, name: ch.name_arabic || "", englishName: ch.name_simple || "",
      revelationType: ch.revelation_place === "makkah" ? "Meccan" : "Madinan",
      numberOfAyahs: ch.verses_count || (j2.verses || []).length,
      ayahs: (j2.verses || []).map((v, i) => ({ numberInSurah: i + 1, text: v.text_uthmani }))
    }
  }
}
/* ambil 1 ayat dgn terjemah: alquran.cloud dulu, quran.com fallback */
const ayahData = async (s, a) => {
  try {
    const j = await API(`https://api.alquran.cloud/v1/ayah/${s}/${a}/editions/quran-uthmani,id.indonesian,en.asad`)
    const eds = j.data || []
    const ar = eds.find(x => x.edition.identifier === "quran-uthmani") || eds[0]
    const idn = eds.find(x => x.edition.identifier === "id.indonesian")
    const en = eds.find(x => x.edition.identifier === "en.asad")
    return { ar: { text: ar.text, name: ar.surah?.name, numberInSurah: ar.numberInSurah, number: ar.number }, idn: idn?.text, en: en?.text, audio: ar.audio }
  } catch {
    const j2 = await API2(`https://api.quran.com/api/v4/verses/by_key/${s}%3A${a}?fields=text_uthmani&translations=33,131&audio=1&recitation=1`)
    const v = j2.verse || {}
    return {
      ar: { text: v.text_uthmani, name: "", numberInSurah: v.verse_number, number: v.id },
      idn: (v.translations || [])[0]?.text, en: (v.translations || [])[1]?.text,
      audio: v.audio?.url ? (String(v.audio.url).startsWith("http") ? v.audio.url : "https://verses.quran.com/" + String(v.audio.url).replace(/^\//, "")) : null
    }
  }
}
/* audio full surah: cdn.islamic.network (403 di server owner) → mp3quran.net */
const surahAudio = async (no) => {
  const cdn = `https://cdn.islamic.network/quran/audio-surah/128/ar.alafasy/${no}.mp3`
  try {
    const r = await fetch(cdn, { signal: AbortSignal.timeout(25000) })
    if (r.ok) { const b = Buffer.from(await r.arrayBuffer()); if (b.length > 100000) return b }
  } catch {}
  const pad = String(no).padStart(3, "0")
  const r2 = await fetch(`https://server8.mp3quran.net/afs/${pad}.mp3`, { signal: AbortSignal.timeout(90000) })
  if (!r2.ok) throw new Error("HTTP " + r2.status)
  return Buffer.from(await r2.arrayBuffer())
}

const SURAH_NAMES = [
  ["Al-Fatihah",7],["Al-Baqarah",286],["Ali 'Imran",200],["An-Nisa",176],["Al-Ma'idah",120],["Al-An'am",165],
  ["Al-A'raf",206],["Al-Anfal",75],["At-Tawbah",129],["Yunus",109],["Hud",123],["Yusuf",111],["Ar-Ra'd",43],
  ["Ibrahim",52],["Al-Hijr",99],["An-Nahl",128],["Al-Isra",111],["Al-Kahf",110],["Maryam",98],["Ta-Ha",135],
  ["Al-Anbiya",112],["Al-Hajj",78],["Al-Mu'minun",118],["An-Nur",64],["Al-Furqan",77],["Ash-Shu'ara",227],
  ["An-Naml",93],["Al-Qasas",88],["Al-'Ankabut",69],["Ar-Rum",60],["Luqman",34],["As-Sajdah",30],["Al-Ahzab",73],
  ["Saba",54],["Fatir",45],["Ya-Sin",83],["As-Saffat",182],["Sad",88],["Az-Zumar",75],["Ghafir",85],
  ["Fussilat",54],["Ash-Shura",53],["Az-Zukhruf",89],["Ad-Dukhan",59],["Al-Jathiyah",37],["Al-Ahqaf",35],
  ["Muhammad",38],["Al-Fath",29],["Al-Hujurat",18],["Qaf",45],["Adh-Dhariyat",60],["At-Tur",49],["An-Najm",62],
  ["Al-Qamar",55],["Ar-Rahman",78],["Al-Waqi'ah",96],["Al-Hadid",29],["Al-Mujadila",22],["Al-Hashr",24],
  ["Al-Mumtahanah",13],["As-Saf",14],["Al-Jumu'ah",11],["Al-Munafiqun",11],["At-Taghabun",18],["At-Talaq",12],
  ["At-Tahrim",12],["Al-Mulk",30],["Al-Qalam",52],["Al-Haqqah",52],["Al-Ma'arij",44],["Nuh",28],["Al-Jinn",28],
  ["Al-Muzzammil",20],["Al-Muddaththir",56],["Al-Qiyamah",40],["Al-Insan",31],["Al-Mursalat",50],["An-Naba",40],
  ["An-Nazi'at",46],["'Abasa",42],["At-Takwir",29],["Al-Infitar",19],["Al-Mutaffifin",36],["Al-Inshiqaq",25],
  ["Al-Buruj",22],["At-Tariq",17],["Al-A'la",19],["Al-Ghashiyah",26],["Al-Fajr",30],["Al-Balad",20],
  ["Ash-Shams",15],["Al-Layl",21],["Ad-Duhaa",11],["Ash-Sharh",8],["At-Tin",8],["Al-'Alaq",19],["Al-Qadr",5],
  ["Al-Bayyinah",8],["Az-Zalzalah",8],["Al-Adiyat",11],["Al-Qari'ah",11],["At-Takathur",8],["Al-'Asr",3],
  ["Al-Humazah",9],["Al-Fil",5],["Quraysh",4],["Al-Ma'un",7],["Al-Kawthar",3],["Al-Kafirun",6],["An-Nasr",3],
  ["Al-Masad",5],["Al-Ikhlas",4],["Al-Falaq",5],["An-Nas",6]
]

const fmtTimings = (t) => {
  const rows = [
    ["🌅", "Fajr", "Subuh"], ["🌄", "Sunrise", "Terbit"], ["☀️", "Dhuhr", "Dzuhur"],
    ["🌤️", "Asr", "Ashar"], ["🌇", "Maghrib", "Maghrib"], ["🌆", "Isha", "Isya"]
  ]
  return rows.map(([e, k, id]) => {
    const v = String(t[k] || "-").replace(/\s*\(.*\)/, "")
    return `${e} <b>${id}</b>: <code>${esc(v)}</code>`
  }).join("\n")
}

const handler = async (m, { Rafz, command, text }) => {
  try {
    const tr = (key, vars) => (m.t ? m.t(key, vars) : key)
    const px = (global.prefix && global.prefix[0]) || "/"

    /* ── /surah <no|nama> — detail surah + potongan ayat ── */
    if (command === "surah" || command === "surat") {
      const q = String(text || "").trim().toLowerCase()
      if (!q) {
        let out = "📖 <b>DAFTAR SURAH</b> (1-114)\n" + tr("isl3.surahHint", { px }) + "\n\n"
        for (let i = 0; i < 30; i++) out += `<code>${i + 1}</code>. ${esc(SURAH_NAMES[i][0])} (${SURAH_NAMES[i][1]} ayat)\n`
        out += "...\n💡 <code>" + px + "surah list2</code>"
        const kb = { inline_keyboard: [[
          { text: "📖 List 31-114", callback_data: "/surahpage 2", style: "primary" },
          { text: "🎲 Random", callback_data: "/surah " + (1 + Math.floor(Math.random() * 114)), style: "success" }
        ]] }
        return m.reply(out, { parse_mode: "HTML", reply_markup: kb })
      }
      if (q === "list2") {
        let out = "📖 <b>DAFTAR SURAH</b> (31-114)\n\n"
        for (let i = 30; i < 114; i++) out += `<code>${i + 1}</code>. ${esc(SURAH_NAMES[i][0])} (${SURAH_NAMES[i][1]})\n`
        return m.reply(out, { parse_mode: "HTML" })
      }
      let no = parseInt(q)
      if (!no) {
        const idx = SURAH_NAMES.findIndex(([n]) => n.toLowerCase().replace(/[^a-z]/g, "").includes(q.replace(/[^a-z]/g, "")))
        if (idx >= 0) no = idx + 1
      }
      if (!no || no < 1 || no > 114) return m.reply(tr("isl3.surahNotFound"), { parse_mode: "HTML" })
      const wait = await m.reply(tr("common.searching"), { parse_mode: "HTML" })
      try {
        const s = await surahData(no)
        const ayat = (s.ayahs || []).slice(0, 3)
        let out = `📖 <b>${esc(s.number)}. ${esc(s.name)} — ${esc(s.englishName)}</b>\n`
        out += `${s.revelationType === "Meccan" ? "🕋 Mekkah" : "🕌 Madinah"} • ${s.numberOfAyahs} ayat\n\n`
        for (const a of ayat) out += `<code>${a.numberInSurah}</code> ${esc(String(a.text).slice(0, 400))}\n\n`
        if (s.numberOfAyahs > 3) out += "… (" + tr("isl3.moreAyah", { n: s.numberOfAyahs - 3 }) + ")\n"
        const kb = { inline_keyboard: [[
          { text: "🎧 Murotal", callback_data: `/murotal ${no}`, style: "success" },
          { text: "🎲 Random", callback_data: "/surah " + (1 + Math.floor(Math.random() * 114)), style: "primary" }
        ]] }
        try { Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {}) } catch {}
        return m.reply(out, { parse_mode: "HTML", reply_markup: kb })
      } catch (e) {
        try { Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {}) } catch {}
        const em = String(e?.message || e)
        if (e?.name === "TimeoutError" || /timeout|fetch failed|ENOTFOUND|ECONNRESET/i.test(em))
          return m.reply(tr("isl3.netError"), { parse_mode: "HTML" })
        return m.reply(tr("common.failed"), { parse_mode: "HTML" })
      }
    }

    /* ── /surahpage — pager daftar surah ── */
    if (command === "surahpage") {
      if (!m.callback) return false
      const p = Math.min(2, Math.max(1, parseInt(String(m.callback).replace(/\D+/g, "")) || 1))
      let out = "📖 <b>DAFTAR SURAH</b>\n\n"
      const start = p === 1 ? 0 : 30
      const end = p === 1 ? 30 : 114
      for (let i = start; i < end; i++) out += `<code>${i + 1}</code>. ${esc(SURAH_NAMES[i][0])} (${SURAH_NAMES[i][1]} ayat)\n`
      const kb = { inline_keyboard: [] }
      const row = []
      if (p > 1) row.push({ text: "⬅️ 1-30", callback_data: "/surahpage 1", style: "secondary" })
      if (p < 2) row.push({ text: "31-114 ➡️", callback_data: "/surahpage 2", style: "primary" })
      row.push({ text: "🎲", callback_data: "/surah " + (1 + Math.floor(Math.random() * 114)), style: "success" })
      kb.inline_keyboard.push(row)
      try { await Rafz.editMessageText(out, { chat_id: m.chat, message_id: m.id, parse_mode: "HTML", reply_markup: kb }) } catch {}
      try { await Rafz.answerCallbackQuery(m.callbackId) } catch {}
      return true
    }

    /* ── /ayat <surah:ayat> — ayat tunggal + audio ── */
    if (command === "ayat") {
      const mt = String(text || "").match(/(\d+)\s*[:\-.\/ ]\s*(\d+)/)
      if (!mt) return m.reply("⚠️ <code>" + px + "ayat 2:255</code>", { parse_mode: "HTML" })
      const s = Math.min(114, Math.max(1, parseInt(mt[1])))
      const a = Math.max(1, parseInt(mt[2]))
      const wait = await m.reply(tr("common.searching"), { parse_mode: "HTML" })
      try {
        const d = await ayahData(s, a)
        const ar = d.ar
        let out = `📖 <b>QS ${esc(ar.name || ("Surah " + s))} : ${ar.numberInSurah}</b>\n\n`
        out += esc(ar.text) + "\n"
        if (d.idn) out += "\n🇮🇩 " + esc(String(d.idn).slice(0, 500)) + "\n"
        if (d.en) out += "\n🇬🇧 " + esc(String(d.en).slice(0, 500)) + "\n"
        const audio = `https://cdn.islamic.network/quran/audio/128/ar.alafasy/${ar.number || 0}.mp3`
        const kb = { inline_keyboard: [[
          { text: "🎧 Audio", callback_data: `/murotalayat ${s} ${a}`, style: "success" },
          { text: "📖 Surah", callback_data: `/surah ${s}`, style: "primary" }
        ]] }
        try { Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {}) } catch {}
        await m.reply(out, { parse_mode: "HTML", reply_markup: kb })
        return true
      } catch (e) {
        try { Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {}) } catch {}
        const em = String(e?.message || e)
        if (e?.name === "TimeoutError" || /timeout|fetch failed|ENOTFOUND|ECONNRESET/i.test(em))
          return m.reply(tr("isl3.netError"), { parse_mode: "HTML" })
        return m.reply(tr("common.failed"), { parse_mode: "HTML" })
      }
    }

    /* ── /murotal <surah> — audio full surah (mishary) ── */
    if (command === "murotal") {
      let no = parseInt(String(text || "").trim())
      if (!no || no < 1 || no > 114) no = 1
      const wait = await m.reply(tr("isl3.downloading"), { parse_mode: "HTML" })
      try {
        const buf = await surahAudio(no)
        if (buf.length > 49 * 1024 * 1024) throw new Error("too large")
        try { Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {}) } catch {}
        await Rafz.sendAudio(m.chat, buf, { caption: `🎧 QS ${no} — ${SURAH_NAMES[no - 1][0]}\nSheikh Mishary Alafasy`, reply_to_message_id: m.id, allow_sending_without_reply: true })
        return true
      } catch (e) {
        try { Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {}) } catch {}
        /* fallback: kirim link */
        return m.reply("🎧 " + tr("isl3.audioLink") + "\nhttps://cdn.islamic.network/quran/audio-surah/128/ar.alafasy/" + no + ".mp3", { parse_mode: "HTML" })
      }
    }

    /* ── /murotalayat — audio satu ayat (callback) ── */
    if (command === "murotalayat") {
      if (!m.callback) return false
      const mt = String(m.callback).match(/(\d+)\s+(\d+)/)
      if (!mt) return false
      const j = await ayahData(mt[1], mt[2])
      const a = j.ar
      const audioUrl = j.audio || (a.number ? `https://cdn.islamic.network/quran/audio/128/ar.alafasy/${a.number}.mp3` : null)
      if (!audioUrl) return false
      await Rafz.sendAudio(m.chat, audioUrl, { caption: `🎧 QS ${mt[1]}:${mt[2]}` })
      try { await Rafz.answerCallbackQuery(m.callbackId) } catch {}
      return true
    }

    /* ── /jadwalsholat <kota> — aladhan timingsByCity ── */
    if (command === "jadwalsholat" || command === "sholat" || command === "sholat2") {
      const city = String(text || "").trim() || "Jakarta"
      const wait = await m.reply(tr("common.searching"), { parse_mode: "HTML" })
      try {
        const j = await API("https://api.aladhan.com/v1/timingsByCity?city=" + encodeURIComponent(city) + "&country=Indonesia&method=11")
        const t = j.data.timings
        const date = j.data.date?.readable || ""
        const out = "🕌 <b>JADWAL SHOLAT — " + esc(city.toUpperCase()) + "</b>\n📅 " + esc(date) + "\n\n" + fmtTimings(t)
        const kb = { inline_keyboard: [[
          { text: "🧭 Kiblat", callback_data: "/kiblat", style: "primary" },
          { text: "📅 Hijriah", callback_data: "/hijri", style: "success" }
        ]] }
        try { Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {}) } catch {}
        return m.reply(out, { parse_mode: "HTML", reply_markup: kb })
      } catch (e) {
        try { Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {}) } catch {}
        return m.reply(tr("common.failed"), { parse_mode: "HTML" })
      }
    }

    /* ── /kiblat — arah kiblat dari koordinat default Jakarta ── */
    if (command === "kiblat" || command === "qibla") {
      let lat = 6.2, lon = 106.8
      const mt = String(text || "").match(/(-?\d+[.,]?\d*)\D+(-?\d+[.,]?\d*)/)
      if (mt) { lat = parseFloat(mt[1].replace(",", ".")); lon = parseFloat(mt[2].replace(",", ".")) }
      try {
        const j = await API(`https://api.aladhan.com/v1/qibla/${lat}/${lon}`)
        const d = j.data.direction
        const arrow = d < 90 ? "↗️" : d < 180 ? "↘️" : d < 270 ? "↙️" : "↖️"
        const out = "🧭 <b>ARAH KIBLAT</b>\n\n" + arrow + " <b>" + d.toFixed(1) + "°</b> dari Utara\n📍 " + lat + ", " + lon
        return m.reply(out, { parse_mode: "HTML" })
      } catch (e) {
        const em = String(e?.message || e)
        if (e?.name === "TimeoutError" || /timeout|fetch failed|ENOTFOUND|ECONNRESET/i.test(em))
          return m.reply(tr("isl3.netError"), { parse_mode: "HTML" })
        return m.reply(tr("common.failed"), { parse_mode: "HTML" })
      }
    }

    /* ── /hijri — tanggal hijriah hari ini ── */
    if (command === "hijri" || command === "kalender" || command === "hijriah") {
      const now = new Date()
      const ds = `${String(now.getDate()).padStart(2, "0")}-${String(now.getMonth() + 1).padStart(2, "0")}-${now.getFullYear()}`
      try {
        const j = await API("https://api.aladhan.com/v1/gToH/" + ds)
        const h = j.data.hijri
        const out = "📅 <b>KALENDER HIJRIAH</b>\n\n" +
          `<b>${esc(h.day)} ${esc(h.month.en)} ${esc(h.year)} H</b>\n` +
          `${esc(h.weekday.en)} • ${esc(h.date)}\n` +
          `${esc(h.month.ar)} — ${esc(h.holidays && h.holidays.length ? "🎉 " + h.holidays.join(", ") : "—")}`
        return m.reply(out, { parse_mode: "HTML" })
      } catch (e) {
        const em = String(e?.message || e)
        if (e?.name === "TimeoutError" || /timeout|fetch failed|ENOTFOUND|ECONNRESET/i.test(em))
          return m.reply(tr("isl3.netError"), { parse_mode: "HTML" })
        return m.reply(tr("common.failed"), { parse_mode: "HTML" })
      }
    }

    /* ── /doa [no|cari] — doa harian dari data WA Furina ── */
    if (command === "doa" || command === "doaharian2") {
      const db = jget(DOA_FILE) || []
      if (!db.length) return m.reply(tr("common.failed"), { parse_mode: "HTML" })
      const q = String(text || "").trim().toLowerCase()
      if (!q) {
        let out = "🤲 <b>DOA HARIAN</b> (" + db.length + ")\n" + tr("isl3.doaHint", { px }) + "\n\n"
        db.slice(0, 18).forEach((d, i) => { out += `<code>${i + 1}</code>. ${esc(d.title)}\n` })
        out += "..."
        const kb = { inline_keyboard: [[
          { text: "🎲 Random", callback_data: "/doa " + (1 + Math.floor(Math.random() * db.length)), style: "success" }
        ]] }
        return m.reply(out, { parse_mode: "HTML", reply_markup: kb })
      }
      const no = parseInt(q)
      const d = no && no <= db.length ? db[no - 1] : db.find(x => String(x.title).toLowerCase().includes(q))
      if (!d) return m.reply(tr("isl3.doaNotFound"), { parse_mode: "HTML" })
      const out = "🤲 <b>" + esc(d.title) + "</b>\n\n" + esc(d.arabic) + "\n\n_<i>" + esc(d.latin) + "</i>_\n\n" + esc(d.translation || "")
      return m.reply(out, { parse_mode: "HTML" })
    }

    /* ── /tahlil — bacaan tahlil dari data WA Furina ── */
    if (command === "tahlil" || command === "tahlil2" || command === "doatahlil") {
      const db = jget(TAHLIL_FILE)
      const arr = db && db.data ? db.data : (Array.isArray(db) ? db : [])
      if (!arr.length) return m.reply(tr("common.failed"), { parse_mode: "HTML" })
      const d = pick(arr)
      const out = "📿 <b>TAHLIL — " + esc(d.title || "Bacaan") + "</b>\n\n" + esc(String(d.arabic || "").slice(0, 700)) + "\n\n_<i>" + esc(String(d.latin || "").slice(0, 300)) + "</i>_\n\n" + esc(String(d.terjemah || d.translation || "").slice(0, 500))
      return m.reply(out, { parse_mode: "HTML" })
    }

    /* ── /asmaulhusna2 — lengkap 99 nama ── */
    if (command === "asmaulhusna2") {
      try {
        const r = await fetch("https://raw.githubusercontent.com/BochilTeam/database/master/religi/asmaulhusna.json", { signal: AbortSignal.timeout(12000) })
        const db = await r.json()
        const d = pick(db)
        const out = "✨ <b>ASMAUL HUSNA</b> (" + d.index + "/99)\n\n" +
          `<b>${esc(d.latin)}</b> — ${esc(d.arabic)}\n\n🇮🇩 ${esc(d.translation_id)}\n🇬🇧 ${esc(d.translation_en || "-")}`
        return m.reply(out, { parse_mode: "HTML" })
      } catch {
        return m.reply(tr("common.failed"), { parse_mode: "HTML" })
      }
    }

    return false
  } catch (e) {
    console.error("[islamic3]", command, e?.message)
    try { await m.reply("❌ " + esc(String(e?.message || e).slice(0, 120)), { parse_mode: "HTML" }) } catch {}
    return false
  }
}

handler.command = ["surah", "surat", "surahpage", "ayat", "murotal", "murotalayat", "jadwalsholat", "sholat", "sholat2", "kiblat", "qibla", "hijri", "kalender", "hijriah", "doa", "doaharian2", "tahlil", "tahlil2", "doatahlil", "asmaulhusna2"]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
