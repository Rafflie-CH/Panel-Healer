// plugin: notif.js — helper untuk kirim notifikasi grup
// dipanggil dari case.js untuk notif create/delete panel, seller, dll.
// TIDAK punya handler command — ini library internal

const sendGroupNotif = async (bot, text) => {
  try {
    const gid = global.notifGroupId
    if (!gid) return
    await bot.sendMessage(gid, text, {
      parse_mode: "HTML",
      disable_web_page_preview: true
    })
  } catch (e) {
    console.log("notif: gagal kirim:", e.message)
  }
}

module.exports = { sendGroupNotif }
