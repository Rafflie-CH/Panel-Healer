// plugin: broadcast.js — /broadcast, /stats, /panelstat
// fitur saran tambahan

const fs = require("fs")
const path = require("path")

const DB = (f) => path.join(__dirname, "..", "library", "database", f)
const antiflood = require("../library/antiflood")

const readArr = (file) => {
  try {
    const j = JSON.parse(fs.readFileSync(DB(file), "utf8"))
    return Array.isArray(j) ? j : []
  } catch { return [] }
}

const readObj = (file) => {
  try {
    const j = JSON.parse(fs.readFileSync(DB(file), "utf8"))
    return (j && typeof j === "object" && !Array.isArray(j)) ? j : {}
  } catch { return {} }
}

const handler = async (m, { Rafz, command, text }) => {
  try {
    const sender = String(m.sender)
    const isOwner = (global.owner || []).includes(sender) ||
                    readArr("owner.json").includes(sender)
    const px = (global.prefix && global.prefix[0]) || "/"
    const tr = (key, vars) => (m.t ? m.t(key, vars) : key)

    /* ─────────────── /broadcast ─────────────── */
    if (command === "broadcast" || command === "bc") {
      if (!isOwner) return m.reply(tr("bc.ownerOnly"))
      if (!text)
        return m.reply(
          `⚠️ <b>${tr("use.usage")}</b>\n<code>${px}bc ${tr("bc.usageText")}</code>\n\n` +
          tr("bc.sentToAll"),
          { parse_mode: "HTML" }
        )

      const cache = readObj("usercache.json")
      const ids = [...new Set(Object.values(cache).map(String))]

      if (!ids.length) return m.reply(tr("bc.noUsers"))

      const wait = await m.reply(`⏳ ${tr("bc.sending", { n: ids.length })}`)

      let ok = 0, fail = 0
      for (const id of ids) {
        try {
          /* auto-retry 429 per user — tunggu limit lepas, jangan gagalkan broadcast */
          await antiflood.withRetry(() => Rafz.sendMessage(id,
            `📢 <b>${tr("bc.from", { owner: global.namaOwner || "Owner" })}</b>\n\n${text}`,
            { parse_mode: "HTML" }
          ), "broadcast:" + id)
          ok++
        } catch { fail++ }
        // throttle — hindari flood
        await new Promise(r => setTimeout(r, Number(global.broadcastDelayMs) || 100))
      }

      try { Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {}) } catch {}
      return m.reply(
        `✅ <b>${tr("bc.done")}</b>\n\n` +
        `📨 ${tr("bc.okCount")} : ${ok}\n` +
        `❌ ${tr("bc.failCount")} : ${fail}\n` +
        `👥 ${tr("bc.totalCount")} : ${ids.length}`,
        { parse_mode: "HTML" }
      )
    }

    /* ─────────────── /stats ─────────────── */
    if (command === "stats") {
      if (!isOwner) return m.reply(tr("bc.ownerOnlyStats"))

      const cache    = readObj("usercache.json")
      const sellers  = readArr("seller.json")
      const supers   = readArr("superseller.json")
      const owners   = readArr("owner.json")
      const panels   = readObj("panel.json")
      const privates = readArr("private.json")

      const totalUsers   = Object.values(cache).length
      const totalPanels  = Object.values(panels).reduce((s, arr) => s + (Array.isArray(arr) ? arr.length : 0), 0)
      const servers      = Object.keys(global.panelServer || {}).length
      const uptime       = process.uptime()
      const uptimeStr    = `${Math.floor(uptime/3600)}h ${Math.floor((uptime%3600)/60)}m ${Math.floor(uptime%60)}s`
      const mem          = process.memoryUsage()
      const memMb        = (mem.rss / 1024 / 1024).toFixed(1)

      return m.reply(
        `📊 <b>${tr("stats.title", { bot: global.botname || "Bot" })}</b>\n\n` +
        `<b>─── ${tr("stats.users")} ───</b>\n` +
        `👥 ${tr("stats.totalUsers")}   : ${totalUsers}\n` +
        `👑 ${tr("stats.owners")}        : ${owners.length + global.owner.length}\n` +
        `⭐ ${tr("stats.supers")} : ${supers.length}\n` +
        `🛒 ${tr("stats.sellers")}       : ${sellers.length}\n` +
        `🔒 ${tr("stats.privates")}      : ${privates.length}\n\n` +
        `<b>─── ${tr("stats.panels")} ───</b>\n` +
        `🖥️ ${tr("stats.totalPanels")}  : ${totalPanels}\n` +
        `🌐 ${tr("stats.serversActive")} : ${servers}\n\n` +
        `<b>─── Bot ───</b>\n` +
        `⏱️ ${tr("stats.uptime")}       : ${uptimeStr}\n` +
        `💾 ${tr("stats.memory")}       : ${memMb} MB\n` +
        `📦 Node.js      : ${process.version}\n` +
        `🔔 ${tr("stats.notifGroup")}   : ${global.notifGroupId ? "✅ " + global.notifGroupId : "❌ " + tr("stats.notSet")}`,
        { parse_mode: "HTML" }
      )
    }

    /* ─────────────── /panelstat — ringkasan panel milik user ─────────────── */
    if (command === "panelstat" || command === "mypanel") {
      const panels = readObj("panel.json")
      const myList = panels[sender] || []
      const servers = global.panelServer || {}

      if (!myList.length)
        return m.reply(tr("mypanel.empty"), { parse_mode: "HTML" })

      let out = `<b>🖥️ ${tr("mypanel.title", { n: myList.length })}</b>\n\n`

      for (const p of myList) {
        const srvName = servers[p.srv]?.name || p.srv
        out += `• ID <code>${p.id}</code> — ${tr("mypanel.server")}: <b>${srvName}</b>\n`
      }

      out += `\n${tr("mypanel.hint", { px })}`

      return m.reply(out, { parse_mode: "HTML" })
    }

    /* ─────────────── /uptime ─────────────── */
    if (command === "uptime") {
      const uptime = process.uptime()
      const h = Math.floor(uptime / 3600)
      const min = Math.floor((uptime % 3600) / 60)
      const sec = Math.floor(uptime % 60)
      const mem = (process.memoryUsage().rss / 1024 / 1024).toFixed(1)
      return m.reply(
        `⏱️ <b>${tr("uptime.title")}</b>\n\n` +
        `🕐 ${h}${tr("uptime.h")} ${min}${tr("uptime.m")} ${sec}${tr("uptime.s")}\n` +
        `💾 ${tr("stats.memory")}: ${mem} MB\n` +
        `📦 Node: ${process.version}`,
        { parse_mode: "HTML" }
      )
    }

    return false
  } catch (e) {
    console.error("[broadcast] command:", command, "error:", e.message)
    try { await m.reply("⚠️ Error: " + e.message) } catch {}
    return false
  }
}

handler.command = ["broadcast", "bc", "stats", "panelstat", "mypanel", "uptime"]
module.exports = handler

try {
  const fs = require("fs")
  const file = require.resolve(__filename)
  fs.watchFile(file, () => {
    try { fs.unwatchFile(file); delete require.cache[file]; require(file) } catch {}
  })
} catch {}
