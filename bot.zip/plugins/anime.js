/* anime.js — anime reaction images SFW (2026-09, semua API terverifikasi hidup).
   - nekos.life   → waifu/neko/hug/kiss/cuddle/pat/slap/smile/cry/happy/dance/wave
   - purrbot.site → blush/smile/cry/happy/nom/bite/kick + gif hug/kiss/pat/poke/slap/cuddle/dance
   - otakugifs    → blush/smile/happy/wink/poke/nom/handhold/highfive/bite/kill/cry/dance/wave
   API MATI DIBUANG: waifu.pics (DNS), waifu.im (403 Cloudflare), some-random-api (403),
   cecan/* (fitur dewasa, dibuang permanen), wallpaper/wallhp (403 Cloudflare).
   Semua reply i18n + fail jelas. */

"use strict"
const https = require("https")
const http = require("http")
const { smartLookup } = require("../library/net")

const UA = "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/130 Mobile Safari/537.36"

const getBuffer = (url) =>
  new Promise((resolve, reject) => {
    try {
      const follow = (u, depth = 0) => {
        if (depth > 5) return reject(new Error("Too many redirects"))
        const parsed = new URL(u)
        const mod = parsed.protocol === "https:" ? https : http
        /* nekos.best (API+CDN) MEMBLOKIR UA Mozilla (403) — pakai UA curl utk host itu */
        const bufUa = /nekos\.best/.test(u) ? "curl/8.5.0" : UA
        mod.get({ hostname: parsed.hostname, path: parsed.pathname + parsed.search, timeout: 60000, lookup: smartLookup, headers: { "User-Agent": bufUa } }, (res) => {
          if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) return follow(new URL(res.headers.location, u).href, depth + 1)
          if (res.statusCode !== 200) return reject(new Error("HTTP " + res.statusCode))
          const c = []
          res.on("data", d => c.push(d))
          res.on("end", () => resolve(Buffer.concat(c)))
        }).on("error", reject).on("timeout", function () { this.destroy(); reject(new Error("Timeout")) })
      }
      follow(url)
    } catch (e) { reject(e) }
  })

const getJSON = (url, ua) =>
  new Promise((resolve, reject) => {
    try {
      const parsed = new URL(url)
      const mod = parsed.protocol === "https:" ? https : http        /* timeout 8s/request: API JSON kecil — cukup. Total worst-case fallback chain
           tetap di bawah deadline /testall (45s) walau semua sumber lambat */
        mod.get({ hostname: parsed.hostname, path: parsed.pathname + parsed.search, timeout: 8000, lookup: smartLookup, headers: { "User-Agent": ua || UA, "Accept": "application/json" } }, (res) => {
        let d = ""
        res.on("data", c => d += c)
        res.on("end", () => { try { resolve(JSON.parse(d)) } catch { resolve(null) } })
      }).on("error", reject).on("timeout", function () { this.destroy(); reject(new Error("Timeout")) })
    } catch (e) { reject(e) }
  })

const pick = (arr) => arr[Math.floor(Math.random() * arr.length)]

/* ── sumber per command: [urlAPI, extractor] — fallback chain antar API ── */
const NEKOS = { waifu: "waifu", neko: "neko", hug: "hug", kiss: "kiss", cuddle: "cuddle", pat: "pat", slap: "slap" }
const PURRBOT = {
  blush: ["sfw/blush/gif"], smile: ["sfw/smile/gif"], cry: ["sfw/cry/gif"],
  bite: ["sfw/bite/gif"],
  hug: ["sfw/hug/gif"], kiss: ["sfw/kiss/gif"], pat: ["sfw/pat/gif"], poke: ["sfw/poke/gif"],
  slap: ["sfw/slap/gif"], cuddle: ["sfw/cuddle/gif"], dance: ["sfw/dance/gif"], neko: ["sfw/neko/gif", "sfw/neko/img"]
}
const OTAKU = {
  blush: "blush", smile: "smile", happy: "happy", wink: "wink", poke: "poke", nom: "nom",
  handhold: "handhold", cry: "cry", dance: "dance", wave: "wave"
}
/* nekos.best — sumber utama utk reaksi yang hanya ada di otakugifs (fallback) */
const NEKOSB = {
  happy: "happy", nom: "nom", handhold: "handhold", wave: "wave", wink: "wink",
  poke: "poke", dance: "dance", cry: "cry", blush: "blush", smile: "smile", bite: "bite"
}
const LABELS = {
  waifu: "Waifu \ud83c\udf38", neko: "Neko \ud83d\udc31", hug: "Hug \ud83e\udde1", kiss: "Kiss \ud83d\udc8b",
  cuddle: "Cuddle \ud83e\udd1d", pat: "Pat \ud83e\uddf3", slap: "Slap \ud83d\udc4b", blush: "Blush \ud83d\ude33",
  smile: "Smile \ud83d\ude0a", cry: "Cry \ud83d\ude2d", happy: "Happy \ud83d\ude04", nom: "Nom \ud83c\udf5c", wink: "Wink \ud83d\ude0c",
  bite: "Bite \ud83e\udeb6", poke: "Poke \ud83d\udc46", handhold: "Handhold \ud83e\udd1d",
  dance: "Dance \ud83d\udd7a", wave: "Wave \ud83d\udc4b"
}
const CMDS = Object.keys(LABELS)

const getJSONRetry = async (url, ua) => {
  try { return await getJSON(url, ua) } catch (e) {
    /* DNS sinkhole sesaat di env tertentu — tunggu 0.8s lalu coba sekali lagi */
    await new Promise(r => setTimeout(r, 800))
    return getJSON(url, ua)
  }
}

const fetchUrl = async (command) => {
  const tries = []
  if (NEKOS[command]) tries.push(async () => {
    const j = await getJSONRetry("https://nekos.life/api/v2/img/" + NEKOS[command])
    if (j && j.url) return j.url
    throw new Error("no url")
  })
  if (PURRBOT[command]) for (const ep of PURRBOT[command]) tries.push(async () => {
    const j = await getJSONRetry("https://purrbot.site/api/img/" + ep)
    if (j && j.link) return j.link
    throw new Error("no link")
  })
  if (NEKOSB[command]) tries.push(async () => {
    /* nekos.best MEMBLOKIR UA "Mozilla" (403) — pakai UA curl (200 OK) */
    const j = await getJSONRetry("https://nekos.best/api/v2/" + NEKOSB[command], "curl/8.5.0")
    if (j && Array.isArray(j.results) && j.results[0] && j.results[0].url) return j.results[0].url
    throw new Error("no url")
  })
  if (OTAKU[command]) tries.push(async () => {
    const j = await getJSONRetry("https://api.otakugifs.xyz/gif?reaction=" + OTAKU[command])
    if (j && j.url) return j.url
    throw new Error("no url")
  })
  /* 2 pass: DNS/network kadang gagal sesaat — retry sekali sebelum menyerah */
  for (let pass = 0; pass < 2; pass++) {
    for (const t of tries) {
      try { return await t() } catch { }
    }
  }
  throw new Error("all sources failed")
}

const sendPhoto = async (Rafz, m, buf, caption) => {
  await Rafz.sendPhoto(m.chat, buf, { caption, reply_to_message_id: m.id, allow_sending_without_reply: true })
}

const handler = async (m, { Rafz, command }) => {
  if (!CMDS.includes(command)) return false
  try {
    const tr = (key) => (m.t ? m.t(key) : key)
    const wait = await m.reply("Mencari gambar...")
    try {
      const url = await fetchUrl(command)
      const buf = await getBuffer(url)
      if (!buf || buf.length < 1000) throw new Error("empty image")
      try { await Rafz.deleteMessage(m.chat, wait.message_id) } catch { }
      await sendPhoto(Rafz, m, buf, LABELS[command] + " \u2764")
      return true
    } catch (e) {
      try { await Rafz.deleteMessage(m.chat, wait.message_id) } catch { }
      return m.reply("Gagal mengambil gambar anime: " + e.message)
    }
  } catch (e) {
    console.error("[anime]", command, e?.message)
    try { await m.reply("Error: " + (e?.message || e)) } catch { }
    return false
  }
}

handler.command = CMDS
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch { } })
} catch { }
