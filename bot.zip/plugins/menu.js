/* /menu - hub tombol yang sadar role + /allmenu (semua fitur per kategori)
   - tombol yang role-nya nggak cukup: HILANG (nggak ditampilin)
   - kalau masih ke-tap (pesan lama / role turun): POPUP alert Telegram,
     pesan menu-nya nggak diubah sama sekali
   - semua tombol PUNYA STYLE WARNA (primary/success/danger) agar muncul
     konsisten di semua device yang mendukung Bot API 9.4+

   callback_data selalu bawa id pemilik pesan di paling belakang:
     /menu home 8342218412
     /menu panel 8342218412
     /menu list admins 8342218412 */

const path = require("path")
const fs = require("fs")
const caseFile = require("../case")

const DB = (f) => path.join(__dirname, "..", "library", "database", f)

const readArr = (file) => {
  try {
    const j = JSON.parse(fs.readFileSync(DB(file), "utf8"))
    return Array.isArray(j) ? j : []
  } catch { return [] }
}

/* daftar fitur yang sedang error — dipakai buat nandain command di menu */
const errorFeatures = () => {
  try {
    const errorLog = require("../library/errorlog")
    return errorLog.getErrors().map(e => String(e.feature || "").toLowerCase())
  } catch { return [] }
}

let handler = async (m, { conn, Rafz, args }) => {
  try {

    const tr = (key, vars) => (m.t ? m.t(key, vars) : key)
    const px = m.prefix || (global.prefix && global.prefix[0]) || "/"
    const sender = String(m.sender)

    /* ---------- role ---------- */
    const isCreator = global.owner.includes(sender)
    const isOwnerDB = readArr("owner.json").includes(sender)
    const isSuperDB = readArr("superseller.json").includes(sender)
    const isSellerDB = readArr("seller.json").includes(sender)

    const isOwner = isCreator || isOwnerDB
    const isSuper = isSuperDB || isOwner
    const isSeller = isSellerDB || isSuper
    const isPrivate = isCreator || readArr("private.json").includes(sender)

    const role = isCreator ? tr("menu.roleCreator")
      : isOwnerDB ? tr("menu.roleOwner")
        : isSuperDB ? tr("menu.roleSuper")
          : isSellerDB ? tr("menu.roleSeller")
            : tr("menu.roleUser")

    /* ---------- tabel akses ---------- */
    const ACCESS = { user: true, seller: isSeller, super: isSuper, owner: isOwner, private: isPrivate, creator: isCreator }
    const canUse = (need) => !!ACCESS[need || "user"]

    /* ---------- isi section ---------- */
    const _errList = errorFeatures()
    const escTxt = (s) => String(s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
    const cmd = (usage, need, hint) => {
      if (!canUse(need)) return ""          /* command yang nggak boleh -> jangan ditampilin */
      /* hint bisa berupa key i18n (menu.hint.*) atau sudah berupa teks jadi */
      const hintText = hint ? (hint.includes(".") && hint.startsWith("menu.") ? tr(hint) : hint) : ""
      /* ONE PER LINE: "warn/dwarn/swarn" atau "1gb|2gb|..." → tiap command di baris sendiri.
         Deskripsi setelah " — " hanya di baris pertama. */
      const [mainPart, ...descParts] = usage.split(" — ")
      const desc = descParts.join(" — ")
      const variants = mainPart.split(/[|/]/).map(s => s.trim()).filter(Boolean)
      let out = ""
      variants.forEach((v, i) => {
        const base = v.split(/\s+/)[0].toLowerCase()
        const bad = _errList.includes(base)
        const h = i === 0 && hintText ? " — " + escTxt(hintText) : (i === 0 && desc ? " — " + escTxt(desc) : "")
        out += `<code>${px}${escTxt(v)}</code>${bad ? " ❌" : ""}${h}\n`
      })
      return out
    }
    const head = (title) => `<blockquote><b>${title}</b></blockquote>\n`
    const hintBtn = tr("menu.buttonHint")

    const SECTIONS = {
      panel: { btn: "menu.btnPanel", head: () => tr("menu.panelMenu"), items: [
        ["cpanel user|id/tag/me|ram|bulan|server", "seller", hintBtn],
        ["1gb|2gb|...|10gb nama|target", "seller", "menu.hint.fastPanel"],
        ["unli nama|target", "seller", "menu.hint.unliPanel"],
        ["listpanel", "seller"],
        ["delpanel id|server", "seller"],
        ["mypanel", "user"],
        ["cleanpanel 1|2|3|123|server", "owner"],
        ["blclean bl|unbl|id|server", "owner"]
      ] },
      admin: { btn: "menu.btnAdmin", head: () => tr("menu.adminMenu"), items: [
        ["cadmin user|id/tag/me|server", "owner", hintBtn],
        ["listadmin", "owner"],
        ["deladmin id", "owner"]
      ] },
      seller: { btn: "menu.btnSeller", head: () => tr("menu.sellerMenu"), items: [
        ["addseller id|@username|reply", "owner"],
        ["listseller", "owner"],
        ["delseller id|@username|reply", "owner"],
        ["addseller2/delseller2 id|reply", "owner", "menu.hint.viaReply"],
        ["addsuper2/delsuper2 id|reply", "owner", "menu.hint.viaReply"],
        ["addowner2/delowner2 id|reply", "owner", "menu.hint.viaReply"],
        ["warn2/cekwarn/resetwarn2", "owner", "menu.hint.warn2"]
      ] },
      owner: { btn: "menu.btnOwner", head: () => tr("menu.ownerMenu"), items: [
        ["addowner id|@username|reply", "owner"],
        ["listowner", "owner"],
        ["delowner id|@username|reply", "creator"],
        ["set botname|ownername|prefix|lang|server|backup", "creator", "menu.hint.setVia"],
        ["set amkey|tolakbot", "creator", "menu.hint.setKey"],
        ["getset", "creator", "menu.hint.seeSet"],
        ["panelmanager", "creator", "menu.hint.panelmanager"],
        ["addserver id|nama|domain|apikey", "creator", "menu.hint.addserver"],
        ["delserver id", "creator"],
        ["servers", "creator", "menu.hint.servers"],
        ["addsubdo domain|zone|apikey", "creator", "menu.hint.addsubdo"],
        ["deldomain domain", "creator"],
        ["clone", "creator", "menu.hint.clone"],
        ["clonelist", "creator", "menu.hint.cloneList"],
        ["stopclone index", "creator", "menu.hint.stopclone"],
        ["clonedel index", "creator"],
        ["addfitur nama|kode", "creator", "menu.hint.addFeature"],
        ["delfitur nama", "creator", "menu.hint.delFeature"],
        ["ambilfitur nama", "creator", "menu.hint.getFeature"],
        ["listfitur", "creator", "menu.hint.listFeature"],
        ["getcase nama", "creator", "menu.hint.getCase"],
        ["testall", "creator", "menu.hint.testAll"],
        ["errorlist|geterror", "creator", "menu.hint.errList"],
        ["errorfix nama", "creator", "menu.hint.errFix"],
        ["errorcode nama", "creator", "menu.hint.errCode"],
        ["errordelete nama", "creator", "menu.hint.errDelete"]
      ] },
      monitor: { btn: "menu.btnMonitor", head: () => "◈ MONITOR PANEL", items: [
        ["monitor", "owner"],
        ["monitor on|off", "owner"],
        ["top10", "owner"],
        ["unsuspend id|server", "owner"],
        ["monhelp", "owner"]
      ] },
      domain: { btn: "menu.btnDomain", head: () => tr("menu.domainMenu"), items: [
        ["cdomain sub|ip|on/off|domain", "owner"],
        ["cdomainpanel nama|ip|domain", "owner"],
        ["listsubdo domain", "owner"],
        ["delsubdo host|domain", "owner"]
      ] },
      pv: { btn: "menu.btnPv", head: () => tr("menu.pvMenu"), items: [
        ["pvhelp", "private"],
        ["pvcreate nama|id|ram|cpu|disk", "private"],
        ["pvlist", "private"],
        ["pvinfo id", "private"],
        ["pvdelete id", "private"],
        ["pvstart|pvstop id", "private"],
        ["addpv id|@username|reply", "owner"],
        ["listpv", "owner"],
        ["delpv id|@username|reply", "owner"]
      ] },
      lang: { btn: "menu.btnLang", head: () => tr("menu.langMenu"), items: [] },
      /* ── KATEGORI USER ── */
      downloader: { btn: "menu.btnDownloader", head: () => "📥 DOWNLOADER", items: [
        ["yts judul", "user", "menu.hint.yts"],
        ["ytdl link", "user", "menu.hint.ytdl"],
        ["play nama lagu", "user", "menu.hint.play"],
        ["tt link", "user", "menu.hint.tt"],
        ["mediafire link", "user", "menu.hint.mediafire"],
        ["gitclone link", "user", "menu.hint.gitclone"],
        ["spotify link", "user", "menu.hint.spotify"],
        ["soundcloud link", "user", "menu.hint.soundcloud"],
        ["terabox link", "user", "menu.hint.terabox"],
        ["capcut link", "user", "menu.hint.capcut"],
        ["threads link", "user", "menu.hint.threads"],
        ["tourl", "user", "menu.hint.tourl"],
        ["ttsearch kata", "user", "menu.hint.ttsearch"],
        ["scs|ssearch kata", "user", "menu.hint.scs"],
        ["pindl link pin", "user", "menu.hint.pindl"],
        ["sfile|gdrive kata", "user", "menu.hint.sfile"],
        ["apkmod|happymod app", "user", "menu.hint.apkmod"],
        ["aiodl link", "user", "menu.hint.aiodl"],
        ["ttnowm|ttaudio|ttinfo link", "user", "menu.hint.ttnowm"],
        ["mcserver addr", "user", "menu.hint.mcserver"],
        ["kurs [USD]", "user", "menu.hint.kurs"],
        ["gempa2 — gempa dirasakan", "user", "menu.hint.gempa2"],
        ["provinsi — wilayah Indonesia", "user", "menu.hint.provinsi"]
      ] },
      sticker: { btn: "menu.btnSticker", head: () => "🎨 STICKER & BRAT", items: [
        ["brat teks", "user", "menu.hint.brat"],
        ["sticker", "user", "menu.hint.sticker"],
        ["stickerinfo", "user", "menu.hint.stickerinfo"],
        ["qc teks", "user", "menu.hint.qc"],
        ["smeme atas , bawah", "user", "menu.hint.smeme"],
        ["style teks", "user", "menu.hint.style"],
        ["ttp2 | attp2 teks — sticker teks/animasi", "user", "menu.hint.ttp"],
        ["toimg", "user", "menu.hint.toimg"],
        ["emojimix 😄+😎", "user", "menu.hint.emojimix"],
        ["fakereact teks|emoji", "user", "menu.hint.fakereact"],
        ["typewriter teks", "user", "menu.hint.typewriter"],
        ["captcha", "user", "menu.hint.captcha"],
        ["tohd|tograyscale|tosepia", "user", "menu.hint.filter"],
        ["toblur|topixel|tocircle", "user", "menu.hint.filter"],
        ["flip|flop|rotate (reply foto)", "user", "menu.hint.filter"]
      ] },
      rose: { btn: "menu.btnRose", head: () => "🌹 ROSE MODERATION", items: [
        ["connect — kelola grup dari PM", "admin", "menu.hint.connect"],
        ["ban/tban/unban + d/s varian", "admin", "menu.hint.roseMod"],
        ["mute/tmute/unmute + d/s varian", "admin", "menu.hint.roseMod"],
        ["kick/dkick/skick", "admin", "menu.hint.roseMod"],
        ["setwarnlimit/setwarnmode/warnings", "admin", "menu.hint.roseWarn"],
        ["warn/dwarn/swarn → warns/unwarn/resetwarn", "admin", "menu.hint.roseWarn"],
        ["promote/demote/admincache", "admin", "menu.hint.roseAdmin2"],
        ["adminerror/anonadmin (on|off)", "admin", "menu.hint.roseAdmin2"],
        ["rules/setrules/clearrules", "admin", "menu.hint.roseMisc"],
        ["id/info/privacy/ping", "user", "menu.hint.roseMisc"],
        ["language — ganti bahasa id/en", "user", null],
        ["log/nolog/setlog — log channel", "admin", "menu.hint.roseAdmin2"],
        ["silentactions/disableable/cleancommand", "admin", "menu.hint.roseAdmin2"],
        ["export/import/resetgroup — backup setelan", "admin", "menu.hint.roseMisc"],
        ["afk/unafk — status AFK", "user", "menu.hint.roseMisc"],
        ["gif/ud — cari GIF & kamus urban", "user", "menu.hint.roseMisc"],
        ["setcaptchatext/captchamutetime/captchakicktime", "admin", "menu.hint.roseCaptcha"],
        ["purge/spurge/purgefrom+purgeto/del", "admin", "menu.hint.rosePurge"],
        ["lock/unlock/locks/locktypes", "admin", "menu.hint.roseLocks"],
        ["addblocklist/blocklist/rmblocklist", "admin", "menu.hint.roseBlocklist"],
        ["blocklistdelete (on|off)", "admin", "menu.hint.roseBlocklist"],
        ["setflood/setfloodmode/flood", "admin", "menu.hint.roseFlood"],
        ["antiraid/raidtime/raidactiontime/autoantiraid", "admin", "menu.hint.roseRaid"],
        ["captcha/captchamode", "admin", "menu.hint.roseCaptcha"],
        ["setwelcome/setgoodbye/cleanwelcome", "admin", "menu.hint.roseWelcome"],
        ["filter/stop/filters", "admin", "menu.hint.roseFilters"],
        ["save/get/notes (note #trigger)", "admin", "menu.hint.roseNotes"],
        ["privatenotes (on|off) — note ke PM", "admin", "menu.hint.roseNotes"],
        ["disable/enable/disabled", "admin", "menu.hint.roseNotes"],
        ["newfed/joinfed/fban/fedinfo", "admin", "menu.hint.roseFed"],
        ["renamefed/myfeds/fedstat/fedsubs/fedadmins", "admin", "menu.hint.roseFed"]
      ] },
      shield: { btn: "menu.btnShield", head: () => "🛡️ SHIELD PROTECTRON", items: [
        ["status — cek permission bot", "admin", "menu.hint.shieldStatus"],
        ["nolinks/noforwards/nolocations", "admin", "menu.hint.shieldToggles"],
        ["nocontacts/nocommands/nohashtags", "admin", "menu.hint.shieldToggles"],
        ["novoice/noevents/nobots", "admin", "menu.hint.shieldToggles"],
        ["antispam/antispam_mode", "admin", "menu.hint.shieldToggles"],
        ["profanity/imagefilter (+checknsfw)", "admin", "menu.hint.shieldToggles"],
        ["blacklist_add/blacklist_remove", "admin", "menu.hint.shieldBlacklist"],
        ["whitelist_add/whitelist_remove", "admin", "menu.hint.shieldBlacklist"],
        ["warningbans — ban lintas grup", "admin", "menu.hint.shieldWb"],
        ["reportspam (reply spam)", "admin", "menu.hint.shieldWb"],
        ["welcome_set — teks welcome", "admin", "menu.hint.roseWelcome"]
      ] },
      barker: { btn: "menu.btnBarker", head: () => "📣 BARKER TAG", items: [
        ["all — tag semua member", "admin", "menu.hint.barkerAll"],
        ["callone 10 — satu-satu", "admin", "menu.hint.barkerCall"],
        ["calladmins — tag admin saja", "admin", "menu.hint.barkerCall"],
        ["setme/me/bigme — callsign", "user", "menu.hint.barkerMe"],
        ["unreg — keluar dari tag /all", "user", "menu.hint.barkerMe"],
        ["addhelper — helper bot pribadi", "admin", "menu.hint.barkerAdv"],
        ["upatterns/cpatterns — template tag", "user", "menu.hint.barkerAdv"]
      ] },
      effects: { btn: "menu.btnEffects", head: () => "🎨 EFFECT MAKER (800+)", items: [
        ["listfx — browse 800+ efek", "user", "menu.hint.listfx"],
        ["(fx) teks — 500+ text effect", "user", "menu.hint.fxText"],
        ["contoh: neon, galaxy, avenger, blackpink", "user", null],
        ["(fx) teks1|teks2 — efek 2 teks", "user", "menu.hint.fxText2"],
        ["(fx) (reply foto) — 350 photo frame", "user", "menu.hint.fxPhoto"],
        ["contoh: brokenglass, pencilphoto, tearphoto", "user", null]
      ] },
      faker: { btn: "menu.btnFaker", head: () => "🎭 FAKER (all local render)", items: [
        ["ektp|fakektp nama|kota|lahir|kerja", "user", "menu.hint.fakerKtp"],
        ["fakedana|fakeovo|fakegopay|fakebca", "user", "menu.hint.fakerPay"],
        ["fakeqris|fakebangjago jumlah|nama", "user", null],
        ["fakeff|fakeml — lobby game", "user", "menu.hint.fakerGame"],
        ["fakejuara hero|nama — victory ML", "user", null],
        ["fakewa|faketweet|fakevn teks", "user", "menu.hint.fakerChat"],
        ["fakech channel|teks — WA channel", "user", null],
        ["fakegc grup|penulis|teks", "user", null],
        ["fakedev — pesan dev WA", "user", null],
        ["fakeig user|post|follower|following|bio", "user", "menu.hint.fakerSoc"],
        ["fakestory user|teks — IG story", "user", null],
        ["fakethread user|teks — Threads", "user", null],
        ["fakenotif app|judul|teks", "user", "menu.hint.fakerHp"],
        ["fakecallandro|fakecallios|fakecallwa nama", "user", null],
        ["fakewafat nama|tanggal — in memoriam", "user", null],
        ["fakedj judul — music card", "user", null],
        ["suratsakit nama|instansi|hari", "user", null],
        ["undangannikah nama1|nama2|tempat|tgl", "user", null]
      ] },
      maker: { btn: "menu.btnMaker", head: () => "🖨️ MAKER & TEXT LOGO", items: [
        ["blackpink teks", "user", "menu.hint.blackpink"],
        ["pornhub teks|teks", "user", "menu.hint.pornhub"],
        ["glitch|avengers|naruto teks", "user", "menu.hint.textpro"],
        ["bear|wolfgalaxy|grafitti teks", "user", "menu.hint.textpro"],
        ["wetglass|pavement|comic teks", "user", "menu.hint.textpro"],
        ["devilwings|mascot|pixelglitch teks", "user", "menu.hint.textpro"],
        ["ektp nama|kota|tgl|kerja", "user", "menu.hint.ektp"],
        ["suratsakit nama|instansi|hari", "user", "menu.hint.suratsakit"],
        ["undangannikah nama|nama|tempat|tgl", "user", "menu.hint.undangan"]
      ] },
      fake: { btn: "menu.btnFake", head: () => "💸 FAKE & PRANK", items: [
        ["fakelobby ff|judul", "user", "menu.hint.fakelobby"],
        ["fakeff|fakeml judul", "user", "menu.hint.fakeff"],
        ["fakedana nominal|nama", "user", "menu.hint.fakedana"],
        ["fakeovo|fakegopay nominal|nama", "user", "menu.hint.fakepay"],
        ["fakebca|fakeqris nominal|nama", "user", "menu.hint.fakepay"],
        ["faketweet teks", "user", "menu.hint.faketweet"],
        ["fakewa teks", "user", "menu.hint.fakewa"]
      ] },
      premium: { btn: "menu.btnPremium", head: () => "✨ ALIGHT MOTION PREMIUM", items: [
        ["ampremium email", "user", "menu.hint.ampremium"],
        ["amverify email|link", "user", "menu.hint.amverify"],
        ["amreg email|nama", "user", "menu.hint.amreg"],
        ["amotp kode", "user", "menu.hint.amotp"],
        ["presetam link", "user", "menu.hint.presetam"]
      ] },
      stalker: { btn: "menu.btnStalker", head: () => "🕵️ STALKER & SEARCH", items: [
        ["githubstalk user", "user", "menu.hint.githubstalk"],
        ["npmstalk paket", "user", "menu.hint.npmstalk"],
        ["igstalk user", "user", "menu.hint.igstalk"],
        ["tiktokstalk user", "user", "menu.hint.tiktokstalk"],
        ["ffstalk id", "user", "menu.hint.ffstalk"],
        ["robloxstalk user", "user", "menu.hint.robloxstalk"],
        ["ytstalk channel", "user", "menu.hint.ytstalk"],
        ["discordstalk id", "user", "menu.hint.discordstalk"],
        ["gempa", "user", "menu.hint.gempa"],
        ["google kata", "user", "menu.hint.google"],
        ["pinterest kata", "user", "menu.hint.pinterest"],
        ["lirik|chord judul", "user", "menu.hint.lirik"],
        ["kbbi kata", "user", "menu.hint.kbbi"],
        ["gsmarena hp", "user", "menu.hint.gsmarena"],
        ["info reply/id/@user", "user", "menu.hint.info"],
        ["pinstalk user", "user", "menu.hint.pinstalk"],
        ["npmsearch|npmstalk2 paket", "user", "menu.hint.npmsearch"],
        ["robloxstalk2 user", "user", "menu.hint.robloxstalk"],
        ["threadsstalk user", "user", "menu.hint.threadsstalk"],
        ["xstalk user", "user", "menu.hint.xstalk"],
        ["modrinth mod", "user", "menu.hint.modrinth"],
        ["fontlist font", "user", "menu.hint.fontlist"],
        ["apkmirror|apkpure app", "user", "menu.hint.apksearch"]
      ] },
      tools: { btn: "menu.btnTools", head: () => "🛠️ TOOLS", items: [
        ["short link", "user", "menu.hint.short"],
        ["qr teks", "user", "menu.hint.qr"],
        ["calc 12*(3+4)", "user", "menu.hint.calc"],
        ["weather kota", "user", "menu.hint.weather"],
        ["wiki kata", "user", "menu.hint.wiki"],
        ["tr en teks", "user", "menu.hint.tr"],
        ["ip 8.8.8.8", "user", "menu.hint.ip"],
        ["github user", "user", "menu.hint.github"],
        ["npm paket", "user", "menu.hint.npm"],
        ["pass 16", "user", "menu.hint.pass"],
        ["b64 enc|dec teks", "user", "menu.hint.b64"],
        ["hash sha256 teks", "user", "menu.hint.hash"],
        ["time kota", "user", "menu.hint.time"],
        ["ss url", "user", "menu.hint.ss"],
        ["tts en teks", "user", "menu.hint.tts"],
        ["define word", "user", "menu.hint.define"],
        ["getid", "user", "menu.hint.getid"]
      ] },
      audio: { btn: "menu.btnAudio", head: () => "🎧 AUDIO FX & CONVERT", items: [
        ["bass|blown|earrape|nightcore", "user", "menu.hint.audiofx"],
        ["fast|slow|robot|squirrel|deep", "user", "menu.hint.audiofx"],
        ["reverse|fat|removenoise", "user", "menu.hint.audiofx"],
        ["tupai", "user", "menu.hint.tupai"],
        ["tovn|toptt|tomp3", "user", "menu.hint.toaudio"],
        ["tovideo", "user", "menu.hint.tovideo"],
        ["removebg", "user", "menu.hint.removebg"]
      ] },
      utility: { btn: "menu.btnUtility", head: () => "🧰 UTILITY & ISLAMIC", items: [
        ["alquran number", "user", "menu.hint.alquran"],
        ["murotal number", "user", "menu.hint.murotal"],
        ["kisahnabi nama", "user", "menu.hint.kisahnabi"],
        ["jadwalsholat kota", "user", "menu.hint.jadwalsholat"],
        ["hadist kitab|no", "user", "menu.hint.hadist"],
        ["artimimpi mimpi", "user", "menu.hint.artimimpi"],
        ["zodiak|shio|weton", "user", "menu.hint.primbon"],
        ["ramalanjodoh nama|nama", "user", "menu.hint.ramalanjodoh"],
        ["artinama nama", "user", "menu.hint.artinama"],
        ["doa|wirid|asmaulhusna", "user", "menu.hint.islamic2"],
        ["ayatkursi|niatsholat|tahlil", "user", "menu.hint.islamic2"],
        ["surah 1 | surah al-fatihah", "user", "menu.hint.surah3"],
        ["ayat 2:255", "user", "menu.hint.ayat3"],
        ["murotal — audio full surah", "user", "menu.hint.murotal3"],
        ["kiblat | hijri | kalender", "user", "menu.hint.kiblat3"],
        ["asmaulhusna2 — random 99 nama", "user", "menu.hint.islamic2"]
      ] },
      webx: { btn: "menu.btnWebx", head: () => "🌐 WEB & MUSIC", items: [
        ["genius lagu — cari lagu (Genius)", "user", "menu.hint.genius"],
        ["deezer lagu — cari lagu (Deezer)", "user", null],
        ["archive kata — Internet Archive", "user", "menu.hint.archive"],
        ["wayback url — cek arsip lama", "user", null],
        ["tweet url — info tweet + foto", "user", "menu.hint.tweet"],
        ["tempmail / tempmailcheck — email sementara", "user", "menu.hint.tempmail"],
        ["searchfit kata — cari fitur bot", "user", "menu.hint.searchfit"],
        ["ffstalk id — cek nama FF", "user", "menu.hint.ffstalk"],
        ["githubstalk user — profil GitHub", "user", null],
        ["npmstalk paket — info npm detail", "user", null],
        ["tarot — kartu tarot + gambar", "user", null],
        ["sambungkata — game sambung kata", "user", null]
      ] },
      news: { btn: "menu.btnNews", head: () => "📰 NEWS & PRIMBON API", items: [
        ["beritacnn|beritakompas|beritaantara", "user", "menu.hint.berita"],
        ["beritaliputan6|beritamerdeka", "user", null],
        ["beritasuara|beritasindonews|beritacnbc", "user", null],
        ["beritatribun", "user", null],
        ["artinama nama — arti nama", "user", "menu.hint.primbonApi"],
        ["tafsirmimpi mimpi", "user", null],
        ["kecocokanpasangan nama1|nama2", "user", null],
        ["ramalanjodoh n1|tgl|bln|thn|n2|tgl|bln|thn", "user", null],
        ["potensipenyakit tgl|bln|thn", "user", null],
        ["rejekihoki tgl|bln|thn — weton", "user", null],
        ["sifatusaha tgl|bln|thn", "user", null],
        ["kodepos carian", "user", "menu.hint.kodepos"],
        ["countryinfo negara", "user", null],
        ["threadsstalk username", "user", null],
        ["pinterest2|duckduckgo2|brave kata", "user", "menu.hint.searchApi"],
        ["spotifysearch|applemusic kata", "user", null]
      ] },
      fun: { btn: "menu.btnFun", head: () => "🎲 FUN & GAMES", items: [
        ["8ball pertanyaan", "user", "menu.hint.8ball"],
        ["dice | coin | roll", "user", "menu.hint.quick"],
        ["rate sesuatu", "user", "menu.hint.rate"],
        ["love a & b", "user", "menu.hint.love"],
        ["pick a, b, c", "user", "menu.hint.pick"],
        ["bucin | quote", "user", "menu.hint.words"],
        ["wpick @a @b", "user", "menu.hint.wpick"],
        ["artitarot|fakta|puisi", "user", "menu.hint.random"],
        ["bijak|gombalan|motivasi", "user", "menu.hint.random"],
        ["cerpen|kepo|arahrezeki", "user", "menu.hint.random"],
        ["ttt bot|@user", "user", "menu.hint.ttt"],
        ["tebakbendera/asahotak/susunkata", "user", "menu.hint.quiz"],
        ["siapakahaku/tebaktebakan", "user", "menu.hint.quiz"],
        ["family100", "user", "menu.hint.family100"],
        ["tebakangka|tebakkata|tebakgambar", "user", "menu.hint.quiz"],
        ["slot|suit|dare|truth", "user", "menu.hint.games"],
        ["apakah/bisakah/kapankah", "user", "menu.hint.askbot"],
        ["cekkodam/cekjodoh/cekwibu", "user", "menu.hint.cek"],
        ["checkme", "user", "menu.hint.checkme"],
        ["janda/duda/jelek/ganteng/cantik", "user", "menu.hint.cek"],
        ["nikah/pesugihan/hoki/future", "user", "menu.hint.cek"],
        ["haribaik/harisial/nasib/rezeki", "user", "menu.hint.cek"],
        ["tebaklagu/tebakkata/tebakgame", "user", "menu.hint.quiz"],
        ["tebakbom", "user", "menu.hint.quiz"],
        ["caklontong/tebakkalimat/tebakkimia", "user", "menu.hint.quiz"],
        ["tebakkabupaten/tebaklirik/tebakbendera2", "user", "menu.hint.quiz"],
        ["soal3 — lihat soal aktif", "user", "menu.hint.soal3"],
        ["pantun/renungan/katacinta", "user", "menu.hint.random"],
        ["gombal2/bucin2/motivasi2/bijak2", "user", "menu.hint.random"],
        ["fakta2/wangy nama", "user", "menu.hint.random"],
        ["siapa/kapan/dimana", "user", "menu.hint.quiz"]
      ] },
      anime: { btn: "menu.btnAnime", head: () => "🌸 ANIME", items: [
        ["waifu|neko|shinobu|megumin", "user", "menu.hint.randomPic"],
        ["awoo|bully|cuddle|cry|hug", "user", "menu.hint.reaction"],
        ["kiss|pat|smug|bonk|yeet", "user", "menu.hint.reaction"],
        ["blush|smile|wave|highfive", "user", "menu.hint.reaction"],
        ["handhold|nom|bite|glomp", "user", "menu.hint.reaction"],
        ["slap|kill|kick|happy|wink", "user", "menu.hint.reaction"],
        ["poke|dance|cringe", "user", "menu.hint.reaction"],
        ["randomchina|indo|vietnam|thailand", "user", "menu.hint.randomPic"],
        ["randomkorea|japan|malaysia", "user", "menu.hint.randomPic"],
        ["animequote|quotesanime", "user", "menu.hint.animequote"],
        ["wallpaper|wallhp", "user", "menu.hint.wallpaper"]
      ] },
      ai: { btn: "menu.btnAI", head: () => "🤖 AI CHAT", items: [
        ["ai pertanyaan", "user", "menu.hint.ai"],
        ["gpt|deepseek|claude", "user", "menu.hint.aiAlias"],
        ["blackbox|llama|mistral", "user", "menu.hint.aiAlias"]
      ] },
      group: { btn: "menu.btnGroup", head: () => "👥 GROUP & PROTECT", items: [
        ["warn/unwarn/warns", "user", "menu.hint.roseWarn"],
        ["antilink/antitoxic/antivirtex", "user", "menu.hint.protect"],
        ["tagall/adminlist/rules", "user", "menu.hint.groupAdmin"],
        ["grouplink/lock/unlock", "user", "menu.hint.groupAdmin"],
        ["mute/unmute/pin/unpin", "user", "menu.hint.groupAdmin"],
        ["purge/kickme/report", "user", "menu.hint.groupAdmin"],
        ["pengumuman teks", "user", "menu.hint.pengumuman"],
        ["absen/absenlist/absenreset", "user", "menu.hint.absen"],
        ["votemulai tanya|a|b", "user", "menu.hint.vote"],
        ["votehasil/voteselesai", "user", "menu.hint.vote"]
      ] },
      owner_tools: { btn: "menu.btnOwnerTools", head: () => "⚙️ OWNER TOOLS", items: [
        ["broadcast pesan", "owner", "menu.hint.broadcast"],
        ["stats", "owner", "menu.hint.stats"],
        ["uptime", "user", "menu.hint.uptime"],
        ["topcmd|topmessage", "user", "menu.hint.topstats"],
        ["afk alasan", "user", "menu.hint.afk"],
        ["addgb", "owner", "menu.hint.addgb"],
        ["ping", "creator", "menu.hint.ping"],
        ["setcommands", "creator", "menu.hint.setcommands"]
      ] },
      backup: { btn: "menu.btnBackup", head: () => "💾 BACKUP", items: [
        ["backup", "owner", "menu.hint.backup"],
        ["backupset jam", "owner", "menu.hint.backupset"]
      ] },
      extra: { btn: "menu.extraMenu", head: () => tr("menu.extraMenu"), items: [
        ["say teks", "user"],
        ["getpp reply/id/@user", "user", "menu.hint.getpp"],
        ["batal", "user", "menu.hint.batal"],
        ["copy teks", "creator"]
      ] },
      /* isinya daftar server slot (lihat serversBody) */
      servers: { btn: "menu.btnServer", head: () => tr("menu.serverMenu"), items: [] }
    }

    /* body satu section (cuma baris yang boleh) */
    const bodyOf = (key) => {
      const S = SECTIONS[key]
      if (!S) return ""
      if (key === "lang") return head(S.head()) + `<code>${px}lang</code> — ${tr("menu.langHint")} 🇬🇧 / 🇮🇩\n`
      if (key === "servers") return serversBody()
      return (S.items.some(([, need]) => canUse(need)) ? head(S.head()) : "") +
        S.items.map(([u, need, h]) => cmd(u, need, h)).join("")
    }

    /* section dianggap ada kalau minimal 1 barisnya boleh dipakai */
    const sectionOpen = (key) => {
      if (key === "help") return true
      if (key === "lang") return true
      if (key === "servers") return true
      const S = SECTIONS[key]
      return !!S && S.items.some(([, need]) => canUse(need))
    }

    const serverList = Object.entries(global.panelServer || {})
      .map(([id, s]) => `• ${id}. ${s.name}`)
      .join("\n") || tr("menu.noServer")

    /* daftar server: section-nya sendiri, bukan cuma nempel di Help */
    const serversBody = () =>
      head(tr("menu.serverMenu")) +
      serverList + "\n\n" +
      `<blockquote>${tr("menu.serverHint")}\n${tr("menu.pickServer")}</blockquote>`

    const helpBody = () =>
      head(tr("menu.userInfo")) +
      `• ${tr("menu.name")} : <code>${m.pushName}</code>\n` +
      `• ${tr("menu.id")}   : <code>${sender}</code>\n` +
      `• ${tr("menu.role")} : <code>${role}</code>\n\n` +
      Object.keys(SECTIONS).filter(k => k !== "servers").map(k => bodyOf(k)).filter(Boolean).join("\n") +
      `<blockquote>${tr("menu.activePrefix")} ${(global.prefix || ["/"]).join(" ")}</blockquote>`

    /* /allmenu — semua fitur + kategori, tanpa tombol per-section */
    const allMenuText = () => {
      const t0 = new Date().toLocaleString(global.locale || "id-ID", { timeZone: global.timeZone || "Asia/Jakarta" })
      let out =
        `<b>╭━━━〔 🌐 ${global.botname} 〕━━━╮</b>\n` +
        `<blockquote>📚 ALL MENU — Total ${tr("menu.totalCmds")}</blockquote>\n` +
        `<b>╰━━━━━━━━━━━━━━━━━━━━╯</b>\n\n` +
        head(tr("menu.userInfo")) +
        `• ${tr("menu.name")} : <code>${m.pushName}</code>\n` +
        `• ${tr("menu.id")}   : <code>${sender}</code>\n` +
        `• ${tr("menu.role")} : <code>${role}</code>\n` +
        `• 🕐 <code>${t0}</code>\n\n`

      for (const k of Object.keys(SECTIONS)) {
        if (k === "servers") continue
        const body = bodyOf(k)
        if (body) out += body + "\n"
      }
      out += `<blockquote>${tr("menu.activePrefix")} ${(global.prefix || ["/"]).join(" ")}</blockquote>`
      return out
    }

    /* ---------- teks ---------- */
    const hubText = () =>
      `<b>╭━━━〔 🌐 ${global.botname} 〕━━━╮</b>\n` +
      `<blockquote>${tr("menu.tagline")}</blockquote>\n` +
      `<b>╰━━━━━━━━━━━━━━━━━━━━╯</b>\n\n` +
      head(tr("menu.userInfo")) +
      `• ${tr("menu.name")} : <code>${m.pushName}</code>\n` +
      `• ${tr("menu.id")}   : <code>${sender}</code>\n` +
      `• ${tr("menu.role")} : <code>${role}</code>\n\n` +
      `<b>────────────────────</b>\n` +
      `<blockquote>${tr("menu.chooseMenu")}</blockquote>\n` +
      `<blockquote>${tr("menu.listsHint")}</blockquote>\n\n` +
      `<blockquote>${tr("menu.activePrefix")} ${(global.prefix || ["/"]).join(" ")}</blockquote>`

    /* ---------- tombol ---------- */
    const cb = (sec, extra) => "/menu " + sec + (extra ? " " + extra : "") + " " + sender
    /* SEMUA tombol punya style warna → warna konsisten muncul di semua button */
    const btn = (label, data, style) => ({ text: label, callback_data: data, style: style || "primary" })
    const btnBack = () => ({ text: tr("menu.btnBack"), callback_data: cb("home"), style: "danger" })
    const btnHome = () => ({ text: "🏠 " + tr("menu.btnHome"), callback_data: cb("home"), style: "danger" })
    const btnAll = () => ({ text: "📚 " + tr("menu.btnAllMenu"), callback_data: cb("allmenu"), style: "success" })

    /* urutan tombol kategori di hub menu */
    const SECT_BTNS = ["help", "servers", "panel", "admin", "owner", "seller", "monitor", "domain", "pv",
      "downloader", "sticker", "maker", "fake", "premium", "stalker", "tools", "audio", "utility",
      "fun", "anime", "ai", "group", "owner_tools", "backup", "lang", "extra"]

    /* baris tombol section: dibuang yang role-nya nggak cukup, dipasang 2 per baris.
       WARNA MERATA: selang-seling primary/success supaya tiap baris kontras. */
    const sectionRows = () => {
      const vis = SECT_BTNS.filter(sectionOpen).map(s => {
        const key = SECTIONS[s] ? SECTIONS[s].btn : "menu.btnHelp"
        return btn(tr(key), cb(s))
      })
      const rows = []
      const palette = ["primary", "success"]
      vis.forEach((b, i) => { b.style = palette[i % palette.length] })
      for (let i = 0; i < vis.length; i += 2) rows.push(vis.slice(i, i + 2))
      return rows
    }

    /* baris tombol daftar */
    const LIST_BTNS = [
      ["admins", "menu.btnListAdmin", "owner"],
      ["sellers", "menu.btnListSeller", "owner"],
      ["owners", "menu.btnListOwner", "owner"],
      ["panels", "menu.btnListPanel", "seller"]
    ]
    const LIST_CMD = { admins: "listadmin", sellers: "listseller", owners: "listowner", panels: "listpanel" }
    const LIST_NEED = { admins: "owner", sellers: "owner", owners: "owner", panels: "seller" }

    const listRows = () => {
      const vis = LIST_BTNS.filter(([k]) => canUse(LIST_NEED[k]))
        .map(([k, label]) => btn(tr(label), cb("list", k), "success"))
      const rows = []
      const palette = ["success", "primary"]
      vis.forEach((b, i) => { b.style = palette[i % palette.length] })
      for (let i = 0; i < vis.length; i += 2) rows.push(vis.slice(i, i + 2))
      return rows
    }

    const hubKb = () => ({
      inline_keyboard: [
        [ btnAll() ],                         /* All Menu selalu di baris pertama */
        ...sectionRows(),
        ...listRows()
      ]
    })
    const secKb = () => ({ inline_keyboard: [[btnHome(), btnAll()]] })
    const allKb = () => ({ inline_keyboard: [[btnHome()]] })

    /* ---------- tampil ---------- */
    const show = async (text, kb) => {
      try {
        if (m.callback) return await m.edit(text, { reply_markup: kb })
        return await m.reply(text, { reply_markup: kb })
      } catch (e) {
        return m.reply(text, { reply_markup: kb })
      }
    }

    /* popup cuma kelihatan yang nge-tap */
    const popup = (text) => {
      if (!m.callback) return m.reply(text)
      m.callback.answered = true
      if (Rafz && typeof Rafz.answerCallbackQuery === "function") {
        const plain = String(text || "").replace(/<[^>]+>/g, "").slice(0, 190)
        try { Rafz.answerCallbackQuery(m.callback.id, { text: plain, show_alert: true }).catch(() => {}) } catch {}
      }
      return true
    }

    /* ---------- argumen ---------- */
    const argv = Array.isArray(args) ? args : []
    const a0 = String(argv[0] || "").toLowerCase()
    const a1 = String(argv[1] || "").toLowerCase()
    const tail = String(argv[argv.length - 1] || "")
    const uidArg = /^\d{5,}$/.test(tail) ? tail : null

    /* 1. tombol punya orang lain -> popup, pesan tidak diubah */
    if (m.callback && uidArg && uidArg !== sender)
      return popup(tr("denied.buttons", { cmd: px + "menu" }))

    /* 2. tombol yang role-nya nggak cukup -> popup */
    if (m.callback) {
      if (a0 === "list" && LIST_CMD[a1] && !canUse(LIST_NEED[a1]))
        return popup(tr("denied.buttonsRole"))
      if (SECTIONS[a0] && !sectionOpen(a0))
        return popup(tr("denied.buttonsRole"))
    }

    /* 3. tombol daftar -> jalanin command aslinya biar hasilnya identik */
    if (a0 === "list" && LIST_CMD[a1]) {
      const target = LIST_CMD[a1]
      const sub = Object.assign({}, m)
      sub.isCmd = true
      sub.command = target
      sub.text = ""
      sub.body = px + target
      sub.raw = px + target
      sub.args = []
      try {
        await caseFile(sub, Rafz || conn)
      } catch (e) {
        await m.reply("❌ " + String(e.message || e))
      }
      return true
    }

    /* 4. ALL MENU — semua fitur per kategori (pola edit-only) */
    if (a0 === "allmenu" || a0 === "all") {
      return show(allMenuText(), allKb())
    }

    /* 5. section command / bantuan / balik ke home */
    if (a0 === "help" || SECTIONS[a0]) {
      const title = a0 === "help" ? tr("menu.btnHelp") : (a0 === "monitor" ? "◈ MONITOR PANEL" : tr(SECTIONS[a0].btn))
      const body = a0 === "help" ? helpBody() + "\n\n" : bodyOf(a0) + "\n"
      return show("<b>" + title + "</b>\n\n" + body, secKb())
    }

    return show(hubText(), hubKb())
  } catch (e) {
    console.log("menu plugin error:", e && e.message)
    try {
      if (m && m.reply) await m.reply("⚠️ Menu error: " + (e.message || "unknown"))
    } catch {}
  }
}

handler.command = ["allmenu", "help", "menu"]
module.exports = handler

try {
  let fs = require("fs")
  let file = require.resolve(__filename)
  fs.watchFile(file, () => {
    try {
      fs.unwatchFile(file)
      delete require.cache[file]
      require(file)
    } catch {}
  })
} catch {}
