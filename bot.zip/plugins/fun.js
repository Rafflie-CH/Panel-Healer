/* plugin: fun.js — fitur hiburan:
   /8ball /dice /coin /rate /love /pick /roll /reverse /bucin /quote /wpick
   Semua output pakai pola EDIT-MESSAGE (langsung edit pesan progress). */

"use strict"

const makeEditor = (m, Rafz, wait) => async (text, opt = {}) => {
  try {
    return await Rafz.editMessageText(String(text), {
      chat_id: m.chat, message_id: wait.message_id, parse_mode: "HTML",
      disable_web_page_preview: true, ...opt
    })
  } catch (e) {
    if (String(e?.message || e).includes("not modified")) return null
    return m.reply(String(text), opt)
  }
}

const pick1 = (arr) => arr[Math.floor(Math.random() * arr.length)]

const handler = async (m, { Rafz, command, text }) => {
  try {
    const px = (global.prefix && global.prefix[0]) || "/"
    const tr = (key, vars) => (m.t ? m.t(key, vars) : key)
    const q = (text || "").trim()
    const wait = await m.reply(tr("util.loading"), { parse_mode: "HTML" })
    const out = makeEditor(m, Rafz, wait)

    switch (command) {

      /* ── /8ball pertanyaan ── */
      case "8ball":
      case "eightball": {
        if (!q) return out(`⚠️ <b>${tr("use.usage")}:</b> <code>${px}8ball ${tr("fun.q8ball")}</code>`)
        const answers = tr("fun.8ballList").split("|")
        return out(`🎱 <b>${tr("fun.question")}:</b> ${q}\n\n${pick1(answers)}`)
      }

      /* ── /dice — dadu ── */
      case "dice":
      case "dadu": {
        const n = Math.min(6, Math.max(1, parseInt(q) || 6))
        const roll = 1 + Math.floor(Math.random() * 6)
        const dots = "⚀⚁⚂⚃⚄⚅"[roll - 1]
        return out(`🎲 <b>${tr("fun.dice")} (${n})</b>\n\n${dots} ${tr("fun.youGot")}: <b>${roll}</b>`)
      }

      /* ── /coin — lempar koin ── */
      case "coin":
      case "koinflip": {
        const side = Math.random() < 0.5 ? tr("fun.heads") : tr("fun.tails")
        return out(`🪙 <b>${tr("fun.coinToss")}...</b>\n\n${tr("fun.result")}: <b>${side}</b>`)
      }

      /* ── /rate sesuatu ── */
      case "rate": {
        if (!q) return out(`⚠️ <b>${tr("use.usage")}:</b> <code>${px}rate ${tr("fun.qRate")}</code>`)
        const val = Math.floor(Math.random() * 101)
        const bar = "█".repeat(Math.round(val / 10)) + "░".repeat(10 - Math.round(val / 10))
        return out(`📊 <b>${tr("fun.rating")}</b>\n\n${q}\n${bar} <b>${val}%</b>`)
      }

      /* ── /love nama1 [nama2] ── */
      case "love":
      case "couple": {
        const parts = q.split(/[,&+]| vs | dengan /i).map(s => s.trim()).filter(Boolean)
        const a = parts[0] || m.pushName
        const b = parts[1] || "Rafz Bot"
        const val = 1 + Math.floor(Math.random() * 100)
        const hearts = "❤️".repeat(Math.round(val / 20)) + "🖤".repeat(5 - Math.round(val / 20))
        const desc = val > 80 ? tr("fun.loveDesc").split("|")[0] : val > 50 ? tr("fun.loveDesc").split("|")[1] : val > 25 ? tr("fun.loveDesc").split("|")[2] : tr("fun.loveDesc").split("|")[3]
        return out(
          `💕 <b>${tr("fun.match")}</b>\n\n` +
          `${a} ❤️ ${b}\n${hearts} <b>${val}%</b>\n\n${desc}`
        )
      }

      /* ── /pick a, b, c — pilih salah satu ── */
      case "pick":
      case "pilih": {
        const parts = q.split(/[,;]/).map(s => s.trim()).filter(Boolean)
        if (parts.length < 2) return out(`⚠️ <b>${tr("use.usage")}:</b> <code>${px}pick ${tr("fun.qPick")}</code>`)
        return out(`🤔 <b>${tr("fun.iPick")}...</b>\n\n✅ <b>${pick1(parts)}</b>`)
      }

      /* ── /roll 1-100 ── */
      case "roll": {
        const max = Math.min(1000000, Math.max(2, parseInt(q) || 100))
        const val = 1 + Math.floor(Math.random() * max)
        return out(`🎯 <b>${tr("fun.roll")} 1-${max}</b>\n\n${tr("fun.youGot")}: <b>${val}</b>`)
      }

      /* ── /reverse teks ── */
      case "reverse":
      case "balik": {
        if (!q) return out(`⚠️ <b>${tr("use.usage")}:</b> <code>${px}reverse halo</code>`)
        return out(`🔁 <b>${tr("fun.reversed")}</b>\n\n<code>${[...q].reverse().join("")}</code>`)
      }

      /* ── /bucin ── */
      case "bucin": {
        return out(`💔 <i>${pick1(tr("fun.bucinList").split("|"))}</i>`)
      }

      /* ── /quote ── */
      case "quote":
      case "kata": {
        return out(`💡 <i>${pick1(tr("fun.quoteList").split("|"))}</i>`)
      }

      /* ── /wpick @a @b @c — pilih salah satu user yang di-tag ── */
      case "wpick":
      case "pickuser": {
        const ids = (m.mentioned || []).filter(x => x.id)
        if (ids.length < 2) return out(`⚠️ <b>${tr("use.usage")}:</b> ${tr("fun.wpickHint")}\n<code>${px}wpick @a @b @c</code>`)
        const chosen = pick1(ids)
        return out(`🎲 <b>${tr("fun.chosenOne")}...</b>\n\n🎉 <a href="tg://user?id=${chosen.id}">${chosen.name || chosen.username || chosen.id}</a>`)
      }

      default:
        return false
    }
  } catch (e) {
    console.error("[fun]", command, e?.message)
    try { await m.reply("⚠️ Error: " + (e?.message || e)) } catch {}
    return false
  }
}

handler.command = ["8ball", "eightball", "dice", "dadu", "coin", "koinflip", "rate", "love", "couple", "pick", "pilih", "roll", "reverse", "balik", "bucin", "quote", "kata", "wpick", "pickuser"]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
