"use strict"
const https = require("https")
const http = require("http")

const UA = "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/130 Mobile Safari/537.36"

const getJSON = (url, hdrs = {}) =>
  new Promise((resolve, reject) => {
    try {
      const parsed = new URL(url)
      const mod = parsed.protocol === "https:" ? https : http
      mod.get({ hostname: parsed.hostname, path: parsed.pathname + parsed.search, timeout: 25000, headers: { "User-Agent": UA, "Accept": "application/json", ...hdrs } }, (res) => {
        let d = ""
        res.on("data", c => d += c)
        res.on("end", () => { try { resolve(JSON.parse(d)) } catch { resolve(null) } })
      }).on("error", reject).on("timeout", function () { this.destroy(); reject(new Error("Timeout")) })
    } catch (e) { reject(e) }
  })

const getBuffer = (url, hdrs = {}) =>
  new Promise((resolve, reject) => {
    try {
      const follow = (u, depth = 0) => {
        if (depth > 5) return reject(new Error("Too many redirects"))
        const parsed = new URL(u)
        const mod = parsed.protocol === "https:" ? https : http
        mod.get({ hostname: parsed.hostname, path: parsed.pathname + parsed.search, timeout: 90000, headers: { "User-Agent": UA, ...hdrs } }, (res) => {
          if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) return follow(new URL(res.headers.location, u).href, depth + 1)
          if (res.statusCode !== 200) return reject(new Error("HTTP " + res.statusCode))
          const c = []
          res.on("data", d => c.push(d))
          res.on("end", () => resolve(Buffer.concat(c)))
        }).on("error", reject).on("timeout", function () { this.destroy(); reject(new Error("Timeout")) })
      }
      follow(url)
    } catch (e) { reject(e) }
  })

const fmtSize = (b) => {
  if (b === 0) return "0B"
  const k = 1024
  const sizes = ["B", "KB", "MB", "GB"]
  const i = Math.floor(Math.log(b) / Math.log(k))
  return parseFloat((b / Math.pow(k, i)).toFixed(1)) + sizes[i]
}

const handler = async (m, { Rafz, command, text }) => {
  try {
    const px = (global.prefix && global.prefix[0]) || "/"
    const q = (text || "").trim()
    const usage = (u) => "Penggunaan: " + px + u
    if (!q.startsWith("http")) return m.reply(usage(command + " <link>"))
    const wait = await m.reply("Mengunduh...")

    const editOut = async (t2) => {
      try { await Rafz.editMessageText(t2, { chat_id: m.chat, message_id: wait.message_id, parse_mode: "HTML" }) } catch {}
    }

    if (command === "mediafire" || command === "mediafiredl") {
      try {
        const j = await getJSON("https://api.siputzx.my.id/api/dl/mediafire?url=" + encodeURIComponent(q))
        if (j && j.status && j.data) {
          const d = j.data
          const buf = await getBuffer(d.link || d.url)
          await editOut("Mengirim file: " + (d.title || d.filename || "file"))
          await Rafz.sendDocument(m.chat, buf, { filename: (d.title || d.filename || "file"), caption: "MEDIAFIRE DL\n\nNama: " + (d.title || "-") + "\nSize: " + (d.size || fmtSize(buf.length)), reply_to_message_id: m.id })
          return true
        }
        throw new Error("API error")
      } catch (e) { return editOut("MediaFire gagal: " + e.message) }
    }

    if (command === "gitclone" || command === "git") {
      const match = q.match(/github\.com\/([^\/]+)\/([^\/]+)/)
      if (!match) return editOut("Link GitHub repo tidak valid")
      const [, user, repo] = match
      const repoName = repo.replace(/\.git$/, "")
      const zipUrl = "https://github.com/" + user + "/" + repoName + "/archive/refs/heads/main.zip"
      try {
        const buf = await getBuffer(zipUrl)
        if (buf.length < 1000) throw new Error("repo kosong")
        await editOut("Mengirim repo: " + repoName)
        await Rafz.sendDocument(m.chat, buf, { filename: repoName + ".zip", caption: "GITHUB CLONE\n\nRepo: " + user + "/" + repoName + "\nSize: " + fmtSize(buf.length), reply_to_message_id: m.id })
        return true
      } catch {
        return editOut("Repo tidak ditemukan atau branch main tidak ada. Coba cek link-nya.")
      }
    }

    if (command === "spotify" || command === "spotifydl") {
      try {
        const j = await getJSON("https://api.siputzx.my.id/api/dl/spotify?url=" + encodeURIComponent(q))
        if (j && j.status && j.data) {
          const d = j.data
          await editOut("Mengirim: " + (d.title || "track"))
          const buf = await getBuffer(d.download || d.link || d.url)
          await Rafz.sendAudio(m.chat, buf, { title: d.title || "Spotify Track", performer: d.artis || d.artist || "-", caption: "SPOTIFY DL\n\nJudul: " + (d.title || "-") + "\nArtis: " + (d.artis || d.artist || "-"), reply_to_message_id: m.id })
          return true
        }
        throw new Error("API error")
      } catch (e) { return editOut("Spotify gagal: " + e.message) }
    }

    if (command === "soundcloud" || command === "scdl") {
      try {
        const j = await getJSON("https://api.siputzx.my.id/api/dl/soundcloud?url=" + encodeURIComponent(q))
        if (j && j.status && j.data) {
          const d = j.data
          await editOut("Mengirim: " + (d.title || "track"))
          const buf = await getBuffer(d.download || d.url || d.link)
          await Rafz.sendAudio(m.chat, buf, { title: d.title || "SoundCloud", caption: "SOUNDCLOUD DL\n\n" + (d.title || q), reply_to_message_id: m.id })
          return true
        }
        throw new Error("API error")
      } catch (e) { return editOut("SoundCloud gagal: " + e.message) }
    }

    if (command === "terabox" || command === "teraboxdl") {
      return editOut("Terabox DL tidak stabil. Gunakan /mediafire atau link langsung.")
    }

    if (command === "capcut" || command === "cc") {
      return editOut("CapCut DL: gunakan /tt untuk download video TikTok yang berisi link CapCut.")
    }

    if (command === "threads" || command === "th") {
      return editOut("Threads DL tidak stabil saat ini. Gunakan /ig untuk Instagram.")
    }

    if (command === "zippyshare") {
      return editOut("Zippyshare sudah tutup.")
    }

    editOut("Downloader tidak dikenali.")
    return false
  } catch (e) {
    console.error("[downloader2]", e?.message)
    try { await m.reply("Error: " + (e?.message || e)) } catch {}
    return false
  }
}

handler.command = ["mediafire", "mediafiredl", "gitclone", "git", "spotify", "spotifydl", "soundcloud", "scdl", "terabox", "teraboxdl", "capcut", "cc", "threads", "th"]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
