// plugin: start.js — welcome dengan foto, sound random, tombol menu
// UI rapi: pakai blockquote (bukan ASCII box) supaya tidak terpotong di
// layar sempit. Tombol semuanya berwarna (style). Teks dari language.js.

const path = require("path")
const fs = require("fs")

const handler = async (m, { Rafz }) => {
  try {
    const sender = String(m.sender)
    const name = m.pushName || "Sobat"
    const botname = global.botname || "RAFZ BOT"
    const sounds = global.SOUND_URLS || []
    const photo = global.WELCOME_PHOTO || ""
    const linkOwner = global.linkOwner || ""
    const prefix = (global.prefix && global.prefix[0]) || "/"
    const tr = (key, vars) => (m.t ? m.t(key, vars) : key)

    // tentukan role
    const readArr = (file) => {
      try {
        const p = path.join(__dirname, "..", "library", "database", file)
        const j = JSON.parse(fs.readFileSync(p, "utf8"))
        return Array.isArray(j) ? j : []
      } catch { return [] }
    }
    const isCreator = (global.owner || []).includes(sender)
    const isOwner   = isCreator || readArr("owner.json").includes(sender)
    const isSuper   = readArr("superseller.json").includes(sender) || isOwner
    const isSeller  = readArr("seller.json").includes(sender) || isSuper
    const role = isCreator ? "👑 " + tr("menu.roleCreator")
               : isOwner   ? "🔑 " + tr("menu.roleOwner")
               : isSuper   ? "⭐ " + tr("menu.roleSuper")
               : isSeller  ? "🛒 " + tr("menu.roleSeller")
               : "👤 " + tr("menu.roleUser")

    /* UI rapi & aman di semua device: blockquote + baris pendek,
       tanpa karakter box-drawing panjang yang bisa terpotong */
    const caption =
      `<b>✦ ${botname} ✦</b>\n` +
      `<blockquote>${tr("start.tagline")}</blockquote>\n\n` +
      `<blockquote>` +
      `${tr("start.hello", { name })}\n` +
      `${tr("start.welcome", { bot: botname })}\n\n` +
      `🆔 <code>${sender}</code>\n` +
      `🎭 ${role}\n` +
      `🕐 ${new Date().toLocaleString(global.locale || "id-ID", { timeZone: global.timeZone || "Asia/Jakarta" })}\n` +
      `⚙️ Ver: <code>${global.versi || "1.0"}</code>` +
      `</blockquote>\n\n` +
      `${tr("start.useMenu", { prefix })}\n` +
      `👤 <a href="${linkOwner}">${global.namaOwner || "Owner"}</a>`

    const kb = {
      inline_keyboard: [
        [
          { text: "📋 " + tr("start.btnMenu"), callback_data: "/menu home", style: "primary" },
          { text: "📚 " + tr("start.btnAll"), callback_data: "/menu allmenu", style: "success" }
        ],
        [
          { text: "ℹ️ " + tr("start.btnInfo"), callback_data: "/menu help", style: "success" },
          { text: "🌐 " + tr("menu.btnLang"), callback_data: "/lang", style: "primary" }
        ],
        [
          { text: "👨‍💼 " + tr("start.btnOwner"), url: linkOwner, style: "danger" }
        ]
      ]
    }

    // kirim foto welcome
    let sent = false
    if (photo) {
      try {
        await Rafz.sendPhoto(m.chat, photo, {
          caption,
          parse_mode: "HTML",
          reply_markup: kb,
          reply_to_message_id: m.id,
          allow_sending_without_reply: true
        })
        sent = true
      } catch (e) {
        console.log("start: gagal kirim foto:", e.message)
      }
    }

    if (!sent) {
      await m.reply(caption, { parse_mode: "HTML", reply_markup: kb })
    }

    // kirim sound random
    if (sounds.length > 0) {
      try {
        const url = sounds[Math.floor(Math.random() * sounds.length)]
        await Rafz.sendVoice(m.chat, url, {
          caption: "🎵 " + tr("start.welcomeSound"),
          reply_to_message_id: m.id,
          allow_sending_without_reply: true
        })
      } catch (e) {
        console.log("start: gagal kirim sound:", e.message)
      }
    }

    // kirim notif ke grup jika ada
    try {
      const gid = global.notifGroupId
      if (gid) {
        const notifText =
          `🟢 <b>User baru /start bot!</b>\n` +
          `👤 Nama  : <b>${name}</b>\n` +
          `🆔 ID    : <code>${sender}</code>\n` +
          `🎭 ${tr("menu.role")}  : ${role}\n` +
          `🕐 ${tr("confirm.name")} : ${new Date().toLocaleString(global.locale || "id-ID", { timeZone: global.timeZone || "Asia/Jakarta" })}`
        await Rafz.sendMessage(gid, notifText, { parse_mode: "HTML" }).catch(() => {})
      }
    } catch {}

    return true
  } catch (e) {
    console.error("start plugin error:", e.message)
    try { await m.reply("⚠️ Error: " + e.message) } catch {}
    return false
  }
}

handler.command = ["start"]
module.exports = handler

try {
  const fs = require("fs")
  const file = require.resolve(__filename)
  fs.watchFile(file, () => { try { fs.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
