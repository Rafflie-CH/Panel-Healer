// plugin: backup.js — /backup manual & /backupset
const path = require("path")
const fs = require("fs")

const handler = async (m, { Rafz, command, text }) => {
  try {
    const sender = String(m.sender)
    const isOwner = (global.owner || []).includes(sender)
    if (!isOwner) return m.reply("❌ Hanya owner yang bisa menjalankan perintah ini.")

    const backupMod = require("../library/backup")
    const px = (global.prefix && global.prefix[0]) || "/"

    /* /backup — jalankan backup sekarang */
    if (command === "backup") {
      const wait = await m.reply("⏳ Membuat backup...")
      try {
        await backupMod.sendBackup(Rafz, "Backup manual oleh owner")
        try { await Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {}) } catch {}
        return m.reply("✅ Backup selesai dan terkirim!")
      } catch (e) {
        try { await Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {}) } catch {}
        return m.reply("❌ Backup gagal: " + e.message)
      }
    }

    /* /backupset [interval_jam] — ubah interval */
    if (command === "backupset") {
      const jam = parseFloat(text)
      if (!text || isNaN(jam) || jam <= 0) {
        const cur = Math.round((global.backup?.intervalMs || 21600000) / 60000)
        return m.reply(
          `⚙️ <b>Pengaturan Backup</b>\n\n` +
          `🕐 Interval saat ini : ${cur} menit\n` +
          `📤 Kirim ke owner    : ${global.backup?.sendToOwner ? "✅" : "❌"}\n\n` +
          `<b>Penggunaan:</b>\n` +
          `<code>${px}backupset 6</code> — backup tiap 6 jam\n` +
          `<code>${px}backupset 0.5</code> — backup tiap 30 menit`,
          { parse_mode: "HTML" }
        )
      }
      if (!global.backup) global.backup = {}
      global.backup.intervalMs = jam * 60 * 60 * 1000
      backupMod.stop()
      backupMod.start(Rafz)

      return m.reply(
        `✅ Interval backup diubah ke <b>${jam} jam</b> (${jam * 60} menit).\n` +
        `Backup berikutnya dalam ${jam} jam.`,
        { parse_mode: "HTML" }
      )
    }

    return false
  } catch (e) {
    console.error("backup plugin error:", e.message)
    try { await m.reply("⚠️ Error: " + e.message) } catch {}
    return false
  }
}

handler.command = ["backup", "backupset"]
module.exports = handler

try {
  const fs = require("fs")
  const file = require.resolve(__filename)
  fs.watchFile(file, () => {
    try { fs.unwatchFile(file); delete require.cache[file]; require(file) } catch {}
  })
} catch {}
