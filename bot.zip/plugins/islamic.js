"use strict"
const https = require("https")
const http = require("http")

const UA = "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/130 Mobile Safari/537.36"

const getJSON = (url) =>
  new Promise((resolve, reject) => {
    try {
      const parsed = new URL(url)
      const mod = parsed.protocol === "https:" ? https : http
      mod.get({ hostname: parsed.hostname, path: parsed.pathname + parsed.search, timeout: 25000, headers: { "User-Agent": UA, "Accept": "application/json" } }, (res) => {
        let d = ""
        res.on("data", c => d += c)
        res.on("end", () => { try { resolve(JSON.parse(d)) } catch { resolve(null) } })
      }).on("error", reject).on("timeout", function () { this.destroy(); reject(new Error("Timeout")) })
    } catch (e) { reject(e) }
  })

const getBuffer = (url) =>
  new Promise((resolve, reject) => {
    try {
      const follow = (u, depth = 0) => {
        if (depth > 5) return reject(new Error("Too many redirects"))
        const parsed = new URL(u)
        const mod = parsed.protocol === "https:" ? https : http
        mod.get({ hostname: parsed.hostname, path: parsed.pathname + parsed.search, timeout: 90000, headers: { "User-Agent": UA } }, (res) => {
          if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) return follow(new URL(res.headers.location, u).href, depth + 1)
          if (res.statusCode !== 200) return reject(new Error("HTTP " + res.statusCode))
          const c = []
          res.on("data", d => c.push(d))
          res.on("end", () => resolve(Buffer.concat(c)))
        }).on("error", reject).on("timeout", function () { this.destroy(); reject(new Error("Timeout")) })
      }
      follow(url)
    } catch (e) { reject(e) }
  })

const handler = async (m, { Rafz, command, text }) => {
  try {
    const px = (global.prefix && global.prefix[0]) || "/"
    const q = (text || "").trim()

    if (command === "alquran" || command === "quran") {
      if (!q) return m.reply("Contoh: " + px + "alquran 1\n\nNomor surah 1-114")
      const surah = parseInt(q)
      if (isNaN(surah) || surah < 1 || surah > 114) return m.reply("Nomor surah 1-114")
      try {
        const j = await getJSON("https://api.alquran.cloud/v1/surah/" + surah + "/id.indonesian")
        if (j && j.code === 200) {
          const d = j.data
          let out = "SURAH " + d.name.replace("Surah ", "").toUpperCase() + "\n"
          out += "(" + d.englishName + " - " + d.numberOfAyahs + " ayat)\n\n"
          const ayahs = d.ayahs.slice(0, 10)
          for (const a of ayahs) out += a.numberInSurah + ". " + (a.text || "") + "\n"
          if (d.ayahs.length > 10) out += "\n... dan " + (d.ayahs.length - 10) + " ayat lagi."
          return m.reply(out.slice(0, 4000))
        }
        throw new Error("api error")
      } catch {
        return m.reply("Gagal mengambil data Al-Quran")
      }
    }

    if (command === "murotal" || command === "audiosurah" || command === "audiosurat") {
      if (!q) return m.reply("Contoh: " + px + "murotal 1\n\nNomor surah 1-114")
      const surah = parseInt(q)
      if (isNaN(surah) || surah < 1 || surah > 114) return m.reply("Nomor surah 1-114")
      const wait = await m.reply("Mengunduh murotal...")
      try {
        const buf = await getBuffer("https://cdn.islamic.network/quran/audio-surah/128/ar.alafasy/" + surah + ".mp3")
        if (!buf || buf.length < 10000) throw new Error("audio kosong")
        await Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {})
        await Rafz.sendAudio(m.chat, buf, { title: "Murotal Surah " + surah, performer: "Mishary Alafasy", reply_to_message_id: m.id })
        return true
      } catch (e) {
        try { await Rafz.deleteMessage(m.chat, wait.message_id) } catch {}
        return m.reply("Gagal: " + e.message)
      }
    }

    if (command === "kisahnabi") {
      if (!q) return m.reply("Contoh: " + px + "kisahnabi muhammad\n\nNabi: adam idris nuh hud shalih ibrahim ismail ishaq yaqub yusuf ayyub musa harun dzulkifli daud sulaiman ilyas ilyasa yunus zakaria yahya isa muhammad")
      try {
        const j = await getJSON("https://api.kisahnabi.com/search/" + encodeURIComponent(q))
        const nabi = j?.data?.[0]
        if (nabi) {
          return m.reply("KISAH NABI\n\nNama: " + nabi.nama + "\nTahun lahir: " + nabi.tahun + "\nUmur: " + nabi.umur + "\nTempat: " + nabi.tmp + "\n\nCerita:\n" + String(nabi.kisah || "-").slice(0, 1500))
        }
        throw new Error("not found")
      } catch {
        return m.reply("Nabi tidak ditemukan")
      }
    }

    if (command === "jadwalsholat" || command === "prayer") {
      if (!q) return m.reply("Contoh: " + px + "jadwalsholat jakarta")
      try {
        const j = await getJSON("https://api.aladhan.com/v1/timingsByCity?city=" + encodeURIComponent(q) + "&country=Indonesia&method=11")
        if (j && j.code === 200) {
          const t = j.data.timings
          return m.reply("JADWAL SHOLAT - " + q.toUpperCase() + "\n\nSubuh: " + t.Fajr + "\nDzuhur: " + t.Dhuhr + "\nAshar: " + t.Asr + "\nMaghrib: " + t.Maghrib + "\nIsya: " + t.Isha)
        }
        throw new Error("not found")
      } catch {
        return m.reply("Kota tidak ditemukan")
      }
    }

    if (command === "hadist" || command === "hadith") {
      if (!q) return m.reply("Contoh: " + px + "hadist bukhari 1\n\nKitab: bukhari muslim (nomor 1-50)")
      const parts = q.split(/\s+/)
      const kitab = (parts[0] || "").toLowerCase()
      const num = parseInt(parts[1]) || 1
      if (!["bukhari", "muslim"].includes(kitab)) return m.reply("Kitab: bukhari/muslim")
      try {
        const j = await getJSON("https://api.hadith.gading.dev/books/" + kitab + "?range=" + num + "-" + (num + 1))
        const h = j?.data?.hadiths?.[0]
        if (h) return m.reply("HADIST " + kitab.toUpperCase() + " No. " + h.number + "\n\n" + h.arabic + "\n\nArtinya: " + h.id)
        throw new Error("not found")
      } catch {
        return m.reply("Hadist tidak ditemukan")
      }
    }

    return false
  } catch (e) {
    console.error("[islamic]", e?.message)
    try { await m.reply("Error: " + (e?.message || e)) } catch {}
    return false
  }
}

handler.command = ["alquran", "quran", "murotal", "audiosurah", "audiosurat", "kisahnabi", "jadwalsholat", "prayer", "hadist", "hadith"]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
