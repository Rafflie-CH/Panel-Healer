/* plugin: games2.js — porting kuis dari bot WA (Prabowo)
   /tebaklagu  — tebak judul lagu (preview Deezer)
   /tebakkata /tebakgame /tebakbom — bank soal lokal
   Jawaban diketik langsung di chat (integritas dengan /skipquiz & /soal).
*/
"use strict"
const fs = require("fs")

const DB = "./library/database/quizzes.json"
const load = () => { try { const j = JSON.parse(fs.readFileSync(DB, "utf8")); return j && typeof j === "object" ? j : {} } catch { return {} } }
const save = (d) => { try { fs.mkdirSync("library/database", { recursive: true }); fs.writeFileSync(DB, JSON.stringify(d, null, 2)) } catch {} }
const pick = (arr) => arr[Math.floor(Math.random() * arr.length)]
const norm = (s) => String(s || "").toLowerCase().trim().replace(/[^a-z0-9 ]/g, "")

/* bank soal lokal — selalu jalan */
const BANK = {
  tebakkata: [
    { q: "Alat untuk menulis di kertas (5 huruf)", a: "pulpen" },
    { q: "Kendaraan beroda dua tanpa mesin", a: "sepeda" },
    { q: "Tempat menyimpan uang", a: "bank" },
    { q: "Makanan khas Jepang dari beras", a: "sushi" },
    { q: "Alat menyapu lantai", a: "sapu" }
  ],
  tebakgame: [
    { q: "Game sandbox blok paling terkenal?", a: "minecraft" },
    { q: "Battle royale dari Epic Games?", a: "fortnite" },
    { q: "Moba dari Riot Games?", a: "leagueoflegends" },
    { q: "Game GTA artinya?", a: "grandtheftauto" },
    { q: "Hero game DOTA 2 berjumlah?", a: "5" }
  ],
  tebakbom: [
    { q: "💣 Kotak berisi bom kecuali satu. Kotak aman: 2, 5, 7 (pilih nomor aman)", a: "3" },
    { q: "💣 Kotak berisi bom kecuali satu. Kotak aman: 1, 4, 6 (pilih nomor aman)", a: "2" }
  ]
}

const NAME = { tebakkata: "Tebak Kata", tebakgame: "Tebak Game", tebakbom: "Tebak Bom" }

/* handler jawaban hook — dipanggil case.js lewat global.gameAnswerHook */
const answerHook = async (m, { text, chatKey }) => {
  const q = norm(text)
  if (!q) return false
  const db = load()
  const g = db[chatKey]
  if (!g || !NAME[g.game]) return false
  if (norm(q) === norm(g.answer)) {
    delete db[chatKey]; save(db)
    await m.reply("🎉 <b>BENAR!</b> " + (m.pushName || m.sender) + " menjawab: " + g.answer, { parse_mode: "HTML" })
    return true
  }
  return true /* sedang main → chat dianggap percobaan jawaban */
}

const handler = async (m, { Rafz, command, text }) => {
  try {
    const tr = (key, vars) => (m.t ? m.t(key, vars) : key)
    const chatKey = String(m.chat) + ":" + String(m.sender)
    const db = load()
    const px = (global.prefix && global.prefix[0]) || "/"

    /* ── /tebaklagu — kirim preview audio dari Deezer, tebak judul ── */
    if (command === "tebaklagu") {
      const kw = ["slank", "dewa", "nihh", "armada", "tulus", "payung teduh", "raisa", "god bless"]
      const q2 = pick(kw)
      try {
        const r = await fetch("https://api.deezer.com/search/track?q=" + encodeURIComponent(q2) + "&limit=10")
        const j = await r.json()
        const tracks = (j.data || []).filter(t => t.preview && t.title)
        if (!tracks.length) throw new Error("no track")
        const t = pick(tracks)
        db[chatKey] = { game: "tebaklagu", answer: norm(t.title), q: "🎧 Dengarkan preview lagunya!", at: Date.now(), audio: t.preview, title: t.title, artist: t.artist?.name }
        save(db)
        /* download preview + kirim audio */
        const ar = await fetch(t.preview)
        const buf = Buffer.from(await ar.arrayBuffer())
        try { await Rafz.sendAudio(m.chat, buf, { caption: "🎵 " + tr("quiz.startHint") }) } catch {}
        return m.reply(
          "<b>🎵 TEBAK LAGU</b>\n\n" + tr("quiz.startHint") + "\n💡 <code>" + px + "skipquiz</code> " + tr("quiz.toSkip"),
          { parse_mode: "HTML" }
        )
      } catch (e) {
        /* fallback: tebak judul dari emoji/lyric tanpa audio */
        const list = [
          { q: "🎵 Lagu dengan lirik 'Kalau semesta sudah berdagang cinta...'", a: "semestadu" },
          { q: "🎵 Band Indonesia dengan lagu 'Kirana'", a: "dewa" },
          { q: "🎵 Lagu 'Mungkin' dinyanyikan oleh?", a: "melly goeslaw" }
        ]
        const item = pick(list)
        db[chatKey] = { game: "tebaklagu", answer: norm(item.a), q: item.q, at: Date.now() }
        save(db)
        return m.reply("<b>🎵 TEBAK LAGU</b>\n\n" + item.q + "\n\n⏳ " + tr("quiz.startHint"), { parse_mode: "HTML" })
      }
    }

    /* ── kuis lokal ── */
    if (BANK[command]) {
      const item = pick(BANK[command])
      db[chatKey] = { game: command, answer: item.a, q: item.q, at: Date.now() }
      save(db)
      return m.reply(
        "<b>🎮 " + NAME[command].toUpperCase() + "</b>\n\n" + item.q + "\n\n⏳ " + tr("quiz.startHint") + "\n💡 <code>" + px + "skipquiz</code> " + tr("quiz.toSkip"),
        { parse_mode: "HTML" }
      )
    }

    /* ── /soal kalau game aktif adalah game ini ── */
    if (command === "soal2") {
      const g = db[chatKey]
      if (!g || !NAME[g.game]) return m.reply(tr("quiz.noGameHint", { px }))
      return m.reply("<b>" + tr("quiz.activeQuestion") + " (" + g.game + ")</b>\n\n❓ " + g.q, { parse_mode: "HTML" })
    }

    return false
  } catch (e) {
    console.error("[games2]", command, e?.message)
    try { await m.reply("❌ " + e.message) } catch {}
    return false
  }
}

/* hook jawaban non-command dipasang global — quizzes.js sudah menangani tebakan
   untuk gamenya sendiri; games2 menambahkan tebaklagu/tebakkata/tebakgame/tebakbom */
try {
  const prev = global.gameAnswerHook
  global.gameAnswerHook = async (m, ctx) => {
    if (prev) { const r = await prev(m, ctx); if (r) return r }
    return answerHook(m, ctx)
  }
} catch {}

handler.command = ["tebaklagu", "tebakkata", "tebakgame", "tebakbom", "soal2"]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
