/* plugin: islamic2.js — porting fitur islami dari bot WA (Prabowo & RAFZ Botz)
   /doa       — doa harian random (dari API doa)
   /ayatkursi — teks ayat kursi
   /niatsholat— niat sholat wajib
   /wirid     — wirid harian
   /asmaulhusna — 99 nama Allah (random 5)
   /tahlil    — bacaan tahlil singkat
   Semua teks lokal/embedded biar selalu jalan (API doa sering mati). */
"use strict"

const esc = (s) => String(s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
const pick = (arr) => arr[Math.floor(Math.random() * arr.length)]

const DOA = [
  { t: "Doa sebelum tidur", a: "بِاسْمِكَ اللَّهُمَّ أَمُوتُ وَأَحْيَا", l: "Bismillahumma amuutu wa ahya — Dengan nama-Mu ya Allah aku mati dan aku hidup." },
  { t: "Doa bangun tidur", a: "الْحَمْدُ لِلَّهِ الَّذِي أَحْيَانَا بَعْدَ مَا أَمَاتَنَا وَإِلَيْهِ النُّشُورُ", l: "Alhamdulillahilladzi ahyaanaa ba'da maa amaatanaa wa ilaihin-nusyuur." },
  { t: "Doa makan", a: "بِسْمِ اللهِ وَعَلَى بَرَكَةِ اللهِ", l: "Bismillahi wa 'ala barakatillah — Dengan nama Allah dan atas berkah Allah." },
  { t: "Doa keluar rumah", a: "بِسْمِ اللهِ تَوَكَّلْتُ عَلَى اللهِ", l: "Bismillahi tawakkaltu 'alallah." },
  { t: "Doa masuk masjid", a: "اللَّهُمَّ افْتَحْ لِي أَبْوَابَ رَحْمَتِكَ", l: "Allahummaktah li abwaaba rahmatik." },
  { t: "Doa untuk orang sakit", a: "أَسْأَلُ اللهَ الْعَظِيمَ رَبَّ الْعَرْشِ الْعَظِيمِ أَنْ يَشْفِيَكَ", l: "As'alullahal-'Adzima rabbal-'arsyil-'adzimi an yasyfiyak." }
]

const WIRID = [
  "Astaghfirullah 33×",
  "Subhanallah 33×",
  "Alhamdulillah 33×",
  "Allahu Akbar 34×",
  "La ilaaha illallah 100×",
  "Subhanallahi wa bihamdihi 100×"
]

const ASMA = [
  "Ar-Rahman — Maha Pengasih", "Ar-Rahim — Maha Penyayang", "Al-Malik — Maha Raja",
  "Al-Quddus — Maha Suci", "As-Salam — Maha Memberi Kesejahteraan", "Al-Mu'min — Maha Memberi Keamanan",
  "Al-Aziz — Maha Perkasa", "Al-Alim — Maha Mengetahui", "Al-Khaliq — Maha Pencipta",
  "Al-Ghafur — Maha Pengampun", "Ar-Razzaq — Maha Pemberi Rezeki", "An-Nur — Maha Bercahaya"
]

const handler = async (m, { command }) => {
  try {
    const tr = (key, vars) => (m.t ? m.t(key, vars) : key)

    if (command === "doa" || command === "doaharian") {
      const d = pick(DOA)
      return m.reply(
        "🤲 <b>" + d.t + "</b>\n\n" +
        "<code>" + d.a + "</code>\n\n<i>" + esc(d.l) + "</i>",
        { parse_mode: "HTML" }
      )
    }

    if (command === "wirid" || command === "wird") {
      const w = pick(WIRID)
      return m.reply("📿 <b>" + tr("isl2.wirid") + "</b>\n\n" + w, { parse_mode: "HTML" })
    }

    if (command === "asmaulhusna" || command === "asma") {
      const shuffled = [...ASMA].sort(() => Math.random() - 0.5).slice(0, 5)
      let out = "🌌 <b>" + tr("isl2.asma") + "</b>\n\n"
      shuffled.forEach((a, i) => { out += (i + 1) + ". " + a + "\n" })
      return m.reply(out, { parse_mode: "HTML" })
    }

    if (command === "ayatkursi") {
      return m.reply(
        "🕌 <b>Ayat Kursi</b>\n\n" +
        "<code>اللَّهُ لَا إِلَٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۚ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ ۚ لَهُ مَا فِي السَّمَاوَاتِ وَمَا فِي الْأَرْضِ</code>\n\n" +
        "<i>\"Allah, tidak ada Tuhan selain Dia, Yang Maha Hidup, Yang terus-menerus mengurus makhluk-Nya. Dia tidak mengantuk dan tidak tidur. Milik-Nya apa yang ada di langit dan apa yang ada di bumi...\"</i> (QS. Al-Baqarah: 255)",
        { parse_mode: "HTML" }
      )
    }

    if (command === "niatsholat" || command === "niat") {
      return m.reply(
        "🕌 <b>" + tr("isl2.niat") + "</b>\n\n" +
        "<b>Maghrib:</b>\n<code>أُصَلِّي فَرْضَ الْمَغْرِبِ ثَلَاثَ رَكَعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ أَدَاءً لِلَّهِ تَعَالَى</code>\n\n" +
        "<b>Isya:</b>\n<code>أُصَلِّي فَرْضَ الْعِشَاءِ أَرْبَعَ رَكَعَاتٍ مُسْتَقْبِلَ الْقِبْلَةِ أَدَاءً لِلَّهِ تَعَالَى</code>\n\n" +
        "<b>Subuh:</b>\n<code>أُصَلِّي فَرْضَ الصُّبْحِ رَكْعَتَيْنِ مُسْتَقْبِلَ الْقِبْلَةِ أَدَاءً لِلَّهِ تَعَالَى</code>",
        { parse_mode: "HTML" }
      )
    }

    if (command === "tahlil") {
      return m.reply(
        "🕌 <b>" + tr("isl2.tahlil") + "</b>\n\n" +
        "1. Al-Fatihah (1×)\n2. Ayat Kursi (1×)\n3. Al-Ikhlas (3×)\n4. Al-Falaq (1×)\n5. An-Nas (1×)\n6. La ilaaha illallah (3×)\n7. Allahumma shalli 'ala sayyidina Muhammad (3×)\n\n<i>" + tr("isl2.tahlilNote") + "</i>",
        { parse_mode: "HTML" }
      )
    }

    return false
  } catch (e) {
    console.error("[islamic2]", command, e?.message)
    try { await m.reply("❌ " + e.message) } catch {}
    return false
  }
}

handler.command = ["doa", "doaharian", "wirid", "wird", "asmaulhusna", "asma", "ayatkursi", "niatsholat", "niat", "tahlil"]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
