/* plugin: protect.js - proteksi grup */
"use strict"
const fs = require("fs")
const path = require("path")

const PROT_DB = "./library/database/protect.json"

const loadProt = () => {
  try {
    const j = JSON.parse(fs.readFileSync(PROT_DB, "utf8"))
    return (j && typeof j === "object" && !Array.isArray(j)) ? j : {}
  } catch { return {} }
}
const saveProt = (data) => {
  try { fs.mkdirSync(path.dirname(PROT_DB), { recursive: true }); fs.writeFileSync(PROT_DB, JSON.stringify(data, null, 2)) } catch {}
}

const handler = async (m, { Rafz, command, text }) => {
  try {
    const px = (global.prefix && global.prefix[0]) || "/"
    const sender = String(m.sender)
    const isGroup = String(m.chat).startsWith("-")
    if (!isGroup) return m.reply("Hanya bisa di grup.")

    const prot = loadProt()
    const gid = String(m.chat)
    prot[gid] = prot[gid] || {}

    if (command === "antilink") {
      const isAdmin = m.isAdmin
      const isOwner = (global.owner || []).includes(sender)
      if (!isAdmin && !isOwner) return m.reply("Hanya admin.")

      if (text.toLowerCase() === "on") {
        prot[gid].antilink = true
        saveProt(prot)
        return m.reply("Antilink diaktifkan.")
      }
      if (text.toLowerCase() === "off") {
        prot[gid].antilink = false
        saveProt(prot)
        return m.reply("Antilink dinonaktifkan.")
      }
      return m.reply("Status: " + (prot[gid].antilink ? "ON" : "OFF") + "\n\n" + px + "antilink on/off")
    }

    if (command === "antivirtex") {
      const isAdmin = m.isAdmin
      const isOwner = (global.owner || []).includes(sender)
      if (!isAdmin && !isOwner) return m.reply("Hanya admin.")

      if (text.toLowerCase() === "on") {
        prot[gid].antivirtex = true
        saveProt(prot)
        return m.reply("Antivirtex diaktifkan.")
      }
      if (text.toLowerCase() === "off") {
        prot[gid].antivirtex = false
        saveProt(prot)
        return m.reply("Antivirtex dinonaktifkan.")
      }
      return m.reply("Status: " + (prot[gid].antivirtex ? "ON" : "OFF") + "\n\n" + px + "antivirtex on/off")
    }

    if (command === "antitoxic") {
      const isAdmin = m.isAdmin
      const isOwner = (global.owner || []).includes(sender)
      if (!isAdmin && !isOwner) return m.reply("Hanya admin.")

      const toxicWords = ["anjir", "bangsat", "kontol", "memek", "ngentot", "goblok", "bodoh", "idiot", "retard", "fuck", "shit", "bitch", "asshole", "dick", "cock", "pussy", "whore", "slut"]

      if (text.toLowerCase() === "on") {
        prot[gid].antitoxic = true
        prot[gid].toxicWords = toxicWords
        saveProt(prot)
        return m.reply("Antitoxic diaktifkan.")
      }
      if (text.toLowerCase() === "off") {
        prot[gid].antitoxic = false
        saveProt(prot)
        return m.reply("Antitoxic dinonaktifkan.")
      }
      return m.reply("Status: " + (prot[gid].antitoxic ? "ON" : "OFF") + "\n\n" + px + "antitoxic on/off")
    }

    // Auto-protection on messages
    if (prot[gid].antilink && m.text && m.text.includes("http")) {
      const isOwnerMsg = (global.owner || []).includes(sender)
      const isAdminMsg = m.isAdmin
      if (!isOwnerMsg && !isAdminMsg) {
        try {
          await Rafz.deleteMessage(m.chat, m.id)
          await Rafz.sendMessage(m.chat, "Link dilarang di grup ini!", { parse_mode: "HTML" })
        } catch {}
        return true
      }
    }

    if (prot[gid].antitoxic && m.text) {
      const lower = m.text.toLowerCase()
      const words = prot[gid].toxicWords || []
      if (words.some(w => lower.includes(w))) {
        const isOwnerMsg = (global.owner || []).includes(sender)
        const isAdminMsg = m.isAdmin
        if (!isOwnerMsg && !isAdminMsg) {
          try {
            await Rafz.deleteMessage(m.chat, m.id)
            await Rafz.sendMessage(m.chat, "Pesan toxic dilarang!", { parse_mode: "HTML" })
          } catch {}
          return true
        }
      }
    }

    return false
  } catch (e) {
    console.error("[protect]", e?.message)
    try { await m.reply("Error: " + (e?.message || e)) } catch {}
    return false
  }
}

handler.command = ["antilink", "antivirtex", "antitoxic"]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
