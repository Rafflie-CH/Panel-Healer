/* plugin: stalk2.js — porting fitur stalk/search dari bot WA
   Command:
     /npmsearch /npmstalk2  — cari & stalk package npm
     /robloxstalk2          — Roblox stalk (user + avatar)
     /threadsstalk          — Threads stalk
     /xstalk /twitterstalk2 — Twitter/X user stalk
     /modrinth              — Modrinth mod search
     /fontlist              — daftar font (dafont via Bing)
     /apkmirror             — APKMirror search
*/
"use strict"

const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
const antiflood = require("../library/antiflood")

const getJSON = async (url, headers = {}) => {
  const ac = new AbortController()
  const t = setTimeout(() => ac.abort(), 20000)
  try {
    const res = await antiflood.withRetry(() => fetch(url, {
      headers: { "User-Agent": UA, Accept: "application/json", ...headers },
      signal: ac.signal
    }), "getJSON " + url.slice(0, 60))
    if (!res.ok) throw new Error("HTTP " + res.status)
    return await res.json()
  } finally { clearTimeout(t) }
}

const getText = async (url, headers = {}) => {
  const ac = new AbortController()
  const t = setTimeout(() => ac.abort(), 20000)
  try {
    const res = await antiflood.withRetry(() => fetch(url, {
      headers: { "User-Agent": UA, "Accept-Language": "en-US,en;q=0.9", ...headers },
      signal: ac.signal
    }), "getText " + url.slice(0, 60))
    if (!res.ok) throw new Error("HTTP " + res.status)
    return await res.text()
  } finally { clearTimeout(t) }
}

const esc = (s) => String(s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
const kb1 = (label, url) => ({ reply_markup: { inline_keyboard: [[{ text: "🌐 " + label, url, style: "primary" }]] } })

const bingSearch = async (query, count = 8) => {
  const url = "https://www.bing.com/search?q=" + encodeURIComponent(query) + "&format=rss&count=" + count
  const xml = await getText(url, { "Accept-Language": "id-ID,id;q=0.9,en;q=0.8" })
  const items = []
  const re = /<item>([\s\S]*?)<\/item>/g
  let mm
  while ((mm = re.exec(xml)) && items.length < count) {
    const blk = mm[1]
    const t = (blk.match(/<title>([\s\S]*?)<\/title>/) || [])[1] || ""
    const l = (blk.match(/<link>([\s\S]*?)<\/link>/) || [])[1] || ""
    const d = (blk.match(/<description>([\s\S]*?)<\/description>/) || [])[1] || ""
    if (t && l) items.push({ title: t.replace(/<!\[CDATA\[|\]\]>/g, "").trim(), link: l.trim(), desc: d.replace(/<!\[CDATA\[|\]\]>/g, "").replace(/<[^>]+>/g, "").trim().slice(0, 140) })
  }
  return items
}

const handler = async (m, { Rafz, command, text }) => {
  const tr = (key, vars) => (m.t ? m.t(key, vars) : key)
  const wait = await m.reply("⏳ " + tr("common.searching"), { parse_mode: "HTML" })
  const done = () => { try { Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {}) } catch {} }
  const editOut = async (t2, extra = {}) => {
    try {
      return await Rafz.editMessageText(String(t2).slice(0, 4000), {
        chat_id: m.chat, message_id: wait.message_id, parse_mode: "HTML",
        disable_web_page_preview: true, ...extra
      })
    } catch (e) {
      if (String(e?.message || e).includes("not modified")) return null
      return null
    }
  }

  try {
    const q = (text || "").trim()
    if (!q) { done(); return m.reply(tr("dl3.needQuery"), { parse_mode: "HTML" }) }

    /* ─────────── /npmsearch — cari package npm ─────────── */
    if (command === "npmsearch" || command === "carinpm") {
      const j = await getJSON("https://registry.npmjs.org/-/v1/search?text=" + encodeURIComponent(q) + "&size=8")
      done()
      const objs = (j.objects || []).map(o => o.package)
      if (!objs.length) return m.reply(tr("dl3.noResult"), { parse_mode: "HTML" })
      let out = "<b>📦 npm — " + esc(q) + "</b>\n\n"
      objs.forEach((p, i) => {
        out += (i + 1) + ". <b>" + esc(p.name) + "</b> v" + esc(p.version) + "\n"
        out += "   " + esc((p.description || "-").slice(0, 90)) + "\n"
        out += "   🔗 " + p.links?.npm + "\n"
      })
      const rows = objs.slice(0, 3).map(p => [{ text: "📦 " + esc(p.name).slice(0, 20), url: p.links?.npm, style: "primary" }])
      return m.reply(out, { parse_mode: "HTML", reply_markup: { inline_keyboard: rows } })
    }

    /* ─────────── /npmstalk2 — detail package npm ─────────── */
    if (command === "npmstalk2" || command === "npmpkg") {
      const j = await getJSON("https://registry.npmjs.org/" + encodeURIComponent(q)).catch(() => null)
      done()
      if (!j || j.error) return m.reply(tr("dl3.noResult"), { parse_mode: "HTML" })
      const latest = j["dist-tags"]?.latest
      const v = j.versions?.[latest] || {}
      let out = "<b>📦 " + esc(j.name) + "</b>\n\n"
      out += "🏷️ Latest: <code>" + esc(latest || "-") + "</code>\n"
      out += "📝 " + esc((j.description || "-").slice(0, 200)) + "\n"
      out += "🏠 " + (j.homepage || "-") + "\n"
      out += "🧑 " + esc(Object.keys(j.versions || {}).length) + " versi\n"
      out += "🪪 License: <code>" + esc(v.license || "-") + "</code>\n"
      if (v.dist?.tarball) out += "📥 " + v.dist.tarball + "\n"
      return m.reply(out, { parse_mode: "HTML", ...(j.homepage ? kb1("Homepage", j.homepage) : {}) })
    }

    /* ─────────── /robloxstalk2 — Roblox user stalk ─────────── */
    if (command === "robloxstalk2" || command === "rbxstalk2") {
      /* API roblox butuh POST */
      const ac = new AbortController()
      const t = setTimeout(() => ac.abort(), 20000)
      const res = await antiflood.withRetry(() => fetch("https://users.roblox.com/v1/usernames/users", {
        method: "POST",
        headers: { "Content-Type": "application/json", "User-Agent": UA },
        body: JSON.stringify({ usernames: [q], excludeBannedUsers: false }),
        signal: ac.signal
      }), "roblox " + q.slice(0, 30)).catch(() => null)
      clearTimeout(t)
      const rj = res && res.ok ? await res.json().catch(() => null) : null
      done()
      const u = rj?.data?.[0]
      if (!u) return m.reply(tr("dl3.noResult"), { parse_mode: "HTML" })
      const detail = await getJSON("https://users.roblox.com/v1/users/" + u.id).catch(() => null)
      let out = "<b>🎮 Roblox — " + esc(u.name) + "</b>\n\n"
      out += "🆔 ID: <code>" + u.id + "</code>\n"
      if (detail) {
        out += "📝 " + esc((detail.description || "-").slice(0, 200)) + "\n"
        out += "📅 Created: " + String(detail.created || "-").slice(0, 10) + "\n"
        out += "✅ Verified: " + (detail.hasVerifiedBadge ? "✅" : "❌") + "\n"
      }
      out += "🔗 https://www.roblox.com/users/" + u.id + "/profile"
      /* avatar headshot */
      const av = await getJSON("https://thumbnails.roblox.com/v1/users/avatar-headshot?userIds=" + u.id + "&size=420x420&format=Png&isCircular=false").catch(() => null)
      const avUrl = av?.data?.[0]?.imageUrl
      if (avUrl) {
        try { return await Rafz.sendPhoto(m.chat, avUrl, { caption: out, parse_mode: "HTML" }) } catch {}
      }
      return m.reply(out, { parse_mode: "HTML" })
    }

    /* ─────────── /threadsstalk — Threads user stalk ─────────── */
    if (command === "threadsstalk" || command === "threadstalk") {
      const user = q.replace(/^@/, "")
      const html = await getText("https://www.threads.net/@" + user).catch(() => null)
      done()
      if (!html || html.length < 1000) return m.reply(tr("dl3.noResult"), { parse_mode: "HTML" })
      const name = (html.match(/<meta[^>]+property="og:title"[^>]+content="([^"]+)"/) || [])[1] || user
      const desc = (html.match(/<meta[^>]+property="og:description"[^>]+content="([^"]+)"/) || [])[1] || "-"
      const img = (html.match(/<meta[^>]+property="og:image"[^>]+content="([^"]+)"/) || [])[1]
      let out = "<b>🧵 Threads — " + esc(name) + "</b>\n\n" + esc(desc.slice(0, 300)) + "\n\n🔗 https://www.threads.net/@" + user
      if (img) { try { return await Rafz.sendPhoto(m.chat, img, { caption: out, parse_mode: "HTML" }) } catch {} }
      return m.reply(out, { parse_mode: "HTML" })
    }

    /* ─────────── /xstalk — Twitter/X stalk ─────────── */
    if (command === "xstalk" || command === "twitterstalk2") {
      const user = q.replace(/^@/, "")
      /* og:meta dari twitter.com masih jalan tanpa login utk profile publik */
      const html = await getText("https://twitter.com/" + user, { "Accept-Language": "en-US,en;q=0.9" }).catch(() => null)
      done()
      const name = (html || "").match(/<meta[^>]+property="og:title"[^>]+content="([^"]+)"/)?.[1]
      const desc = (html || "").match(/<meta[^>]+property="og:description"[^>]+content="([^"]+)"/)?.[1]
      if (!name) {
        /* fallback link saja */
        return m.reply("<b>𝕏 / Twitter</b>\n\n🔗 https://x.com/" + esc(user), { parse_mode: "HTML", ...kb1("Buka profil", "https://x.com/" + user) })
      }
      let out = "<b>𝕏 " + esc(name) + "</b>\n\n" + esc((desc || "-").slice(0, 300)) + "\n\n🔗 https://x.com/" + esc(user)
      return m.reply(out, { parse_mode: "HTML", ...kb1("Buka profil", "https://x.com/" + user) })
    }

    /* ─────────── /modrinth — search mod Minecraft ─────────── */
    if (command === "modrinth" || command === "modrinthsearch") {
      const j = await getJSON("https://api.modrinth.com/v2/search?query=" + encodeURIComponent(q) + "&limit=8").catch(() => null)
      done()
      if (!j || !j.hits?.length) return m.reply(tr("dl3.noResult"), { parse_mode: "HTML" })
      let out = "<b>⛏️ Modrinth — " + esc(q) + "</b>\n\n"
      j.hits.slice(0, 8).forEach((h, i) => {
        out += (i + 1) + ". <b>" + esc(h.title) + "</b> (" + esc(h.project_type) + ")\n"
        out += "   " + esc((h.description || "-").slice(0, 90)) + "\n"
        out += "   ⬇️ " + (h.downloads || 0).toLocaleString("id-ID") + " | 🔗 https://modrinth.com/mod/" + h.slug + "\n"
      })
      const rows = j.hits.slice(0, 3).map(h => [{ text: "⛏️ " + esc(h.title).slice(0, 20), url: "https://modrinth.com/mod/" + h.slug, style: "success" }])
      return m.reply(out, { parse_mode: "HTML", reply_markup: { inline_keyboard: rows } })
    }

    /* ─────────── /fontlist — cari font di dafont ─────────── */
    if (command === "fontlist" || command === "dafont") {
      const items = await bingSearch("site:dafont.com " + q + ".font", 8)
      done()
      if (!items.length) return m.reply(tr("dl3.noResult"), { parse_mode: "HTML" })
      let out = "<b>🔤 Dafont — " + esc(q) + "</b>\n\n"
      items.forEach((it, i) => { out += (i + 1) + ". <b>" + esc(it.title.slice(0, 60)) + "</b>\n   🔗 " + it.link + "\n" })
      const rows = items.slice(0, 3).map(it => [{ text: "🔤 Download font", url: it.link, style: "primary" }])
      return m.reply(out, { parse_mode: "HTML", reply_markup: { inline_keyboard: rows } })
    }

    /* ─────────── /apkmirror — search APKMirror ─────────── */
    if (command === "apkmirror" || command === "apkpure") {
      const site = command === "apkmirror" ? "apkmirror.com" : "apkpure.net"
      const items = await bingSearch("site:" + site + " " + q, 6)
      done()
      if (!items.length) return m.reply(tr("dl3.noResult"), { parse_mode: "HTML" })
      let out = "<b>📱 APK — " + esc(q) + "</b>\n\n"
      items.forEach((it, i) => { out += (i + 1) + ". <b>" + esc(it.title.slice(0, 70)) + "</b>\n   🔗 " + it.link + "\n" })
      const rows = items.slice(0, 3).map(it => [{ text: "📱 Download", url: it.link, style: "primary" }])
      return m.reply(out, { parse_mode: "HTML", reply_markup: { inline_keyboard: rows } })
    }

    return false
  } catch (e) {
    done()
    console.error("[stalk2]", command, e?.message)
    try { await m.reply("❌ " + e.message) } catch {}
    return false
  }
}

handler.command = [
  "npmsearch", "carinpm", "npmstalk2", "npmpkg",
  "robloxstalk2", "rbxstalk2",
  "threadsstalk", "threadstalk",
  "xstalk", "twitterstalk2",
  "modrinth", "modrinthsearch",
  "fontlist", "dafont",
  "apkmirror", "apkpure"
]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
