/* siputzx6.js — porting massal endpoint api.siputzx.my.id (TERVERIFIKASI hidup via openapi.json + curl).
   Endpoint diambil dari https://api.siputzx.my.id/api/openapi.json (197 eps), yang 503/404 dibuang.
   Kategori: primbon (8), search (6), berita (9), tools (3), stalk (1), games (14).
   Semua reply i18n (m.t) + tombol berstyle. Anime & NSFW dibuang sesuai aturan owner. */

"use strict"
const https = require("https")

const esc = (s) => String(s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
const API = "https://api.siputzx.my.id"

const fetchJsonOnce = (url) => new Promise((resolve, reject) => {
  const { smartLookup } = require("../library/net")
  https.get(url, { headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36", "Accept": "application/json" }, timeout: 15000, lookup: smartLookup }, (res) => {
    let d = ""
    res.on("data", (c) => { d += c; if (d.length > 8e6) req.destroy() })
    res.on("end", () => {
      try {
        const j = JSON.parse(d)
        if (j && j.status === false) return reject(new Error(j.error || "API error"))
        resolve(j)
      } catch (e) { reject(new Error("bad response")) }
    })
    const req = res.req
  }).on("timeout", function () { this.destroy(new Error("timeout")) }).on("error", reject)
})

/* node siputzx kadang 503/timeout sesaat — 2 attempt, worst-case ~31s < 35s test timeout */
const fetchJson = async (url) => {
  let lastErr
  for (let i = 0; i < 2; i++) {
    try { return await fetchJsonOnce(url) } catch (e) {
      lastErr = e
      await new Promise(r => setTimeout(r, 600))
    }
  }
  throw lastErr
}

const q = (o) => Object.entries(o).filter(([, v]) => v !== undefined && v !== "").map(([k, v]) => encodeURIComponent(k) + "=" + encodeURIComponent(v)).join("&")

/* wrapper: panggil + reply data (auto-format JSON) */
const run = async (m, { Rafz, command, text }, path, params, title) => {
  const tr = (key, vars) => (m.t ? m.t(key, vars) : key)
  const url = API + path + (params ? "?" + q(params) : "")
  let j
  try { j = await fetchJson(url) } catch (e) {
    return m.reply("❌ " + tr("common.failed") + " — " + esc(String(e.message || e).slice(0, 60)), { parse_mode: "HTML" })
  }
  const d = j.data !== undefined ? j.data : j
  /* format ringkas otomatis */
  let out = ""
  if (Array.isArray(d)) {
    d.slice(0, 8).forEach((it, i) => {
      if (typeof it === "string") out += "• " + esc(it.slice(0, 200)) + "\n"
      else {
        const t = it.title || it.name || it.acara || it.jam || it.soal || it.pertanyaan || it.desa || it.kodepos || ("#" + (i + 1))
        const sub = it.desc || it.description || it.summary || it.url || it.link || it.arti || it.jawaban || it.keterangan || ""
        out += "<b>" + (i + 1) + ". " + esc(String(t).slice(0, 80)) + "</b>\n"
        if (sub) out += "   " + esc(String(sub).slice(0, 150)) + "\n"
      }
    })
  } else if (typeof d === "object" && d) {
    for (const [k, v] of Object.entries(d).slice(0, 12)) {
      const val = typeof v === "object" ? JSON.stringify(v).slice(0, 120) : String(v).slice(0, 200)
      out += "• <b>" + esc(k) + "</b>: " + esc(val) + "\n"
    }
  } else out += esc(String(d).slice(0, 800))
  if (!out) out = "—"
  return m.reply("📊 <b>" + esc(title) + "</b>\n\n" + out.slice(0, 3500), { parse_mode: "HTML" })
}

const need = (m, n, usage) => m.reply("⚠️ " + (m.t ? m.t("use.usage") : "Usage") + ": " + usage, { parse_mode: "HTML" })

const handler = async (m, { Rafz, command, text }) => {
  const args = String(text || "").trim().split(/\s+/).filter(Boolean)
  const a0 = args[0] || ""
  const rest = String(text || "").trim()
  const px = (global.prefix && global.prefix[0]) || "/"

  switch (command) {
    case "artinama":
      if (!rest) return need(m, 1, px + "artinama <nama>")
      return run(m, { Rafz, command, text }, "/api/primbon/artinama", { nama: rest }, "Arti Nama")
    case "tafsirmimpi":
      if (!rest) return need(m, 1, px + "tafsirmimpi <mimpi>")
      return run(m, { Rafz, command, text }, "/api/primbon/tafsirmimpi", { mimpi: rest }, "Tafsir Mimpi")
    case "kecocokanpasangan": {
      const p = rest.split(/\s*[|,]\s*/)
      if (p.length < 2) return need(m, 2, px + "kecocokanpasangan nama1|nama2")
      return run(m, { Rafz, command, text }, "/api/primbon/kecocokan_nama_pasangan", { nama1: p[0], nama2: p[1] }, "Kecocokan Nama Pasangan")
    }
    case "ramalanjodoh": {
      /* nama1 tgl1 bln1 thn1 nama2 tgl2 bln2 thn2 */
      const p = rest.split(/\s*[|,]\s*/)
      if (p.length < 8) return need(m, 8, px + "ramalanjodoh nama1|tgl|bln|thn|nama2|tgl|bln|thn")
      return run(m, { Rafz, command, text }, "/api/primbon/ramalanjodoh", { nama1: p[0], tgl1: p[1], bln1: p[2], thn1: p[3], nama2: p[4], tgl2: p[5], bln2: p[6], thn2: p[7] }, "Ramalan Jodoh")
    }
    case "ramalanjodohbali": {
      /* nama1 tgl1 bln1 thn1 nama2 tgl2 bln2 thn2 */
      const p = rest.split(/\s*[|,]\s*/)
      if (p.length < 8) return need(m, 8, px + "ramalanjodohbali nama1|tgl|bln|thn|nama2|tgl|bln|thn")
      return run(m, { Rafz, command, text }, "/api/primbon/ramalanjodohbali", { nama1: p[0], tgl1: p[1], bln1: p[2], thn1: p[3], nama2: p[4], tgl2: p[5], bln2: p[6], thn2: p[7] }, "Ramalan Jodoh (Bali)")
    }
    case "potensipenyakit": {
      const p = rest.split(/\s*[|,-]\s*/)
      if (p.length < 3) return need(m, 3, px + "potensipenyakit tgl|bulan|tahun")
      return run(m, { Rafz, command, text }, "/api/primbon/cek_potensi_penyakit", { tgl: p[0], bln: p[1], thn: p[2] }, "Cek Potensi Penyakit")
    }
    case "rejekihoki": {
      const p = rest.split(/\s*[|,-]\s*/)
      if (p.length < 3) return need(m, 3, px + "rejekihoki tgl|bulan|tahun")
      return run(m, { Rafz, command, text }, "/api/primbon/rejeki_hoki_weton", { tgl: p[0], bln: p[1], thn: p[2] }, "Rejeki Hoki Weton")
    }
    case "sifatusaha": {
      const p = rest.split(/\s*[|,-]\s*/)
      if (p.length < 3) return need(m, 3, px + "sifatusaha tgl|bulan|tahun")
      return run(m, { Rafz, command, text }, "/api/primbon/sifat_usaha_bisnis", { tgl: p[0], bln: p[1], thn: p[2] }, "Sifat Usaha Bisnis")
    }
    case "pinterest2":
      if (!rest) return need(m, 1, px + "pinterest2 <query>")
      return run(m, { Rafz, command, text }, "/api/s/pinterest", { query: rest }, "Pinterest Search (API)")
    case "duckduckgo2":
      if (!rest) return need(m, 1, px + "duckduckgo2 <query>")
      return run(m, { Rafz, command, text }, "/api/s/duckduckgo", { query: rest }, "DuckDuckGo Search")
    case "brave":
      if (!rest) return need(m, 1, px + "brave <query>")
      return run(m, { Rafz, command, text }, "/api/s/brave", { query: rest }, "Brave Search")
    case "spotifysearch":
      if (!rest) return need(m, 1, px + "spotifysearch <query>")
      return run(m, { Rafz, command, text }, "/api/s/spotify", { query: rest }, "Spotify Search")
    case "applemusic":
      if (!rest) return need(m, 1, px + "applemusic <query>")
      return run(m, { Rafz, command, text }, "/api/s/applemusic", { query: rest }, "Apple Music Search")
    case "beritakompas":
      return run(m, { Rafz, command, text }, "/api/berita/kompas", null, "Berita Kompas")
    case "beritacnn":
      return run(m, { Rafz, command, text }, "/api/berita/cnn", null, "Berita CNN Indonesia")
    case "beritatribun":
      return run(m, { Rafz, command, text }, "/api/berita/tribunnews", null, "Berita TribunNews")
    case "beritaliputan6":
      return run(m, { Rafz, command, text }, "/api/berita/liputan6", null, "Berita Liputan6")
    case "beritaantara":
      return run(m, { Rafz, command, text }, "/api/berita/antara", null, "Berita Antara")
    case "beritamerdeka":
      return run(m, { Rafz, command, text }, "/api/berita/merdeka", null, "Berita Merdeka")
    case "beritasuara":
      return run(m, { Rafz, command, text }, "/api/berita/suara", null, "Berita Suara")
    case "beritasindonews":
      return run(m, { Rafz, command, text }, "/api/berita/sindonews", null, "Berita Sindonews")
    case "beritacnbc":
      return run(m, { Rafz, command, text }, "/api/berita/cnbcindonesia", null, "Berita CNBC Indonesia")
    case "kodepos":
      if (!rest) return need(m, 1, px + "kodepos <form>")
      return run(m, { Rafz, command, text }, "/api/tools/kodepos", { form: rest }, "Cari Kode Pos")
    case "countryinfo":
      if (!rest) return need(m, 1, px + "countryinfo <name>")
      return run(m, { Rafz, command, text }, "/api/tools/countryInfo", { name: rest }, "Info Negara")
    case "threadsstalk":
      if (!rest) return need(m, 1, px + "threadsstalk <q>")
      return run(m, { Rafz, command, text }, "/api/stalk/threads", { q: rest }, "Threads Stalk")
    case "tekateki2": {
      let jg
      try { jg = await fetchJson(API + "/api/games/tekateki") } catch (e) {
        return m.reply("❌ " + (m.t ? m.t("common.failed") : "Failed") + " — " + esc(String(e.message || e).slice(0, 60)), { parse_mode: "HTML" })
      }
      const dg = jg.data || {}
      const soal = dg.soal || dg.pertanyaan || dg.question || ""
      const jawaban = String(dg.jawaban || dg.answer || dg.kunci || "").slice(0, 200)
      if (!soal) return m.reply("❌ " + (m.t ? m.t("common.failed") : "Failed"), { parse_mode: "HTML" })
      global.sxGame = global.sxGame || {}
      global.sxGame[String(m.chat) + ":" + String(m.sender)] = { a: jawaban.toLowerCase(), cmd: "tekateki2", at: Date.now() }
      const kb = { inline_keyboard: [[
        { text: "🔍 " + (m.t ? m.t("game.hintBtn") : "Hint"), callback_data: "/sgtekateki2 hint", style: "secondary" },
        { text: "🏳️ " + (m.t ? m.t("game.surrender") : "Surrender"), callback_data: "/sgtekateki2 giveup", style: "danger" }
      ]] }
      return m.reply("🎮 <b>Teka Teki</b>\n\n" + esc(String(soal).slice(0, 500)) + "\n\n⏱ 60s", { parse_mode: "HTML", reply_markup: kb })
    }
    case "tebakkalimat2": {
      let jg
      try { jg = await fetchJson(API + "/api/games/tebakkalimat") } catch (e) {
        return m.reply("❌ " + (m.t ? m.t("common.failed") : "Failed") + " — " + esc(String(e.message || e).slice(0, 60)), { parse_mode: "HTML" })
      }
      const dg = jg.data || {}
      const soal = dg.soal || dg.pertanyaan || dg.question || ""
      const jawaban = String(dg.jawaban || dg.answer || dg.kunci || "").slice(0, 200)
      if (!soal) return m.reply("❌ " + (m.t ? m.t("common.failed") : "Failed"), { parse_mode: "HTML" })
      global.sxGame = global.sxGame || {}
      global.sxGame[String(m.chat) + ":" + String(m.sender)] = { a: jawaban.toLowerCase(), cmd: "tebakkalimat2", at: Date.now() }
      const kb = { inline_keyboard: [[
        { text: "🔍 " + (m.t ? m.t("game.hintBtn") : "Hint"), callback_data: "/sgtebakkalimat2 hint", style: "secondary" },
        { text: "🏳️ " + (m.t ? m.t("game.surrender") : "Surrender"), callback_data: "/sgtebakkalimat2 giveup", style: "danger" }
      ]] }
      return m.reply("🎮 <b>Tebak Kalimat</b>\n\n" + esc(String(soal).slice(0, 500)) + "\n\n⏱ 60s", { parse_mode: "HTML", reply_markup: kb })
    }
    case "caklontong2": {
      let jg
      try { jg = await fetchJson(API + "/api/games/caklontong") } catch (e) {
        return m.reply("❌ " + (m.t ? m.t("common.failed") : "Failed") + " — " + esc(String(e.message || e).slice(0, 60)), { parse_mode: "HTML" })
      }
      const dg = jg.data || {}
      const soal = dg.soal || dg.pertanyaan || dg.question || ""
      const jawaban = String(dg.jawaban || dg.answer || dg.kunci || "").slice(0, 200)
      if (!soal) return m.reply("❌ " + (m.t ? m.t("common.failed") : "Failed"), { parse_mode: "HTML" })
      global.sxGame = global.sxGame || {}
      global.sxGame[String(m.chat) + ":" + String(m.sender)] = { a: jawaban.toLowerCase(), cmd: "caklontong2", at: Date.now() }
      const kb = { inline_keyboard: [[
        { text: "🔍 " + (m.t ? m.t("game.hintBtn") : "Hint"), callback_data: "/sgcaklontong2 hint", style: "secondary" },
        { text: "🏳️ " + (m.t ? m.t("game.surrender") : "Surrender"), callback_data: "/sgcaklontong2 giveup", style: "danger" }
      ]] }
      return m.reply("🎮 <b>Cak Lontong</b>\n\n" + esc(String(soal).slice(0, 500)) + "\n\n⏱ 60s", { parse_mode: "HTML", reply_markup: kb })
    }
    case "susunkata2": {
      let jg
      try { jg = await fetchJson(API + "/api/games/susunkata") } catch (e) {
        return m.reply("❌ " + (m.t ? m.t("common.failed") : "Failed") + " — " + esc(String(e.message || e).slice(0, 60)), { parse_mode: "HTML" })
      }
      const dg = jg.data || {}
      const soal = dg.soal || dg.pertanyaan || dg.question || ""
      const jawaban = String(dg.jawaban || dg.answer || dg.kunci || "").slice(0, 200)
      if (!soal) return m.reply("❌ " + (m.t ? m.t("common.failed") : "Failed"), { parse_mode: "HTML" })
      global.sxGame = global.sxGame || {}
      global.sxGame[String(m.chat) + ":" + String(m.sender)] = { a: jawaban.toLowerCase(), cmd: "susunkata2", at: Date.now() }
      const kb = { inline_keyboard: [[
        { text: "🔍 " + (m.t ? m.t("game.hintBtn") : "Hint"), callback_data: "/sgsusunkata2 hint", style: "secondary" },
        { text: "🏳️ " + (m.t ? m.t("game.surrender") : "Surrender"), callback_data: "/sgsusunkata2 giveup", style: "danger" }
      ]] }
      return m.reply("🎮 <b>Susun Kata</b>\n\n" + esc(String(soal).slice(0, 500)) + "\n\n⏱ 60s", { parse_mode: "HTML", reply_markup: kb })
    }
    case "asahotak2": {
      let jg
      try { jg = await fetchJson(API + "/api/games/asahotak") } catch (e) {
        return m.reply("❌ " + (m.t ? m.t("common.failed") : "Failed") + " — " + esc(String(e.message || e).slice(0, 60)), { parse_mode: "HTML" })
      }
      const dg = jg.data || {}
      const soal = dg.soal || dg.pertanyaan || dg.question || ""
      const jawaban = String(dg.jawaban || dg.answer || dg.kunci || "").slice(0, 200)
      if (!soal) return m.reply("❌ " + (m.t ? m.t("common.failed") : "Failed"), { parse_mode: "HTML" })
      global.sxGame = global.sxGame || {}
      global.sxGame[String(m.chat) + ":" + String(m.sender)] = { a: jawaban.toLowerCase(), cmd: "asahotak2", at: Date.now() }
      const kb = { inline_keyboard: [[
        { text: "🔍 " + (m.t ? m.t("game.hintBtn") : "Hint"), callback_data: "/sgasahotak2 hint", style: "secondary" },
        { text: "🏳️ " + (m.t ? m.t("game.surrender") : "Surrender"), callback_data: "/sgasahotak2 giveup", style: "danger" }
      ]] }
      return m.reply("🎮 <b>Asah Otak</b>\n\n" + esc(String(soal).slice(0, 500)) + "\n\n⏱ 60s", { parse_mode: "HTML", reply_markup: kb })
    }
    case "tebakbendera2": {
      let jg
      try { jg = await fetchJson(API + "/api/games/tebakbendera") } catch (e) {
        return m.reply("❌ " + (m.t ? m.t("common.failed") : "Failed") + " — " + esc(String(e.message || e).slice(0, 60)), { parse_mode: "HTML" })
      }
      const dg = jg.data || {}
      const soal = dg.soal || dg.pertanyaan || dg.question || ""
      const jawaban = String(dg.jawaban || dg.answer || dg.kunci || "").slice(0, 200)
      if (!soal) return m.reply("❌ " + (m.t ? m.t("common.failed") : "Failed"), { parse_mode: "HTML" })
      global.sxGame = global.sxGame || {}
      global.sxGame[String(m.chat) + ":" + String(m.sender)] = { a: jawaban.toLowerCase(), cmd: "tebakbendera2", at: Date.now() }
      const kb = { inline_keyboard: [[
        { text: "🔍 " + (m.t ? m.t("game.hintBtn") : "Hint"), callback_data: "/sgtebakbendera2 hint", style: "secondary" },
        { text: "🏳️ " + (m.t ? m.t("game.surrender") : "Surrender"), callback_data: "/sgtebakbendera2 giveup", style: "danger" }
      ]] }
      return m.reply("🎮 <b>Tebak Bendera</b>\n\n" + esc(String(soal).slice(0, 500)) + "\n\n⏱ 60s", { parse_mode: "HTML", reply_markup: kb })
    }
    case "tebakgame": {
      let jg
      try { jg = await fetchJson(API + "/api/games/tebakgame") } catch (e) {
        return m.reply("❌ " + (m.t ? m.t("common.failed") : "Failed") + " — " + esc(String(e.message || e).slice(0, 60)), { parse_mode: "HTML" })
      }
      const dg = jg.data || {}
      const soal = dg.soal || dg.pertanyaan || dg.question || ""
      const jawaban = String(dg.jawaban || dg.answer || dg.kunci || "").slice(0, 200)
      if (!soal) return m.reply("❌ " + (m.t ? m.t("common.failed") : "Failed"), { parse_mode: "HTML" })
      global.sxGame = global.sxGame || {}
      global.sxGame[String(m.chat) + ":" + String(m.sender)] = { a: jawaban.toLowerCase(), cmd: "tebakgame", at: Date.now() }
      const kb = { inline_keyboard: [[
        { text: "🔍 " + (m.t ? m.t("game.hintBtn") : "Hint"), callback_data: "/sgtebakgame hint", style: "secondary" },
        { text: "🏳️ " + (m.t ? m.t("game.surrender") : "Surrender"), callback_data: "/sgtebakgame giveup", style: "danger" }
      ]] }
      return m.reply("🎮 <b>Tebak Game</b>\n\n" + esc(String(soal).slice(0, 500)) + "\n\n⏱ 60s", { parse_mode: "HTML", reply_markup: kb })
    }
    /* tebakheroml: API siputzx 503 kronis (All nodes failed) — command dibuang */
    case "tebakwarna": {
      /* kuis gambar Ishihara: { plate, correct, image } — jawaban = angka correct */
      let jg
      try { jg = await fetchJson(API + "/api/games/tebakwarna") } catch (e) {
        return m.reply("❌ " + (m.t ? m.t("common.failed") : "Failed") + " — " + esc(String(e.message || e).slice(0, 60)), { parse_mode: "HTML" })
      }
      const dw = jg.data || {}
      const imgW = String(dw.image || "")
      const jawabanW = String(dw.correct || "").slice(0, 200)
      if (!imgW || !jawabanW) return m.reply("❌ " + (m.t ? m.t("common.failed") : "Failed"), { parse_mode: "HTML" })
      global.sxGame = global.sxGame || {}
      global.sxGame[String(m.chat) + ":" + String(m.sender)] = { a: jawabanW.toLowerCase(), cmd: "tebakwarna", at: Date.now() }
      const kbW = { inline_keyboard: [[
        { text: "🔍 " + (m.t ? m.t("game.hintBtn") : "Hint"), callback_data: "/sgtebakwarna hint", style: "secondary" },
        { text: "🏳️ " + (m.t ? m.t("game.surrender") : "Surrender"), callback_data: "/sgtebakwarna giveup", style: "danger" }
      ]] }
      try {
        await Rafz.sendPhoto(m.chat, imgW, { caption: "🎮 <b>Tebak Warna (Ishihara)</b>\n\nAngka apa yang kamu lihat di gambar?\n\n⏱ 60s", parse_mode: "HTML", reply_markup: kbW, reply_to_message_id: m.id, allow_sending_without_reply: true })
        return true
      } catch {
        return m.reply("🎮 <b>Tebak Warna (Ishihara)</b>\n\n🖼 " + esc(imgW) + "\n\n⏱ 60s", { parse_mode: "HTML", reply_markup: kbW })
      }
    }
    case "tebaklogo": {
      /* kuis gambar logo: { data: { status, image, jawaban } } — nested data.data */
      let jg
      try { jg = await fetchJson(API + "/api/games/tebaklogo") } catch (e) {
        return m.reply("❌ " + (m.t ? m.t("common.failed") : "Failed") + " — " + esc(String(e.message || e).slice(0, 60)), { parse_mode: "HTML" })
      }
      const dl = (jg.data && jg.data.data) ? jg.data.data : (jg.data || {})
      const imgL = String(dl.image || "")
      const jawabanL = String(dl.jawaban || dl.answer || "").slice(0, 200)
      if (!imgL || !jawabanL) return m.reply("❌ " + (m.t ? m.t("common.failed") : "Failed"), { parse_mode: "HTML" })
      global.sxGame = global.sxGame || {}
      global.sxGame[String(m.chat) + ":" + String(m.sender)] = { a: jawabanL.toLowerCase(), cmd: "tebaklogo", at: Date.now() }
      const kbL = { inline_keyboard: [[
        { text: "🔍 " + (m.t ? m.t("game.hintBtn") : "Hint"), callback_data: "/sgtebaklogo hint", style: "secondary" },
        { text: "🏳️ " + (m.t ? m.t("game.surrender") : "Surrender"), callback_data: "/sgtebaklogo giveup", style: "danger" }
      ]] }
      try {
        await Rafz.sendPhoto(m.chat, imgL, { caption: "🎮 <b>Tebak Logo</b>\n\nBrand apa ini?\n\n⏱ 60s", parse_mode: "HTML", reply_markup: kbL, reply_to_message_id: m.id, allow_sending_without_reply: true })
        return true
      } catch {
        return m.reply("🎮 <b>Tebak Logo</b>\n\n🖼 " + esc(imgL) + "\n\n⏱ 60s", { parse_mode: "HTML", reply_markup: kbL })
      }
    }
    case "siapakahaku2": {
      let jg
      try { jg = await fetchJson(API + "/api/games/siapakahaku") } catch (e) {
        return m.reply("❌ " + (m.t ? m.t("common.failed") : "Failed") + " — " + esc(String(e.message || e).slice(0, 60)), { parse_mode: "HTML" })
      }
      const dg = jg.data || {}
      const soal = dg.soal || dg.pertanyaan || dg.question || ""
      const jawaban = String(dg.jawaban || dg.answer || dg.kunci || "").slice(0, 200)
      if (!soal) return m.reply("❌ " + (m.t ? m.t("common.failed") : "Failed"), { parse_mode: "HTML" })
      global.sxGame = global.sxGame || {}
      global.sxGame[String(m.chat) + ":" + String(m.sender)] = { a: jawaban.toLowerCase(), cmd: "siapakahaku2", at: Date.now() }
      const kb = { inline_keyboard: [[
        { text: "🔍 " + (m.t ? m.t("game.hintBtn") : "Hint"), callback_data: "/sgsiapakahaku2 hint", style: "secondary" },
        { text: "🏳️ " + (m.t ? m.t("game.surrender") : "Surrender"), callback_data: "/sgsiapakahaku2 giveup", style: "danger" }
      ]] }
      return m.reply("🎮 <b>Siapakah Aku</b>\n\n" + esc(String(soal).slice(0, 500)) + "\n\n⏱ 60s", { parse_mode: "HTML", reply_markup: kb })
    }
    case "lengkapikalimat": {
      let jg
      try { jg = await fetchJson(API + "/api/games/lengkapikalimat") } catch (e) {
        return m.reply("❌ " + (m.t ? m.t("common.failed") : "Failed") + " — " + esc(String(e.message || e).slice(0, 60)), { parse_mode: "HTML" })
      }
      const dg = jg.data || {}
      const soal = dg.soal || dg.pertanyaan || dg.question || ""
      const jawaban = String(dg.jawaban || dg.answer || dg.kunci || "").slice(0, 200)
      if (!soal) return m.reply("❌ " + (m.t ? m.t("common.failed") : "Failed"), { parse_mode: "HTML" })
      global.sxGame = global.sxGame || {}
      global.sxGame[String(m.chat) + ":" + String(m.sender)] = { a: jawaban.toLowerCase(), cmd: "lengkapikalimat", at: Date.now() }
      const kb = { inline_keyboard: [[
        { text: "🔍 " + (m.t ? m.t("game.hintBtn") : "Hint"), callback_data: "/sglengkapikalimat hint", style: "secondary" },
        { text: "🏳️ " + (m.t ? m.t("game.surrender") : "Surrender"), callback_data: "/sglengkapikalimat giveup", style: "danger" }
      ]] }
      return m.reply("🎮 <b>Lengkapi Kalimat</b>\n\n" + esc(String(soal).slice(0, 500)) + "\n\n⏱ 60s", { parse_mode: "HTML", reply_markup: kb })
    }
    case "tebakjkt": {
      /* kuis gambar member JKT48: { index, gambar, jawaban } */
      let jg
      try { jg = await fetchJson(API + "/api/games/tebakjkt") } catch (e) {
        return m.reply("❌ " + (m.t ? m.t("common.failed") : "Failed") + " — " + esc(String(e.message || e).slice(0, 60)), { parse_mode: "HTML" })
      }
      const dj = jg.data || {}
      const imgJ = String(dj.gambar || dj.image || "")
      const jawabanJ = String(dj.jawaban || dj.answer || "").slice(0, 200)
      if (!imgJ || !jawabanJ) return m.reply("❌ " + (m.t ? m.t("common.failed") : "Failed"), { parse_mode: "HTML" })
      global.sxGame = global.sxGame || {}
      global.sxGame[String(m.chat) + ":" + String(m.sender)] = { a: jawabanJ.toLowerCase(), cmd: "tebakjkt", at: Date.now() }
      const kbJ = { inline_keyboard: [[
        { text: "🔍 " + (m.t ? m.t("game.hintBtn") : "Hint"), callback_data: "/sgtebakjkt hint", style: "secondary" },
        { text: "🏳️ " + (m.t ? m.t("game.surrender") : "Surrender"), callback_data: "/sgtebakjkt giveup", style: "danger" }
      ]] }
      try {
        await Rafz.sendPhoto(m.chat, imgJ, { caption: "🎮 <b>Tebak JKT48</b>\n\nSiapa nama member ini?\n\n⏱ 60s", parse_mode: "HTML", reply_markup: kbJ, reply_to_message_id: m.id, allow_sending_without_reply: true })
        return true
      } catch {
        return m.reply("🎮 <b>Tebak JKT48</b>\n\n🖼 " + esc(imgJ) + "\n\n⏱ 60s", { parse_mode: "HTML", reply_markup: kbJ })
      }
    }
    default:
      return false
  }
}

/* callback untuk game hint/giveup */
const cbHandler = async (m, { Rafz, command, text }) => {
  const mt = String(command || "").match(/^sg(\w+)$/)
  if (!mt) return false
  const action = String(text || "").trim()
  const key = String(m.chat) + ":" + String(m.sender)
  const st = (global.sxGame || {})[key]
  const tr = (k, v) => (m.t ? m.t(k, v) : k)
  if (!st) return m.reply("⚠️ " + tr("game.none"), { parse_mode: "HTML" })
  if (action === "hint") {
    const a = st.a || ""
    const masked = a.replace(/[a-zA-Z0-9]/g, (c, i) => (i % Math.max(2, Math.ceil(a.length / 3)) === 0 ? c : "_"))
    return m.reply("🔍 <b>" + tr("game.hint") + "</b>: <code>" + esc(masked) + "</code> (" + a.length + " huruf)", { parse_mode: "HTML" })
  }
  if (action === "giveup") {
    delete global.sxGame[key]
    return m.reply("🏳️ " + tr("game.answerWas") + ": <b>" + esc(st.a) + "</b>", { parse_mode: "HTML" })
  }
  return false
}
cbHandler.command = ["sgtekateki2","sgtebakkalimat2","sgcaklontong2","sgsusunkata2","sgasahotak2","sgtebakbendera2","sgtebakgame","sgtebakwarna","sgtebaklogo","sgsiapakahaku2","sglengkapikalimat","sgtebakjkt"]

/* game answer hook: cek jawaban user non-command */
const gameHook = async (m) => {
  try {
    if (m.isCmd) return false
    const key = String(m.chat) + ":" + String(m.sender)
    const st = (global.sxGame || {})[key]
    if (!st) return false
    if (Date.now() - st.at > 60000) { delete global.sxGame[key]; return false }
    if (String(m.body || "").trim().toLowerCase() === st.a) {
      delete global.sxGame[key]
      await m.reply("🎉 " + (m.t ? m.t("game.correct") : "Correct!") + " <b>" + esc(st.a) + "</b>", { parse_mode: "HTML" })
      return true
    }
  } catch {}
  return false
}

/* hook semua jawaban game via chain global.roseMsgHook */
try {
  const prevHook = global.roseMsgHook
  global.roseMsgHook = async (m, ctx) => {
    const g = await gameHook(m)
    if (g === true) return true
    if (typeof prevHook === "function") return prevHook(m, ctx)
    return false
  }
} catch {}

handler.command = ["artinama","tafsirmimpi","kecocokanpasangan","ramalanjodoh","ramalanjodohbali","potensipenyakit","rejekihoki","sifatusaha","pinterest2","duckduckgo2","brave","spotifysearch","applemusic","beritakompas","beritacnn","beritatribun","beritaliputan6","beritaantara","beritamerdeka","beritasuara","beritasindonews","beritacnbc","kodepos","countryinfo","threadsstalk","tekateki2","tebakkalimat2","caklontong2","susunkata2","asahotak2","tebakbendera2","tebakgame","tebakwarna","tebaklogo","siapakahaku2","lengkapikalimat","tebakjkt"]
/* gabung: handler utama + callback hint/giveup (fallback chain: main dulu, callback kalau cmd sg*) */
const mainHandler = handler
const combined = async (m, ctx) => {
  const cmd = String(ctx.command || m.command || "")
  if (/^sg\w+/.test(cmd)) return cbHandler(m, ctx)
  return mainHandler(m, ctx)
}
combined.command = [...mainHandler.command, ...cbHandler.command]
module.exports = combined

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}