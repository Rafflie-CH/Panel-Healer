/* plugin: textmaker2.js — porting textmaker/fun-visual dari bot WA
   /fakereact   — gambar chat Telegram dengan reaksi emoji (sharp)
   /typewriter  — teks gaya mesin ketik (sticker)
   /captcha     — gambar captcha teks random
*/
"use strict"
const fs = require("fs")

const esc = (s) => String(s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
const rnd = (n) => Math.floor(Math.random() * n)

const svgPng = async (svg) => {
  const sharp = require("sharp")
  return sharp(Buffer.from(svg)).png().toBuffer()
}

const wrap = (text, max) => {
  const words = String(text).split(" ")
  const lines = []
  let line = ""
  for (const w of words) {
    if ((line + " " + w).trim().length > max) { lines.push(line.trim()); line = w } else line += " " + w
  }
  if (line.trim()) lines.push(line.trim())
  return lines
}

const escXml = (s) => String(s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")

const handler = async (m, { Rafz, command, text }) => {
  try {
    const tr = (key, vars) => (m.t ? m.t(key, vars) : key)
    const q = (text || "").trim()

    /* ─────────── /fakereact — chat dengan reaksi ─────────── */
    if (command === "fakereact") {
      if (!q) return m.reply(tr("use.usage") + ": <code>/fakereact halo|😍</code>", { parse_mode: "HTML" })
      const [msg, emo] = q.split("|").map(s => s.trim())
      const lines = wrap(msg || "halo", 28)
      const W = 560
      const bubbleH = 44 + lines.length * 30
      const H = bubbleH + 90
      const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}">
  <rect width="${W}" height="${H}" fill="#0f1620"/>
  <rect x="30" y="30" rx="18" width="${W - 120}" height="${bubbleH}" fill="#182533"/>
  ${lines.map((l, i) => `<text x="52" y="${66 + i * 30}" font-family="sans-serif" font-size="22" fill="#e9edef">${escXml(l)}</text>`).join("")}
  <rect x="${W - 140}" y="${30 + bubbleH + 8}" rx="14" width="110" height="42" fill="#182533"/>
  <text x="${W - 130}" y="${30 + bubbleH + 37}" font-family="sans-serif" font-size="22">${escXml(emo || "👍")} 1</text>
  <text x="30" y="${H - 14}" font-family="sans-serif" font-size="14" fill="#8696a0">Telegram • fake reaction</text>
</svg>`
      const png = await svgPng(svg)
      await Rafz.sendPhoto(m.chat, png, { caption: "🫶 " + tr("tm2.fakeReact") })
      return true
    }

    /* ─────────── /typewriter — teks gaya mesin ketik ─────────── */
    if (command === "typewriter" || command === "ketik") {
      if (!q) return m.reply(tr("use.usage") + ": <code>/typewriter hello world</code>", { parse_mode: "HTML" })
      const lines = wrap(q, 26)
      const W = 640
      const H = 120 + lines.length * 56
      const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}">
  <rect width="${W}" height="${H}" fill="#1a1a1a"/>
  <rect x="20" y="20" width="${W - 40}" height="${H - 40}" rx="10" fill="#f5f1e6" stroke="#8b7d5a" stroke-width="6"/>
  ${lines.map((l, i) => `<text x="${W / 2}" y="${100 + i * 56}" text-anchor="middle" font-family="monospace" font-size="40" fill="#2b2b2b">${escXml(l)}_|</text>`).join("")}
</svg>`
      const png = await svgPng(svg)
      await Rafz.sendPhoto(m.chat, png, { caption: "⌨️ " + tr("tm2.typeWriter") })
      return true
    }

    /* ─────────── /captcha — gambar captcha acak ─────────── */
    if (command === "captcha" || command === "captchagen") {
      const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
      let code = ""
      for (let i = 0; i < 5; i++) code += chars[rnd(chars.length)]
      const W = 380
      const H = 140
      const dots = Array.from({ length: 40 }, () =>
        `<circle cx="${rnd(W)}" cy="${rnd(H)}" r="${1 + rnd(3)}" fill="rgba(255,255,255,0.4)"/>`).join("")
      const rot = (r) => `rotate(${rnd(r) - r / 2} ${40 + i * 62} ${H / 2})`
      let i = 0
      const letters = code.split("").map((c) => {
        const x = 40 + i++ * 62
        return `<text x="${x}" y="${H / 2 + 16}" text-anchor="middle" font-family="sans-serif" font-weight="bold" font-size="52" fill="#${rnd(0xffffff).toString(16).padStart(6, "0")}" transform="rotate(${rnd(40) - 20} ${x} ${H / 2})">${c}</text>`
      }).join("")
      const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}">
  <rect width="${W}" height="${H}" fill="#22303f"/>
  ${dots}
  ${letters}
</svg>`
      const png = await svgPng(svg)
      await Rafz.sendPhoto(m.chat, png, { caption: "🤖 " + tr("tm2.captcha") + ": <code>" + code + "</code>", parse_mode: "HTML" })
      return true
    }

    return false
  } catch (e) {
    console.error("[textmaker2]", command, e?.message)
    try { await m.reply("❌ " + e.message) } catch {}
    return false
  }
}

handler.command = ["fakereact", "typewriter", "ketik", "captcha", "captchagen"]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
