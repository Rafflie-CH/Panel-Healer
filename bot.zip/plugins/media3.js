/* media3.js — porting media & data dari WA bot (Rafzbotz/Prabowo/Furina).
   API TERVERIFIKASI hidup (2026-09):
   - tikwm.com           (tiktok nowm / audio / info — tanpa API key)
   - api.mcsrvstat.us    (Minecraft server status)
   - BochilTeam kurs.json (kurs mata uang)
   - data.bmkg.go.id     (gempa dirasakan)
   - emsifa api-wilayah-indonesia (provinsi→kabupaten→kecamatan→desa via tombol)
   Semua tombol berstyle + i18n. */

"use strict"

const esc = (s) => String(s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
const API = async (u, opts) => {
  const r = await fetch(u, Object.assign({ signal: AbortSignal.timeout(25000), headers: { "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120", "accept": "application/json" } }, opts || {}))
  if (!r.ok) throw new Error("HTTP " + r.status)
  return r.json()
}
const fetchBuf = async (u) => {
  const r = await fetch(u, { signal: AbortSignal.timeout(60000), headers: { "user-agent": "Mozilla/5.0" } })
  if (!r.ok) throw new Error("HTTP " + r.status)
  return Buffer.from(await r.arrayBuffer())
}

const handler = async (m, { Rafz, command, text }) => {
  try {
    const tr = (key, vars) => (m.t ? m.t(key, vars) : key)
    const px = (global.prefix && global.prefix[0]) || "/"

    /* ═══ TIKTOK via tikwm.com ═══ */
    if (command === "ttnowm" || command === "ttnowm2" || command === "ttaudio" || command === "ttmusic" || command === "ttinfo") {
      const url = String(text || "").trim().match(/https?:\/\/\S+/)?.[0]
      if (!url) return m.reply("⚠️ " + tr("dl3.needUrl") + "\n<code>" + px + command + " https://vt.tiktok.com/xxx</code>", { parse_mode: "HTML" })
      const wait = await m.reply(tr("common.searching"), { parse_mode: "HTML" })
      try {
        const j = await API("https://tikwm.com/api/?url=" + encodeURIComponent(url))
        if (!j || j.code !== 0 || !j.data) throw new Error("tikwm: " + (j.msg || "no data"))
        const d = j.data
        try { Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {}) } catch {}

        if (command === "ttinfo") {
          const out = "📊 <b>TIKTOK INFO</b>\n\n" +
            `📝 ${esc(String(d.title || "-").slice(0, 300))}\n` +
            `👤 ${esc(d.author?.nickname || "-")} (@${esc(d.author?.unique_id || "-")})\n` +
            `⏱️ ${d.duration || 0}s\n❤️ ${Number(d.digg_count || 0).toLocaleString("en")}  💬 ${Number(d.comment_count || 0).toLocaleString("en")}\n` +
            `🔁 ${Number(d.share_count || 0).toLocaleString("en")}  ▶️ ${Number(d.play_count || 0).toLocaleString("en")}`
          const kb = { inline_keyboard: [[
            { text: "▶️ Video", callback_data: "/ttnowm " + url.slice(0, 50), style: "primary" },
            { text: "🎵 Audio", callback_data: "/ttaudio " + url.slice(0, 50), style: "success" }
          ]] }
          return m.reply(out, { parse_mode: "HTML", reply_markup: kb })
        }

        if (command === "ttaudio" || command === "ttmusic") {
          const au = d.music || d.music_info?.play_url
          if (!au) throw new Error("no audio")
          const buf = await fetchBuf(au)
          await Rafz.sendAudio(m.chat, buf, {
            caption: "🎵 " + esc(String(d.music_info?.title || d.title || "TikTok Audio").slice(0, 80)),
            reply_to_message_id: m.id, allow_sending_without_reply: true
          })
          return true
        }

        /* ttnowm */
        const v = d.play || d.hdplay
        if (!v) throw new Error("no video")
        if (String(v).includes(".mp4")) {
          try {
            const buf = await fetchBuf(v.startsWith("http") ? v : "https://tikwm.com" + v)
            await Rafz.sendVideo(m.chat, buf, {
              caption: "✅ " + esc(String(d.title || "TikTok").slice(0, 200)),
              reply_to_message_id: m.id, allow_sending_without_reply: true
            })
            return true
          } catch {}
        }
        await Rafz.sendVideo(m.chat, v, {
          caption: "✅ " + esc(String(d.title || "TikTok").slice(0, 200)),
          reply_to_message_id: m.id, allow_sending_without_reply: true
        })
        return true
      } catch (e) {
        try { Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {}) } catch {}
        return m.reply(tr("common.failed") + " (" + esc(String(e?.message || e).slice(0, 80)) + ")", { parse_mode: "HTML" })
      }
    }

    /* ═══ MINECRAFT SERVER ═══ */
    if (command === "mcserver" || command === "mcstatus") {
      const addr = String(text || "").trim()
      if (!addr) return m.reply("⚠️ <code>" + px + "mcserver mc.hypixel.net</code>", { parse_mode: "HTML" })
      const wait = await m.reply(tr("common.searching"), { parse_mode: "HTML" })
      try {
        const j = await API("https://api.mcsrvstat.us/3/" + encodeURIComponent(addr))
        try { Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {}) } catch {}
        if (!j.online) return m.reply("🔴 " + tr("media3.mcOffline") + " — <code>" + esc(addr) + "</code>", { parse_mode: "HTML" })
        let out = "🟢 <b>MINECRAFT SERVER</b> — <code>" + esc(addr) + "</code>\n\n"
        out += "👥 " + j.players?.online + " / " + j.players?.max + " online\n"
        if (j.version) out += "📦 " + esc(String(j.version).slice(0, 60)) + "\n"
        if (j.motd?.clean) out += "💬 " + esc(j.motd.clean.join(" ").slice(0, 200)) + "\n"
        if (j.players?.list) out += "\n🧑‍🤝‍🧑 " + esc(j.players.list.slice(0, 10).join(", "))
        const kb = { inline_keyboard: [[{ text: "🔄 Refresh", callback_data: "/mcserver " + addr, style: "primary" }]] }
        return m.reply(out, { parse_mode: "HTML", reply_markup: kb })
      } catch (e) {
        try { Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {}) } catch {}
        return m.reply(tr("common.failed"), { parse_mode: "HTML" })
      }
    }

    /* ═══ KURS ═══ */
    if (command === "kurs" || command === "kurs2") {
      const q = String(text || "").trim().toUpperCase()
      try {
        const r = await fetch("https://raw.githubusercontent.com/BochilTeam/database/master/ekonomi/kurs.json", { signal: AbortSignal.timeout(15000) })
        const db = await r.json()
        if (q) {
          const d = db.find(x => x.mata_uang === q)
          if (!d) return m.reply(tr("media3.kursNotFound") + " — " + esc(q), { parse_mode: "HTML" })
          const out = "💱 <b>KURS " + esc(d.mata_uang) + "</b>\n" + esc(d.nama_mata_uang) + "\n\n" +
            "💰 Beli: <b>" + esc(d.kurs_beli) + "</b>\n💸 Jual: <b>" + esc(d.kurs_jual) + "</b>"
          return m.reply(out, { parse_mode: "HTML" })
        }
        let out = "💱 <b>KURS MATA UANG</b> (USD/EUR/JPY/SGD/…)\n\n"
        db.slice(0, 15).forEach(d => { out += `<b>${esc(d.mata_uang)}</b> — ${esc(d.kurs_jual)}\n` })
        out += "\n💡 <code>" + px + "kurs USD</code>"
        return m.reply(out, { parse_mode: "HTML" })
      } catch {
        return m.reply(tr("common.failed"), { parse_mode: "HTML" })
      }
    }

    /* ═══ GEMPA DIRASAKAN (BMKG) ═══ */
    if (command === "gempa2" || command === "gempadirasakan") {
      try {
        const j = await API("https://data.bmkg.go.id/DataMKG/TEWS/gempadirasakan.json")
        const arr = j.Infogempa?.gempa || []
        let out = "earthq 🌋 <b>GEMPA DIRASAKAN</b> (BMKG)\n\n".replace("earthq ", "🌋 ")
        arr.slice(0, 8).forEach(g => {
          out += `<b>${esc(g.Wilayah)}</b>\n📅 ${esc(g.Tanggal)} ${esc(g.Jam)}\n📏 M${esc(g.Magnitudo)} — ${esc(g.Kedalaman)}\n📍 ${esc(g.Dirasakan)}\n\n`
        })
        const kb = { inline_keyboard: [[{ text: "🔄 Refresh", callback_data: "/gempa2", style: "primary" }]] }
        return m.reply(out.slice(0, 3800), { parse_mode: "HTML", reply_markup: kb })
      } catch {
        return m.reply(tr("common.failed"), { parse_mode: "HTML" })
      }
    }

    /* ═══ WILAYAH INDONESIA (chain callback) ═══ */
    if (command === "provinsi" || command === "provinsi2") {
      try {
        const list = await API("https://www.emsifa.com/api-wilayah-indonesia/api/provinces.json")
        let out = "🇮🇩 <b>PROVINSI INDONESIA</b> (" + list.length + ")\n\n"
        list.slice(0, 24).forEach(p => { out += `• ${esc(p.name)}\n` })
        out += "\n💡 ketik <code>" + px + "provinsi nama</code> / tap tombol"
        const kb = { inline_keyboard: [[
          { text: "➡️ Next", callback_data: "/provpage 2", style: "primary" }
        ]] }
        return m.reply(out, { parse_mode: "HTML", reply_markup: kb })
      } catch {
        return m.reply(tr("common.failed"), { parse_mode: "HTML" })
      }
    }

    return false
  } catch (e) {
    console.error("[media3]", command, e?.message)
    try { await m.reply("❌ " + esc(String(e?.message || e).slice(0, 120)), { parse_mode: "HTML" }) } catch {}
    return false
  }
}

/* ═══ CALLBACK HANDLERS (wilayah chain + provinsi pager) ═══ */
const callbackHandler = async (m, { Rafz }) => {
  const cb = String(m.callback || "")
  const tr = (key, vars) => (m.t ? m.t(key, vars) : key)
  try {
    /* provinsi pager — tombol per provinsi → kabupaten (chain) */
    let mt = cb.match(/^\/provpage\s*(\d+)$/)
    if (mt) {
      const page = Math.max(1, parseInt(mt[1]))
      const list = await API("https://www.emsifa.com/api-wilayah-indonesia/api/provinces.json")
      const per = 20
      const pages = Math.ceil(list.length / per)
      const p = Math.min(pages, page)
      const slice = list.slice((p - 1) * per, p * per)
      const kb = { inline_keyboard: [] }
      for (let i = 0; i < slice.length; i += 2) {
        const row = [{ text: "🏙️ " + slice[i].name.slice(0, 20), callback_data: "/kab " + slice[i].id + " 1", style: "secondary" }]
        if (slice[i + 1]) row.push({ text: "🏙️ " + slice[i + 1].name.slice(0, 20), callback_data: "/kab " + slice[i + 1].id + " 1", style: "secondary" })
        kb.inline_keyboard.push(row)
      }
      const nav = []
      if (p > 1) nav.push({ text: "⬅️", callback_data: `/provpage ${p - 1}`, style: "secondary" })
      nav.push({ text: p + "/" + pages, callback_data: `/provpage ${p}`, style: "secondary" })
      if (p < pages) nav.push({ text: "➡️", callback_data: `/provpage ${p + 1}`, style: "primary" })
      kb.inline_keyboard.push(nav)
      const out = "🇮🇩 <b>PROVINSI INDONESIA</b> (" + list.length + ")\n" + tr("media3.pickBelow")
      try { await Rafz.editMessageText(out, { chat_id: m.chat, message_id: m.id, parse_mode: "HTML", reply_markup: kb }) } catch {}
      try { await Rafz.answerCallbackQuery(m.callbackId) } catch {}
      return true
    }

    /* kabupaten <kodeProv> <page> — tombol per item → kecamatan (chain) */
    mt = cb.match(/^\/kab\s+([\d.]+)\s*(\d*)$/)
    if (mt) {
      const list = await API("https://www.emsifa.com/api-wilayah-indonesia/api/regencies/" + mt[1] + ".json")
      const per = 20
      const pages = Math.ceil(list.length / per)
      const p = Math.min(pages, Math.max(1, parseInt(mt[2] || "1")))
      const slice = list.slice((p - 1) * per, p * per)
      const kb = { inline_keyboard: [] }
      for (let i = 0; i < slice.length; i += 2) {
        const row = [{ text: "🏘️ " + slice[i].name.slice(0, 20), callback_data: "/kec " + slice[i].id + " 1", style: "secondary" }]
        if (slice[i + 1]) row.push({ text: "🏘️ " + slice[i + 1].name.slice(0, 20), callback_data: "/kec " + slice[i + 1].id + " 1", style: "secondary" })
        kb.inline_keyboard.push(row)
      }
      const nav = []
      if (p > 1) nav.push({ text: "⬅️", callback_data: `/kab ${mt[1]} ${p - 1}`, style: "secondary" })
      nav.push({ text: p + "/" + pages, callback_data: `/kab ${mt[1]} ${p}`, style: "secondary" })
      if (p < pages) nav.push({ text: "➡️", callback_data: `/kab ${mt[1]} ${p + 1}`, style: "primary" })
      kb.inline_keyboard.push(nav)
      const out = "🏙️ <b>KABUPATEN/KOTA</b> (" + list.length + ")\n" + tr("media3.pickBelow")
      try { await Rafz.editMessageText(out, { chat_id: m.chat, message_id: m.id, parse_mode: "HTML", reply_markup: kb }) } catch {}
      try { await Rafz.answerCallbackQuery(m.callbackId) } catch {}
      return true
    }

    /* kecamatan <kodeKab> <page> — tombol per item → desa (chain) */
    mt = cb.match(/^\/kec\s+([\d.]+)\s*(\d*)$/)
    if (mt) {
      const list = await API("https://www.emsifa.com/api-wilayah-indonesia/api/districts/" + mt[1] + ".json")
      const per = 20
      const pages = Math.ceil(list.length / per)
      const p = Math.min(pages, Math.max(1, parseInt(mt[2] || "1")))
      const slice = list.slice((p - 1) * per, p * per)
      const kb = { inline_keyboard: [] }
      for (let i = 0; i < slice.length; i += 2) {
        const row = [{ text: "🏡 " + slice[i].name.slice(0, 20), callback_data: "/desa " + slice[i].id + " 1", style: "secondary" }]
        if (slice[i + 1]) row.push({ text: "🏡 " + slice[i + 1].name.slice(0, 20), callback_data: "/desa " + slice[i + 1].id + " 1", style: "secondary" })
        kb.inline_keyboard.push(row)
      }
      const nav = []
      if (p > 1) nav.push({ text: "⬅️", callback_data: `/kec ${mt[1]} ${p - 1}`, style: "secondary" })
      nav.push({ text: p + "/" + pages, callback_data: `/kec ${mt[1]} ${p}`, style: "secondary" })
      if (p < pages) nav.push({ text: "➡️", callback_data: `/kec ${mt[1]} ${p + 1}`, style: "primary" })
      kb.inline_keyboard.push(nav)
      const out = "🏘️ <b>KECAMATAN</b> (" + list.length + ")\n" + tr("media3.pickBelow")
      try { await Rafz.editMessageText(out, { chat_id: m.chat, message_id: m.id, parse_mode: "HTML", reply_markup: kb }) } catch {}
      try { await Rafz.answerCallbackQuery(m.callbackId) } catch {}
      return true
    }

    /* desa <kodeKec> <page> */
    mt = cb.match(/^\/desa\s+([\d.]+)\s*(\d*)$/)
    if (mt) {
      const list = await API("https://www.emsifa.com/api-wilayah-indonesia/api/villages/" + mt[1] + ".json")
      const per = 20
      const pages = Math.ceil(list.length / per)
      const p = Math.min(pages, Math.max(1, parseInt(mt[2] || "1")))
      const slice = list.slice((p - 1) * per, p * per)
      let out = "🏡 <b>DESA/KELURAHAN</b> (" + list.length + ")\n\n"
      slice.forEach(x => { out += `• ${esc(x.name)}\n` })
      const kb = { inline_keyboard: [] }
      const row = []
      if (p > 1) row.push({ text: "⬅️", callback_data: `/desa ${mt[1]} ${p - 1}`, style: "secondary" })
      row.push({ text: p + "/" + pages, callback_data: `/desa ${mt[1]} ${p}`, style: "secondary" })
      if (p < pages) row.push({ text: "➡️", callback_data: `/desa ${mt[1]} ${p + 1}`, style: "primary" })
      kb.inline_keyboard.push(row)
      try { await Rafz.editMessageText(out, { chat_id: m.chat, message_id: m.id, parse_mode: "HTML", reply_markup: kb }) } catch {}
      try { await Rafz.answerCallbackQuery(m.callbackId) } catch {}
      return true
    }
    return false
  } catch (e) {
    try { await Rafz.answerCallbackQuery(m.callbackId, { text: "❌ " + String(e?.message || e).slice(0, 60) }) } catch {}
    return false
  }
}

const combined = async (m, opts) => {
  if (m.callback) {
    if (/^\/(provpage|kab|kec|desa)\b/.test(String(m.callback))) return callbackHandler(m, opts)
    return false
  }
  return handler(m, opts)
}
combined.command = ["ttnowm", "ttnowm2", "ttaudio", "ttmusic", "ttinfo", "mcserver", "mcstatus", "kurs", "kurs2", "gempa2", "gempadirasakan", "provinsi", "provinsi2"]
module.exports = combined

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
