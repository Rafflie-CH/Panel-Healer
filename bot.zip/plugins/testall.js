/* plugin: testall.js - test semua fitur satu persatu, khusus owner utama.
   DUA MODE (permintaan owner):
   1. LIVE MODE (default): fitur dijalankan dengan bot & chat ASLI — hasilnya
      (teks/gambar/sticker/audio) MUNCUL BENERAN di chat. Ada pacing anti-flood
      (default 350ms) + seed media + pesan reply otomatis supaya syarat fitur
      "terpenuhin sendiri". Jalankan di grup → fitur admin/group ikut teruji.
   2. MOCK MODE (env RAFZ_TESTALL_LIVE=0): seperti dulu — tidak kirim apa-apa.
   Fitur yang melempar error / membalas "❌ gagal" → masuk errorlog, dinotifikasi
   ke owner, dan ditandai ❌ di menu sampai sukses dipakai lagi. */

"use strict"
const path = require("path")
const fs = require("fs")

const handler = async (m, { Rafz, command, text }) => {
  try {
    const sender = String(m.sender)
    const isCreator = (global.owner || []).includes(sender)
    const tr = (key, vars) => (m.t ? m.t(key, vars) : key)
    if (!isCreator) return m.reply(tr("test.creatorOnly"))

    const px = (global.prefix && global.prefix[0]) || "/"
    const bot = Rafz
    const errorLog = require("../library/errorlog")

    /* LIVE MODE: aktif kalau Rafz asli (bisa kirim media) dan tidak dimatikan via env */
    const live = process.env.RAFZ_TESTALL_LIVE !== "0" && typeof Rafz?.sendPhoto === "function"

    const wait = await m.reply((live ? "🛰 " + tr("test.liveMode") + "\n" : "") + tr("test.running"), { parse_mode: "HTML" })

    const editOut = async (t2) => {
      try {
        return await bot.editMessageText(String(t2).slice(0, 4000), {
          chat_id: m.chat, message_id: wait?.message_id, parse_mode: "HTML"
        })
      } catch (e) {
        if (String(e?.message || e).includes("not modified")) return null
        return null
      }
    }

    /* ---------- LIVE BOT WRAPPER: pacing anti-flood untuk semua kirim pesan ---------- */
    const LIVE_PACE = Number(global.featureTestPaceMs) || 350
    let _nextSlot = 0
    const pace = async () => {
      const now = Date.now()
      const d = Math.max(0, _nextSlot - now)
      _nextSlot = Math.max(now, _nextSlot) + LIVE_PACE
      if (d > 0) await new Promise(r => setTimeout(r, d))
    }
    const SEND_METHODS = ["sendMessage", "sendPhoto", "sendAudio", "sendVideo", "sendVoice", "sendDocument", "sendSticker", "sendMediaGroup", "sendPoll", "sendChatAction", "editMessageText", "deleteMessage"]
    const R = {}
    for (const k of Object.keys(Rafz || {})) R[k] = Rafz[k]
    for (const meth of SEND_METHODS) {
      if (typeof Rafz?.[meth] !== "function") continue
      R[meth] = async (...a) => { await pace(); return Rafz[meth](...a) }
    }
    /* DRY MODE: isi stub utk method Telegram yang tidak ada di objek bot yang dipass
       (runner lokal dsb) — supaya hasil test konsisten dgn live mode */
    if (!live) {
      const STUBS = {
        sendMessage: async () => ({ message_id: 1 }), sendPhoto: async () => ({ message_id: 1 }),
        sendAudio: async () => ({ message_id: 1 }), sendVideo: async () => ({ message_id: 1 }),
        sendVoice: async () => ({ message_id: 1 }), sendDocument: async () => ({ message_id: 1 }),
        sendSticker: async () => ({ message_id: 1 }), sendMediaGroup: async () => [{ message_id: 1 }],
        sendPoll: async () => ({ message_id: 1 }), sendChatAction: async () => true,
        editMessageText: async () => ({ message_id: 1 }), deleteMessage: async () => true,
        getMe: async () => ({ id: 1, username: "test_bot", first_name: "Test Bot" }),
        getFile: async () => ({ file_path: "documents/test.jpg" }),
        answerCallbackQuery: async () => true, setMyCommands: async () => true, deleteMyCommands: async () => true,
        getChatMemberCount: async () => 100, restrictChatMember: async () => true,
        promoteChatMember: async () => true, banChatMember: async () => true, unbanChatMember: async () => true,
        pinChatMessage: async () => true, unpinChatMessage: async () => true, unpinAllChatMessages: async () => true,
        getChatMember: async () => ({ status: "member", user: { id: 555, is_bot: false, first_name: "Test", username: "test_user" } }),
        getChatAdministrators: async () => [],
        getChat: async () => ({ id: 12345, type: "private", first_name: "Test" })
      }
      for (const k of Object.keys(STUBS)) if (typeof R[k] !== "function") R[k] = STUBS[k]
    }

    /* ---------- MOCK MESSAGE (live: pass-through ke chat asli) ---------- */
    const mockMsg = (cmd, args, ctx) => {
      const failReplies = [] /* KETAT: tangkap balasan "❌ gagal ..." dari plugin */
      const isLive = !!(ctx && ctx.live)
      const record = (t) => {
        try {
          if (errorLog.isFailReply(t)) failReplies.push(String(t).replace(/<[^>]+>/g, "").trim().slice(0, 160))
        } catch {}
        try { base._lastReplyText = String(t).slice(0, 300) } catch {}
      }
      const base = {
        raw: "/" + cmd + (args.length ? " " + args.join(" ") : ""),
        id: isLive ? (ctx.seedId || 999999) : 999999,
        chat: m.chat,
        sender: sender,
        pushName: m.pushName || "TestAll",
        isGroup: !!m.isGroup,
        text: args.join(" "),
        body: "/" + cmd + (args.length ? " " + args.join(" ") : ""),
        isCmd: true,
        prefix: "/",
        command: cmd,
        args: args,
        thread: null,
        lang: m.lang || "id",
        t: (key) => key,
        setLang: () => false,
        entities: [],
        mentioned: [],
        /* media otomatis terpenuhi: pakai file_id pesan seed (foto) supaya fitur
           "reply foto / kirim foto" ikut keuji tanpa manual upload */
        media: isLive && ctx.fileId ? { type: "photo", fileId: ctx.fileId } : null,
        fileId: isLive && ctx.fileId ? ctx.fileId : null,
        filename: isLive && ctx.fileId ? "testall.jpg" : null,
        mimetype: isLive && ctx.fileId ? "image/jpeg" : null,
        mediaType: isLive && ctx.fileId ? "photo" : null,
        sticker: null,
        /* quoted otomatis: pesan seed foto — fitur yang butuh REPLY pesan ikut jalan */
        quoted: isLive && ctx.quoted ? ctx.quoted : null,
        forward: null,
        callback: null,
        _mockTest: true,
        reply: isLive
          ? async (t, o) => { const res = await R.sendMessage(m.chat, String(t).slice(0, 4000), o || {}); record(t); return res }
          : async (t) => { record(t); return { message_id: 1 } },
        send: isLive
          ? async (t, o) => { const res = await R.sendMessage(m.chat, String(t).slice(0, 4000), o || {}); record(t); return res }
          : async (t) => { record(t); return { message_id: 1 } },
        edit: isLive
          ? async (t, o) => { const res = await R.editMessageText(String(t).slice(0, 4000), Object.assign({ chat_id: m.chat, message_id: base.id }, o || {})); record(t); return res }
          : async (t) => { record(t); return { message_id: 1 } },
        /* react tidak dirender live (hindari spam reaction) */
        react: async () => ({})
      }
      base.failReplies = failReplies
      return base
    }

    /* ---------- SEED MEDIA (live): 1 foto sebagai bahan reply/media-test ---------- */
    const seed = { id: null, fileId: null }
    if (live) {
      try {
        const sent = await Rafz.sendPhoto(m.chat, "https://picsum.photos/seed/testall/800/500.jpg", {
          caption: "🧪 <b>TestAll</b> — media seed. Aman dihapus setelah test selesai.",
          parse_mode: "HTML"
        })
        seed.id = sent?.message_id || null
        const ph = Array.isArray(sent?.photo) ? sent.photo[sent.photo.length - 1] : null
        seed.fileId = ph?.file_id || null
      } catch {}
    }

    /* ---------- kumpulkan semua command dari plugin ---------- */
    const pluginsDir = path.join(__dirname, "..", "plugins")
    const pluginFiles = fs.readdirSync(pluginsDir).filter(f => f.endsWith(".js"))

    let allCommands = []
    const loadErrors = []
    for (const file of pluginFiles) {
      try {
        const p = path.join(pluginsDir, file)
        delete require.cache[require.resolve(p)]
        const mod = require(p)
        /* library internal (notif.js) bukan function — skip, bukan error */
        if (typeof mod !== "function") continue
        if (!Array.isArray(mod.command) || !mod.command.length) continue
        for (const cmd of mod.command) {
          allCommands.push({ cmd, file, handler: mod })
        }
      } catch (e) {
        loadErrors.push({ feature: file, error: e.message, source: "plugin" })
      }
    }

    /* duplikat command → test sekali aja (fallback chain di handler) */
    const seen = new Set()
    allCommands = allCommands.filter(c => {
      if (seen.has(c.cmd)) return false
      seen.add(c.cmd)
      return true
    })

    /* skip command internal yang bukan fitur user */
    /* - ytdl_dl/tt_dl: callback internal
       - testall/testfitur/testfeature: self-test (loop diri sendiri, tidak ada gunanya)
       - play/uploadscript: test-nya memicu download file besar/upload jaringan */
    /* ytdl/tt/tiktok butuh link YouTube/TikTok valid — diuji manual (API download berat);
       kbbi/kamus API eksternal lambat → skip biar tidak false-positive */
    const SKIP = new Set(["ytdl_dl", "tt_dl", "cpanel_server", "testall", "testfitur", "testfeature", "play", "uploadscript", "upl", "kbbi", "kamus", "ytdl", "tt", "tiktok"])
    /* shortcut panel cpanel (1gb..10gb/unli + varian server v2): membuat panel NYATA
       di Pterodactyl — tidak boleh di-auto-test */
    try {
      for (let i = 1; i <= 10; i++) { SKIP.add(i + "gb"); SKIP.add(i + "gbv2") }
      SKIP.add("unli"); SKIP.add("unliv2"); SKIP.add("unlimited"); SKIP.add("unlimitedv2")
    } catch {}
    /* cmd berbahaya saat LIVE (efek nyata di luar grup uji): broadcast massal,
       reset/restart bot, keluar grup, kick diri, hapus fed/log */
    const LIVE_SKIP = new Set(["broadcast", "bc", "reset", "restart", "reboot", "leave", "out", "kickme", "delfed", "errorclear", "errordelete", "panelstat", "mypanel"])
    /* cmd yang MENULIS file (AI rewrite plugin/case, add plugin dari teks) —
       JANGAN pernah auto-test: bahaya corrupt source saat test */
    const WRITE_CMDS = new Set(["errorfix", "errorai", "addfitur", "addfeature"])

    /* QUERY NYATA per command — bukan cuma "test" (request owner):
       fitur pencarian/download diuji dengan argumen yang masuk akal supaya
       API-nya benar-benar dieksekusi, bukan cuma menu pesan usage. */
    const QUERY_MAP = {
      yts: ["luka"], ytsearch: ["luka"],
      google: ["cuaca jakarta"], gsearch: ["cuaca jakarta"],
      weather: ["jakarta"], cuaca: ["jakarta"],
      wiki: ["Indonesia"], wikipedia: ["Indonesia"],
      lirik: ["luka"], lyrics: ["luka"], chord: ["luka"],
      pinterest: ["anime"], pin: ["anime"], wallpaper2: ["anime"], wpsearch: ["anime"],
      githubstalk: ["octocat"], github: ["octocat"], npmstalk: ["express"], npm: ["express"],
      igstalk: ["instagram"], tiktokstalk: ["tiktok"], ytstalk: ["mrbeast"],
      ffstalk: ["946716486"], robloxstalk: ["roblox"], discordstalk: ["123456789012345678"],
      gempa: [], gempabumi: [],
      gsmarena: ["samsung a54"], hp: ["samsung a54"],
      define: ["hello"], time: ["jakarta"],
      ip: ["8.8.8.8"], short: ["https://google.com"],
      qr: ["hello bot"], calc: ["12*(3+4)"], kalkulator: ["12*(3+4)"],
      tr: ["en hello world"], translate: ["en hello world"],
      b64: ["enc hello"], hash: ["sha256 hello"],
      tts: ["en hello"], pass: ["16"], password: ["16"],
      alquran: ["1"], murotal: ["1"], kisahnabi: ["muhammad"],
      jadwalsholat: ["jakarta"], artimimpi: ["ular"], zodiak: ["scorpio"], shio: ["naga"],
      weton: [], artinama: ["dika"], ramalanjodoh: ["dika|rina"],
      style: ["hello"], styletext: ["hello"],
      say: ["hello bot"], getpp: ["me"], getid: [], uptime: [], ping: [],
      "8ball": ["will I win?"], rate: ["pizza"], love: ["dika|rina"],
      pick: ["a, b, c"], apakah: ["boleh"], bisakah: ["bisa"], kapankah: ["nanti"],
      cekkodam: [], cekjodoh: [], cekwibu: [],
      artitarot: [], fakta: [], puisi: [], bijak: [], gombalan: [], motivasi: [],
      cerpen: [], kepo: [], arahrezeki: [], bucin: [], quote: [], quotes: [],
      dice: [], coin: [], roll: [], slot: [], suit: [], dare: [], truth: [],
      wp: ["jakarta"], ss: ["https://google.com"],
      ttt: ["bot"], tebakangka: ["50"],
      mediafire: ["https://www.mediafire.com/file/mbalm9wv3q0pdkb/test.txt/file"],
      gitclone: ["https://github.com/octocat/Hello-World.git"],
      spotify: ["https://open.spotify.com/track/4cOdK2wGLETKBW3PvgPWqT"],
      /* fitur porting WA (downloader3 / stalk2) */
      ttsearch: ["luka"], searchtiktok: ["luka"], ttsr: ["luka"],
      scs: ["luka"], scsearch: ["luka"],
      ssearch: ["luka"], spotifysearch: ["laskar pelangi"],
      pinstalk: ["instagram"], pintereststalk: ["instagram"],
      pindl: ["https://id.pinterest.com/pin/1970393889917044/"], pinterestdl: ["https://id.pinterest.com/pin/1970393889917044/"],
      sfile: ["apk"], sfilematis: ["apk"],
      gdrive: ["template"], gdrivesearch: ["template"],
      apkmod: ["whatsapp"], happymod: ["whatsapp"],
      aiodl: ["https://vt.tiktok.com/ZSabc123/"], alldl: ["https://vt.tiktok.com/ZSabc123/"],
      npmsearch: ["chalk"], carinpm: ["chalk"],
      npmstalk2: ["chalk"], npmpkg: ["chalk"],
      robloxstalk2: ["roblox"], rbxstalk2: ["roblox"],
      threadsstalk: ["instagram"], threadstalk: ["instagram"],
      xstalk: ["elonmusk"], twitterstalk2: ["elonmusk"],
      modrinth: ["sodium"], modrinthsearch: ["sodium"],
      fontlist: ["graffiti"], dafont: ["graffiti"],
      apkmirror: ["whatsapp"], apkpure: ["whatsapp"],
      /* fitur porting WA batch-4 */
      murotal: ["1"], surah: ["1"], surat: ["1"], ayat: ["2:255"],
      jadwalsholat: ["jakarta"], sholat: ["jakarta"], sholat2: ["jakarta"],
      kiblat: [], qibla: [], hijri: [], hijriah: [], kalender: [],
      doa: ["1"], doaharian2: ["makan"], tahlil: [], tahlil2: [], doatahlil: [], asmaulhusna2: [],
      kurs: ["USD"], kurs2: ["USD"], gempa2: [], gempadirasakan: [],
      mcserver: ["mc.hypixel.net"], mcstatus: ["mc.hypixel.net"],
      provinsi: [], provinsi2: [],
      ttnowm: ["https://vt.tiktok.com/ZSabc123/"], ttnowm2: ["https://vt.tiktok.com/ZSabc123/"],
      ttaudio: ["https://vt.tiktok.com/ZSabc123/"], ttmusic: ["https://vt.tiktok.com/ZSabc123/"],
      ttinfo: ["https://vt.tiktok.com/ZSabc123/"],
      caklontong: [], tebakkalimat: [], tebakkabupaten: [], tebakkimia: [], tebaklirik: [], tebakbendera2: [],
      soal3: [], skipquiz2: [],
      pantun: [], renungan: [], katacinta: [], gombal2: [], bucin2: [], motivasi2: [], bijak2: [], fakta2: [],
      wangy: ["dika"], siapa: [], kapan: [], dimana: [],
      ramalannasib: ["14 2 2000"], ramalnasib: ["14 2 2000"], sifatusaha: ["14 2 2000"],
      rejekihoki: ["14 2 2000"], pekerjaanweton: ["14 2 2000"], potensipenyakit: ["14 2 2000"],
      kartutarot: ["14 2 2000"], tanggaljadian: ["14 2 2000"], ramalannasibbali: ["14 2 2000"],
      fengshui: ["budi l 2000"], sifatkarakter: ["budi 14 2 2000"], potensikeberuntungan: ["budi 14 2 2000"],
      haribaik2: ["14 2 2000"], harisangar: ["14 2 2000"], harinaas: ["14 2 2000"], nagahari: ["14 2 2000"],
      arahrejeki2: ["14 2 2000"], ramalanperuntungan: ["14 2 2000"], masasubur: ["14 2 2000 28"],
      zodiakcek: ["aquarius"], shiocek: ["naga"], nomorhoki: ["6281234567890"], wetonjawa2: ["14 2 2000"],
      memancingikan: ["14 2 2000"], cocoknama: ["budi 14 2 2000"],
      neko: [], neko2: [], waifu: [], waifu2: [], avatar: [], avatar2: [], wallpaper3: [], wallpaper4: [],
      foxgirl: [], woof: [], meow: [], hug2: [], pat2: [], kiss3: [], cuddle2: [], feed2: [], slap2: [],
      tickle: [], smug2: [], goose: [], lizard: [], gecg: [],
      /* ROSE + BARKER + SHIELD (batch-5) */
      connect: [], disconnect: [], connection: [], connections: [], reconnect: [],
      ban: [], dban: [], sban: [], tban: [], unban: [],
      mute: [], dmute: [], smute: [], tmute: [], unmute: [],
      kick: [], dkick: [], skick: [],
      setwarnlimit: ["3"], setwarnmode: ["mute"], warnings: [], warnsettings: [],
      purge: [], spurge: [], del: [], delete2: [],
      unpinall: [], permapin: ["tes pinned"], pinned: [], report2: [], rreport: [],
      resetgroup: [],
      lock: ["gif"], unlock: ["gif"], locks: [], locktypes: [], lockwarns: ["on"],
      allowlist: [], rmallowlist: ["x"],
      addblocklist: ["spam Jangan spam {tmute 1m}"], blocklistadd: ["scam Penipuan"],
      blocklist: [], blocklistlist: [], rmblocklist: ["spam"], rmblocklistall: [], blocklistmode: ["mute"],
      setflood: ["5"], setfloodtimer: ["5 10s"], setfloodmode: ["tmute 1h"], flood: [],
      antiraid: ["on"], raidtime: ["3h"], autoantiraid: ["10"],
      captcha: [], captchamode: ["math"], captchakick: ["on"],
      welcome: [], goodbye: [], setwelcome: ["Halo {mention}!"], setgoodbye: ["Bye {fullname}"],
      resetwelcome: [], resetgoodbye: [], welcomehelp: [], welcomemute: ["on"],
      filter: ["halo Halo juga!"], filteradd: ["pagi Pagi!"], stop: ["halo"], stopfilter: ["halo"],
      stopall: [], filters: [], filterlist: [],
      save: ["faq Baca rules dulu"], savenote: ["faq Baca rules"], get: ["faq"], getnote: ["faq"],
      notes: [], notelist: [], clear: ["faq"], clearnote: ["faq"], clearall: [],
      disable: ["welcome2"], enable: ["welcome2"], disabled: [],
      newfed: ["TestFed"], delfed: [], joinfed: ["FABCDEF"], leavefed: [], fedinfo: [], chatfed: [],
      fban: [], unfban: ["123456"], fedpromote: [],
      status: [], shieldstatus: [], antispam_mode: ["strict"], reportspam: [], kickbot: [], checknsfw: [],
      nolinks: [], noforwards: [], nolocations: [], nocontacts: [], nocommands: [],
      nohashtags: [], novoice: [], noevents: [], nobots: [], antispam: [], profanity: [], imagefilter: [],
      blacklist: [], shieldbl: [], blacklist_add: ["spam, scam"], shieldbladd: ["crypto"],
      blacklist_remove: ["spam"], shieldblrm: ["spam"], blacklist_clear: [], shieldblclear: [],
      whitelist: [], shieldwl: [], whitelist_add: ["mychannel"], shieldwladd: ["x"],
      whitelist_remove: ["x"], shieldwlrm: ["x"], whitelist_clear: [], shieldwlclear: [],
      warningbans: [], warningbans_reset: [],
      all: [], callall: [], tagall2: [], callone: ["5"], calladmins: [],
      setme: ["\ud83d\ude80Rafz"], changeme: ["\ud83d\ude80"], me: [], mycallsign: [], bigme: [],
      unreg: [], reg: [], upatterns: [], cpatterns: [],
      /* batch-5 roseextra + roseprotect */
      id: [], info: [], setrules: ["No spam"], clearrules: [], privacy: [],
      promote: [], demote: [], admincache: [], adminerror: ["on"], anonadmin: ["off"],
      mutegc: [], unmutegc: [], grouplink: [], invitelink: [],
      logcategories: [], log: ["admin"], nolog: ["other"], setlog: ["-1001234"], unsetlog: [],
      silentactions: ["on"], disableable: [], disabledel: ["off"], disableadmin: ["off"],
      cleancommand: ["user"], keepcommand: [], cleancommandtypes: [],
      renamefed: ["FedBaru"], myfeds: [], fedadmins: [], feddemote: [], fedstat: [], fedsubs: [],
      bot2bot: ["admin"], bot2botskipreview: ["on"],
      export: [], import: [],
      afk: ["kerja dulu"], unafk: [],
      gif: ["cat"], ud: ["bot"], ping: [], markdownhelp: [],
      setcaptchatext: ["Solve me"], resetcaptchatext: [], captcharules: [], captchamutetime: ["10m"], clearflood: ["on"],
      dwarn: [], swarn: [], kickme: [],
      myid: [], userinfo: [], adminpromote: [], warnlimit: [], delwarn: [],
      gifsearch: ["dog"], urban: ["roof"], addhelperbot: [],
      admins: [], adminlist: [], rules: [], unpin: [], report: [], admins2: [], antiflood: ["on"],
      /* batch-6: siputzx6 + webx + port5 (artinama/ramalanjodoh/potensipenyakit/
         rejekihoki/sifatusaha sudah ada di batch-4 — jangan duplikat key) */
      tafsirmimpi: ["ular"], kecocokanpasangan: ["dika|sari"], ramalanjodohbali: ["dika|sari"],
      haribaik: ["14 2 2000"], wetonjawa: ["14 2 2000"], arahrejeki: ["14 2 2000"],
      pinterest2: ["kucing"], duckduckgo2: ["news"], brave: ["bot"],
      applemusic: ["test"],
      beritakompas: [], beritacnn: [], beritatribun: [], beritaliputan6: [],
      beritaantara: [], beritamerdeka: [], beritasuara: [], beritasindonews: [], beritacnbc: [],
      kodepos: ["bogor"], countryinfo: ["indonesia"],
      tekateki2: [], tebakkalimat2: [], caklontong2: [], susunkata2: [], asahotak2: [],
      tebakbendera2: [], tebakgame: [], tebakwarna: [],
      tebaklogo: [], siapakahaku2: [], lengkapikalimat: [], tebakjkt: [],
      genius: ["laskar pelangi"], deezer: ["laskar pelangi"], archive: ["linux"],
      wayback: ["https://example.com"],
      tweet: ["https://x.com/elonmusk/status/1816974609637417112"], tweetinfo: ["https://x.com/elonmusk/status/1816974609637417112"],
      tempmail: [], tempmailcheck: [],
      cekff: ["946716486"], githubstalk: ["torvalds"], ghstalk: ["torvalds"],
      ipinfo: ["8.8.8.8"],
      npm2: ["axios"], tarot: [], sambungkata: [],
      searchfit: ["sticker"], cariFitur: [],
      /* cmd baru pasca-audit spec */
      language: [], lang: [], cleanwelcome: ["on"], privatenotes: ["off"],
      blocklistdelete: ["on"], raidactiontime: ["1h"], purgefrom: [], purgeto: [],
      ttp2: ["Halo Bot"], attp2: ["Rafz Keren"], captchakicktime: ["5m"]
    }
    /* textmaker3 fx specs: jumlah teks per efek (diexport plugin sbg fxTextCount) */
    let FX_TEXT = {}
    try { FX_TEXT = require("./textmaker3.js").fxTextCount || {} } catch { }
    const argsFor = (cmd) => {
      if (QUERY_MAP[cmd]) return QUERY_MAP[cmd]
      if (FX_TEXT[cmd] != null) {
        /* t=0 = photo-frame (butuh foto, bukan teks) → biarkan default */
        if (FX_TEXT[cmd] === 0) return ["test"]
        return Array.from({ length: FX_TEXT[cmd] }, (_, i) => "teks" + (i + 1))
      }
      /* default: "test" — cukup buat fitur non-query berjalan */
      return ["test"]
    }

    /* REPLY yang BUKAN error (dihitung skip, permintaan owner):
       - usage/needMore (argumen kurang di environment test — group-only, reply-only)
       - state yang memang belum ada (sesi clone/OTP/game aktif)
       - akses yang tidak bisa diuji di PM (botAdmin/noFed) */
    const SKIP_REPLY_RE = /tm3\.need(?:More|Text|Photo)|rose\.groupOnly|rose\.noFed|rose\.noFedChat|rose\.needChatId|rose\.need\w+|rose\.alreadyHave\w+|rose\.importHint|rose\.botAdmin|rose\.replyMsg|rose\.adminOnly|No active game|Tidak ada game aktif|No ada sesi clone|Tidak ada sesi clone|No ada registrasi aktif|Tidak ada registrasi aktif|addhelper (?:&lt;|<)bot_token(?:&gt;|>)|diblokir Cloudflare|rate limited|Too Many Requests/
    /* API eksternal yang ME-APLIKASI rate-limit keras (429) saat sering ditest —
       bukan error fitur (API-nya hidup, diverifikasi via curl) */
    const RATELIMIT_OK = new Set(["wayback", "archive", "archiveorg"])

    /* cmd pelapor error (geterror/errorlist/dll) LEGITIMAT menampilkan "❌" di output —
       jangan dianggap gagal hanya karena laporannya berisi baris ❌ */
    const REPORT_CMDS = new Set(["geterror", "geterrors", "errorlist", "errorfix", "errorai", "errorai2", "errorclear", "errordelete", "errorcode", "errorraw", "testcmd"])

    let tested = 0, ok = 0, notHandled = 0, fail = 0, skipped = 0
    const errors = [...loadErrors]
    const failedList = []
    const skippedList = []
    const TEST_TIMEOUT = Number(global.featureTestTimeoutMs) || (live ? 45000 : 35000)
    const started = Date.now()

    for (const item of allCommands) {
      if (SKIP.has(item.cmd)) continue
      if (live && LIVE_SKIP.has(item.cmd)) { skipped++; if (!skippedList.includes(item.cmd)) skippedList.push(item.cmd); continue }
      if (WRITE_CMDS.has(item.cmd)) { skipped++; if (!skippedList.includes(item.cmd)) skippedList.push(item.cmd); continue }
      tested++
      const tArgs = argsFor(item.cmd)
      const tText = tArgs.join(" ")
      /* progress tiap 25 fitur (live run lama — biar owner lihat kemajuan) */
      if (tested % 25 === 0) await editOut("🧪 " + tr("test.running") + "\n\n" + (live ? "🛰 " + tr("test.liveMode") + "\n" : "") + "⏳ " + tested + "…")
      const ctx = { live, fileId: live ? seed.fileId : null, seedId: live ? seed.id : null, quoted: live && seed.id ? { id: seed.id, chat: m.chat, sender: sender, text: "halo testall", fileId: seed.fileId, pushName: "TestAllSeed" } : null }
      try {
        const mm = mockMsg(item.cmd, tArgs, ctx)
        /* panggil handler asli dengan bot ASLI (live) / mock (dry); timeout guard per fitur
           (live 45s / dry 35s default, bisa diatur global.featureTestTimeoutMs di settings.js) */
        const res = await Promise.race([
          item.handler(mm, { conn: { sendMessage: R.sendMessage }, Rafz: R, args: tArgs, text: tText, command: item.cmd, prefix: "/" }),
          new Promise((_, rej) => setTimeout(() => rej(new Error("timeout " + Math.round(TEST_TIMEOUT / 1000) + "s")), TEST_TIMEOUT))
        ])
        /* KETAT (permintaan owner, batch-4):
           1. Reply "❌ gagal ..." apa pun bentuknya = ERROR
           2. Reply yang CUMA berisi usage/contoh padahal query nyata diberikan = ERROR tersembunyi
              (fitur seharusnya mengeksekusi, bukan balik bertanya)
           3. Exception = ERROR (sudah)
           4. Success tanpa reply apa pun ke user = dicatat (rawan tidak menghasilkan apa-apa) */
        if (mm.failReplies && mm.failReplies.length) {
          const firstReply = mm.failReplies[0]
          if (REPORT_CMDS.has(item.cmd)) {
            /* laporan error memang berisi ❌ — hitung OK */
            ok++
          } else if (SKIP_REPLY_RE.test(firstReply)) {
            /* usage/state/group-only → EXPECTED, bukan error (permintaan owner) */
            skipped++
            if (!skippedList.includes(item.cmd)) skippedList.push(item.cmd)
          } else if (RATELIMIT_OK.has(item.cmd) && /rate limited|Too Many Requests|429/i.test(firstReply)) {
            /* rate-limit eksternal → bukan error fitur */
            skipped++
            if (!skippedList.includes(item.cmd)) skippedList.push(item.cmd)
          } else {
            fail++
            const em = firstReply.slice(0, 120)
            errors.push({ feature: item.cmd, error: em, source: item.file })
            if (!failedList.includes(item.cmd)) failedList.push(item.cmd)
          }
        } else if (res === false || res === undefined || res === null) {
          notHandled++
        } else {
          /* deteksi usage-masked-failure: handler return true tapi balasannya cuma
             "⚠️ teksnya mana? / usage / contoh" — padahal QUERY_MAP sudah kasih argumen nyata */
          const replies = (mm.failReplies || []).concat(mm.usageReplies || [])
          if (mm._lastReplyText) replies.push(mm._lastReplyText)
          const joined = replies.join(" ")
          const usageOnly = /teksnya mana|where is the text|usage format|cara pakai|contoh penggunaan|butuh \d+ teks|needs \d+ texts|butuh nama|name required|butuh (?:link|url|kata|query|teks|text)|(?:link|url|query|text) (?:is )?required|reply (?:foto|photo) dulu|send\/[reply] a photo/i.test(joined)
          if (usageOnly && QUERY_MAP[item.cmd]) {
            fail++
            const em = "usage-masked-fail: " + joined.replace(/<[^>]+>/g, "").slice(0, 100)
            errors.push({ feature: item.cmd, error: em, source: item.file })
            if (!failedList.includes(item.cmd)) failedList.push(item.cmd)
          } else {
            ok++
          }
        }
      } catch (e) {
        const em = String(e?.message || e).slice(0, 120)
        if (/timeout/.test(em) === false && SKIP_REPLY_RE.test(em)) { skipped++; if (!skippedList.includes(item.cmd)) skippedList.push(item.cmd); continue }
        if (RATELIMIT_OK.has(item.cmd) && /429|Too Many Requests/i.test(em)) { skipped++; if (!skippedList.includes(item.cmd)) skippedList.push(item.cmd); continue }
        fail++
        /* simpan OBJEK error agar errorlog ekstrak file:baris:kode (AI-ready) */
        errors.push({ feature: item.cmd, error: em, source: item.file, errObj: e })
        if (!failedList.includes(item.cmd)) failedList.push(item.cmd)
      }
    }

    /* catat error ke errorlog (fitur error → dinotif ke owner + tanda ❌ menu)
       errObj (objek Error asli) dipakai bila ada → file:baris:kode terekstrak */
    for (const err of errors) {
      try { errorLog.logError(err.feature, err.errObj || err.error, err.source) } catch {}
    }
    /* fitur yang lulus test → hapus dari daftar error */
    const failedSet = new Set(failedList)
    for (const item of allCommands) {
      if (!failedSet.has(item.cmd)) {
        try { errorLog.removeError(item.cmd) } catch {}
      }
    }

    const durS = Math.round((Date.now() - started) / 1000)
    const durTxt = durS >= 60 ? Math.floor(durS / 60) + "m " + (durS % 60) + "s" : durS + "s"
    let report = "<b>🧪 " + tr("test.report") + "</b>" + (live ? " 🛰" : "") + "\n"
    report += "⏱ " + durTxt + "\n\n"
    report += "📦 " + tr("test.total") + ": <b>" + tested + "</b>\n"
    report += "✅ " + tr("test.okCount") + ": <b>" + ok + "</b>\n"
    report += "➖ " + tr("test.notHandled") + ": <b>" + notHandled + "</b>\n"
    report += "⏭ " + tr("test.skipCount") + ": <b>" + skipped + "</b>\n"
    report += "❌ " + tr("test.errorCount") + ": <b>" + fail + "</b>\n\n"

    if (fail > 0) {
      report += "<b>" + tr("test.errorList") + ":</b>\n"
      for (const cmd of failedSet) {
        const err = errors.find(e => e.feature === cmd)
        report += "❌ <code>" + cmd + "</code>: " + (err ? err.error.slice(0, 80) : "?") + "\n"
      }
      if (failedSet.size > 60) report += "... " + tr("test.moreErrors", { n: failedSet.size - 60 }) + "\n"
      report += "\n💡 " + tr("test.checkHint", { px: px })
    }
    if (skippedList.length) {
      report += "\n⏭ <b>" + tr("test.skipList") + ":</b> " + skippedList.slice(0, 40).map(c => "<code>" + c + "</code>").join(", ")
      if (skippedList.length > 40) report += " +" + (skippedList.length - 40)
      report += "\n"
    }
    /* di PM: fitur group-only tidak teruji — beri tahu owner (permintaan:
       "otomatis handled kalau /testall di gc") */
    if (!m.isGroup && skipped > 0) {
      report += "\n💡 " + tr("test.groupTip")
    }
    if (fail === 0 && errors.length === 0) {
      report += "\n🎉 " + tr("test.allOk")
    }

    await editOut(report)
    return m.reply(report, { parse_mode: "HTML" })
  } catch (e) {
    console.error("[testall]", e?.message)
    try { await m.reply("Error: " + (e?.message || e)) } catch {}
    return false
  }
}

handler.command = ["testall", "testfitur", "testfeature"]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
