"use strict"
const https = require("https")
const http = require("http")

const httpPost = (url, body, hdrs = {}) =>
  new Promise((resolve, reject) => {
    try {
      const parsed = new URL(url)
      const data = typeof body === "string" ? body : JSON.stringify(body)
      const mod = parsed.protocol === "https:" ? https : http
      const req = mod.request({
        hostname: parsed.hostname,
        path: parsed.pathname + parsed.search,
        method: "POST",
        headers: { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(data), "User-Agent": "Mozilla/5.0", ...hdrs },
        timeout: 60000
      }, (res) => {
        let d = ""
        res.on("data", c => d += c)
        res.on("end", () => { try { resolve(JSON.parse(d)) } catch { resolve({ raw: d }) } })
      })
      req.on("error", reject)
      req.on("timeout", () => { req.destroy(); reject(new Error("Timeout")) })
      req.write(data)
      req.end()
    } catch (e) { reject(e) }
  })

const getJSON = (url) =>
  new Promise((resolve, reject) => {
    try {
      const parsed = new URL(url)
      https.get({ hostname: parsed.hostname, path: parsed.pathname + parsed.search, timeout: 30000, headers: { "User-Agent": "Mozilla/5.0", "Accept": "application/json" } }, (res) => {
        let d = ""
        res.on("data", c => d += c)
        res.on("end", () => { try { resolve(JSON.parse(d)) } catch { resolve(null) } })
      }).on("error", reject).on("timeout", function () { this.destroy(); reject(new Error("Timeout")) })
    } catch (e) { reject(e) }
  })

const AI_HISTORY = {}

const handler = async (m, { Rafz, command, text }) => {
  try {
    const px = (global.prefix && global.prefix[0]) || "/"
    const q = (text || "").trim()
    const sender = String(m.sender)
    const AI_CMDS = ["ai", "gpt", "openai", "chatgpt", "gpt4", "deepseek", "claude", "blackbox", "llama", "mistral", "copilot", "chatbot", "publicai"]

    if (!AI_CMDS.includes(command)) return false
    if (!q) return m.reply("Penggunaan: " + px + command + " pertanyaan kamu")

    const wait = await m.reply("AI sedang berpikir...")
    const editOut = async (t2) => {
      try { await Rafz.editMessageText(String(t2).slice(0, 4000), { chat_id: m.chat, message_id: wait.message_id, parse_mode: "HTML" }) } catch {
        try { await m.reply(String(t2).slice(0, 4000)) } catch {}
      }
    }

    try {
      // Primary:免费的 AI API
      const brain = await httpPost("https://api.siputzx.my.id/api/ai/gpt3", { content: q })
      if (brain && brain.status && brain.data) {
        return editOut("AI (" + command + "):\n\n" + String(brain.data).slice(0, 3500))
      }
      const lz = await getJSON("https://api.siputzx.my.id/api/ai/luminai?q=" + encodeURIComponent(q))
      if (lz && lz.status && lz.data) {
        return editOut("AI (" + command + "):\n\n" + String(lz.data).slice(0, 3500))
      }
      throw new Error("AI tidak merespon")
    } catch (e) {
      return editOut("AI error: " + e.message + "\n\nCoba lagi nanti.")
    }
  } catch (e) {
    console.error("[aichat]", e?.message)
    try { await m.reply("Error: " + (e?.message || e)) } catch {}
    return false
  }
}

handler.command = ["ai", "gpt", "openai", "chatgpt", "gpt4", "deepseek", "claude", "blackbox", "llama", "mistral", "copilot", "chatbot", "publicai"]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
