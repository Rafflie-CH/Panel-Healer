/* plugin: fitur.js - /addfitur /delfitur /ambilfitur /listfitur */
"use strict"
const fss = require("fs")
const path = require("path")

const PLUGINS_DIR = path.join(__dirname, "..", "plugins")
const CASE_PATH = path.join(__dirname, "..", "case.js")

const handler = async (m, { Rafz, command, text }) => {
  try {
    const sender = String(m.sender)
    const isCreator = (global.owner || []).includes(sender)
    if (!isCreator) return m.reply("Hanya Creator yang bisa manage fitur.")

    const px = (global.prefix && global.prefix[0]) || "/"

    if (command === "listfitur" || command === "fiturlist") {
      const plugins = fss.readdirSync(PLUGINS_DIR).filter(f => f.endsWith(".js"))
      let out = "<b>DAFTAR FITUR (Plugins)</b>\n\n"
      for (const p of plugins) {
        try {
          delete require.cache[require.resolve(path.join(PLUGINS_DIR, p))]
          const mod = require(path.join(PLUGINS_DIR, p))
          const cmds = (mod.command || []).join(", ")
          out += p + ": <code>" + (cmds || "no commands") + "</code>\n"
        } catch (e) {
          out += p + ": ERROR - " + e.message.slice(0, 50) + "\n"
        }
      }
      return m.reply(out, { parse_mode: "HTML" })
    }

    if (command === "delfitur" || command === "delfeature") {
      if (!text) return m.reply("Penggunaan: " + px + "delfitur namafile.js")
      const fname = text.endsWith(".js") ? text : text + ".js"
      const fpath = path.join(PLUGINS_DIR, fname)
      if (!fss.existsSync(fpath)) return m.reply("File " + fname + " tidak ditemukan.")
      try {
        fss.unlinkSync(fpath)
        return m.reply("Fitur " + fname + " dihapus.")
      } catch (e) { return m.reply("Gagal hapus: " + e.message) }
    }

    if (command === "addfitur" || command === "addfeature") {
      if (!text) return m.reply(
        "Penggunaan:\n" +
        px + "addfitur namafile.js|kode\n\n" +
        "Atau reply pesan yang berisi kode JS, lalu ketik " + px + "addfitur namafile.js"
      )
      const parts = text.split("|")
      const fname = (parts[0] || "").trim()
      const code = parts.slice(1).join("|")
      if (!fname) return m.reply("Nama file harus diisi.")

      const finalName = fname.endsWith(".js") ? fname : fname + ".js"
      const fpath = path.join(PLUGINS_DIR, finalName)

      let codeContent = code
      if (!codeContent && m.quoted?.text) codeContent = m.quoted.text
      if (!codeContent) return m.reply("Kode kosong. Reply pesan berisi kode atau ketik setelah |")

      try {
        fss.writeFileSync(fpath, codeContent)
        return m.reply("Fitur " + finalName + " ditambahkan.")
      } catch (e) { return m.reply("Gagal tulis: " + e.message) }
    }

    if (command === "ambilfitur" || command === "getfitur" || command === "getfeature") {
      if (!text) return m.reply("Penggunaan: " + px + "ambilfitur namafile.js")
      const fname = text.endsWith(".js") ? text : text + ".js"
      const fpath = path.join(PLUGINS_DIR, fname)
      if (!fss.existsSync(fpath)) return m.reply("File " + fname + " tidak ditemukan.")
      try {
        const code = fss.readFileSync(fpath, "utf8")
        if (code.length > 4000) return m.reply("File terlalu besar (" + code.length + " chars). Ketik " + px + "ambilfitur " + fname + " untuk melihat potongan.")
        return m.reply("<code>" + code.replace(/</g, "&lt;").replace(/>/g, "&gt;") + "</code>", { parse_mode: "HTML" })
      } catch (e) { return m.reply("Gagal baca: " + e.message) }
    }

    if (command === "getcase") {
      if (!text) return m.reply("Penggunaan: " + px + "getcase nama_command")
      try {
        const caseContent = fss.readFileSync(CASE_PATH, "utf8")
        const regex = new RegExp('case\\s+"' + text + '"[\\s\\S]*?break', "i")
        const match = caseContent.match(regex)
        if (!match) return m.reply("Case " + text + " tidak ditemukan.")
        const code = match[0]
        if (code.length > 4000) return m.reply("Case terlalu besar (" + code.length + " chars).")
        return m.reply("<code>" + code.replace(/</g, "&lt;").replace(/>/g, "&gt;") + "</code>", { parse_mode: "HTML" })
      } catch (e) { return m.reply("Gagal: " + e.message) }
    }

    return false
  } catch (e) {
    console.error("[fitur]", e?.message)
    try { await m.reply("Error: " + (e?.message || e)) } catch {}
    return false
  }
}

handler.command = ["listfitur", "fiturlist", "delfitur", "delfeature", "addfitur", "addfeature", "ambilfitur", "getfitur", "getfeature", "getcase"]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
