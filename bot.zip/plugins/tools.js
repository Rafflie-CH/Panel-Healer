// plugin: tools.js — yts, ytdl, play, tt, info (+ helper download)
// scraper: ssyoutube.online (primary) + savetube + y2mate fallback
// /brat & /bratpack pindah ke plugins/sticker.js (berbentuk pack)

"use strict"
const fs = require("fs")
const path = require("path")
const https = require("https")
const http = require("http")
const { createDecipheriv } = require("crypto")

/* yt-search npm (fallback utama bila innertube diblokir IP/datacenter) */
let _ytSearch = null
const ytSearchFn = async (query) => {
  if (!_ytSearch) {
    try { _ytSearch = require("yt-search") } catch { _ytSearch = false }
  }
  if (!_ytSearch) return []
  const r = await _ytSearch(String(query || ""))
  return (r?.videos || []).map(v => ({
    id: v.videoId,
    title: v.title || "No Title",
    channel: v.author?.name || "Unknown",
    views: v.views ? String(v.views) : "",
    duration: v.timestamp || v.duration?.toString() || "",
    publishedTime: v.ago || "",
    url: v.url,
    videoId: v.videoId
  }))
}

/* master search: innertube dulu → yt-search fallback */
const searchYoutubeSafe = async (query) => {
  try {
    const r = await searchYoutube(query)
    if (r && r.length) return r
  } catch (e) { console.log("[yts] innertube fail:", e.message) }
  return ytSearchFn(query)
}

/* ═══════════════════════════════════════════
   HTTP HELPERS
═══════════════════════════════════════════ */

const UA_MOBILE = "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/139.0.0.0 Mobile Safari/537.36"
const UA_DESK   = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/125.0 Safari/537.36"

const getBuffer = (url, hdrs = {}) =>
  new Promise((resolve, reject) => {
    try {
      const follow = (u) => {
        const mod = u.startsWith("https") ? https : http
        const parsed = new URL(u)
        mod.get({
          hostname: parsed.hostname,
          path: parsed.pathname + parsed.search,
          timeout: 90000,
          headers: { "User-Agent": UA_MOBILE, ...hdrs }
        }, (res) => {
          if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location)
            return follow(new URL(res.headers.location, u).href)
          if (res.statusCode !== 200)
            return reject(new Error(`HTTP ${res.statusCode}`))
          const c = []
          res.on("data", d => c.push(d))
          res.on("end", () => resolve(Buffer.concat(c)))
          res.on("error", reject)
        }).on("error", reject).on("timeout", function() { this.destroy(); reject(new Error("Timeout")) })
      }
      follow(url)
    } catch(e) { reject(e) }
  })

const httpPost = (url, body, hdrs = {}, isForm = false) =>
  new Promise((resolve, reject) => {
    try {
      const parsed = new URL(url)
      const bodyStr = isForm
        ? (typeof body === "string" ? body : new URLSearchParams(body).toString())
        : (typeof body === "string" ? body : JSON.stringify(body))
      const mod = parsed.protocol === "https:" ? https : http
      const req = mod.request({
        hostname: parsed.hostname,
        path: parsed.pathname + parsed.search,
        method: "POST",
        timeout: 30000,
        headers: {
          "Content-Type": isForm ? "application/x-www-form-urlencoded" : "application/json",
          "Content-Length": Buffer.byteLength(bodyStr),
          "User-Agent": UA_MOBILE,
          ...hdrs
        }
      }, (res) => {
        let d = ""
        res.on("data", c => d += c)
        res.on("end", () => {
          try { resolve({ status: res.statusCode, body: JSON.parse(d), headers: res.headers }) }
          catch { resolve({ status: res.statusCode, body: d, headers: res.headers }) }
        })
      })
      req.on("error", reject)
      req.on("timeout", () => { req.destroy(); reject(new Error("Timeout")) })
      req.write(bodyStr)
      req.end()
    } catch(e) { reject(e) }
  })

const httpGet = (url, hdrs = {}) =>
  new Promise((resolve, reject) => {
    try {
      const parsed = new URL(url)
      const mod = parsed.protocol === "https:" ? https : http
      mod.get({
        hostname: parsed.hostname,
        path: parsed.pathname + parsed.search,
        timeout: 20000,
        headers: { "User-Agent": UA_MOBILE, ...hdrs }
      }, (res) => {
        let d = ""
        res.on("data", c => d += c)
        res.on("end", () => {
          try { resolve({ status: res.statusCode, body: JSON.parse(d), headers: res.headers }) }
          catch { resolve({ status: res.statusCode, body: d, headers: res.headers }) }
        })
      }).on("error", reject).on("timeout", function() { this.destroy(); reject(new Error("Timeout")) })
    } catch(e) { reject(e) }
  })

/* ═══════════════════════════════════════════
   YOUTUBE SEARCH SCRAPE (internal API)
═══════════════════════════════════════════ */

const searchYoutube = async (query) => {
  const payload = {
    context: { client: { clientName: "WEB", clientVersion: "2.20240514.01.00", hl: "en", gl: "US" } },
    query
  }
  const { status, body } = await httpPost(
    "https://www.youtube.com/youtubei/v1/search?prettyPrint=false",
    payload,
    { "X-YouTube-Client-Name": "1", "X-YouTube-Client-Version": "2.20240514.01.00", "Content-Type": "application/json" }
  )
  if (status !== 200) throw new Error("YT search status " + status)
  const results = []
  const contents = body?.contents?.twoColumnSearchResultsRenderer?.primaryContents?.sectionListRenderer?.contents || []
  for (const section of contents) {
    const items = section.itemSectionRenderer?.contents || section.richGridRenderer?.contents || []
    for (const item of items) {
      const vr = item.videoRenderer || item.richItemRenderer?.content?.videoRenderer
      if (vr?.videoId) results.push({
        id: vr.videoId,
        title: vr.title?.runs?.map(r => r.text).join("") || "No Title",
        channel: vr.ownerText?.runs?.map(r => r.text).join("") || "Unknown",
        views: vr.viewCountText?.simpleText || "",
        duration: vr.lengthText?.simpleText || "LIVE",
        publishedTime: vr.publishedTimeText?.simpleText || "",
        url: `https://www.youtube.com/watch?v=${vr.videoId}`,
        videoId: vr.videoId
      })
    }
  }
  return results
}

/* ═══════════════════════════════════════════
   SSYOUTUBE SCRAPER (primary downloader)
   Support: audio mp3 + video mp4 hingga 1080p
═══════════════════════════════════════════ */

const SSY_HEADERS = {
  "User-Agent": UA_MOBILE,
  "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
  "Content-Type": "application/x-www-form-urlencoded",
  "origin": "https://ssyou.online",
  "referer": "https://ssyou.online/en12/",
  "accept-language": "id-ID,id;q=0.9,en-US;q=0.6"
}

const ssyoutube = async (url, resolusi = "720") => {
  // step 1: ambil info video
  const r1 = await httpPost("https://ssyou.online/yt-video-detail/",
    `videoURL=${encodeURIComponent(url)}`,
    SSY_HEADERS, false)

  const html = typeof r1.body === "string" ? r1.body : JSON.stringify(r1.body)
  if (!html || html.length < 100) throw new Error("ssyou: respon kosong")

  const get = (re) => { const m = html.match(re); return m ? m[1].trim() : null }

  const title     = get(/<div class="col-lg-12[^"]*videoTitle"[^>]*>\s*(.*?)\s*<\/div>/) || "Unknown"
  const thumbnail = get(/<img class="thumbnail" src="([^"]+)"/)
  const duration  = get(/<label class="duration">Duration: ([^<]+)<\/label>/)
  const videoId   = get(/name="video_id" value="([^"]+)"/)
  const nonce     = get(/'X-WP-Nonce':\s*'([^']+)'/) || ""

  const ajaxHdrs = { ...SSY_HEADERS, Accept: "application/json", "x-wp-nonce": nonce }

  if (resolusi === "audio") {
    const { body: a } = await httpPost("https://ssyou.online/wp-admin/admin-ajax.php", {
      action: "get_mp3_conversion_url",
      videoUrl: url,
      downloadMode: "audio",
      audioFormat: "mp3",
      audioBitrate: "256"
    }, ajaxHdrs, true)
    if (!a?.data?.url) throw new Error("ssyou audio: no url")

    const { body: p } = await httpPost("https://ssyou.online/wp-admin/admin-ajax.php", {
      action: "wp_get_proxied_url",
      targetUrl: a.data.url
    }, ajaxHdrs, true)
    return {
      title, thumbnail, duration,
      downloadUrl: (p?.success && p?.data?.proxiedUrl) ? p.data.proxiedUrl : a.data.url
    }
  }

  // video — ambil format URLs dari JS
  const fmMatch = html.match(/let cachedFormatUrls = ({[\s\S]*?});/)
  const formats = {}
  if (fmMatch) {
    const re = /'([^']+)'\s*:\s*'([^']+)'/g; let m
    while ((m = re.exec(fmMatch[1])) !== null) formats[m[1]] = m[2]
  }

  const resKey = `${resolusi}p`
  if (!formats[resKey]) {
    // fallback ke resolusi terdekat
    const avail = Object.keys(formats).filter(k => k.endsWith("p")).sort((a,b) => parseInt(b)-parseInt(a))
    if (!avail.length) throw new Error("ssyou: resolusi tidak tersedia")
    return ssyoutube(url, avail[0].replace("p",""))
  }

  // perlu WebSocket merge — pakai fallback savetube untuk video supaya tidak butuh ws
  throw new Error("ssyou_video_ws") // signal buat caller pakai fallback savetube untuk video
}

/* ═══════════════════════════════════════════
   SAVETUBE (AES decrypt) — audio + video
═══════════════════════════════════════════ */

const SAVETUBE_KEY = Buffer.from("C5D58EF67A7584E4A29F6C35BBC4EB12", "hex")
const ST_HEADERS = {
  "Content-Type": "application/json",
  "Origin": "https://yt.savetube.me",
  "User-Agent": "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/130 Mobile Safari/537.36"
}

const savetubeDl = async (videoUrl, type = "audio", quality = "128kbps") => {
  const idMatch = videoUrl.match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|shorts\/|embed\/))([a-zA-Z0-9_-]{11})/)
  if (!idMatch) throw new Error("savetube: invalid YouTube URL")
  const videoId = idMatch[1]

  const { body: cdnBody } = await httpGet("https://media.savetube.vip/api/random-cdn", ST_HEADERS)
  const cdn = cdnBody?.cdn
  if (!cdn) throw new Error("savetube: no CDN")

  const { body: info } = await httpPost(`https://${cdn}/v2/info`,
    { url: "https://www.youtube.com/watch?v=" + videoId },
    ST_HEADERS)
  if (!info?.data) throw new Error("savetube: no info")

  // decrypt metadata
  const encrypted = Buffer.from(info.data, "base64")
  const decipher = createDecipheriv("aes-128-cbc", SAVETUBE_KEY, encrypted.subarray(0, 16))
  const decrypted = Buffer.concat([decipher.update(encrypted.subarray(16)), decipher.final()])
  const metadata = JSON.parse(decrypted.toString("utf8"))
  if (!metadata?.key) throw new Error("savetube: no key")

  const { body: dl } = await httpPost(`https://${cdn}/download`, {
    id: videoId,
    downloadType: type,
    quality: type === "audio" ? "128kbps" : quality,
    key: metadata.key
  }, ST_HEADERS)
  if (!dl?.data?.downloadUrl) throw new Error("savetube: no downloadUrl")

  return {
    title: metadata.title || "Unknown",
    thumbnail: metadata.thumbnail || "",
    duration: metadata.durationLabel || "",
    downloadUrl: dl.data.downloadUrl
  }
}

/* ═══════════════════════════════════════════
   Y2MATE FALLBACK (via cnv.cx)
═══════════════════════════════════════════ */

const y2mateDl = async (videoUrl) => {
  const { body: k } = await httpGet("https://cnv.cx/v2/sanity/key", {
    "origin": "https://frame.y2meta-uk.com",
    "referer": "https://frame.y2meta-uk.com/",
    "accept": "*/*"
  })
  const key = k?.key
  if (!key) throw new Error("y2mate: no key")

  const { body: r } = await httpPost("https://cnv.cx/v2/converter", {
    link: videoUrl, format: "mp3", audioBitrate: "128",
    videoQuality: "720", filenameStyle: "pretty", vCodec: "h264"
  }, {
    "key": key,
    "origin": "https://frame.y2meta-uk.com",
    "referer": "https://frame.y2meta-uk.com/",
    "accept": "*/*",
    "Content-Type": "application/x-www-form-urlencoded"
  }, true)

  if (!r?.url) throw new Error("y2mate: no url")
  return { downloadUrl: r.url, filename: r.filename || "audio" }
}

/* ═══════════════════════════════════════════
   MASTER DOWNLOAD — audio (multi-fallback)
═══════════════════════════════════════════ */

const downloadAudio = async (videoUrl) => {
  // 1. ssyoutube
  try {
    const r = await ssyoutube(videoUrl, "audio")
    return r
  } catch(e) { console.log("ssyou audio fail:", e.message) }

  // 2. savetube
  try {
    const r = await savetubeDl(videoUrl, "audio")
    return r
  } catch(e) { console.log("savetube audio fail:", e.message) }

  // 3. y2mate
  try {
    const r = await y2mateDl(videoUrl)
    return { downloadUrl: r.downloadUrl, title: r.filename }
  } catch(e) { console.log("y2mate fail:", e.message) }

  throw new Error("Semua sumber audio gagal. Coba lagi nanti.")
}

/* ═══════════════════════════════════════════
   MASTER DOWNLOAD — video (multi-fallback)
═══════════════════════════════════════════ */

const downloadVideo = async (videoUrl, quality = "360") => {
  // 1. savetube video
  try {
    const r = await savetubeDl(videoUrl, "video", quality + "p")
    return r
  } catch(e) { console.log("savetube video fail:", e.message) }

  // 2. ssyoutube audio-only sebagai fallback info
  // (video via ssyou butuh WebSocket — skip langsung ke error)
  throw new Error("Download video gagal. Coba resolusi lebih rendah.")
}

/* ═══════════════════════════════════════════
   TIKTOK DOWNLOAD via tikwm
═══════════════════════════════════════════ */

const tiktokDl = async (url) => {
  const { body } = await httpPost("https://www.tikwm.com/api/",
    `url=${encodeURIComponent(url)}&count=12&cursor=0&web=1&hd=1`,
    { "Content-Type": "application/x-www-form-urlencoded", "User-Agent": UA_MOBILE },
    false)

  const r = body?.data
  if (!r) throw new Error("TikTok: data kosong")

  const fmt = n => Number(parseInt(n) || 0).toLocaleString().replace(/,/g, ".")
  return {
    title:     r.title || "",
    duration:  r.duration || 0,
    cover:     "https://www.tikwm.com" + (r.cover || ""),
    play_nowm: "https://www.tikwm.com" + (r.play || ""),
    play_hd:   r.hdplay ? "https://www.tikwm.com" + r.hdplay : null,
    play_wm:   "https://www.tikwm.com" + (r.wmplay || ""),
    music:     "https://www.tikwm.com" + (r.music || ""),
    // foto: array URL string langsung
    images:    r.images && r.images.length ? r.images : null,
    stats: {
      views:    fmt(r.play_count),
      likes:    fmt(r.digg_count),
      comments: fmt(r.comment_count),
      shares:   fmt(r.share_count)
    },
    author: {
      name:     r.author?.nickname || "",
      username: r.author?.unique_id || ""
    },
    music_info: {
      title:  r.music_info?.title || "",
      author: r.music_info?.author || "",
      url:    "https://www.tikwm.com" + (r.music || r.music_info?.play || "")
    }
  }
}

/* ═══════════════════════════════════════════
   HELPERS UI (edit-only)
═══════════════════════════════════════════ */

/* tombol berwarna (style) — dipakai semua keyboard di plugin ini */
const btn = (text, callback_data, style) => ({ text, callback_data, style: style || "primary" })

/* edit pesan progress jadi teks hasil */
const editOut = async (m, Rafz, wait, text, opt = {}) => {
  try {
    return await Rafz.editMessageText(String(text), {
      chat_id: m.chat, message_id: wait.message_id, parse_mode: "HTML",
      disable_web_page_preview: true, ...opt
    })
  } catch (e) {
    if (String(e?.message || e).includes("not modified")) return null
    return m.reply(String(text), opt)
  }
}

/* ═══════════════════════════════════════════
   MAIN HANDLER
═══════════════════════════════════════════ */

const handler = async (m, { Rafz, command, text }) => {
  try {
    const px = (global.prefix && global.prefix[0]) || "/"
    const sender = String(m.sender)
    const del = (msgId) => { try { Rafz.deleteMessage(m.chat, msgId).catch(() => {}) } catch {} }    /* ─────────── /yts ─────────── */
    if (command === "yts") {
      if (!text) return m.reply(`⚠️ <b>Penggunaan:</b> <code>${px}yts judul video</code>`, { parse_mode: "HTML" })
      const wait = await m.reply("🔍 Mencari di YouTube...")
      let results
      try { results = await searchYoutubeSafe(text) }
      catch (e) { del(wait.message_id); return m.reply("❌ Gagal mencari: " + e.message) }
      if (!results?.length) { del(wait.message_id); return editOut(m, Rafz, wait, "❌ Tidak ditemukan hasil untuk: " + text) }

      let out = `🎬 <b>Hasil YouTube: "${text}"</b>\n\n`
      results.slice(0, 5).forEach((v, i) => {
        out += `${i+1}. <a href="${v.url}">${v.title}</a>\n`
        out += `   📺 ${v.channel} · ⏱ ${v.duration} · 👁 ${v.views}\n\n`
      })
      return editOut(m, Rafz, wait, out)
    }

    /* ─────────── /ytdl ─────────── */
    if (command === "ytdl") {
      if (!text || !text.startsWith("http"))
        return m.reply(`⚠️ <b>Penggunaan:</b> <code>${px}ytdl [link YouTube]</code>`, { parse_mode: "HTML" })

      const kb = { inline_keyboard: [
        [ btn("🎵 Audio MP3",  `/ytdl_dl A|0|${text}`, "success") ],
        [ btn("🎬 Video 360p", `/ytdl_dl V|360|${text}`, "primary"),
          btn("🎬 Video 720p", `/ytdl_dl V|720|${text}`, "primary") ],
        [ btn("📦 Audio + Video 360p", `/ytdl_dl B|360|${text}`, "danger") ]
      ]}
      return m.reply(
        `🎬 <b>YouTube Downloader</b>\n\n🔗 <code>${text}</code>\n\nPilih format:`,
        { parse_mode: "HTML", reply_markup: kb }
      )
    }

    /* ─────────── /ytdl_dl (callback) ─────────── */
    if (command === "ytdl_dl") {
      const i1 = text.indexOf("|"), i2 = text.indexOf("|", i1+1)
      if (i1 < 0 || i2 < 0) return m.reply("❌ Format tidak valid.")
      const type = text.slice(0, i1).trim()   // A / V / B
      const qual = text.slice(i1+1, i2).trim()
      const url  = text.slice(i2+1).trim()
      if (!url) return m.reply("❌ URL kosong.")

      /* callback → EDIT pesan yang punya tombol (tanpa pesan baru) */
      if (m.callback?.message?.message_id) {
        const tryEdit = async (t) => {
          try {
            return await Rafz.editMessageText(t, {
              chat_id: m.chat, message_id: m.callback.message.message_id, parse_mode: "HTML"
            })
          } catch (e) {
            if (String(e?.message || e).includes("not modified")) return null
            return null
          }
        }
        await tryEdit("⏳ Mendownload... tunggu sebentar")

        try {
          if (type === "A" || type === "B") {
            let info
            try { info = await downloadAudio(url) }
            catch(e) { return editOut(m, Rafz, m.callback.message, "❌ " + e.message) }

            await Rafz.sendAudio(m.chat, info.downloadUrl, {
              caption: `🎵 <b>${info.title || "Audio"}</b>`,
              parse_mode: "HTML",
              reply_to_message_id: m.callback.message.message_id,
              allow_sending_without_reply: true
            }).catch(async () => {
              await Rafz.sendVoice(m.chat, info.downloadUrl, {
                reply_to_message_id: m.callback.message.message_id,
                allow_sending_without_reply: true
              }).catch(async () => {
                await m.reply(`⚠️ Kirim audio gagal. Link langsung:\n${info.downloadUrl}`)
              })
            })

            await tryEdit(`✅ Audio terkirim: <b>${(info.title || "Audio").slice(0, 60)}</b>`)
          }

          if (type === "V" || type === "B") {
            let info
            try { info = await downloadVideo(url, qual) }
            catch(e) { return editOut(m, Rafz, m.callback.message, "❌ " + e.message) }

            await Rafz.sendVideo(m.chat, info.downloadUrl, {
              caption: `🎬 <b>${info.title || "Video"}</b>`,
              parse_mode: "HTML",
              reply_to_message_id: m.callback.message.message_id,
              allow_sending_without_reply: true
            }).catch(async () => {
              await m.reply(`⚠️ Kirim video gagal. Link langsung:\n${info.downloadUrl}`)
            })

            await tryEdit(`✅ Video terkirim: <b>${(info.title || "Video").slice(0, 60)}</b>`)
          }
        } catch(e) {
          return editOut(m, Rafz, m.callback.message, "❌ Error: " + e.message)
        }
        return true
      }

      /* dipanggil lewat teks (fallback lama) */
      const wait = await m.reply("⏳ Mendownload... tunggu sebentar")
      try {
        if (type === "A" || type === "B") {
          let info
          try { info = await downloadAudio(url) }
          catch(e) { del(wait.message_id); return m.reply("❌ " + e.message) }

          await Rafz.sendAudio(m.chat, info.downloadUrl, {
            caption: `🎵 <b>${info.title || "Audio"}</b>`,
            parse_mode: "HTML",
            reply_to_message_id: m.id,
            allow_sending_without_reply: true
          }).catch(async () => {
            await Rafz.sendVoice(m.chat, info.downloadUrl, {
              reply_to_message_id: m.id,
              allow_sending_without_reply: true
            }).catch(async () => {
              await m.reply(`⚠️ Kirim audio gagal. Link langsung:\n${info.downloadUrl}`)
            })
          })
        }

        if (type === "V" || type === "B") {
          let info
          try { info = await downloadVideo(url, qual) }
          catch(e) { del(wait.message_id); return m.reply("❌ " + e.message) }

          await Rafz.sendVideo(m.chat, info.downloadUrl, {
            caption: `🎬 <b>${info.title || "Video"}</b>`,
            parse_mode: "HTML",
            reply_to_message_id: m.id,
            allow_sending_without_reply: true
          }).catch(async () => {
            await m.reply(`⚠️ Kirim video gagal. Link langsung:\n${info.downloadUrl}`)
          })
        }

        del(wait.message_id)
      } catch(e) {
        del(wait.message_id)
        return m.reply("❌ Error: " + e.message)
      }
      return true
    }

    /* ─────────── /play ─────────── */
    if (command === "play") {
      if (!text) return m.reply(`⚠️ <b>Penggunaan:</b> <code>${px}play nama lagu</code>`, { parse_mode: "HTML" })
      const wait = await m.reply("🔍 Mencari: " + text + "...")
      let results
      try { results = await searchYoutubeSafe(text + " audio") }
      catch (e) { del(wait.message_id); return m.reply("❌ Gagal mencari: " + e.message) }

      if (!results?.length) { del(wait.message_id); return editOut(m, Rafz, wait, "❌ Lagu tidak ditemukan.") }
      const top = results[0]

      await editOut(m, Rafz, wait, `🎵 Ditemukan: <b>${top.title}</b>\n⏳ Mendownload audio...`)

      let info
      try { info = await downloadAudio(top.url) }
      catch(e) {
        del(wait.message_id)
        // kirim tombol manual sebagai fallback
        const kb = { inline_keyboard: [[
          btn("▶️ Download Audio", `/ytdl_dl A|0|${top.url}`, "success"),
          btn("🎬 Download Video", `/ytdl_dl V|360|${top.url}`, "primary")
        ]]}
        return m.reply(
          `🎵 <b>${top.title}</b>\n📺 ${top.channel} · ⏱ ${top.duration}\n\n` +
          `⚠️ Download otomatis gagal (${e.message})\nPilih manual:`,
          { parse_mode: "HTML", reply_markup: kb }
        )
      }

      del(wait.message_id)

      await Rafz.sendAudio(m.chat, info.downloadUrl, {
        caption: `🎵 <b>${info.title || top.title}</b>\n📺 ${top.channel} · ⏱ ${top.duration}`,
        parse_mode: "HTML",
        reply_to_message_id: m.id,
        allow_sending_without_reply: true
      }).catch(async () => {
        await Rafz.sendVoice(m.chat, info.downloadUrl, {
          reply_to_message_id: m.id,
          allow_sending_without_reply: true
        }).catch(async () => {
          await m.reply(
            `🎵 <b>${info.title || top.title}</b>\n\n⚠️ Kirim audio gagal.\n🔗 <a href="${info.downloadUrl}">Link Download</a>`,
            { parse_mode: "HTML" }
          )
        })
      })
      return true
    }

    /* ─────────── /tt ─────────── */
    if (command === "tt" || command === "tiktok") {
      if (!text || !text.startsWith("http"))
        return m.reply(`⚠️ <b>Penggunaan:</b> <code>${px}tt [link TikTok]</code>`, { parse_mode: "HTML" })

      // fetch info dulu, tampilkan tombol pilih tipe
      const wait = await m.reply("⏳ Memproses link TikTok...")
      let res
      try { res = await tiktokDl(text) }
      catch(e) { del(wait.message_id); return m.reply("❌ Gagal proses TikTok: " + e.message) }
      del(wait.message_id)

      const hasImages = res.images && res.images.length > 0
      const caption =
        `<b>${res.title || "TikTok"}</b>\n` +
        `👤 ${res.author.name} (@${res.author.username})\n` +
        `⏱ ${res.duration}s · 👁 ${res.stats.views} · ❤️ ${res.stats.likes}\n\n` +
        `Pilih yang mau didownload:`

      const kb = { inline_keyboard: [] }

      if (hasImages) {
        kb.inline_keyboard.push([{ text: `📸 Foto/Slideshow (${res.images.length})`, callback_data: `/tt_dl photo|${text}` }])
      } else {
        kb.inline_keyboard.push([
          { text: "🎬 Video (No WM)", callback_data: `/tt_dl video_nowm|${text}` },
          { text: "🎬 Video HD",      callback_data: `/tt_dl video_hd|${text}` }
        ])
        kb.inline_keyboard.push([
          { text: "🎬 Video (WM)",    callback_data: `/tt_dl video_wm|${text}` }
        ])
      }
      kb.inline_keyboard.push([{ text: "🎵 Audio / Music", callback_data: `/tt_dl audio|${text}` }])

      // kirim thumbnail + tombol
      try {
        await Rafz.sendPhoto(m.chat, res.cover, {
          caption, parse_mode: "HTML", reply_markup: kb,
          reply_to_message_id: m.id, allow_sending_without_reply: true
        })
      } catch {
        await m.reply(caption, { parse_mode: "HTML", reply_markup: kb })
      }
      return true
    }

    /* ─────────── /tt_dl (callback) ─────────── */
    if (command === "tt_dl") {
      const idx = text.indexOf("|")
      if (idx < 0) return m.reply("❌ Format callback tidak valid.")
      const type = text.slice(0, idx).trim()
      const url  = text.slice(idx+1).trim()

      /* callback → EDIT pesan yang punya tombol */
      const editBase = m.callback?.message?.message_id
      if (editBase) {
        try {
          await Rafz.editMessageText("⏳ Mendownload...", {
            chat_id: m.chat, message_id: editBase, parse_mode: "HTML"
          })
        } catch {}
      }
      const wait = editBase ? { message_id: editBase } : await m.reply("⏳ Mendownload...")

      let res
      try { res = await tiktokDl(url) }
      catch(e) { return editOut(m, Rafz, wait, "❌ Gagal: " + e.message) }

      const cap =
        `<b>${res.title || "TikTok"}</b>\n` +
        `👤 ${res.author.name} (@${res.author.username})\n` +
        `👁 ${res.stats.views} · ❤️ ${res.stats.likes}`

      try {
        if (type === "photo" && res.images) {
          // slideshow — kirim per batch 10
          const imgs = res.images
          const media = imgs.slice(0, 10).map((imgUrl, i) => ({
            type: "photo",
            media: imgUrl,
            caption: i === 0 ? cap : "",
            parse_mode: "HTML"
          }))
          await Rafz.sendMediaGroup(m.chat, media, {
            reply_to_message_id: m.id, allow_sending_without_reply: true
          })
        } else if (type === "video_hd") {
          const vidUrl = res.play_hd || res.play_nowm
          await Rafz.sendVideo(m.chat, vidUrl, {
            caption: cap, parse_mode: "HTML",
            reply_to_message_id: m.id, allow_sending_without_reply: true
          })
        } else if (type === "video_wm") {
          await Rafz.sendVideo(m.chat, res.play_wm, {
            caption: cap, parse_mode: "HTML",
            reply_to_message_id: m.id, allow_sending_without_reply: true
          })
        } else if (type === "video_nowm") {
          await Rafz.sendVideo(m.chat, res.play_nowm, {
            caption: cap, parse_mode: "HTML",
            reply_to_message_id: m.id, allow_sending_without_reply: true
          })
        } else if (type === "audio") {
          await Rafz.sendAudio(m.chat, res.music_info.url, {
            caption: `🎵 <b>${res.music_info.title || res.title}</b>\n👤 ${res.music_info.author}`,
            parse_mode: "HTML",
            reply_to_message_id: m.id, allow_sending_without_reply: true
          }).catch(async () => {
            await Rafz.sendVoice(m.chat, res.music, {
              reply_to_message_id: m.id, allow_sending_without_reply: true
            })
          })
        }
      } catch(e) {
        return editOut(m, Rafz, wait, "❌ Gagal kirim media: " + e.message)
      }
      return editOut(m, Rafz, wait, "✅ Selesai dikirim.")
    }

    /* ─────────── /info — reply/ID/@tag semuanya jalan ─────────── */
    if (command === "info") {
      const readArr = (file) => {
        try {
          const j = JSON.parse(fs.readFileSync(path.join(__dirname, "..", "library", "database", file), "utf8"))
          return Array.isArray(j) ? j : []
        } catch { return [] }
      }
      const fullName = (u) => [u?.first_name, u?.last_name].filter(Boolean).join(" ") || ""

      let targetId = sender, targetName = m.pushName || "N/A", targetUsername = null

      /* 1. @tag / text_mention di pesan → ambil dari m.mentioned (dari handler) */
      const ment = (m.mentioned || []).find(x => x.id) || null
      const rawText = (text || "").trim()

      if (ment && ment.id && (!/^\d+$/.test(rawText))) {
        targetId = String(ment.id)
        targetName = ment.name || ment.username || ""
        targetUsername = ment.username || null
        /* coba lengkapi nama via getChat */
        try {
          const ch = await Rafz.getChat(Number(targetId))
          targetName = fullName(ch) || targetName
          targetUsername = targetUsername || ch.username || null
        } catch {}
      }

      /* 2. reply */
      if (targetId === sender && m.quoted?.sender) {
        targetId = String(m.quoted.sender)
        targetName = m.quoted.name || targetName
        targetUsername = m.quoted.username || null
      }

      /* 3. ID langsung */
      if (/^\d+$/.test(rawText)) {
        targetId = rawText
        try {
          const ch = await Rafz.getChat(Number(targetId))
          targetName = fullName(ch) || targetName
          targetUsername = targetUsername || ch.username || null
        } catch {}
      }

      /* 4. @username eksplisit (kalau mention belum resolve) */
      if (targetId === sender && /^@[a-zA-Z0-9_]{4,}$/.test(rawText)) {
        targetUsername = rawText.slice(1)
        try {
          const cache = JSON.parse(fs.readFileSync(path.join(__dirname, "..", "library", "database", "usercache.json"), "utf8"))
          const cached = cache[targetUsername.toLowerCase()]
          if (cached) {
            targetId = String(cached)
            try {
              const ch = await Rafz.getChat(Number(targetId))
              targetName = fullName(ch) || targetName
            } catch {}
          } else {
            const ch = await Rafz.getChat("@" + targetUsername)
            targetId = String(ch.id)
            targetName = fullName(ch) || targetName
          }
        } catch {}
      }

      const isCreator = (global.owner || []).includes(targetId)
      const isOwner   = isCreator || readArr("owner.json").includes(targetId)
      const isSuper   = readArr("superseller.json").includes(targetId) || isOwner
      const isSeller  = readArr("seller.json").includes(targetId) || isSuper
      const role = isCreator ? "👑 Creator" : isOwner ? "🔑 Owner" : isSuper ? "⭐ Super Seller" : isSeller ? "🛒 Seller" : "👤 User"

      let startedBot = false
      try {
        const cache = JSON.parse(fs.readFileSync(path.join(__dirname, "..", "library", "database", "usercache.json"), "utf8"))
        startedBot = Object.values(cache || {}).map(String).includes(targetId) || targetId === sender
      } catch {}

      return m.reply(
        `<b>👤 Info User</b>\n\n` +
        `🔤 Nama     : <b>${targetName || "N/A"}</b>\n` +
        `🆔 ID       : <code>${targetId}</code>\n` +
        (targetUsername ? `📛 Username : @${targetUsername}\n` : "") +
        `🎭 Role     : ${role}\n` +
        `🤖 Start Bot: ${startedBot ? "✅ Sudah" : "❌ Belum"}`,
        { parse_mode: "HTML" }
      )
    }

    return false
  } catch(e) {
    console.error("[tools]", command, e.message)
    try { await m.reply("⚠️ Error pada /" + command + ": " + e.message) } catch {}
    return false
  }
}

handler.command = ["yts","ytdl","ytdl_dl","play","tt","tiktok","tt_dl","info"]
module.exports = handler

try {
  const fs = require("fs")
  const file = require.resolve(__filename)
  fs.watchFile(file, () => { try { fs.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
