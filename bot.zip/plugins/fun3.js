/* plugin: fun3.js — porting fitur fun/cek dari bot WA (Prabowo & RAFZ Botz)
   Semua cek-cek self-contained (tanpa API) jadi selalu jalan.
   Command: /checkme /janda /duda /jelek /pedofil /penyakit /pekerjaan
            /nasib /rezeki /sifat /hobi /pintar /maling /haribaik
            /harisial /ceknikah /cekpesugihan /cekhoki /cekfuture
   Ada yang dobel dengan plugin lain? Aman — handler.js otomatis
   menjadikannya fallback chain (kalau yang pertama error, ini yang jalan). */

"use strict"

const DB = "./library/database/checkme.json"
const fs = require("fs")
const loadPct = () => { try { const j = JSON.parse(fs.readFileSync(DB, "utf8")); return j && typeof j === "object" ? j : {} } catch { return {} } }
const savePct = (d) => { try { fs.mkdirSync("library/database", { recursive: true }); fs.writeFileSync(DB, JSON.stringify(d, null, 2)) } catch {} }

/* persentase konsisten per user per fitur (hash sederhana) */
const pctFor = (uid, key) => {
  const store = loadPct()
  const k = key + ":" + uid
  if (store[k] != null) return store[k]
  const v = Math.floor(Math.random() * 100) + 1
  store[k] = v
  savePct(store)
  return v
}

const nameOf = (m, text) => {
  if (text) return text
  if (m.quoted?.from?.first_name) return m.quoted.from.first_name
  if (m.quoted?.pushName) return m.quoted.pushName
  if (m.pushName) return m.pushName
  return "Kamu"
}

const bar = (p) => {
  const filled = Math.round(p / 10)
  return "█".repeat(filled) + "░".repeat(10 - filled) + " " + p + "%"
}

const handler = async (m, { command, text }) => {
  const tr = (key, vars) => (m.t ? m.t(key, vars) : key)
  try {
    const who = nameOf(m, text)
    const uid = String(m.sender || "anon")
    const px = (global.prefix && global.prefix[0]) || "/"

    const CEKS = {
      janda: { emoji: "💔", min: 0, msg: tr("fun3.janda", { who }) },
      duda: { emoji: "💔", min: 0, msg: tr("fun3.duda", { who }) },
      jelek: { emoji: "🐸", min: 0, msg: tr("fun3.jelek", { who }) },
      ganteng: { emoji: "😎", min: 0, msg: tr("fun3.ganteng", { who }) },
      cantik: { emoji: "🌸", min: 0, msg: tr("fun3.cantik", { who }) },
      pedofil: { emoji: "🚨", min: 0, msg: tr("fun3.pedofil", { who }) },
      penyakit: { emoji: "🤒", min: 0, msg: tr("fun3.penyakit", { who }) },
      pekerjaan: { emoji: "💼", min: 0, msg: tr("fun3.pekerjaan", { who }) },
      nasib: { emoji: "🎴", min: 0, msg: tr("fun3.nasib", { who }) },
      rezeki: { emoji: "🍀", min: 0, msg: tr("fun3.rezeki", { who }) },
      sifat: { emoji: "🧬", min: 0, msg: tr("fun3.sifat", { who }) },
      hobi: { emoji: "🎯", min: 0, msg: tr("fun3.hobi", { who }) },
      pintar: { emoji: "🧠", min: 0, msg: tr("fun3.pintar", { who }) },
      maling: { emoji: "🦝", min: 0, msg: tr("fun3.maling", { who }) },
      haribaik: { emoji: "🌞", min: 0, msg: tr("fun3.haribaik", { who }) },
      harisial: { emoji: "🌧️", min: 0, msg: tr("fun3.harisial", { who }) },
      nikah: { emoji: "💍", min: 0, msg: tr("fun3.nikah", { who }) },
      pesugihan: { emoji: "🔮", min: 0, msg: tr("fun3.pesugihan", { who }) },
      hoki: { emoji: "🧧", min: 0, msg: tr("fun3.hoki", { who }) },
      future: { emoji: "🔮", min: 0, msg: tr("fun3.future", { who }) }
    }

    /* /checkme → gabungan semua cek sekaligus */
    if (command === "checkme") {
      let out = "┌──「 🪪 CHECK ME 」\n"
      for (const [k, c] of Object.entries(CEKS)) {
        out += "│ " + c.emoji + " " + tr("fun3.row", { key: k, who: who, p: pctFor(uid, k) }) + "\n"
      }
      out += "└──────────────\n<i>" + tr("fun3.footer") + "</i>"
      await m.reply(out, { parse_mode: "HTML" })
      return true
    }

    const c = CEKS[command]
    if (!c) return false

    const p = pctFor(uid, command)
    let out =
      "┌──「 " + c.emoji + " " + command.toUpperCase() + " 」\n" +
      "│ " + c.msg + "\n" +
      "└──────────────\n" +
      "📊 <code>" + bar(p) + "</code>\n"
    if (text) out += "👤 @" + who + "\n"
    out += "\n<i>" + tr("fun3.footer") + "</i>"
    await m.reply(out, { parse_mode: "HTML" })
    return true
  } catch (e) {
    console.error("[fun3]", command, e?.message)
    try { await m.reply(tr("common.failed") + " " + e.message) } catch {}
    return false
  }
}

/* cek apakah command-nya milik plugin ini */
handler.__isFun3 = true
const CMDS = Object.keys({
  checkme: 1, janda: 1, duda: 1, jelek: 1, ganteng: 1, cantik: 1, pedofil: 1, penyakit: 1,
  pekerjaan: 1, nasib: 1, rezeki: 1, sifat: 1, hobi: 1, pintar: 1, maling: 1,
  haribaik: 1, harisial: 1, nikah: 1, pesugihan: 1, hoki: 1, future: 1
})

handler.command = CMDS
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
