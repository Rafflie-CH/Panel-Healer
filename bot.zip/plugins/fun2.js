/* plugin: fun2.js — fun ekstra:
   /artitarot /fakta /puisi /bijak /gombalan /motivasi /cerpen /kepo /arahrezeki
   Semua teks dari language.js (i18n) — konten mengikuti bahasa user. */

"use strict"

const pick = (arr) => arr[Math.floor(Math.random() * arr.length)]

/* bank kartu tarot: [kartu, arti] — arti dari language.js per index */
const TAROT_CARDS = [
  "The Fool 🃏", "The Magician ✨", "The Lovers 💑", "The Tower 🗼",
  "The Star ⭐", "The Sun ☀️", "The Moon 🌙", "Death 💀",
  "The Empress 👑", "Wheel of Fortune 🎡"
]

const handler = async (m, { Rafz, command, text }) => {
  try {
    const px = (global.prefix && global.prefix[0]) || "/"
    const tr = (key, vars) => (m.t ? m.t(key, vars) : key)

    if (command === "artitarot" || command === "tarot") {
      const i = Math.floor(Math.random() * TAROT_CARDS.length)
      const meaning = tr("fun2.tarotMeanings").split("|")[i] || ""
      return m.reply(`<b>🔮 ${tr("fun2.tarot")}</b>\n\n${tr("fun2.card")}: <b>${TAROT_CARDS[i]}</b>\n\n${meaning}\n\n<i>${tr("fun2.justFun")}</i>`, { parse_mode: "HTML" })
    }

    if (command === "fakta" || command === "fact") {
      return m.reply(`🧠 <b>${tr("fun2.facts")}</b>\n\n${pick(tr("fun2.factList").split("|"))}`, { parse_mode: "HTML" })
    }

    if (command === "puisi" || command === "puisiacak") {
      return m.reply(`📜 <b>${tr("fun2.poem")}</b>\n\n<i>${pick(tr("fun2.poemList").split("||"))}</i>`, { parse_mode: "HTML" })
    }

    if (command === "bijak" || command === "katabijak") {
      return m.reply(`💡 <i>${pick(tr("fun2.wiseList").split("|"))}</i>`, { parse_mode: "HTML" })
    }

    if (command === "gombalan" || command === "gombal") {
      return m.reply(`😏 <i>${pick(tr("fun2.flirtList").split("|"))}</i>`, { parse_mode: "HTML" })
    }

    if (command === "motivasi" || command === "motivasihidup") {
      return m.reply(`🔥 <b>${pick(tr("fun2.motivationList").split("|"))}</b>`, { parse_mode: "HTML" })
    }

    if (command === "cerpen" || command === "ceritapendek") {
      return m.reply(`📖 <b>${tr("fun2.shortStory")}</b>\n\n${pick(tr("fun2.storyList").split("||"))}`, { parse_mode: "HTML" })
    }

    if (command === "kepo" || command === "asahotakkepo") {
      return m.reply(`🕵️ <b>${tr("fun2.kepoMeter")}</b>\n\n${tr("fun2.kepoLevel")}: <b>${Math.floor(Math.random() * 101)}%</b>`, { parse_mode: "HTML" })
    }

    if (command === "arahrezeki" || command === "rezekiarah") {
      return m.reply(`🍀 <b>${tr("fun2.fortune")}</b>\n\n${pick(tr("fun2.fortuneList").split("|"))}`, { parse_mode: "HTML" })
    }

    return false
  } catch (e) {
    console.error("[fun2]", e?.message)
    try { await m.reply("⚠️ Error: " + (e?.message || e)) } catch {}
    return false
  }
}

handler.command = ["artitarot", "tarot", "fakta", "fact", "puisi", "puisiacak", "bijak", "katabijak", "gombalan", "gombal", "motivasi", "motivasihidup", "cerpen", "ceritapendek", "kepo", "asahotakkepo", "arahrezeki"]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
