/* plugin: utility.js — kumpulan fitur tools:
   /short /qr /calc /weather /wiki /tr /ip /github /npm
   /pass /b64 /hash /time /ss /tts /getid /define /covid
   Semua output pakai pola EDIT-MESSAGE (progress → hasil di pesan yang sama). */

"use strict"
const https = require("https")
const http = require("http")
const crypto = require("crypto")

const UA = "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/130 Mobile Safari/537.36"

const getBuffer = (url, hdrs = {}) =>
  new Promise((resolve, reject) => {
    try {
      const follow = (u, depth = 0) => {
        if (depth > 5) return reject(new Error("Too many redirects"))
        const mod = u.startsWith("https") ? https : http
        const parsed = new URL(u)
        const req = mod.get({
          hostname: parsed.hostname,
          path: parsed.pathname + parsed.search,
          timeout: 45000,
          headers: { "User-Agent": UA, ...hdrs }
        }, (res) => {
          if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location)
            return follow(new URL(res.headers.location, u).href, depth + 1)
          if (res.statusCode !== 200) return reject(new Error(`HTTP ${res.statusCode}`))
          const chunks = []
          res.on("data", c => chunks.push(c))
          res.on("end", () => resolve(Buffer.concat(chunks)))
          res.on("error", reject)
        })
        req.on("error", reject)
        req.on("timeout", () => { req.destroy(); reject(new Error("Timeout")) })
      }
      follow(url)
    } catch (e) { reject(e) }
  })

const getJSON = async (url, hdrs = {}) => {
  /* fetch() dulu (lebih toleran terhadap CDN lambat), https.request sebagai fallback */
  try {
    const r = await fetch(url, { headers: { "User-Agent": UA, "Accept": "application/json", ...hdrs }, signal: AbortSignal.timeout(15000) })
    if (!r.ok) throw new Error("HTTP " + r.status)
    return await r.json()
  } catch {}
  const buf = await getBuffer(url, { "Accept": "application/json", ...hdrs })
  try { return JSON.parse(buf.toString("utf8")) } catch { throw new Error("Respon bukan JSON") }
}

const getText = async (url, hdrs = {}) => {
  try {
    const r = await fetch(url, { headers: { "User-Agent": UA, ...hdrs }, signal: AbortSignal.timeout(45000) })
    if (r.ok) return await r.text()
  } catch {}
  const buf = await getBuffer(url, hdrs)
  return buf.toString("utf8")
}

/* helper edit-progress → hasil (pola edit-only) */
const makeEditor = (m, Rafz, wait) => async (text, opt = {}) => {
  try {
    return await Rafz.editMessageText(String(text), {
      chat_id: m.chat, message_id: wait.message_id, parse_mode: "HTML",
      disable_web_page_preview: true, ...opt
    })
  } catch (e) {
    if (String(e?.message || e).includes("not modified")) return null
    return m.reply(String(text), opt)
  }
}

const handler = async (m, { Rafz, command, text }) => {
  try {
    const px = (global.prefix && global.prefix[0]) || "/"
    const tr = (key, vars) => (m.t ? m.t(key, vars) : key)
    const q = (text || "").trim()
    const usage = (u) => `⚠️ <b>Penggunaan:</b> <code>${px}${u}</code>`
    const wait = await m.reply(tr("util.loading"), { parse_mode: "HTML" })
    const out = makeEditor(m, Rafz, wait)
    const del = () => { try { Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {}) } catch {} }

    switch (command) {

      /* ── /short url — pendekkan link (3 provider fallback: tinyurl → cleanuri POST → v.gd) ── */
      case "short":
      case "tinyurl": {
        if (!q.startsWith("http")) return out(usage("short [link]"))
        try {
          let short = null
          try {
            const t = await getText(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(q)}`)
            if (t && t.startsWith("http")) short = t.trim()
          } catch {}
          if (!short) {
            /* cleanuri pakai POST form-urlencoded (GET selalu HTTP 400) */
            try {
              const res = await fetch("https://cleanuri.com/api/v1/shorten", {
                method: "POST",
                headers: { "Content-Type": "application/x-www-form-urlencoded" },
                body: "url=" + encodeURIComponent(q)
              })
              const j = await res.json()
              if (j && j.result_url) short = j.result_url
            } catch {}
          }
          if (!short) {
            try {
              const t = await getText(`https://v.gd/create.php?format=simple&url=${encodeURIComponent(q)}`)
              if (t && t.startsWith("http")) short = t.trim()
            } catch {}
          }
          if (!short) throw new Error("Semua layanan shortlink gagal. Coba lagi nanti.")
          return out(`🔗 <b>Shortlink</b>\n\nAsli : <code>${q}</code>\nPendek : <a href="${short}">${short}</a>`)
        } catch (e) { return out("❌ " + e.message) }
      }

      /* ── /qr teks — buat QR code ── */
      case "qr":
      case "qrcode": {
        if (!q) return out(usage("qr [teks]"))
        del()
        try {
          const url = `https://api.qrserver.com/v1/create-qr-code/?size=500x500&data=${encodeURIComponent(q)}`
          const buf = await getBuffer(url)
          await Rafz.sendPhoto(m.chat, buf, {
            caption: `✅ QR Code: <code>${q.slice(0, 100)}</code>`, parse_mode: "HTML",
            reply_to_message_id: m.id, allow_sending_without_reply: true
          })
        } catch (e) { return m.reply("❌ " + e.message) }
        return true
      }

      /* ── /calc ekspresi — kalkulator ── */
      case "calc":
      case "math": {
        if (!q) return out(usage("calc 12*(3+4)"))
        const expr = q.replace(/[^0-9+\-*/().,%\s^]/g, "").replace(/\^/g, "**")
        if (!expr.trim()) return out("❌ " + tr("util.badExpr"))
        try {
          const val = Function(`"use strict";return (${expr})`)()
          if (typeof val !== "number" || !isFinite(val)) throw new Error("hasil tidak valid")
          return out(`🧮 <b>Kalkulator</b>\n\n<code>${q}</code>\n= <b>${val}</b>`)
        } catch (e) { return out("❌ Ekspresi tidak valid") }
      }

      /* ── /weather kota — cuaca (wttr.in) ── */
      case "weather":
      case "cuaca": {
        if (!q) return out(usage("weather Jakarta"))
        try {
          const t = await getText(`https://wttr.in/${encodeURIComponent(q)}?format=j1`)
          const j = JSON.parse(t)
          const cur = j.current_condition?.[0]
          if (!cur) throw new Error("data kosong")
          const area = j.nearest_area?.[0]?.areaName?.[0]?.value || q
          return out(
            `🌤️ <b>Cuaca: ${area}</b>\n\n` +
            `🌡️ Suhu : ${cur.temp_C}°C (terasa ${cur.FeelsLikeC}°C)\n` +
            `☁️ ${cur.weatherDesc?.[0]?.value || "-"}\n` +
            `💧 Kelembapan : ${cur.humidity}%\n` +
            `💨 Angin : ${cur.windspeedKmph} km/j\n` +
            `👁️ Jarak pandang : ${cur.visibility} km\n` +
            `🌅 sunrise ${j.weather?.[0]?.astronomy?.[0]?.sunrise || "-"} / 🌇 sunset ${j.weather?.[0]?.astronomy?.[0]?.sunset || "-"}`
          )
        } catch (e) { return out("❌ Kota tidak ditemukan") }
      }

      /* ── /wiki kata — Wikipedia (REST → Action API fallback, anti "Data tidak ditemukan") ── */
      case "wiki":
      case "wikipedia": {
        if (!q) return out(usage("wiki Jakarta"))
        try {
          const lang = (m.lang === "en") ? "en" : "id"
          const WHDRS = { "User-Agent": "RafzBot/1.0 (Telegram bot; contact owner)" }
          /* 1. summary REST — judul yang persis */
          try {
            const r = await fetch(`https://${lang}.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(q)}`, { headers: WHDRS })
            if (r.ok) {
              const j = await r.json()
              if (j && j.extract && j.extract.trim()) {
                return out(
                  `📖 <b>${j.title}</b>${j.type === "disambiguation" ? " (halaman disambiguasi)" : ""}\n\n` +
                  `${j.extract}\n\n` +
                  (j.content_urls?.desktop?.page ? `🔗 ${j.content_urls.desktop.page}` : "")
                )
              }
            }
          } catch {}
          /* 2. query Action API — cari artikel paling relevan lalu ambil extract-nya */
          try {
            const sr = await fetch(`https://${lang}.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(q)}&format=json&srlimit=3`, { headers: WHDRS })
            if (sr.ok) {
              const sj = await sr.json()
              const hit = sj?.query?.search?.[0]
              if (hit) {
                try {
                  const r2 = await fetch(`https://${lang}.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(hit.title)}`, { headers: WHDRS })
                  if (r2.ok) {
                    const j2 = await r2.json()
                    if (j2 && j2.extract && j2.extract.trim()) {
                      return out(`📖 <b>${j2.title}</b>\n\n${j2.extract}\n\n${j2.content_urls?.desktop?.page ? "🔗 " + j2.content_urls.desktop.page : ""}`)
                    }
                  }
                } catch {}
                const snippet = String(hit.snippet || "").replace(/<[^>]+>/g, "")
                return out(`📖 <b>${hit.title}</b>\n\n${snippet}...\n\n🔗 https://${lang}.wikipedia.org/wiki/${encodeURIComponent(hit.title.replace(/\s/g, "_"))}`)
              }
            }
          } catch {}
          /* 3. saran opensearch */
          try {
            const os = await fetch(`https://${lang}.wikipedia.org/w/api.php?action=opensearch&limit=5&search=${encodeURIComponent(q)}&format=json`, { headers: WHDRS })
            if (os.ok) {
              const oj = await os.json()
              const results = oj?.[1] || []
              if (results.length) {
                return out(`🔍 <b>Artikel tidak ditemukan</b> — mungkin maksud Anda:\n\n` + results.map((t, i) => `${i + 1}. ${t}`).join("\n"))
              }
            }
          } catch {}
          /* 4. coba bahasa lain sebelum menyerah */
          const altLang = lang === "id" ? "en" : "id"
          try {
            const r3 = await fetch(`https://${altLang}.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(q)}`, { headers: WHDRS })
            if (r3.ok) {
              const j3 = await r3.json()
              if (j3 && j3.extract && j3.extract.trim()) {
                return out(`📖 <b>${j3.title}</b> (${altLang})\n\n${j3.extract}`)
              }
            }
          } catch {}
          return out("❌ Tidak ditemukan hasil untuk: " + q)
        } catch (e) { return out("❌ Wikipedia error: " + (e.message || "Data tidak ditemukan")) }
      }

      /* ── /tr id Halo — terjemahan ── */
      case "tr":
      case "translate": {
        const parts = q.split(/\s+/)
        const to = parts[0] && /^[a-z]{2}$/.test(parts[0].toLowerCase()) ? parts.shift().toLowerCase() : (m.lang === "en" ? "id" : "en")
        const body = parts.join(" ").trim()
        if (!body) return out(usage(`tr [kode_bahasa] teks`))
        try {
          const j = await getJSON(`https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${to}&dt=t&q=${encodeURIComponent(body)}`)
          const res = j?.[0]?.map(x => x?.[0]).join("") || ""
          const from = j?.[2] || "?"
          return out(`🌐 <b>Terjemahan</b> (${from} → ${to})\n\n${res}`)
        } catch (e) { return out("❌ " + e.message) }
      }

      /* ── /ip 8.8.8.8 — info IP ── */
      case "ip":
      case "ipinfo": {
        if (!q) return out(usage("ip 8.8.8.8"))
        try {
          const j = await getJSON(`http://ip-api.com/json/${encodeURIComponent(q)}?fields=status,message,country,regionName,city,zip,lat,lon,timezone,isp,org,as,query`)
          if (j.status !== "success") throw new Error(j.message || "fail")
          return out(
            `🌐 <b>Info IP</b>\n\n` +
            `🆔 IP : <code>${j.query}</code>\n` +
            `🌏 Negara : ${j.country}\n` +
            `🏙️ Kota : ${j.city}, ${j.regionName} ${j.zip}\n` +
            `📍 Map : https://maps.google.com/?q=${j.lat},${j.lon}\n` +
            `🏢 ISP : ${j.isp}\n` +
            `🕒 Zona : ${j.timezone}`
          )
        } catch (e) { return out("❌ " + tr("util.notFound")) }
      }

      /* ── /github user — profil GitHub ── */
      case "github":
      case "ghuser": {
        if (!q) return out(usage("github username"))
        try {
          const j = await getJSON(`https://api.github.com/users/${encodeURIComponent(q)}`, { "User-Agent": UA })
          if (j.message) throw new Error(j.message)
          return out(
            `🐙 <b>GitHub</b>\n\n` +
            `👤 ${j.name || j.login}\n` +
            `🆔 @${j.login}\n` +
            (j.bio ? `📝 ${j.bio}\n` : "") +
            `📦 Repo publik : ${j.public_repos}\n` +
            `👥 Followers : ${j.followers} · Following : ${j.following}\n` +
            `📍 ${j.location || "-"}\n` +
            `🔗 ${j.html_url}`
          )
        } catch (e) { return out("❌ User tidak ditemukan") }
      }

      /* ── /npm paket — info package npm ── */
      case "npm":
      case "npmpkg": {
        if (!q) return out(usage("npm axios"))
        try {
          const j = await getJSON(`https://registry.npmjs.org/${encodeURIComponent(q)}`)
          const latest = j["dist-tags"]?.latest || "?"
          const v = j.versions?.[latest] || {}
          return out(
            `📦 <b>npm: ${j.name}</b>\n\n` +
            `🏷️ Versi terbaru : <code>${latest}</code>\n` +
            `📝 ${v.description || "-"}\n` +
            `👤 ${v.author?.name || "-"}\n` +
            `📜 License : ${v.license || "-"}\n` +
            `🔗 https://www.npmjs.com/package/${j.name}`
          )
        } catch (e) { return out("❌ Paket tidak ditemukan") }
      }

      /* ── /pass [panjang] — generator password ── */
      case "pass":
      case "password": {
        const len = Math.min(64, Math.max(8, parseInt(q) || 16))
        const chars = "ABCDEFGHJKLMNPQRSTUVWXYZabcdefghjkmnpqrstuvwxyz23456789!@#$%^&*()-_=+"
        let pass = ""
        const bytes = crypto.randomBytes(len)
        for (let i = 0; i < len; i++) pass += chars[bytes[i] % chars.length]
        return out(`🔐 <b>Password (${len} karakter)</b>\n\n<code>${pass}</code>\n\n💡 <i>${tr("util.passHint")}</i>`)
      }

      /* ── /b64 enc|dec teks — base64 ── */
      case "b64":
      case "base64": {
        const parts = q.split(/\s+/)
        const mode = (parts[0] || "").toLowerCase()
        const body = parts.slice(1).join(" ")
        if ((mode !== "enc" && mode !== "dec") || !body) return out(usage("b64 enc|dec teks"))
        const res = mode === "enc"
          ? Buffer.from(body, "utf8").toString("base64")
          : Buffer.from(body, "base64").toString("utf8")
        return out(`🔄 <b>Base64 (${mode === "enc" ? "encode" : "decode"})</b>\n\n<code>${res}</code>`)
      }

      /* ── /hash md5|sha1|sha256 teks ── */
      case "hash": {
        const parts = q.split(/\s+/)
        const algo = (parts[0] || "sha256").toLowerCase()
        const body = parts.slice(1).join(" ")
        if (!["md5", "sha1", "sha256", "sha512"].includes(algo)) return out(usage("hash md5|sha1|sha256|sha512 teks"))
        if (!body) return out(usage("hash md5|sha1|sha256|sha512 teks"))
        const h = crypto.createHash(algo).update(body).digest("hex")
        return out(`#️⃣ <b>${algo.toUpperCase()}</b>\n\n<code>${h}</code>`)
      }

      /* ── /time kota — waktu lokasi ── */
      case "time":
      case "waktu": {
        if (!q) return out(usage("time Jakarta"))
        try {
          const j = await getJSON(`http://ip-api.com/json/${encodeURIComponent(q)}?fields=status,country,city,timezone`)
          if (j.status !== "success") throw new Error("fail")
          const now = new Date().toLocaleString("id-ID", { timeZone: j.timezone, dateStyle: "full", timeStyle: "medium" })
          return out(`🕒 <b>${j.city}, ${j.country}</b>\n\n${now}\n(Zona: ${j.timezone})`)
        } catch (e) { return out("❌ " + tr("util.notFound")) }
      }

      /* ── /ss url — screenshot website ── */
      case "ss":
      case "screenshot": {
        if (!q.startsWith("http")) return out(usage("ss https://example.com"))
        del()
        try {
          const url = `https://image.thum.io/get/width/1280/crop/900/${q}`
          const buf = await getBuffer(url)
          await Rafz.sendPhoto(m.chat, buf, {
            caption: `📸 Screenshot: <code>${q.slice(0, 100)}</code>`, parse_mode: "HTML",
            reply_to_message_id: m.id, allow_sending_without_reply: true
          })
        } catch (e) { return m.reply("❌ " + e.message) }
        return true
      }

      /* ── /tts kode teks — text to speech ──
         FIX EFATAL "Unsupported Buffer file-type": kirim sebagai DOCUMENT
         dengan filename .mp3 + contentType eksplisit (NTBA_FIX_350 aktif,
         jadi buffer tak dikenal pun tetap valid), bukan VOICE mentah. */
      case "tts":
      case "voice": {
        const parts = q.split(/\s+/)
        const lang = parts[0] && /^[a-z]{2}$/.test(parts[0].toLowerCase()) ? parts.shift().toLowerCase() : (m.lang === "en" ? "en" : "id")
        const body = parts.join(" ").trim()
        if (!body) return out(usage("tts [kode] teks"))
        del()
        const sendTtsAudio = async (buf) => {
          /* filename + contentType eksplisit → lib tidak perlu mendeteksi type buffer */
          try {
            await Rafz.sendVoice(m.chat, buf, {
              reply_to_message_id: m.id, allow_sending_without_reply: true
            })
            return
          } catch {}
          try {
            await Rafz.sendAudio(m.chat, buf, {
              title: "TTS: " + body.slice(0, 30),
              filename: "tts.mp3", contentType: "audio/mpeg",
              reply_to_message_id: m.id, allow_sending_without_reply: true
            })
            return
          } catch {}
          await Rafz.sendDocument(m.chat, buf, {
            filename: "tts.mp3", contentType: "audio/mpeg",
            caption: "🔊 Text to Speech",
            reply_to_message_id: m.id, allow_sending_without_reply: true
          })
        }
        try {
          const url = `https://translate.google.com/translate_tts?ie=UTF-8&tl=${lang}&client=tw-ob&q=${encodeURIComponent(body.slice(0, 200))}`
          const buf = await getBuffer(url, { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/125.0 Safari/537.36", "Referer": "https://translate.google.com/" })
          if (!buf || buf.length < 200) throw new Error("Audio kosong")
          await sendTtsAudio(buf)
        } catch (e) {
          try {
            const voiceMap = {
              id: "Aditi", en: "Brian", ja: "Mizuki", ko: "Seoyeon",
              zh: "Zhiyu", de: "Vicki", fr: "Celine", es: "Conchita",
              it: "Carla", pt: "Camila", ru: "Tatyana", nl: "Lotte",
              pl: "Ewa", sv: "Astrid", tr: "Filiz", ar: "Zeina",
              hi: "Aditi", th: "Niwat", vi: "Chi"
            }
            const voice = voiceMap[lang] || "Brian"
            const fallbackUrl = `https://api.streamelements.com/kappa/v2/speech?voice=${encodeURIComponent(voice)}&text=${encodeURIComponent(body.slice(0, 500))}`
            const buf2 = await getBuffer(fallbackUrl)
            if (!buf2 || buf2.length < 200) throw new Error("Fallback juga gagal")
            await sendTtsAudio(buf2)
          } catch (e2) { return m.reply("❌ TTS gagal: " + (e2.message || e.message)) }
        }
        return true
      }

      /* ── /getid — id chat/user/pesan ── */
      case "getid":
      case "idchat": {
        return out(
          `🆔 <b>ID Info</b>\n\n` +
          `👤 User : <code>${m.sender}</code>\n` +
          `💬 Chat : <code>${m.chat}</code>\n` +
          `✉️ Pesan : <code>${m.id}</code>` +
          (m.quoted ? `\n↩️ Reply dari : <code>${m.quoted.sender || "-"}</code>` : "")
        )
      }

      /* ── /define kata — kamus Inggris ── */
      case "define":
      case "kamus": {
        if (!q) return out(usage("define hello"))
        try {
          /* datamuse dulu (cepat & stabil), dictionaryapi fallback (lambat tapi kaya format) */
          const dj = await getJSON(`https://api.datamuse.com/words?sp=${encodeURIComponent(q)}&md=d&max=1`)
          const d0 = Array.isArray(dj) ? dj[0] : null
          if (d0 && Array.isArray(d0.defs) && d0.defs.length) {
            const defs = d0.defs.slice(0, 3).map(d => {
              const i = d.indexOf("\t")
              const pos = i > 0 ? d.slice(0, i) : ""
              const mean = i > 0 ? d.slice(i + 1) : d
              return (pos ? `<b>(${pos})</b> ` : "") + mean
            })
            return out(`📚 <b>${d0.word || q}</b>\n\n` + defs.map((d, i) => `💡 ${d}`).join("\n\n"))
          }
          const j = await getJSON(`https://api.dictionaryapi.dev/api/v2/entries/en/${encodeURIComponent(q)}`)
          const e0 = j?.[0]
          const mean = e0?.meanings?.[0]
          return out(
            `📚 <b>${e0?.word || q}</b>\n\n` +
            `🔊 /${e0?.phonetic || "-"}/\n` +
            `🏷️ ${mean?.partOfSpeech || "-"}\n\n` +
            `💡 ${mean?.definitions?.[0]?.definition || "-"}\n` +
            (mean?.definitions?.[0]?.example ? `\n📌 "<i>${mean.definitions[0].example}</i>"` : "")
          )
        } catch (e) { return out("❌ " + tr("util.notFound")) }
      }

      default:
        del()
        return false
    }
  } catch (e) {
    console.error("[utility]", command, e?.message)
    try { await m.reply("⚠️ Error: " + (e?.message || e)) } catch {}
    return false
  }
}

handler.command = [
  "short", "tinyurl", "qr", "qrcode", "calc", "math",
  "weather", "cuaca", "wiki", "wikipedia", "tr", "translate",
  "ip", "ipinfo", "github", "ghuser", "npm", "npmpkg",
  "pass", "password", "b64", "base64", "hash",
  "time", "waktu", "ss", "screenshot", "tts", "voice",
  "getid", "idchat", "define", "kamus"
]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
