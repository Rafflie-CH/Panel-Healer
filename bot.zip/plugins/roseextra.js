/* roseextra.js — Rose/Barker/Protectron spec part-2 (porting fitur yang belum ada).
   Info dasar (id/info/rules/privacy), admin mgmt (promote/demote/admincache/adminerror/anonadmin),
   logging (log/nolog/setlog), disable config (disableable/disabledel/disableadmin/cleancommand),
   fed extras (renamefed/myfeds/fedadmins/feddemote/fedstat/fedsubs), bot2bot, export/import,
   AFK, gif (tenor), ud (urbandictionary), ping, markdownhelp, captcha/flood extras,
   addhelper (Barker), welcome_set alias, mutegc/invitelink.
   Enforcement ringan (afk reply + disabled check) via global.roseMsgHook chain.
   Semua reply i18n (m.t) + tombol berstyle. */

"use strict"
const gstore = require("../library/gstore")
const https = require("https")

const esc = (s) => String(s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")

const fetchText = (url) => new Promise((resolve, reject) => {
  const req = https.get(url, { headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36", "Accept-Language": "en-US,en;q=0.9" }, timeout: 12000 }, (res) => {
    if (res.statusCode !== 200) { res.resume(); return reject(new Error("HTTP " + res.statusCode)) }
    let d = ""
    res.on("data", (c) => { d += c; if (d.length > 3e6) req.destroy() })
    res.on("end", () => resolve(d))
  })
  req.on("timeout", () => req.destroy(new Error("timeout")))
  req.on("error", reject)
})

const isAdminChat = async (m, Rafz, uid) => {
  try {
    if ((global.owner || []).includes(uid)) return true
    const admins = await Rafz.getChatAdministrators(m.chat)
    return admins.some(a => String(a.user?.id) === String(uid))
  } catch { return false }
}

const targetOf = (m, text) => {
  if (m.quoted?.sender) return String(m.quoted.sender)
  const t = String(text || "").trim()
  if (/^\d{5,}$/.test(t)) return t
  const um = t.match(/@([a-zA-Z0-9_]{4,})/)
  if (um) return "@" + um[1]
  const ent = (m.entities || []).find(e => e.type === "text_mention" && e.user)
  if (ent) return String(ent.user.id)
  return null
}

const fmtUser = (u) => {
  if (!u) return "-"
  const name = [u.first_name, u.last_name].filter(Boolean).join(" ") || String(u.id)
  const un = u.username ? " @" + u.username : ""
  return "<a href=\"tg://user?id=" + u.id + "\">" + esc(name) + "</a>" + un + " (<code>" + u.id + "</code>)"
}

const LOG_CATS = ["settings", "admin", "user", "automated", "reports", "other"]
const LOCKABLE = [
  "connect", "disconnect", "ban", "mute", "kick", "warn", "purge", "lock", "blocklist",
  "setflood", "antiraid", "captcha", "welcome", "goodbye", "filter", "save", "get",
  "disable", "enable", "rules", "setrules", "promote", "demote", "report", "pin", "unpin",
  "newfed", "fban", "status", "all", "callone", "setme", "unreg"
]

const handler = async (m, { Rafz, command, text }) => {
  try {
    const tr = (key, vars) => (m.t ? m.t(key, vars) : key)
    const uid = String(m.sender)
    const chat = String(m.chat)
    const q = String(text || "").trim()
    const kb1 = (label, data) => ({ inline_keyboard: [[{ text: label, callback_data: data, style: "primary" }]] })

    /* ═══ dasar: id / info ═══ */
    if (command === "id") {
      const tid = targetOf(m, q)
      if (tid && m.quoted) {
        const nm = m.quoted.pushName || m.quoted.name || String(tid)
        return m.reply("🆔 <b>" + tr("rose.userId") + "</b>\n" + fmtUser({ id: tid, first_name: nm }), { parse_mode: "HTML" })
      }
      if (tid && /^@/.test(tid)) {
        try {
          const c = await Rafz.getChat(tid)
          return m.reply("🆔 <b>" + tr("rose.userId") + "</b>\n" + fmtUser(c), { parse_mode: "HTML" })
        } catch { return m.reply("❌ " + tr("common.failed"), { parse_mode: "HTML" }) }
      }
      return m.reply("🆔 <b>" + tr("rose.chatId") + "</b>: <code>" + esc(chat) + "</code>\n🧑 <b>" + tr("rose.userId") + "</b>: <code>" + uid + "</code>", { parse_mode: "HTML" })
    }

    if (command === "info") {
      let u = null
      if (m.quoted) { try { u = (await Rafz.getChatMember(chat, String(m.quoted.sender))).user } catch { u = null } }
      else if (q) {
        const t = targetOf(m, q)
        try { u = (await Rafz.getChat(t && t.startsWith("@") ? t : chat)).id ? (await Rafz.getChatMember(chat, t && !t.startsWith("@") ? t : uid)).user : null } catch {}
      }
      if (!u) { try { u = (await Rafz.getChatMember(chat, uid)).user } catch {} }
      if (!u) return m.reply("❌ " + tr("common.failed"), { parse_mode: "HTML" })
      const mem = await Rafz.getChatMember(chat, String(u.id)).catch(() => null)
      const st = mem ? mem.status : "-"
      return m.reply(
        "ℹ️ <b>USER INFO</b>\n\n" +
        "👤 " + fmtUser(u) + "\n" +
        "🤖 <b>BOT</b>: " + (u.is_bot ? "✅" : "❌") + "\n" +
        "⭐ <b>PREMIUM</b>: " + (u.is_premium ? "✅" : "❌") + "\n" +
        "🛡 <b>" + tr("rose.status") + "</b>: <b>" + esc(st) + "</b>",
        { parse_mode: "HTML" }
      )
    }

    /* ═══ rules (set via gstore — konsisten dgn roseprotect) ═══ */
    if (command === "rules") {
      const r = gstore.get("rules", chat, null)
      return m.reply("📜 <b>RULES</b>\n\n" + (r ? esc(String(r).slice(0, 1500)) : "— " + tr("rose.noRules") + " <code>/setrules &lt;" + tr("rose.rulesPh") + "&gt;</code>"), { parse_mode: "HTML" })
    }
    if (command === "setrules") {
      if (!await isAdminChat(m, Rafz, uid)) return m.reply("⚠️ " + tr("rose.adminOnly"), { parse_mode: "HTML" })
      if (!q) return m.reply("⚠️ <code>/setrules " + tr("rose.rulesPh") + "</code>", { parse_mode: "HTML" })
      gstore.set("rules", chat, q)
      return m.reply("✅ " + tr("rose.rulesSaved"), { parse_mode: "HTML" })
    }
    if (command === "clearrules") {
      if (!await isAdminChat(m, Rafz, uid)) return m.reply("⚠️ " + tr("rose.adminOnly"), { parse_mode: "HTML" })
      gstore.del("rules", chat)
      return m.reply("✅ " + tr("rose.rulesCleared"), { parse_mode: "HTML" })
    }

    /* ═══ privacy ═══ */
    if (command === "privacy") {
      return m.reply(
        "🔒 <b>PRIVACY</b>\n\n" +
        "• <b>ID</b>: " + tr("rose.priv1") + "\n" +
        "• <b>" + tr("rose.rules") + "/notes/filters</b>: " + tr("rose.priv2") + "\n" +
        "• <b>Warnings</b>: " + tr("rose.priv3") + "\n" +
        "• " + tr("rose.priv4"),
        { parse_mode: "HTML", reply_markup: kb1("🌐 missrose.org", "/roseprivacy") }
      )
    }

    /* ═══ admin management ═══ */
    if (command === "promote" || command === "demote") {
      if (!m.isGroup) return m.reply("⚠️ " + tr("rose.groupOnly"), { parse_mode: "HTML" })
      if (!await isAdminChat(m, Rafz, uid)) return m.reply("⚠️ " + tr("rose.adminOnly"), { parse_mode: "HTML" })
      const tgt = targetOf(m, q)
      if (!tgt || !/^\d+$/.test(tgt)) return m.reply("⚠️ " + tr("rose.needTarget"), { parse_mode: "HTML" })
      const up = command === "promote"
      try {
        await Rafz.promoteChatMember(chat, tgt, {
          can_manage_chat: up, can_delete_messages: up, can_restrict_members: up,
          can_invite_users: up, can_pin_messages: up, can_promote_members: false, can_change_info: false
        })
        return m.reply((up ? "⬆️ " : "⬇️ ") + (up ? tr("rose.promoted") : tr("rose.demoted")) + " <code>" + esc(tgt) + "</code>", { parse_mode: "HTML" })
      } catch (e) {
        return m.reply("❌ " + tr("rose.promoteMe") + "\n<code>" + esc(String(e.message || e).slice(0, 80)) + "</code>", { parse_mode: "HTML" })
      }
    }
    if (command === "admincache") {
      if (!m.isGroup) return m.reply("⚠️ " + tr("rose.groupOnly"), { parse_mode: "HTML" })
      const admins = await Rafz.getChatAdministrators(chat).catch(() => [])
      global.roseAdminCache = global.roseAdminCache || {}
      global.roseAdminCache[chat] = { admins, at: Date.now() }
      return m.reply("♻️ " + tr("rose.adminCache") + " <b>" + admins.length + "</b>", { parse_mode: "HTML" })
    }
    if (command === "adminerror" || command === "anonadmin") {
      if (!m.isGroup) return m.reply("⚠️ " + tr("rose.groupOnly"), { parse_mode: "HTML" })
      if (!await isAdminChat(m, Rafz, uid)) return m.reply("⚠️ " + tr("rose.adminOnly"), { parse_mode: "HTML" })
      const col = command === "adminerror" ? "adminerror" : "anonadmin"
      if (/^(on|off)$/i.test(q)) {
        gstore.set(col, chat, q.toLowerCase() === "on")
        return m.reply("✅ <b>" + command + "</b>: " + (q.toLowerCase() === "on" ? "ON ✅" : "OFF ❌"), { parse_mode: "HTML" })
      }
      const cur = gstore.get(col, chat, false)
      return m.reply("<b>" + command + "</b>: " + (cur ? "ON ✅" : "OFF ❌") + "\n<code>/" + command + " on|off</code>", { parse_mode: "HTML" })
    }

    /* ═══ group-wide mute + link (dari roseprotect lama, versi i18n) ═══ */
    if (command === "mutegc" || command === "unmutegc") {
      if (!m.isGroup) return m.reply("⚠️ " + tr("rose.groupOnly"), { parse_mode: "HTML" })
      if (!await isAdminChat(m, Rafz, uid)) return m.reply("⚠️ " + tr("rose.adminOnly"), { parse_mode: "HTML" })
      const mute = command === "mutegc"
      try {
        await Rafz.setChatPermissions(chat, {
          can_send_messages: !mute, can_send_media_messages: !mute, can_send_polls: !mute,
          can_send_other_messages: !mute, can_add_web_page_previews: !mute, can_invite_users: true
        })
        return m.reply((mute ? "🔇 " : "🔊 ") + tr(mute ? "rose.gcMuted" : "rose.gcUnmuted"), { parse_mode: "HTML" })
      } catch { return m.reply("❌ " + tr("rose.botAdmin"), { parse_mode: "HTML" }) }
    }
    if (command === "grouplink" || command === "invitelink") {
      if (!m.isGroup) return m.reply("⚠️ " + tr("rose.groupOnly"), { parse_mode: "HTML" })
      try {
        const link = await Rafz.exportChatInviteLink(chat)
        return m.reply("🔗 <b>" + tr("rose.groupLink") + "</b>\n\n" + esc(link), { parse_mode: "HTML" })
      } catch { return m.reply("❌ " + tr("rose.botAdmin"), { parse_mode: "HTML" }) }
    }

    /* ═══ logging ═══ */
    if (command === "logcategories") {
      return m.reply("🗂 <b>LOG CATEGORIES</b>\n\n" + LOG_CATS.map(c => "• <code>" + c + "</code>").join("\n"), { parse_mode: "HTML" })
    }
    if (command === "log" || command === "nolog") {
      if (!await isAdminChat(m, Rafz, uid)) return m.reply("⚠️ " + tr("rose.adminOnly"), { parse_mode: "HTML" })
      if (!q || !LOG_CATS.includes(q.toLowerCase())) {
        const cats = gstore.arrGet("logcat", chat)
        return m.reply("🗂 <b>LOGS</b>: " + (cats.length ? cats.map(c => "<code>" + c + "</code>").join(", ") : "—") + "\n<code>/log " + LOG_CATS.join("|") + "</code>", { parse_mode: "HTML" })
      }
      const cat = q.toLowerCase()
      const cur = command === "log" ? gstore.arrAdd("logcat", chat, cat) : gstore.arrRemove("logcat", chat, cat)
      return m.reply("✅ <b>" + command + " " + cat + "</b> (" + cur.length + ")", { parse_mode: "HTML" })
    }
    if (command === "setlog" || command === "unsetlog") {
      if (!await isAdminChat(m, Rafz, uid)) return m.reply("⚠️ " + tr("rose.adminOnly"), { parse_mode: "HTML" })
      if (command === "unsetlog") { gstore.del("logch", chat); return m.reply("✅ " + tr("rose.done"), { parse_mode: "HTML" }) }
      if (!q) return m.reply("⚠️ <code>/setlog -100xxxx</code>", { parse_mode: "HTML" })
      gstore.set("logch", chat, q)
      return m.reply("✅ " + tr("rose.logSet") + " <code>" + esc(q) + "</code>", { parse_mode: "HTML" })
    }

    /* ═══ silent actions + disable config ═══ */
    if (command === "silentactions" || command === "disabledel" || command === "disableadmin") {
      if (!m.isGroup) return m.reply("⚠️ " + tr("rose.groupOnly"), { parse_mode: "HTML" })
      if (!await isAdminChat(m, Rafz, uid)) return m.reply("⚠️ " + tr("rose.adminOnly"), { parse_mode: "HTML" })
      const col = "cfg:" + command
      if (/^(on|off)$/i.test(q)) {
        gstore.set(col, chat, q.toLowerCase() === "on")
        return m.reply("✅ <b>" + command + "</b>: " + (q.toLowerCase() === "on" ? "ON ✅" : "OFF ❌"), { parse_mode: "HTML" })
      }
      const cur = gstore.get(col, chat, false)
      return m.reply("<b>" + command + "</b>: " + (cur ? "ON ✅" : "OFF ❌") + "\n<code>/" + command + " on|off</code>", { parse_mode: "HTML" })
    }
    if (command === "disableable") {
      return m.reply("🔓 <b>DISABLEABLE</b>\n\n" + LOCKABLE.map(c => "<code>" + c + "</code>").join(", "), { parse_mode: "HTML" })
    }
    if (command === "cleancommand" || command === "keepcommand") {
      if (!m.isGroup) return m.reply("⚠️ " + tr("rose.groupOnly"), { parse_mode: "HTML" })
      if (!await isAdminChat(m, Rafz, uid)) return m.reply("⚠️ " + tr("rose.adminOnly"), { parse_mode: "HTML" })
      const t = q.toLowerCase() || "user"
      if (!["all", "admin", "user", "other"].includes(t)) return m.reply("⚠️ <code>/cleancommand all|admin|user|other</code>", { parse_mode: "HTML" })
      gstore.set("cleancommand", chat, command === "cleancommand" ? t : "off")
      return m.reply("✅ <b>cleancommand</b>: <b>" + (command === "cleancommand" ? t : "OFF") + "</b>", { parse_mode: "HTML" })
    }
    if (command === "cleancommandtypes") {
      return m.reply("🧹 <b>CLEAN TYPES</b>: <code>all admin user other</code>", { parse_mode: "HTML" })
    }

    /* ═══ federation extras ═══ */
    if (command === "renamefed") {
      const fid = gstore.get("feds", "u" + uid)
      if (!fid) return m.reply("⚠️ " + tr("rose.noFed"), { parse_mode: "HTML" })
      if (!q) return m.reply("⚠️ <code>/renamefed " + tr("rose.fedName") + "</code>", { parse_mode: "HTML" })
      const fed = gstore.get("feds", fid)
      if (fed.owner !== uid) return m.reply("⚠️ " + tr("rose.fedOwner"), { parse_mode: "HTML" })
      fed.name = q
      gstore.set("feds", fid, fed)
      return m.reply("✅ " + tr("rose.fedRenamed") + " <b>" + esc(q) + "</b>", { parse_mode: "HTML" })
    }
    if (command === "myfeds") {
      const fid = gstore.get("feds", "u" + uid)
      if (!fid) return m.reply("⚠️ " + tr("rose.noFed"), { parse_mode: "HTML" })
      const fed = gstore.get("feds", fid)
      return m.reply("🌐 <b>MY FED</b>\n\n<b>" + esc(fed.name) + "</b> (<code>" + fid + "</code>)\n👥 " + tr("rose.fedChats") + ": <b>" + (fed.chats || []).length + "</b>", { parse_mode: "HTML" })
    }
    if (command === "fedadmins") {
      const fid = gstore.get("feds", "c" + chat) || gstore.get("feds", "u" + uid)
      if (!fid) return m.reply("⚠️ " + tr("rose.noFed"), { parse_mode: "HTML" })
      const fed = gstore.get("feds", fid)
      const admins = fed.admins || []
      let out = "🛡 <b>FED ADMINS — " + esc(fed.name) + "</b>\n\n👑 <a href=\"tg://user?id=" + fed.owner + "\">" + fed.owner + "</a>\n"
      admins.forEach(a => { out += "• <a href=\"tg://user?id=" + a + "\">" + a + "</a>\n" })
      return m.reply(out, { parse_mode: "HTML" })
    }
    if (command === "feddemote") {
      const fid = gstore.get("feds", "u" + uid)
      if (!fid) return m.reply("⚠️ " + tr("rose.noFed"), { parse_mode: "HTML" })
      const fed = gstore.get("feds", fid)
      if (fed.owner !== uid) return m.reply("⚠️ " + tr("rose.fedOwner"), { parse_mode: "HTML" })
      const tgt = targetOf(m, q)
      if (!tgt || !/^\d+$/.test(tgt)) return m.reply("⚠️ " + tr("rose.needTarget"), { parse_mode: "HTML" })
      fed.admins = (fed.admins || []).filter(a => a !== tgt)
      gstore.set("feds", fid, fed)
      return m.reply("⬇️ " + tr("rose.fedDemoted") + " <code>" + esc(tgt) + "</code>", { parse_mode: "HTML" })
    }
    if (command === "fedstat") {
      const fid = gstore.get("feds", "c" + chat)
      if (!fid) return m.reply("⚠️ " + tr("rose.noFedChat"), { parse_mode: "HTML" })
      const fed = gstore.get("feds", fid)
      const tgt = targetOf(m, q)
      if (!tgt || !/^\d+$/.test(tgt)) return m.reply("⚠️ " + tr("rose.needTarget"), { parse_mode: "HTML" })
      const banned = (fed.bans || []).some(b => b.id === tgt)
      return m.reply(banned ? "🚫 " + tr("rose.fedBanned") + " <code>" + esc(tgt) + "</code>" : "✅ " + tr("rose.fedNotBanned") + " <code>" + esc(tgt) + "</code>", { parse_mode: "HTML" })
    }
    if (command === "fedsubs") {
      return m.reply("🌐 <b>FED SUBS</b>\n\n— 0 —", { parse_mode: "HTML" })
    }

    /* ═══ bot-to-bot ═══ */
    if (command === "bot2bot" || command === "bot2botskipreview") {
      if (!await isAdminChat(m, Rafz, uid)) return m.reply("⚠️ " + tr("rose.adminOnly"), { parse_mode: "HTML" })
      if (/^(off|admin|all)$/i.test(q)) {
        gstore.set("cfg:" + command, chat, q.toLowerCase())
        return m.reply("✅ <b>" + command + "</b>: <b>" + q.toUpperCase() + "</b>", { parse_mode: "HTML" })
      }
      const cur = gstore.get("cfg:" + command, chat, command === "bot2bot" ? "off" : "off")
      return m.reply("<b>" + command + "</b>: <b>" + String(cur).toUpperCase() + "</b>", { parse_mode: "HTML" })
    }

    /* ═══ export / import settings ═══ */
    if (command === "export") {
      if (!m.isGroup && !gstore.get("connections", uid)) return m.reply("⚠️ " + tr("rose.needChatId"), { parse_mode: "HTML" })
      const dump = {}
      for (const col of ["rules", "welcome", "goodbye", "locks", "blocklist", "blockmode", "antiflood", "antiraid", "captcha", "filters", "notes", "disabled", "shield", "warnconfig", "logcat", "logch"]) {
        for (const [k, v] of gstore.list(col)) {
          if (String(k) === chat || String(k).startsWith(chat + ":")) dump[col + "|" + k] = v
        }
      }
      const buf = Buffer.from(JSON.stringify({ v: 1, chat, data: dump }, null, 1))
      await Rafz.sendDocument(m.chat, buf, { filename: "rose-settings-" + chat + ".json", caption: "♻️ " + tr("rose.exported") })
      return true
    }
    if (command === "import") {
      if (!await isAdminChat(m, Rafz, uid)) return m.reply("⚠️ " + tr("rose.adminOnly"), { parse_mode: "HTML" })
      const doc = m.quoted && (m.quoted.document || (m.quoted.mimeType === "application/json" ? m.quoted : null))
      if (!m.quoted || !(m.quoted.document || m.quoted.fileName)) return m.reply("⚠️ " + tr("rose.importHint"), { parse_mode: "HTML" })
      try {
        const { getMediaBuffer } = require("../library/mediautil")
        const buf = await getMediaBuffer(m, Rafz)
        if (!buf) return m.reply("⚠️ " + tr("rose.importHint"), { parse_mode: "HTML" })
        const parsed = JSON.parse(buf.toString("utf8"))
        if (!parsed || !parsed.data) throw new Error("bad file")
        let n = 0
        for (const [ck, v] of Object.entries(parsed.data)) {
          const [col, ...rest] = ck.split("|")
          if (!rest.length) continue
          gstore.set(col, rest.join("|"), v)
          n++
        }
        return m.reply("✅ " + tr("rose.imported") + " <b>" + n + "</b>", { parse_mode: "HTML" })
      } catch (e) {
        return m.reply("❌ " + tr("rose.importFail") + " <code>" + esc(String(e.message || e).slice(0, 60)) + "</code>", { parse_mode: "HTML" })
      }
    }

    /* ═══ AFK ═══ */
    if (command === "afk") {
      gstore.set("afk", "u" + uid, q || "AFK")
      return m.reply("💤 <b>AFK</b>: " + esc(q || "AFK"), { parse_mode: "HTML" })
    }
    if (command === "unafk") {
      gstore.del("afk", "u" + uid)
      return m.reply("✅ " + tr("rose.backOnline"), { parse_mode: "HTML" })
    }

    /* ═══ gif (tenor web — API v1 mati, scrape situs) ═══ */
    if (command === "gif") {
      if (!q) return m.reply("⚠️ <code>/gif cat</code>", { parse_mode: "HTML" })
      const slug = encodeURIComponent(q.toLowerCase().replace(/[^a-z0-9 ]/g, "").trim().replace(/\s+/g, "-")) || "cat"
      try {
        const html = await fetchText("https://tenor.com/search/" + slug + "-gifs")
        const urls = [...new Set(html.match(/https:\/\/media1?\.tenor\.com\/[a-zA-Z0-9_-]+\/[a-zA-Z0-9_.%-]+\.gif/g) || [])]
        if (!urls.length) return m.reply("❌ " + tr("common.failed"), { parse_mode: "HTML" })
        const pick = urls.sort(() => Math.random() - 0.5).slice(0, 3)
        for (const u of pick) {
          try { await Rafz.sendDocument(m.chat, u, {}, { contentType: "image/gif", filename: "gif.gif" }) } catch {}
        }
        await m.reply("🎬 <b>GIF</b>: " + esc(q) + " (" + urls.length + ")", { parse_mode: "HTML" })
        return true
      } catch (e) {
        return m.reply("❌ " + tr("common.failed") + " <code>" + esc(String(e.message || e).slice(0, 50)) + "</code>", { parse_mode: "HTML" })
      }
    }

    /* ═══ urban dictionary ═══ */
    if (command === "ud") {
      if (!q) return m.reply("⚠️ <code>/ud word</code>", { parse_mode: "HTML" })
      try {
        const raw = await fetchText("https://api.urbandictionary.com/v0/define?term=" + encodeURIComponent(q))
        const j = JSON.parse(raw)
        if (!j.list || !j.list.length) return m.reply("🈳 " + tr("rose.udNo"), { parse_mode: "HTML" })
        const d = j.list[0]
        const out =
          "📖 <b>" + esc(d.word) + "</b>\n\n" +
          esc(String(d.definition || "").slice(0, 700)) + "\n\n" +
          (d.example ? "<i>" + esc(String(d.example).slice(0, 250)) + "</i>\n\n" : "") +
          "👍 " + (d.thumbs_up || 0) + " 👎 " + (d.thumbs_down || 0)
        return m.reply(out, { parse_mode: "HTML" })
      } catch { return m.reply("❌ " + tr("common.failed"), { parse_mode: "HTML" }) }
    }

    /* ═══ ping ═══ */
    if (command === "ping") {
      const lat = Math.max(0, Math.floor(Date.now() / 1000 - (m.date || Date.now() / 1000)))
      return m.reply("🏓 <b>PONG!</b>\n⏱ <b>" + tr("rose.latency") + "</b>: ~<b>" + lat + "</b> s", { parse_mode: "HTML" })
    }

    if (command === "markdownhelp") {
      return m.reply(
        "✏️ <b>MARKDOWN / HTML</b>\n\n" +
        "<code>&lt;b&gt;bold&lt;/b&gt;</code>\n<code>&lt;i&gt;italic&lt;/i&gt;</code>\n<code>&lt;u&gt;underline&lt;/u&gt;</code>\n<code>&lt;s&gt;strike&lt;/s&gt;</code>\n<code>&lt;code&gt;code&lt;/code&gt;</code>\n<code>&lt;pre&gt;pre&lt;/pre&gt;</code>\n<code>&lt;a href=\"https://x.com\"&gt;link&lt;/a&gt;</code>\n<code>&lt;a href=\"tg://user?id=123\"&gt;mention&lt;/a&gt;</code>",
        { parse_mode: "HTML" }
      )
    }

    /* ═══ captcha extras ═══ */
    if (command === "setcaptchatext" || command === "resetcaptchatext") {
      if (!await isAdminChat(m, Rafz, uid)) return m.reply("⚠️ " + tr("rose.adminOnly"), { parse_mode: "HTML" })
      if (command === "resetcaptchatext") { gstore.del("captcha", chat + ":text"); return m.reply("✅ " + tr("rose.done"), { parse_mode: "HTML" }) }
      if (!q) return m.reply("⚠️ <code>/setcaptchatext Solve me!</code>", { parse_mode: "HTML" })
      gstore.set("captcha", chat + ":text", q)
      return m.reply("✅ " + tr("rose.captchaTextSet"), { parse_mode: "HTML" })
    }
    if (command === "captcharules") {
      if (!await isAdminChat(m, Rafz, uid)) return m.reply("⚠️ " + tr("rose.adminOnly"), { parse_mode: "HTML" })
      const cur = gstore.get("captcha", chat + ":rules", false)
      const v = !cur
      gstore.set("captcha", chat + ":rules", v)
      return m.reply("📋 <b>captcharules</b>: " + (v ? "ON ✅" : "OFF ❌"), { parse_mode: "HTML" })
    }
    if (command === "captchamutetime") {
      if (!await isAdminChat(m, Rafz, uid)) return m.reply("⚠️ " + tr("rose.adminOnly"), { parse_mode: "HTML" })
      const mt = q.trim().match(/^(\d+)([smhd])$/)
      if (!mt) return m.reply("⚠️ <code>/captchamutetime 10m</code>", { parse_mode: "HTML" })
      gstore.set("captcha", chat + ":mutetime", q.trim())
      return m.reply("✅ " + tr("rose.captchaMuteSet") + " <b>" + esc(q.trim()) + "</b>", { parse_mode: "HTML" })
    }
    if (command === "captchakicktime") {
      /* delay kick setelah gagal captcha (default 5m) */
      if (!await isAdminChat(m, Rafz, uid)) return m.reply("⚠️ " + tr("rose.adminOnly"), { parse_mode: "HTML" })
      const mt = q.trim().match(/^(\d+)([smhd])$/)
      if (!mt) return m.reply("⚠️ <code>/captchakicktime 5m</code>", { parse_mode: "HTML" })
      gstore.set("captcha", chat + ":kicktime", q.trim())
      return m.reply("✅ " + tr("rose.captchaKickSet") + " <b>" + esc(q.trim()) + "</b>", { parse_mode: "HTML" })
    }
    if (command === "clearflood") {
      if (!await isAdminChat(m, Rafz, uid)) return m.reply("⚠️ " + tr("rose.adminOnly"), { parse_mode: "HTML" })
      if (/^(on|off)$/i.test(q)) {
        gstore.set("cfg:clearflood", chat, q.toLowerCase() === "on")
        return m.reply("✅ <b>clearflood</b>: " + (q.toLowerCase() === "on" ? "ON ✅" : "OFF ❌"), { parse_mode: "HTML" })
      }
      return m.reply("<b>clearflood</b>: " + (gstore.get("cfg:clearflood", chat, false) ? "ON ✅" : "OFF ❌"), { parse_mode: "HTML" })
    }

    /* ═══ ganti bahasa (Rose 1.1 / Barker 2.1) ═══ */
    if (command === "language" || command === "lang") {
      const pxl = (global.prefix && global.prefix[0]) || "/"
      const lang = q.trim().toLowerCase()
      const SUPPORTED = ["id", "en"]
      if (!lang) {
        const cur = m.lang || "id"
        return m.reply(
          "🌐 <b>" + tr("rose.language") + "</b>\n\n" +
          SUPPORTED.map(l => (l === cur ? "✅ " : "• ") + l.toUpperCase()).join("\n") +
          "\n\n💡 <code>" + pxl + "language id|en</code>",
          { parse_mode: "HTML" }
        )
      }
      if (!SUPPORTED.includes(lang)) return m.reply("⚠️ id | en", { parse_mode: "HTML" })
      const ok = m.setLang ? m.setLang(lang) : false
      return m.reply(ok ? ("✅ " + tr("rose.langSet") + ": <b>" + lang.toUpperCase() + "</b>") : "❌ " + tr("common.failed"), { parse_mode: "HTML" })
    }

    /* ═══ Barker: helper bots ═══ */
    if (command === "addhelper") {
      if (!q || q.length < 30) return m.reply("⚠️ <code>/addhelper &lt;bot_token&gt;</code>", { parse_mode: "HTML" })
      const helpers = gstore.arrGet("helpers", uid)
      if (!helpers.includes(q)) gstore.arrAdd("helpers", uid, q, 3)
      return m.reply("🤝 " + tr("rose.helperAdd") + " (" + gstore.arrGet("helpers", uid).length + "/3)", { parse_mode: "HTML" })
    }

    /* ═══ Barker: premium placeholder (free tier info) ═══ */
    if (command === "upatterns") {
      return m.reply(
        "📛 <b>UNREG PATTERNS</b>\n\n<code>{first}</code> — " + tr("rose.varFirst") + "\n<code>{username}</code> — username\n<code>{id}</code> — ID\n<code>{mention}</code> — mention",
        { parse_mode: "HTML" }
      )
    }
    if (command === "cpatterns") {
      return m.reply(
        "📣 <b>CALL PATTERNS</b>\n\n<code>{callsign}</code> — callsign\n<code>{first}</code> — " + tr("rose.varFirst") + "\n<code>{mention}</code> — mention\n\n<code>/setme 🚀Rafz</code>",
        { parse_mode: "HTML" }
      )
    }

    /* ═══ Protectron: welcome_set alias (diproses di rosenotes via alias command) ═══ */
    if (command === "admins2" || command === "adminlist2" || command === "adminlist" || command === "admins") {
      if (!m.isGroup) return m.reply("⚠️ " + tr("rose.groupOnly"), { parse_mode: "HTML" })
      const admins = await Rafz.getChatAdministrators(chat).catch(() => [])
      let out = "👑 <b>" + tr("rose.adminsTitle") + "</b> (" + admins.length + ")\n\n"
      for (const a of admins) out += "• " + fmtUser(a.user) + (a.status === "creator" ? " 👑" : "") + "\n"
      return m.reply(out, { parse_mode: "HTML" })
    }
    if (command === "report") {
      if (!m.quoted?.id && !m.replyTo) return m.reply("⚠️ " + tr("rose.replyMsg"), { parse_mode: "HTML" })
      const admins = await Rafz.getChatAdministrators(chat).catch(() => [])
      const tags = admins.filter(a => !a.user?.is_bot).map(a => '<a href="tg://user?id=' + a.user.id + '">·</a>').join("")
      await m.reply("🚨 <b>" + tr("rose.reported") + "</b> " + tags, { parse_mode: "HTML" })
      return true
    }
    if (command === "unpin") {
      if (!await isAdminChat(m, Rafz, uid)) return m.reply("⚠️ " + tr("rose.adminOnly"), { parse_mode: "HTML" })
      try { await Rafz.unpinChatMessage(chat, m.quoted?.id || undefined); return m.reply("📌 " + tr("rose.done"), { parse_mode: "HTML" }) }
      catch { return m.reply("❌ " + tr("rose.botAdmin"), { parse_mode: "HTML" }) }
    }
    if (command === "welcome_set") {
      if (!await isAdminChat(m, Rafz, uid)) return m.reply("⚠️ " + tr("rose.adminOnly"), { parse_mode: "HTML" })
      if (!q) return m.reply("⚠️ <code>/welcome_set " + tr("rose.welcomeText") + "</code>", { parse_mode: "HTML" })
      const cur = gstore.get("welcome", chat, { on: true })
      cur.on = true
      cur.text = q
      gstore.set("welcome", chat, cur)
      return m.reply("✅ " + tr("rose.welcomeSet"), { parse_mode: "HTML" })
    }

    return false
  } catch (e) {
    console.error("[roseextra]", command, e?.message)
    try { await m.reply("❌ " + esc(String(e?.message || e).slice(0, 120)), { parse_mode: "HTML" }) } catch {}
    return false
  }
}

/* hook: afk auto-reply + welcome back (disabled command ditangani handler.js) */
const afkThrottle = new Map()
handler.hook = async (m, ctx) => {
  try {
    const text = String(m.text || "")
    const cmd = (text.match(/^\/([a-zA-Z0-9_]+)/) || [])[1]
    /* afk: sapa yang di-afk saat di-reply/mention */
    const tgtId = m.quoted?.sender
    if (tgtId) {
      const reason = gstore.get("afk", "u" + tgtId)
      if (reason && String(m.sender) !== String(tgtId)) {
        const now = Date.now()
        const th = afkThrottle.get(tgtId) || 0
        if (now - th > 30000) {
          afkThrottle.set(tgtId, now)
          const nm = m.quoted.pushName || m.quoted.name || String(tgtId)
          await m.reply("💤 <a href=\"tg://user?id=" + tgtId + "\">" + esc(nm) + "</a> AFK: <i>" + esc(String(reason).slice(0, 80)) + "</i>", { parse_mode: "HTML" }).catch(() => {})
        }
      }
    }
    /* afk: user sendiri balik */
    const own = gstore.get("afk", "u" + m.sender)
    if (own && cmd !== "afk") {
      gstore.del("afk", "u" + m.sender)
      await m.reply("✅ " + (m.t ? m.t("rose.backOnline") : "welcome back"), { parse_mode: "HTML" }).catch(() => {})
    }
    return false
  } catch { return false }
}

handler.command = [
  "id", "info", "setrules", "clearrules", "privacy",
  "promote", "demote", "admincache", "adminerror", "anonadmin",
  "mutegc", "unmutegc", "grouplink", "invitelink",
  "logcategories", "log", "nolog", "setlog", "unsetlog",
  "silentactions", "disableable", "disabledel", "disableadmin",
  "cleancommand", "keepcommand", "cleancommandtypes",
  "renamefed", "myfeds", "fedadmins", "feddemote", "fedstat", "fedsubs",
  "bot2bot", "bot2botskipreview",
  "export", "import",
  "afk", "unafk",
  "gif", "ud", "ping", "markdownhelp",
  "setcaptchatext", "resetcaptchatext", "captcharules", "captchamutetime", "captchakicktime", "clearflood",
  "language", "lang",
  "addhelper", "upatterns", "cpatterns",
  "admins2", "adminlist2", "adminlist", "admins", "rules", "report", "unpin",
  "welcome_set"
]
module.exports = handler

/* pasang hook (chain global.roseMsgHook) */
try {
  const prevHook = global.roseMsgHook
  global.roseMsgHook = async (m, ctx) => {
    const a = await handler.hook(m, ctx)
    if (a === true) return true
    if (typeof prevHook === "function") return prevHook(m, ctx)
    return false
  }
} catch {}

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
