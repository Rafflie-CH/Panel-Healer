/* plugin: getpp.js — ambil foto profil user (RafzBotz) + statistik chat
   /getpp → foto profil sendiri
   /getpp @user / reply / ID → foto profil target
   /topcmd → 10 command terpopuler bot
   /topmessage → 10 user paling aktif */

"use strict"
const fs = require("fs")

const handler = async (m, { Rafz, command, text }) => {
  try {
    const px = (global.prefix && global.prefix[0]) || "/"
    const tr = (key, vars) => (m.t ? m.t(key, vars) : key)

    if (command === "getpp" || command === "getphoto" || command === "pp") {
      let target = String(m.sender)

      if (text && /^\d+$/.test(text.trim())) {
        target = text.trim()
      } else if (m.mentioned?.[0]?.id) {
        target = String(m.mentioned[0].id)
      } else if (m.quoted?.sender) {
        target = String(m.quoted.sender)
      }

      const wait = await m.reply(tr("pp.taking"), { parse_mode: "HTML" })
      try {
        const res = await Rafz.getUserProfilePhotos(target, { limit: 1 })
        const photos = res?.photos || res?.result?.photos || []
        try { Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {}) } catch {}
        if (!photos.length) return m.reply(tr("pp.none"))
        const fileId = photos[0][photos[0].length - 1].file_id
        await Rafz.sendPhoto(m.chat, fileId, {
          caption: `🖼️ ${tr("pp.caption")} <a href="tg://user?id=${target}">${target}</a>`,
          parse_mode: "HTML",
          reply_to_message_id: m.id, allow_sending_without_reply: true
        })
        return true
      } catch (e) {
        try { Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {}) } catch {}
        return m.reply(tr("pp.fail") + " " + (e?.message || tr("common.notFound")))
      }
    }

    if (command === "topcmd" || command === "topcommand") {
      let counts = {}
      try {
        const db = JSON.parse(fs.readFileSync("./library/database/cmdstats.json", "utf8"))
        counts = db && typeof db === "object" ? db : {}
      } catch {}
      const top = Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 10)
      if (!top.length) return m.reply("📊 Belum ada data command. Data terkumpul otomatis mulai sekarang.")
      let out = "📊 <b>TOP 10 COMMAND</b>\n\n"
      top.forEach(([c, n], i) => { out += `${i + 1}. <code>${c}</code> — ${n}x\n` })
      return m.reply(out, { parse_mode: "HTML" })
    }

    if (command === "topmessage" || command === "topmsg") {
      let counts = {}
      try {
        const db = JSON.parse(fs.readFileSync("./library/database/msgstats.json", "utf8"))
        counts = db && typeof db === "object" ? db : {}
      } catch {}
      const top = Object.entries(counts).sort((a, b) => b[1] - a[1]).slice(0, 10)
      if (!top.length) return m.reply("📊 Belum ada data pesan. Data terkumpul otomatis mulai sekarang.")
      let out = "💬 <b>TOP 10 USER AKTIF</b>\n\n"
      top.forEach(([id, n], i) => {
        out += `${i + 1}. <a href="tg://user?id=${id}">${id}</a> — ${n} pesan\n`
      })
      return m.reply(out, { parse_mode: "HTML" })
    }

    return false
  } catch (e) {
    console.error("[getpp]", e?.message)
    try { await m.reply("⚠️ Error: " + (e?.message || e)) } catch {}
    return false
  }
}

handler.command = ["getpp", "getphoto", "pp", "topcmd", "topcommand", "topmessage", "topmsg"]
module.exports = handler

/* ── statistik otomatis: catat setiap command & pesan (dipanggil saat load) ──
   Ditulis ke file, di-limit supaya file tidak membengkak. */
try {
  const bump = (file, key) => {
    try {
      const db = JSON.parse(fs.readFileSync(file, "utf8"))
      const map = db && typeof db === "object" ? db : {}
      map[key] = (map[key] || 0) + 1
      const entries = Object.entries(map)
      if (entries.length > 500) {
        entries.sort((a, b) => b[1] - a[1])
        for (const [k] of entries.slice(500)) delete map[k]
      }
      fs.mkdirSync(require("path").dirname(file), { recursive: true })
      fs.writeFileSync(file, JSON.stringify(map, null, 2))
    } catch {}
  }

  /* hook global dipasang sekali dari handler lewat global.cmdStatHook */
  global.cmdStatHook = global.cmdStatHook || ((cmd) => bump("./library/database/cmdstats.json", String(cmd)))
  global.msgStatHook = global.msgStatHook || ((sender) => bump("./library/database/msgstats.json", String(sender)))
} catch {}

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
