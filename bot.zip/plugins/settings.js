/* plugin: settings.js - /set untuk ubah settings tanpa edit file */
"use strict"
const fs = require("fs")
const path = require("path")
const SETTINGS_PATH = path.join(__dirname, "..", "settings.js")

const handler = async (m, { Rafz, command, text }) => {
  try {
    const sender = String(m.sender)
    const isCreator = (global.owner || []).includes(sender)
    const tr = (key, vars) => (m.t ? m.t(key, vars) : key)
    if (!isCreator) return m.reply(tr("set.creatorOnly"))

    const px = (global.prefix && global.prefix[0]) || "/"

    /* helper: tambah/hapus key global + persist ke settings.js (idempoten) */
    const persistGlobal = (name, literal, comment) => {
      let src = ""
      try { src = fs.readFileSync(SETTINGS_PATH, "utf8") } catch { return null }
      const line = "global." + name + " = " + literal
      const re = new RegExp("global\\." + name + "\\s*=\\s*[^\\n]+")
      if (re.test(src)) src = src.replace(re, line)
      else src += "\n/* ── " + comment + " ── */\n" + line + "\n"
      try { fs.writeFileSync(SETTINGS_PATH, src); return true } catch { return false }
    }

    /* ─────────── /panelmanager — panduan config via bot ─────────── */
    if (command === "panelmanager" || command === "cfgmanager" || command === "configmanager") {
      return m.reply(
        "<b>🛠️ PANEL & CONFIG MANAGER</b>\n\n" +
        "<b>Server panel (tanpa edit settings.js):</b>\n" +
        px + "addserver id|nama|domain|apikey|capikey|egg|nestid|loc\n" +
        px + "delserver id\n" +
        px + "servers — lihat semua server\n\n" +
        "<b>Domain & subdomain (Cloudflare):</b>\n" +
        px + "addsubdo domain|zone_id|apikey — daftarkan domain\n" +
        px + "deldomain domain — hapus domain\n" +
        px + "cdomain sub|ip|on/off|domain — buat subdomain\n" +
        px + "listsubdo domain — daftar subdomain\n" +
        px + "delsubdo host|domain — hapus subdomain\n\n" +
        "<b>Panel:</b>\n" +
        px + "cpanel user|ram|bulan|server\n" +
        px + "listpanel / delpanel id\n" +
        px + "blclean bl|unbl|id|server\n\n" +
        px + "getset — lihat config aktif",
        { parse_mode: "HTML" }
      )
    }

    /* ─────────── /addserver — tambah server panel baru ─────────── */
    if (command === "addserver" || command === "addsrv") {
      const sp = (text || "").split("|").map(s => s.trim())
      if (sp.length < 4)
        return m.reply("<b>" + tr("use.usage") + ":</b>\n<code>" + px + "addserver id|nama|domain|apikey|capikey|egg|nestid|loc</code>\n\n" + tr("set.srvExample"), { parse_mode: "HTML" })
      const sid = sp[0]
      if (!/^[a-zA-Z0-9_-]+$/.test(sid)) return m.reply(tr("set.srvBadId"))
      if (!global.panelServer) global.panelServer = {}
      global.panelServer[sid] = {
        name: sp[1] || sid,
        domain: sp[2] || "",
        apikey: sp[3] || "",
        capikey: sp[4] || "",
        egg: sp[5] || "15",
        nestid: sp[6] || "5",
        loc: sp[7] || "1"
      }
      /* persist: tulis ulang blok global.panelServer di settings.js */
      try {
        let src = fs.readFileSync(SETTINGS_PATH, "utf8")
        const block = "global.panelServer = " + JSON.stringify(global.panelServer, null, 2)
        if (/global\.panelServer\s*=\s*\{[\s\S]*?\n\}/.test(src)) src = src.replace(/global\.panelServer\s*=\s*\{[\s\S]*?\n\}/, block)
        else src += "\n" + block + "\n"
        fs.writeFileSync(SETTINGS_PATH, src)
      } catch {}
      const s = global.panelServer[sid]
      return m.reply(
        "<b>✅ SERVER DITAMBAH</b>\n\n" +
        "🆔 ID: <code>" + sid + "</code>\n" +
        "📛 Nama: <b>" + s.name + "</b>\n" +
        "🌐 Domain: <code>" + (s.domain || "-") + "</code>\n" +
        "🔑 API Key: " + (s.apikey ? "✅" : "❌") + "\n" +
        "🥚 Egg/Nest: <code>" + s.egg + "/" + s.nestid + "</code>\n\n" +
        tr("set.srvReady", { id: sid }),
        { parse_mode: "HTML" }
      )
    }

    /* ─────────── /delserver — hapus server panel ─────────── */
    if (command === "delserver" || command === "delsrv") {
      const sid = (text || "").trim()
      if (!sid) return m.reply(tr("use.usage") + ": <code>" + px + "delserver id</code>", { parse_mode: "HTML" })
      if (!global.panelServer || !global.panelServer[sid]) return m.reply(tr("set.srvNotFound"))
      if (String(global.privateServerId) === sid) return m.reply(tr("set.srvPrivate"))
      delete global.panelServer[sid]
      try {
        let src = fs.readFileSync(SETTINGS_PATH, "utf8")
        const block = "global.panelServer = " + JSON.stringify(global.panelServer, null, 2)
        src = src.replace(/global\.panelServer\s*=\s*\{[\s\S]*?\n\}/, block)
        fs.writeFileSync(SETTINGS_PATH, src)
      } catch {}
      return m.reply(tr("set.srvDeleted", { id: sid }), { parse_mode: "HTML" })
    }

    /* ─────────── /servers — daftar server panel ─────────── */
    if (command === "servers" || command === "listsrv") {
      const servers = global.panelServer || {}
      if (!Object.keys(servers).length) return m.reply(tr("set.noServer"))
      let out = "<b>🖥️ " + tr("set.srvList") + "</b>\n\n"
      for (const [id, s] of Object.entries(servers)) {
        const active = String(global.privateServerId) === id ? " ⭐" : ""
        out += "<b>" + id + ". " + (s.name || id) + "</b>" + active + "\n"
        out += "   🌐 " + (s.domain || "-") + " | 🔑 " + (s.apikey ? "✅" : "❌") + "\n"
      }
      return m.reply(out, { parse_mode: "HTML" })
    }

    /* ─────────── /addsubdo — daftarkan domain Cloudflare ─────────── */
    if (command === "addsubdo" || command === "adddomain") {
      const sp = (text || "").split("|").map(s => s.trim())
      if (sp.length < 3)
        return m.reply("<b>" + tr("use.usage") + ":</b>\n<code>" + px + "addsubdo domain|zone_id|apikey</code>\n\n" + tr("set.subdoHint"), { parse_mode: "HTML" })
      const domain = sp[0].toLowerCase()
      if (!/^[a-z0-9.-]+\.[a-z]{2,}$/.test(domain)) return m.reply(tr("set.subdoBadDomain"))
      if (!global.cf) global.cf = { domains: {} }
      if (!global.cf.domains) global.cf.domains = {}
      global.cf.domains[domain] = { zone: sp[1], apikey: sp[2] }
      try {
        let src = fs.readFileSync(SETTINGS_PATH, "utf8")
        const block = "global.cf = " + JSON.stringify(global.cf, null, 2)
        if (/global\.cf\s*=\s*\{[\s\S]*?\n\}/.test(src)) src = src.replace(/global\.cf\s*=\s*\{[\s\S]*?\n\}/, block)
        else src += "\n" + block + "\n"
        fs.writeFileSync(SETTINGS_PATH, src)
      } catch {}
      return m.reply(
        "<b>✅ " + tr("set.subdoAdded") + "</b>\n\n" +
        "🌍 Domain: <code>" + domain + "</code>\n" +
        "🪪 Zone: <code>" + sp[1] + "</code>\n" +
        "🔑 API Key: ✅\n\n" +
        tr("set.subdoNext", { px, domain }),
        { parse_mode: "HTML" }
      )
    }

    /* ─────────── /deldomain — hapus domain dari config ─────────── */
    if (command === "deldomain" || command === "delcf") {
      const domain = (text || "").trim().toLowerCase()
      if (!domain) return m.reply(tr("use.usage") + ": <code>" + px + "deldomain domain.com</code>", { parse_mode: "HTML" })
      if (!global.cf?.domains || !global.cf.domains[domain]) return m.reply(tr("set.subdoNotFound"))
      delete global.cf.domains[domain]
      try {
        let src = fs.readFileSync(SETTINGS_PATH, "utf8")
        const block = "global.cf = " + JSON.stringify(global.cf, null, 2)
        src = src.replace(/global\.cf\s*=\s*\{[\s\S]*?\n\}/, block)
        fs.writeFileSync(SETTINGS_PATH, src)
      } catch {}
      return m.reply(tr("set.subdoDeleted", { domain }), { parse_mode: "HTML" })
    }

    if (command === "getset" || command === "settinginfo") {
      const s = global
      let srvList = ""
      try {
        for (const [id, srv] of Object.entries(s.panelServer || {})) {
          srvList += "Server " + id + ": " + (srv.name || id) + " - " + (srv.domain ? "OK" : "-") + "\n"
        }
      } catch {}
      return m.reply(
        "<b>" + tr("set.current") + "</b>\n\n" +
        "Bot Name: <code>" + (s.botname || "-") + "</code>\n" +
        "Owner Name: <code>" + (s.namaOwner || "-") + "</code>\n" +
        "Link Owner: <code>" + (s.linkOwner || "-") + "</code>\n" +
        "Prefix: <code>" + (s.prefix || []).join(", ") + "</code>\n" +
        "Default Lang: <code>" + (s.defaultLang || "id") + "</code>\n" +
        "Notif Group: <code>" + (s.notifGroupId || tr("set.notSet")) + "</code>\n" +
        "AM API Key: <code>" + (s.amkey ? "✅" : "❌") + "</code>\n" +
        "Clone Mode: <code>" + (s.isClone ? "YES" : "NO") + "</code>\n\n" +
        "<b>" + tr("set.panelServers") + ":</b>\n" + (srvList || tr("set.noServer")),
        { parse_mode: "HTML" }
      )
    }

    const parts = (text || "").trim().split(/\s+/)
    const key = (parts[0] || "").toLowerCase()
    const val = parts.slice(1).join(" ")

    if (!key || !val) {
      return m.reply(
        "<b>" + tr("set.manager") + "</b>\n\n" +
        tr("use.usage") + ":\n" +
        px + "set botname Nama Bot\n" +
        px + "set ownername Nama Owner\n" +
        px + "set linkowner https://t.me/xxx\n" +
        px + "set prefix /\n" +
        px + "set lang id\n" +
        px + "set server 1|Nama|domain|apikey|capikey|egg|nestid|loc\n" +
        px + "set backup on/off\n" +
        px + "set backupinterval 6 (" + tr("set.hours") + ")\n" +
        px + "set notifgroup ID_GRUP\n" +
        px + "set amkey SK-XXXX\n" +
        px + "set tolakbot teks\n\n" +
        px + "getset - " + tr("set.seeAll"),
        { parse_mode: "HTML" }
      )
    }

    let src = ""
    try { src = fs.readFileSync(SETTINGS_PATH, "utf8") } catch { return m.reply("Gagal baca settings.js") }
    let patched = false

    if (key === "botname") {
      global.botname = val; global.botname2 = val
      src = src.replace(/global\.botname\s*=\s*"[^"]*"/, 'global.botname = "' + val + '"')
      src = src.replace(/global\.botname2\s*=\s*"[^"]*"/, 'global.botname2 = "' + val + '"')
      patched = true
    } else if (key === "ownername") {
      global.namaOwner = val
      src = src.replace(/global\.namaOwner\s*=\s*"[^"]*"/, 'global.namaOwner = "' + val + '"')
      patched = true
    } else if (key === "linkowner") {
      global.linkOwner = val
      src = src.replace(/global\.linkOwner\s*=\s*"[^"]*"/, 'global.linkOwner = "' + val + '"')
      patched = true
    } else if (key === "prefix") {
      global.prefix = [val]
      src = src.replace(/global\.prefix\s*=\s*\[[^\]]*\]/, 'global.prefix = ["' + val + '"]')
      patched = true
    } else if (key === "lang") {
      global.defaultLang = val
      src = src.replace(/global\.defaultLang\s*=\s*"[^"]*"/, 'global.defaultLang = "' + val + '"')
      patched = true
    } else if (key === "welcome") {
      global.WELCOME_PHOTO = val
      src = src.replace(/global\.WELCOME_PHOTO\s*=\s*"[^"]*"/, 'global.WELCOME_PHOTO = "' + val + '"')
      patched = true
    } else if (key === "backup") {
      const on = val.toLowerCase() === "on"
      if (!global.backup) global.backup = {}
      global.backup.enabled = on
      src = src.replace(/enabled:\s*(true|false)/, "enabled: " + on)
      patched = true
    } else if (key === "backupinterval") {
      const hours = parseFloat(val)
      if (isNaN(hours) || hours <= 0) return m.reply(tr("set.badInterval"))
      if (!global.backup) global.backup = {}
      global.backup.intervalMs = hours * 3600000
      src = src.replace(/intervalMs:\s*\d+/, "intervalMs: " + global.backup.intervalMs)
      try { const bm = require("../library/backup"); bm.stop(); bm.start(Rafz) } catch {}
      patched = true
    } else if (key === "notifgroup") {
      global.notifGroupId = val
      src = src.replace(/global\.notifGroupId\s*=\s*[^\n]+/, 'global.notifGroupId = "' + val + '"')
      patched = true
    } else if (key === "amkey") {
      /* API key Alight Motion premium (free-restapi) */
      global.amkey = val
      if (src.includes("global.amkey")) {
        src = src.replace(/global\.amkey\s*=\s*"[^"]*"/, 'global.amkey = "' + val + '"')
      } else {
        src += '\n/* ── Alight Motion premium API key (diset via /set amkey) ── */\nglobal.amkey = "' + val + '"\n'
      }
      patched = true
    } else if (key === "tolakbot") {
      /* balasan otomatis buat chat yang ditolak / bukan user terdaftar */
      global.tolakBotText = val
      if (src.includes("global.tolakBotText")) {
        src = src.replace(/global\.tolakBotText\s*=\s*"[^"]*"/, 'global.tolakBotText = "' + val + '"')
      } else {
        src += '\n/* ── Balasan tolak bot (diset via /set tolakbot) ── */\nglobal.tolakBotText = "' + val + '"\n'
      }
      patched = true
    } else if (key === "server") {
      const sp = val.split("|")
      if (sp.length < 4) return m.reply("Format: id|nama|domain|apikey|capikey|egg|nestid|loc")
      const sid = sp[0]
      const srvObj = { name: sp[1]||sid, domain: sp[2]||"", apikey: sp[3]||"", capikey: sp[4]||"", egg: sp[5]||"15", nestid: sp[6]||"5", loc: sp[7]||"1" }
      if (!global.panelServer) global.panelServer = {}
      global.panelServer[sid] = srvObj
      /* persist blok panelServer biar benar-benar tersimpan */
      try {
        let s2 = fs.readFileSync(SETTINGS_PATH, "utf8")
        s2 = s2.replace(/global\.panelServer\s*=\s*\{[\s\S]*?\n\}/, "global.panelServer = " + JSON.stringify(global.panelServer, null, 2))
        fs.writeFileSync(SETTINGS_PATH, s2)
      } catch {}
      patched = true
    } else {
      return m.reply(tr("set.unknownKey"))
    }

    if (patched) {
      try { fs.writeFileSync(SETTINGS_PATH, src) } catch (e) { return m.reply(tr("set.writeFail") + " " + e.message) }
      return m.reply(tr("set.changed", { key: key, val: val }), { parse_mode: "HTML" })
    }
    return m.reply(tr("set.noChange"))
  } catch (e) {
    console.error("[settings]", e?.message)
    try { await m.reply("Error: " + (e?.message || e)) } catch {}
    return false
  }
}

handler.command = ["set", "getset", "settinginfo", "panelmanager", "cfgmanager", "configmanager", "addserver", "addsrv", "delserver", "delsrv", "servers", "listsrv", "addsubdo", "adddomain", "deldomain", "delcf"]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
