"use strict"
const https = require("https")
const http = require("http")

const UA = "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/130 Mobile Safari/537.36"

const getBuffer = (url) =>
  new Promise((resolve, reject) => {
    try {
      const follow = (u, depth = 0) => {
        if (depth > 5) return reject(new Error("Too many redirects"))
        const parsed = new URL(u)
        const mod = parsed.protocol === "https:" ? https : http
        mod.get({ hostname: parsed.hostname, path: parsed.pathname + parsed.search, timeout: 60000, headers: { "User-Agent": UA } }, (res) => {
          if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) return follow(new URL(res.headers.location, u).href, depth + 1)
          if (res.statusCode !== 200) return reject(new Error("HTTP " + res.statusCode))
          const c = []
          res.on("data", d => c.push(d))
          res.on("end", () => resolve(Buffer.concat(c)))
        }).on("error", reject).on("timeout", function () { this.destroy(); reject(new Error("Timeout")) })
      }
      follow(url)
    } catch (e) { reject(e) }
  })

const getJSON = (url) =>
  new Promise((resolve, reject) => {
    try {
      const parsed = new URL(url)
      const mod = parsed.protocol === "https:" ? https : http
      mod.get({ hostname: parsed.hostname, path: parsed.pathname + parsed.search, timeout: 30000, headers: { "User-Agent": UA, "Accept": "application/json" } }, (res) => {
        let d = ""
        res.on("data", c => d += c)
        res.on("end", () => { try { resolve(JSON.parse(d)) } catch { resolve(null) } })
      }).on("error", reject).on("timeout", function () { this.destroy(); reject(new Error("Timeout")) })
    } catch (e) { reject(e) }
  })

const getText = (url) =>
  new Promise((resolve, reject) => {
    try {
      const parsed = new URL(url)
      const mod = parsed.protocol === "https:" ? https : http
      mod.get({ hostname: parsed.hostname, path: parsed.pathname + parsed.search, timeout: 30000, headers: { "User-Agent": UA } }, (res) => {
        let d = ""
        res.on("data", c => d += c)
        res.on("end", () => resolve(d))
      }).on("error", reject).on("timeout", function () { this.destroy(); reject(new Error("Timeout")) })
    } catch (e) { reject(e) }
  })

const handler = async (m, { Rafz, command, text }) => {
  try {
    const px = (global.prefix && global.prefix[0]) || "/"
    const q = (text || "").trim()
    const usage = (u) => "Penggunaan: " + px + u

    // ===== CUACA =====
    if (command === "cuaca" || command === "weather") {
      if (!q) return m.reply(usage("cuaca Jakarta"))
      try {
        const j = await getJSON("https://wttr.in/" + encodeURIComponent(q) + "?format=j1")
        const cur = j.current_condition?.[0]
        const area = j.nearest_area?.[0]?.areaName?.[0]?.value || q
        if (!cur) throw new Error("data kosong")
        return m.reply(
          "<b>CUACA: " + area.toUpperCase() + "</b>\n\n" +
          "Suhu: " + cur.temp_C + "°C (terasa " + cur.FeelsLikeC + "°C)\n" +
          "Kelembapan: " + cur.humidity + "%\n" +
          "Angin: " + cur.windspeedKmph + " km/j\n" +
          "Cuaca: " + (cur.weatherDesc?.[0]?.value || "-") + "\n\n" +
          "Source: wttr.in",
          { parse_mode: "HTML" }
        )
      } catch { return m.reply("Kota tidak ditemukan") }
    }

    // ===== SCREENSHOT WEB =====
    if (command === "ssweb" || command === "screenshot") {
      if (!q) return m.reply(usage("ssweb https://example.com"))
      if (!q.startsWith("http")) return m.reply("Harus pakai https://")
      const wait = await m.reply("Mengambil screenshot...")
      try {
        const buf = await getBuffer("https://image.thum.io/get/fullpage/" + encodeURIComponent(q))
        if (!buf || buf.length < 1000) throw new Error("kosong")
        await Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {})
        await Rafz.sendPhoto(m.chat, buf, { caption: "SCREENSHOT: " + q.slice(0, 80), reply_to_message_id: m.id })
        return true
      } catch (e) {
        try { await Rafz.deleteMessage(m.chat, wait.message_id) } catch {}
        return m.reply("Gagal screenshot: " + e.message)
      }
    }

    // ===== QR CODE =====
    if (command === "qr" || command === "qrcode") {
      if (!q) return m.reply(usage("qr teks/link"))
      const wait = await m.reply("Membuat QR...")
      try {
        const buf = await getBuffer("https://api.qrserver.com/v1/create-qr-code/?size=500x500&data=" + encodeURIComponent(q))
        await Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {})
        await Rafz.sendPhoto(m.chat, buf, { caption: "QR CODE\n\n" + q.slice(0, 100), reply_to_message_id: m.id })
        return true
      } catch (e) {
        try { await Rafz.deleteMessage(m.chat, wait.message_id) } catch {}
        return m.reply("Gagal: " + e.message)
      }
    }

    // ===== SHORTLINK =====
    if (command === "short" || command === "shortlink" || command === "tinyurl") {
      if (!q) return m.reply(usage("short https://linkpanjang.com"))
      if (!q.startsWith("http")) return m.reply("Harus link valid")
      try {
        /* tinyurl return PLAIN TEXT url — bukan JSON (fix: pakai getText) */
        const t = (await getText("https://tinyurl.com/api-create.php?url=" + encodeURIComponent(q))).trim()
        if (t && t.startsWith("https://tinyurl.com/")) return m.reply("SHORTLINK\n\nAsli: " + q + "\nPendek: " + t)
        throw new Error("invalid")
      } catch {
        return m.reply("Gagal memendekkan link")
      }
    }

    // ===== TRANSLATE =====
    if (command === "tr" || command === "translate") {
      if (!q) return m.reply(usage("tr id|en Hello world"))
      const parts = q.split("|")
      const lang = parts[0] || "id"
      const txt = parts.slice(1).join("|")
      if (!txt) return m.reply("Format: " + px + "tr en|id Hello world")
      try {
        const j = await getJSON("https://api.siputzx.my.id/api/tools/translate?text=" + encodeURIComponent(txt) + "&target=" + lang)
        if (j && j.status && j.data) return m.reply("TRANSLATE\n\n" + j.data)
        throw new Error("no data")
      } catch {
        return m.reply("Gagal translate")
      }
    }

    // ===== IP INFO =====
    if (command === "ipinfo" || command === "ip") {
      const ip = q || ""
      try {
        /* j = null kalau bukan JSON valid (respon error) — bukan throw */
        const j = await getJSON("http://ip-api.com/json/" + encodeURIComponent(ip) + "?fields=status,message,country,countryCode,region,regionName,city,zip,lat,lon,timezone,isp,org,as,query")
        if (j && j.status === "success") {
          return m.reply(
            "<b>IP INFO</b>\n\n" +
            "IP: " + j.query + "\n" +
            "Negara: " + j.country + " (" + j.countryCode + ")\n" +
            "Provinsi: " + j.regionName + "\n" +
            "Kota: " + j.city + "\n" +
            "ISP: " + j.isp + "\n" +
            "Org: " + j.org + "\n" +
            "Zona Waktu: " + j.timezone,
            { parse_mode: "HTML" }
          )
        }
        throw new Error((j && j.message) || "not found")
      } catch { return m.reply("Gagal lookup IP") }
    }

    // ===== CALCULATOR =====
    if (command === "calc" || command === "math") {
      if (!q) return m.reply(usage("calc 12*(3+4)"))
      const expr = q.replace(/[^0-9+\-*/().,%\s^]/g, "").replace(/\^/g, "**")
      try {
        const val = Function('"use strict";return (' + expr + ')')()
        if (typeof val !== "number" || !isFinite(val)) throw new Error("invalid")
        return m.reply("KALKULATOR\n\n<code>" + q + "</code>\n= <b>" + val + "</b>", { parse_mode: "HTML" })
      } catch { return m.reply("Ekspresi tidak valid") }
    }

    // ===== BASE64 =====
    if (command === "b64" || command === "base64") {
      if (!q) return m.reply(usage("b64 encode|teks atau b64 decode|teks"))
      const parts = q.split("|")
      const act = parts[0]
      const txt = parts.slice(1).join("|")
      if (act === "encode") return m.reply("BASE64 ENCODE\n\n" + Buffer.from(txt).toString("base64"))
      if (act === "decode") {
        try { return m.reply("BASE64 DECODE\n\n" + Buffer.from(txt, "base64").toString()) } catch { return m.reply("Bukan base64 valid") }
      }
      return m.reply("Perintah: encode|teks atau decode|teks")
    }

    // ===== HASH =====
    if (command === "hash") {
      if (!q) return m.reply(usage("hash sha256|teks"))
      const parts = q.split("|")
      const algo = (parts[0] || "sha256").toLowerCase()
      const txt = parts.slice(1).join("|")
      const crypto = require("crypto")
      const valid = ["md5", "sha1", "sha256", "sha512", "ripemd160"]
      if (!valid.includes(algo)) return m.reply("Algo: md5, sha1, sha256, sha512, ripemd160")
      return m.reply("HASH " + algo.toUpperCase() + "\n\n" + crypto.createHash(algo).update(txt).digest("hex"))
    }

    // ===== PASSWORD GENERATOR =====
    if (command === "pass" || command === "password") {
      const len = parseInt(q) || 16
      const chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*"
      let p = ""
      for (let i = 0; i < Math.min(len, 128); i++) p += chars[Math.floor(Math.random() * chars.length)]
      return m.reply("PASSWORD (" + p.length + " chars)\n\n<code>" + p + "</code>", { parse_mode: "HTML" })
    }

    // ===== TIME =====
    if (command === "time" || command === "waktu") {
      const now = new Date()
      return m.reply(
        "WAKTU\n\n" +
        "WIB: " + now.toLocaleString("id-ID", { timeZone: "Asia/Jakarta" }) + "\n" +
        "WITA: " + now.toLocaleString("id-ID", { timeZone: "Asia/Makassar" }) + "\n" +
        "WIT: " + now.toLocaleString("id-ID", { timeZone: "Asia/Jayapura" }) + "\n" +
        "UTC: " + now.toISOString()
      )
    }

    // ===== COV/COVID =====
    if (command === "covid" || command === "cov") {
      try {
        const j = await getJSON("https://disease.sh/v3/covid-19/countries/indonesia")
        if (j) {
          return m.reply(
            "COVID-19 INDONESIA\n\n" +
            "Kasus: " + j.cases.toLocaleString() + "\n" +
            "Sembuh: " + j.recovered.toLocaleString() + "\n" +
            "Meninggal: " + j.deaths.toLocaleString() + "\n" +
            "Aktif: " + j.active.toLocaleString() + "\n" +
            "Update: " + new Date(j.updated).toLocaleString("id-ID")
          )
        }
        throw new Error("no data")
      } catch { return m.reply("Gagal ambil data covid") }
    }

    return false
  } catch (e) {
    console.error("[informasi]", e?.message)
    try { await m.reply("Error: " + (e?.message || e)) } catch {}
    return false
  }
}

handler.command = ["cuaca", "weather", "ssweb", "screenshot", "qr", "qrcode", "short", "shortlink", "tinyurl", "tr", "translate", "ipinfo", "ip", "calc", "math", "b64", "base64", "hash", "pass", "password", "time", "waktu", "covid", "cov"]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
