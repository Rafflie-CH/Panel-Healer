// plugin: addgb.js — daftarkan grup untuk notifikasi aktivitas user
const fs = require("fs")
const path = require("path")
const SETTINGS_PATH = path.join(__dirname, "..", "settings.js")

const handler = async (m, { Rafz }) => {
  try {
    const sender = String(m.sender)
    const isOwner = (global.owner || []).includes(sender)
    if (!isOwner) {
      return m.reply("❌ Hanya owner yang bisa menjalankan perintah ini.")
    }

    // ambil chat id — bisa dari argumen atau dari chat aktif
    const raw = (m.text || "").trim()
    let chatId = raw || String(m.chat)

    if (!chatId || chatId === "undefined") {
      return m.reply(
        "⚠️ <b>Penggunaan:</b>\n" +
        "<code>/addgb</code> — daftarkan grup/chat ini sebagai penerima notifikasi\n" +
        "<code>/addgb -1001234567890</code> — daftarkan grup dengan ID tertentu",
        { parse_mode: "HTML" }
      )
    }

    // simpan ke global
    global.notifGroupId = chatId

    // patch settings.js supaya persistent
    try {
      let src = fs.readFileSync(SETTINGS_PATH, "utf8")
      if (src.includes("global.notifGroupId =")) {
        src = src.replace(
          /global\.notifGroupId\s*=\s*[^\n]+/,
          `global.notifGroupId = "${chatId}" // diset via /addgb`
        )
      } else {
        // tambah setelah baris notifGroupId null (harusnya ada di settings)
        src = src.replace(
          /global\.notifGroupId\s*=\s*null[^\n]*/,
          `global.notifGroupId = "${chatId}" // diset via /addgb`
        )
      }
      fs.writeFileSync(SETTINGS_PATH, src)
    } catch (e) {
      console.log("addgb: gagal patch settings.js:", e.message)
    }

    // test kirim ke grup
    let testOk = false
    try {
      await Rafz.sendMessage(
        chatId,
        `✅ <b>Grup ini telah didaftarkan sebagai penerima notifikasi bot!</b>\n` +
        `🤖 Bot: <b>${global.botname || "RAFZ BOT"}</b>\n` +
        `🕐 ${new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" })}`,
        { parse_mode: "HTML" }
      )
      testOk = true
    } catch (e) {
      console.log("addgb: test kirim gagal:", e.message)
    }

    await m.reply(
      `✅ <b>Grup notifikasi berhasil didaftarkan!</b>\n\n` +
      `🆔 Chat ID: <code>${chatId}</code>\n` +
      (testOk ? "📨 Test pesan berhasil dikirim." : "⚠️ Test pesan gagal — pastikan bot sudah masuk grup."),
      { parse_mode: "HTML" }
    )

    return true
  } catch (e) {
    console.error("addgb plugin error:", e.message)
    try { await m.reply("⚠️ Error: " + e.message) } catch {}
    return false
  }
}

handler.command = ["addgb", "setgb", "notifgroup"]
module.exports = handler

try {
  const fs = require("fs")
  const file = require.resolve(__filename)
  fs.watchFile(file, () => {
    try { fs.unwatchFile(file); delete require.cache[file]; require(file) } catch {}
  })
} catch {}
