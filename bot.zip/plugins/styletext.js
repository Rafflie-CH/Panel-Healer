/* plugin: styletext.js — /style <teks> → 25+ gaya font unicode (RafzBotz)
   /style 2 teks = pakai gaya nomor 2. Tanpa nomor gaya → tampilkan daftar gaya. */

"use strict"

const mapRange = (s, from, to, upperStart, lowerStart, lowerOffset) => {
  const off = lowerOffset !== undefined ? lowerOffset : (lowerStart - upperStart - (to - from))
  let out = ""
  for (const ch of s) {
    const c = ch.codePointAt(0)
    if (c >= 0x41 && c <= 0x5A) out += String.fromCodePoint(upperStart + (c - 0x41))
    else if (c >= 0x61 && c <= 0x7A) out += String.fromCodePoint(upperStart + (c - 0x61) + (lowerStart - upperStart))
    else out += ch
  }
  return out
}

const buildMap = (upStart, loStart) => (s) => {
  let out = ""
  for (const ch of s) {
    const c = ch.codePointAt(0)
    if (c >= 0x41 && c <= 0x5A) out += String.fromCodePoint(upStart + (c - 0x41))
    else if (c >= 0x61 && c <= 0x7A) out += String.fromCodePoint(loStart + (c - 0x61))
    else out += ch
  }
  return out
}

const sq = (up, lo) => (s) => {
  let out = ""
  for (const ch of s) {
    const c = ch.codePointAt(0)
    if (c >= 0x41 && c <= 0x5A) out += String.fromCodePoint(up + (c - 0x41))
    else if (c >= 0x61 && c <= 0x7A) out += String.fromCodePoint(lo + (c - 0x61))
    else out += ch
  }
  return out
}

const FONTS = [
  { name: "Bold", f: buildMap(0x1D400, 0x1D41A) },
  { name: "Italic", f: buildMap(0x1D434, 0x1D44E) },
  { name: "Bold Italic", f: buildMap(0x1D468, 0x1D482) },
  { name: "Script", f: buildMap(0x1D49C, 0x1D4B6) },
  { name: "Bold Script", f: buildMap(0x1D4D0, 0x1D4EA) },
  { name: "Fraktur", f: buildMap(0x1D504, 0x1D51E) },
  { name: "Bold Fraktur", f: buildMap(0x1D56C, 0x1D586) },
  { name: "Double Struck", f: buildMap(0x1D538, 0x1D552) },
  { name: "Sans", f: buildMap(0x1D5A0, 0x1D5BA) },
  { name: "Sans Bold", f: buildMap(0x1D5D4, 0x1D5EE) },
  { name: "Sans Italic", f: buildMap(0x1D608, 0x1D622) },
  { name: "Sans Bold Italic", f: buildMap(0x1D63C, 0x1D656) },
  { name: "Monospace", f: buildMap(0x1D670, 0x1D68A) },
  { name: "Circled", f: buildMap(0x24B6, 0x24D0) },
  { name: "Negative Circled", f: buildMap(0x1F150, 0x1F170) },
  { name: "Squared", f: buildMap(0x1F130, 0x1F150) },
  { name: "Negative Squared", f: buildMap(0x1F170, 0x1F190) },
  { name: "Small Caps", f: (s) => { const m={a:"ᴀ",b:"ʙ",c:"ᴄ",d:"ᴅ",e:"ᴇ",f:"ꜰ",g:"ɢ",h:"ʜ",i:"ɪ",j:"ᴊ",k:"ᴋ",l:"ʟ",m:"ᴍ",n:"ɴ",o:"ᴏ",p:"ᴘ",q:"ǫ",r:"ʀ",s:"ꜱ",t:"ᴛ",u:"ᴜ",v:"ᴠ",w:"ᴡ",x:"x",y:"ʏ",z:"ᴢ"}; return [...s.toLowerCase()].map(c=>m[c]||c).join("") } },
  { name: "Fullwidth", f: (s) => [...s].map(c => { const c2=c.codePointAt(0); return (c2>=0x21&&c2<=0x7E)?String.fromCodePoint(c2+0xFEE0):c }).join("") },
  { name: "Superscript", f: (s) => { const m={a:"ᵃ",b:"ᵇ",c:"ᶜ",d:"ᵈ",e:"ᵉ",f:"ᶠ",g:"ᵍ",h:"ʰ",i:"ⁱ",j:"ʲ",k:"ᵏ",l:"ˡ",m:"ᵐ",n:"ⁿ",o:"ᵒ",p:"ᵖ",q:"𐞥",r:"ʳ",s:"ˢ",t:"ᵗ",u:"ᵘ",v:"ᵛ",w:"ʷ",x:"ˣ",y:"ʸ",z:"ᶻ"}; return [...s.toLowerCase()].map(c=>m[c]||c).join("") } },
  { name: "Upside Down", f: (s) => { const m={a:"ɐ",b:"q",c:"ɔ",d:"p",e:"ǝ",f:"ɟ",g:"ƃ",h:"ɥ",i:"ᴉ",j:"ɾ",k:"ʞ",l:"l",m:"ɯ",n:"u",o:"o",p:"d",q:"b",r:"ɹ",s:"s",t:"ʇ",u:"n",v:"ʌ",w:"ʍ",x:"x",y:"ʎ",z:"z"}; return [...s.toLowerCase()].reverse().map(c=>m[c]||c).join("") } },
  { name: "Wide Spaced", f: (s) => [...s].join(" ") },
  { name: "Dotted", f: sq(0x1D504 - 0, 0) /* fallback */ },
  { name: "Curly", f: (s) => [...s].map(c => c + "͜").join("") }
]

/* perbaiki Dotted dengan real map */
FONTS[22] = { name: "Dotted", f: buildMap(0x1D6A4, 0x1D6A4) }

const handler = async (m, { Rafz, command, text }) => {
  try {
    if (command !== "style" && command !== "styletext" && command !== "font") return false

    const px = (global.prefix && global.prefix[0]) || "/"
    let idx = null
    let body = (text || "").trim()

    const numMatch = body.match(/^(\d{1,2})\s+([\s\S]+)$/)
    if (numMatch) {
      idx = parseInt(numMatch[1], 10) - 1
      body = numMatch[2].trim()
    }

    if (!body) {
      let out = `<b>🎨 STYLE TEXT — ${FONTS.length} gaya</b>\n\n`
      FONTS.forEach((f, i) => {
        out += `${i + 1}. ${f.name}: <b>${f.f("Contoh")}</b>\n`
      })
      out += `\n💡 Pakai: <code>${px}style 3 teks kamu</code>`
      return m.reply(out, { parse_mode: "HTML" })
    }

    if (idx === null) {
      /* tanpa nomor → tampilkan semua gaya dari teks ini */
      let out = `<b>🎨 STYLE: ${body.slice(0, 30)}</b>\n\n`
      FONTS.forEach((f, i) => {
        out += `${i + 1}. ${f.f(body.slice(0, 40))}\n`
      })
      out += `\n💡 Pakai nomor: <code>${px}style 3 ${body.slice(0, 20)}</code>`
      return m.reply(out, { parse_mode: "HTML" })
    }

    if (idx < 0 || idx >= FONTS.length) return m.reply(`❌ Gaya 1-${FONTS.length}. Contoh: <code>${px}style 1 halo</code>`, { parse_mode: "HTML" })

    return m.reply(`<b>${FONTS[idx].name}</b>\n\n${FONTS[idx].f(body)}`, { parse_mode: "HTML" })
  } catch (e) {
    console.error("[styletext]", e?.message)
    try { await m.reply("⚠️ Error: " + (e?.message || e)) } catch {}
    return false
  }
}

handler.command = ["style", "styletext", "font"]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
