/* rosesys.js — Rose Bot moderation core (porting fitur @MissRose_bot).
   Connection (admin kelola grup via PM), ban/mute/kick + varian d/s + temp,
   warnings + config (warnlimit/warnmode), purge/del, pin ext, report, reset.
   Store: library/gstore.js. Format waktu: 10m 2h 3d 1w.
   Semua reply i18n (m.t) + tombol berstyle. */

"use strict"
const gstore = require("../library/gstore")

const esc = (s) => String(s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
const parseTime = (s) => {
  const m = String(s || "").trim().match(/^(\d+)([smhdw])$/i)
  if (!m) return null
  const mult = { s: 1, m: 60, h: 3600, d: 86400, w: 604800 }[m[2].toLowerCase()]
  return parseInt(m[1]) * mult
}
/* ID user dari text: @mention / ID angka / reply */
const targetOf = (m, text) => {
  if (m.quoted?.sender) return { id: String(m.quoted.sender) }
  const t = String(text || "").trim()
  const idm = t.match(/^(\d{5,})$/)
  if (idm) return { id: idm[1] }
  const um = t.match(/@([a-zA-Z0-9_]{4,})/)
  if (um) return { username: um[1] }
  const ent = (m.entities || []).find(e => e.type === "text_mention" && e.user)
  if (ent) return { id: String(ent.user.id) }
  return null
}

const isAdminChat = async (m, Rafz, uid) => {
  try {
    if ((global.owner || []).includes(uid)) return true
    const admins = await Rafz.getChatAdministrators(m.chat)
    return admins.some(a => String(a.user?.id) === String(uid))
  } catch { return false }
}

const isBotAdmin = async (m, Rafz) => {
  try {
    const me = await Rafz.getMe()
    const admins = await Rafz.getChatAdministrators(m.chat)
    return admins.some(a => String(a.user?.id) === String(me.id))
  } catch { return false }
}

const modErr = (tr) => tr("rose.botAdmin") + "\n" + tr("rose.promoteMe")

const handler = async (m, { Rafz, command, text }) => {
  try {
    const tr = (key, vars) => (m.t ? m.t(key, vars) : key)
    const px = (global.prefix && global.prefix[0]) || "/"
    const uid = String(m.sender)
    const chatKey = String(m.chat)

    /* ═══ 1.2 CONNECTION — kelola grup dari PM ═══ */
    if (command === "connect") {
      const t = String(text || "").trim()
      if (m.isGroup) {
        if (!await isAdminChat(m, Rafz, uid)) return m.reply(tr("rose.adminOnly"), { parse_mode: "HTML" })
        gstore.set("connections", uid, chatKey)
        return m.reply(tr("rose.connected"), { parse_mode: "HTML" })
      }
      if (!t) {
        const cur = gstore.get("connections", uid)
        return m.reply(cur ? (tr("rose.currentConn") + " <code>" + esc(cur) + "</code>") : tr("rose.needChatId"), { parse_mode: "HTML" })
      }
      gstore.set("connections", uid, t.replace(/^@/, ""))
      return m.reply(tr("rose.connectedTo") + " <code>" + esc(t) + "</code>", { parse_mode: "HTML" })
    }
    if (command === "disconnect") {
      gstore.del("connections", uid)
      return m.reply(tr("rose.disconnected"), { parse_mode: "HTML" })
    }
    if (command === "connection" || command === "connections") {
      const cur = gstore.get("connections", uid)
      return m.reply(cur ? (tr("rose.currentConn") + " <code>" + esc(cur) + "</code>") : tr("rose.noConn"), { parse_mode: "HTML" })
    }
    if (command === "reconnect") {
      const last = gstore.get("reconn", uid)
      if (!last) return m.reply(tr("rose.noConn"), { parse_mode: "HTML" })
      gstore.set("connections", uid, last)
      return m.reply(tr("rose.reconnected") + " <code>" + esc(last) + "</code>", { parse_mode: "HTML" })
    }

    /* target resolusi: kalau PM + ada connection → operasikan grup itu */
    let chat = chatKey
    let isGroupHere = m.isGroup
    if (!m.isGroup) {
      const conn = gstore.get("connections", uid)
      if (!conn) return false /* PM tanpa connection + bukan command umum → biarkan */
      chat = conn
      isGroupHere = true
    }
    if (!isGroupHere) return false

    /* ═══ 1.3 MODERATION: ban/tban/unban/mute/tmute/unmute/kick (+ d/s varian) ═══ */
    const isBan = command === "ban" || command === "dban" || command === "sban" || command === "tban"
    const isUnban = command === "unban"
    const isMute = command === "mute" || command === "dmute" || command === "smute" || command === "tmute"
    const isUnmute = command === "unmute"
    const isKick = command === "kick" || command === "dkick" || command === "skick"

    if (isBan || isUnban || isMute || isUnmute || isKick) {
      if (!await isAdminChat(m, Rafz, uid)) return m.reply(tr("rose.adminOnly"), { parse_mode: "HTML" })
      if (!await isBotAdmin(m, Rafz)) return m.reply(modErr(tr), { parse_mode: "HTML" })
      const tgt = targetOf(m, text)
      if (!tgt || !tgt.id) return m.reply(tr("rose.needTarget"), { parse_mode: "HTML" })

      if (isBan || isKick) {
        try { await Rafz.unbanChatMember(chat, tgt.id, { only_if_banned: true }) } catch {}
      }
      try {
        if (isBan) {
          /* tban: /tban @user 3d alasan */
          const parts = String(text || "").trim().split(/\s+/)
          const tm = parseTime(parts.find(p => parseTime(p)))
          const until = tm ? Math.floor(Date.now() / 1000) + tm : undefined
          await Rafz.banChatMember(chat, tgt.id, { until_date: until })
          if (!/^sban|^dban/.test(command)) await m.reply("🔨 " + tr("rose.banned") + " <code>" + esc(tgt.id) + "</code>", { parse_mode: "HTML" })
          return true
        }
        if (isKick) {
          await Rafz.banChatMember(chat, tgt.id)
          await Rafz.unbanChatMember(chat, tgt.id)
          if (!/^s|^d/.test(command)) await m.reply("👢 " + tr("rose.kicked") + " <code>" + esc(tgt.id) + "</code>", { parse_mode: "HTML" })
          return true
        }
        if (isMute) {
          const parts = String(text || "").trim().split(/\s+/)
          const tm = parseTime(parts.find(p => parseTime(p)))
          await Rafz.restrictChatMember(chat, tgt.id, {
            permissions: { can_send_messages: false, can_send_polls: false, can_send_other_messages: false, can_add_web_page_previews: false },
            until_date: tm ? Math.floor(Date.now() / 1000) + tm : undefined
          })
          if (!/^s|^d/.test(command)) await m.reply("🔇 " + tr("rose.muted") + " <code>" + esc(tgt.id) + "</code>" + (tm ? " (" + tr("rose.temp") + ")" : ""), { parse_mode: "HTML" })
          return true
        }
        if (isUnmute) {
          await Rafz.restrictChatMember(chat, tgt.id, {
            permissions: { can_send_messages: true, can_send_polls: true, can_send_other_messages: true, can_add_web_page_previews: true, can_invite_users: true }
          })
          return m.reply("🔊 " + tr("rose.unmuted"), { parse_mode: "HTML" })
        }
        if (isUnban) {
          await Rafz.unbanChatMember(chat, tgt.id)
          return m.reply("✅ " + tr("rose.unbanned"), { parse_mode: "HTML" })
        }
      } catch (e) {
        return m.reply("❌ " + tr("common.failed") + ": " + esc(String(e.message || e).slice(0, 80)), { parse_mode: "HTML" })
      }
    }

    /* ═══ 1.4 WARNINGS (config) — /warn inti sudah ada di roseprotect ═══ */
    if (command === "setwarnlimit") {
      if (!await isAdminChat(m, Rafz, uid)) return m.reply(tr("rose.adminOnly"), { parse_mode: "HTML" })
      const n = parseInt(String(text || "").trim())
      if (!n || n < 1) return m.reply("⚠️ <code>" + px + "setwarnlimit 3</code>", { parse_mode: "HTML" })
      gstore.set("warnconfig", chat + ":limit", n)
      return m.reply("✅ " + tr("rose.warnlimitSet") + " <b>" + n + "</b>", { parse_mode: "HTML" })
    }
    if (command === "setwarnmode") {
      if (!await isAdminChat(m, Rafz, uid)) return m.reply(tr("rose.adminOnly"), { parse_mode: "HTML" })
      const mode = String(text || "").trim().toLowerCase().split(/\s+/)[0]
      if (!["kick", "ban", "mute", "tmute", "tban"].includes(mode)) {
        return m.reply("⚠️ " + tr("rose.warnmodeHint") + ": <code>kick ban mute tmute tban</code>", { parse_mode: "HTML" })
      }
      gstore.set("warnconfig", chat + ":mode", mode)
      return m.reply("✅ " + tr("rose.warnmodeSet") + " <b>" + esc(mode) + "</b>", { parse_mode: "HTML" })
    }
    if (command === "warnings" || command === "warnsettings") {
      const limit = gstore.get("warnconfig", chat + ":limit", 3)
      const mode = gstore.get("warnconfig", chat + ":mode", "ban")
      const on = gstore.get("warnconfig", chat + ":on", true)
      return m.reply(
        "⚠️ <b>WARN SETTINGS</b>\n\n" +
        tr("rose.warnLimit") + ": <b>" + limit + "</b>\n" +
        tr("rose.warnMode") + ": <b>" + esc(mode) + "</b>\n" +
        tr("rose.status") + ": <b>" + (on ? "✅ ON" : "❌ OFF") + "</b>",
        { parse_mode: "HTML" }
      )
    }

    /* ═══ 1.5 PURGE ═══ */
    if (command === "purge" || command === "spurge") {
      if (!await isAdminChat(m, Rafz, uid)) return m.reply(tr("rose.adminOnly"), { parse_mode: "HTML" })
      if (!m.quoted?.id) return m.reply(tr("rose.replyOld"), { parse_mode: "HTML" })
      const fromId = m.quoted.id
      const nMax = parseInt(String(text || "").trim()) || 100
      let deleted = 0
      try {
        /* loop delete dari fromId ke m.id (Telegram butuh ID berurutan) */
        for (let id = fromId; id <= m.id && deleted < nMax; id++) {
          try { await Rafz.deleteMessage(chat, id); deleted++ } catch {}
        }
      } catch {}
      if (command !== "spurge") {
        const done = await m.reply("🧹 " + tr("rose.purged") + " <b>" + deleted + "</b>", { parse_mode: "HTML" })
        setTimeout(() => { try { Rafz.deleteMessage(chat, done.message_id) } catch {} }, 5000)
      }
      return true
    }
    if (command === "purgefrom" || command === "purgeto") {
      /* purge rentang: reply awal → /purgefrom, lalu reply akhir → /purgeto */
      if (!await isAdminChat(m, Rafz, uid)) return m.reply(tr("rose.adminOnly"), { parse_mode: "HTML" })
      if (!m.quoted?.id) return m.reply(tr("rose.replyMsg"), { parse_mode: "HTML" })
      if (command === "purgefrom") {
        gstore.set("purgerange", String(m.sender), { chat: String(chat), from: m.quoted.id, at: Date.now() })
        return m.reply("🧹 " + tr("rose.purgeFrom") + " <code>" + m.quoted.id + "</code> — " + tr("rose.purgeNowTo"), { parse_mode: "HTML" })
      }
      /* purgeto */
      const st = gstore.get("purgerange", String(m.sender), null)
      if (!st || st.chat !== String(chat)) return m.reply(tr("rose.purgeNoFrom"), { parse_mode: "HTML" })
      gstore.del("purgerange", String(m.sender))
      const fromId = Math.min(st.from, m.quoted.id)
      const toId = Math.max(st.from, m.quoted.id)
      let deleted = 0
      for (let id = fromId; id <= toId && deleted < 200; id++) {
        try { await Rafz.deleteMessage(chat, id); deleted++ } catch {}
      }
      return m.reply("🧹 " + tr("rose.purged") + " <b>" + deleted + "</b>", { parse_mode: "HTML" })
    }
    if (command === "del" || command === "delete2") {
      if (!await isAdminChat(m, Rafz, uid)) return m.reply(tr("rose.adminOnly"), { parse_mode: "HTML" })
      if (!m.quoted?.id) return m.reply(tr("rose.replyMsg"), { parse_mode: "HTML" })
      try { await Rafz.deleteMessage(chat, m.quoted.id); return true } catch { return m.reply(tr("common.failed")) }
    }

    /* ═══ 1.6 PIN ext ═══ */
    if (command === "unpinall") {
      if (!await isAdminChat(m, Rafz, uid)) return m.reply(tr("rose.adminOnly"), { parse_mode: "HTML" })
      try { await Rafz.unpinAllChatMessages(chat); return m.reply("📌 " + tr("rose.done"), { parse_mode: "HTML" }) }
      catch { return m.reply(tr("common.failed")) }
    }
    if (command === "permapin") {
      if (!await isAdminChat(m, Rafz, uid)) return m.reply(tr("rose.adminOnly"), { parse_mode: "HTML" })
      if (!text) return m.reply(tr("rose.needText"), { parse_mode: "HTML" })
      const sent = await Rafz.sendMessage(chat, esc(text), { parse_mode: "HTML" })
      try { await Rafz.pinChatMessage(chat, sent.message_id, { disable_notification: false }) } catch {}
      return true
    }
    if (command === "pinned") {
      try {
        const c = await Rafz.getChat(chat)
        const p = c.pinned_message
        if (!p) return m.reply(tr("rose.noPinned"), { parse_mode: "HTML" })
        return m.reply("📌 <b>" + tr("rose.pinnedMsg") + "</b>\n\n" + esc(String(p.text || p.caption || "-").slice(0, 500)), { parse_mode: "HTML" })
      } catch { return m.reply(tr("common.failed")) }
    }

    /* ═══ 1.7 REPORT (varian; inti ada di roseprotect) ═══ */
    if (command === "report2" || command === "rreport") {
      if (!m.quoted && !m.replyTo) return m.reply(tr("rose.replyMsg"), { parse_mode: "HTML" })
      const admins = await Rafz.getChatAdministrators(m.chat).catch(() => [])
      const tags = admins.filter(a => !a.user?.is_bot).map(a => "<a href=\"tg://user?id=" + a.user.id + "\">·</a>").join("")
      await m.reply("🚨 <b>" + tr("rose.reported") + "</b> " + tags, { parse_mode: "HTML" })
      return true
    }

    /* ═══ 1.23 RESET settings grup ═══ */
    if (command === "resetgroup") {
      if (!await isAdminChat(m, Rafz, uid)) return m.reply(tr("rose.adminOnly"), { parse_mode: "HTML" })
      for (const col of ["welcome", "goodbye", "locks", "blocklist", "blockmode", "antiflood", "antiraid", "captcha", "filters", "notes", "disabled", "shield"]) {
        gstore.del(col, chat)
        gstore.del(col, chat + ":")
        for (const [k] of gstore.list(col)) if (String(k).startsWith(chat + ":") || String(k) === chat) gstore.del(col, k)
      }
      return m.reply("♻️ " + tr("rose.resetDone"), { parse_mode: "HTML" })
    }

    return false
  } catch (e) {
    console.error("[rosesys]", command, e?.message)
    try { await m.reply("❌ " + esc(String(e?.message || e).slice(0, 120)), { parse_mode: "HTML" }) } catch {}
    return false
  }
}

handler.command = [
  "connect", "disconnect", "connection", "connections", "reconnect",
  "ban", "dban", "sban", "tban", "unban",
  "mute", "dmute", "smute", "tmute", "unmute",
  "kick", "dkick", "skick",
  "setwarnlimit", "setwarnmode", "warnings", "warnsettings",
  "purge", "spurge", "purgefrom", "purgeto", "del", "delete2",
  "unpinall", "permapin", "pinned", "report2", "rreport",
  "resetgroup"
]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
