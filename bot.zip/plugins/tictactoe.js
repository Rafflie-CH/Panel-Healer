/* plugin: tictactoe.js - TicTacToe vs Bot and vs User */
"use strict"
const crypto = require("crypto")

const GAMES_DB_PATH = "./library/database/tictactoe.json"

const loadGames = () => {
  try {
    const j = JSON.parse(require("fs").readFileSync(GAMES_DB_PATH, "utf8"))
    return (j && typeof j === "object" && !Array.isArray(j)) ? j : {}
  } catch { return {} }
}

const saveGames = (data) => {
  try {
    require("fs").mkdirSync(require("path").dirname(GAMES_DB_PATH), { recursive: true })
    require("fs").writeFileSync(GAMES_DB_PATH, JSON.stringify(data, null, 2))
  } catch {}
}

const WIN_COMBOS = [[0,1,2],[3,4,5],[6,7,8],[0,3,6],[1,4,7],[2,5,8],[0,4,8],[2,4,6]]

const checkWin = (board, player) => {
  return WIN_COMBOS.some(combo => combo.every(i => board[i] === player))
}

const checkDraw = (board) => !board.includes(null)

const renderBoard = (board) => {
  const symbols = board.map((v, i) => v === "X" ? "X" : v === "O" ? "O" : (i + 1).toString())
  return symbols[0] + " | " + symbols[1] + " | " + symbols[2] + "\n" +
         "---------\n" +
         symbols[3] + " | " + symbols[4] + " | " + symbols[5] + "\n" +
         "---------\n" +
         symbols[6] + " | " + symbols[7] + " | " + symbols[8]
}

const botMove = (board) => {
  // Try to win
  for (let i = 0; i < 9; i++) {
    if (!board[i]) {
      board[i] = "O"
      if (checkWin(board, "O")) { board[i] = null; return i }
      board[i] = null
    }
  }
  // Block player
  for (let i = 0; i < 9; i++) {
    if (!board[i]) {
      board[i] = "X"
      if (checkWin(board, "X")) { board[i] = null; return i }
      board[i] = null
    }
  }
  // Center
  if (!board[4]) return 4
  // Corners
  const corners = [0, 2, 6, 8].filter(i => !board[i])
  if (corners.length) return corners[Math.floor(Math.random() * corners.length)]
  // Any
  const available = board.map((v, i) => v ? -1 : i).filter(i => i >= 0)
  return available[Math.floor(Math.random() * available.length)]
}

const handler = async (m, { Rafz, command, text }) => {
  try {
    const px = (global.prefix && global.prefix[0]) || "/"
    const sender = String(m.sender)
    const q = (text || "").trim()
    const games = loadGames()

    if (command === "ttt" || command === "tictactoe") {
      const existing = Object.values(games).find(g => g.players.includes(sender) && !g.finished)
      if (existing) return m.reply("Kamu sudah ada game yang berjalan. Ketik " + px + "tttend untuk berhenti.")

      if (q.toLowerCase() === "bot" || q === "ai" || !q) {
        const gameId = crypto.randomBytes(4).toString("hex")
        const game = {
          id: gameId,
          board: Array(9).fill(null),
          players: [sender, "bot"],
          turn: sender,
          symbol: { [sender]: "X", bot: "O" },
          finished: false,
          vsBot: true,
          chat: String(m.chat),
          msgId: null
        }
        games[gameId] = game
        saveGames(games)

        const boardText = renderBoard(game.board)
        const sent = await m.reply(
          "TICTACTOE vs BOT\n\n" +
          "Kamu: X | Bot: O\n\n" +
          boardText + "\n\n" +
          "Giliran kamu! Ketik " + px + "tttmove 1-9",
          { parse_mode: "HTML" }
        )
        if (sent?.message_id) { game.msgId = sent.message_id; saveGames(games) }
        return true
      }

      // vs user
      const target = m.mentioned?.[0]?.id || (m.quoted?.sender ? String(m.quoted.sender) : null)
      if (!target || target === sender) return m.reply("Tag user lawan!\nContoh: " + px + "ttt @user")
      
      const targetGame = Object.values(games).find(g => g.players.includes(target) && !g.finished)
      if (targetGame) return m.reply("Lawanmu sudah ada game berjalan.")

      const gameId = crypto.randomBytes(4).toString("hex")
      const game = {
        id: gameId,
        board: Array(9).fill(null),
        players: [sender, target],
        turn: sender,
        symbol: { [sender]: "X", [target]: "O" },
        finished: false,
        vsBot: false,
        chat: String(m.chat),
        msgId: null
      }
      games[gameId] = game
      saveGames(games)

      const boardText = renderBoard(game.board)
      const sent = await m.reply(
        "TICTACTOE vs USER\n\n" +
        "X: <a href=\"tg://user?id=" + sender + "\"><code>" + sender + "</code></a>\n" +
        "O: <a href=\"tg://user?id=" + target + "\"><code>" + target + "</code></a>\n\n" +
        boardText + "\n\n" +
        "Giliran X! Ketik " + px + "tttmove 1-9",
        { parse_mode: "HTML" }
      )
      if (sent?.message_id) { game.msgId = sent.message_id; saveGames(games) }
      return true
    }

    if (command === "tttmove" || command === "tictactoemove") {
      const pos = parseInt(q) - 1
      if (isNaN(pos) || pos < 0 || pos > 8) return m.reply("Ketik " + px + "tttmove 1-9")

      const game = Object.values(games).find(g => g.players.includes(sender) && !g.finished)
      if (!game) return m.reply("Kamu tidak punya game aktif. Ketik " + px + "ttt bot")
      if (game.turn !== sender) return m.reply("Bukan giliranmu!")
      if (game.board[pos]) return m.reply("Posisi sudah terisi!")

      const mySymbol = game.symbol[sender]
      game.board[pos] = mySymbol

      if (checkWin(game.board, mySymbol)) {
        game.finished = true
        const boardText = renderBoard(game.board)
        delete games[game.id]; saveGames(games)
        return m.reply("TICTACTOE\n\n" + boardText + "\n\nKAMU MENANG!", { parse_mode: "HTML" })
      }

      if (checkDraw(game.board)) {
        game.finished = true
        const boardText = renderBoard(game.board)
        delete games[game.id]; saveGames(games)
        return m.reply("TICTACTOE\n\n" + boardText + "\n\nSERI!", { parse_mode: "HTML" })
      }

      // Bot turn
      if (game.vsBot) {
        const botPos = botMove(game.board)
        game.board[botPos] = "O"

        if (checkWin(game.board, "O")) {
          game.finished = true
          const boardText = renderBoard(game.board)
          delete games[game.id]; saveGames(games)
          return m.reply("TICTACTOE\n\n" + boardText + "\n\nBOT MENANG!", { parse_mode: "HTML" })
        }

        if (checkDraw(game.board)) {
          game.finished = true
          const boardText = renderBoard(game.board)
          delete games[game.id]; saveGames(games)
          return m.reply("TICTACTOE\n\n" + boardText + "\n\nSERI!", { parse_mode: "HTML" })
        }

        game.turn = sender
      } else {
        game.turn = game.players.find(p => p !== sender)
      }

      saveGames(games)
      const boardText = renderBoard(game.board)
      const nextPlayer = game.vsBot ? "Kamu" : game.turn
      return m.reply("TICTACTOE\n\n" + boardText + "\n\nGiliran: " + nextPlayer, { parse_mode: "HTML" })
    }

    if (command === "tttend" || command === "tictactoeend") {
      const game = Object.values(games).find(g => g.players.includes(sender) && !g.finished)
      if (!game) return m.reply("Tidak ada game aktif.")
      game.finished = true
      delete games[game.id]; saveGames(games)
      return m.reply("Game dihentikan.")
    }

    return false
  } catch (e) {
    console.error("[tictactoe]", e?.message)
    try { await m.reply("Error: " + (e?.message || e)) } catch {}
    return false
  }
}

handler.command = ["ttt", "tictactoe", "tttmove", "tictactoemove", "tttend", "tictactoeend"]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
