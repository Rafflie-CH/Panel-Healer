"use strict"
const https = require("https")
const fs = require("fs")

const GEMINI_API_KEY = process.env.GEMINI_API_KEY || ""
const GEMINI_URL = "https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key="

const httpPost = (url, body) =>
  new Promise((resolve, reject) => {
    try {
      const parsed = new URL(url)
      const data = JSON.stringify(body)
      const mod = parsed.protocol === "https:" ? https : require("http")
      const req = mod.request({
        hostname: parsed.hostname,
        path: parsed.pathname + parsed.search,
        method: "POST",
        headers: { "Content-Type": "application/json", "Content-Length": Buffer.byteLength(data) },
        timeout: 30000
      }, (res) => {
        let d = ""
        res.on("data", c => d += c)
        res.on("end", () => { try { resolve(JSON.parse(d)) } catch { resolve({ candidates: [] }) } })
      })
      req.on("error", reject)
      req.on("timeout", () => { req.destroy(); reject(new Error("Timeout")) })
      req.write(data)
      req.end()
    } catch (e) { reject(e) }
  })

const handler = async (m, { Rafz, command, text }) => {
  try {
    const sender = String(m.sender)
    const isCreator = (global.owner || []).includes(sender)
    if (!isCreator) return m.reply("Hanya Creator.")

    const errorLog = require("../library/errorlog")

    /* fitur fix AI dimatikan di clone (butuh API key & akses file utama) */
    if (global.isClone && (command === "errorfix" || command === "errorai"))
      return m.reply("⛔ Fitur AI-fix dinonaktifkan di clone bot.")

    if (command === "errorlist" || command === "geterror" || command === "geterrors") {
      const errors = errorLog.getErrors()
      if (!errors.length) return m.reply("✅ Tidak ada fitur error tercatat. Semua fitur sehat!")
      let out = "<b>⚠️ DAFTAR FITUR ERROR</b>\n\n"
      for (let i = 0; i < errors.length; i++) {
        out += (i+1) + ". <code>" + errors[i].feature + "</code>" +
          " (" + (errors[i].source || "?") + ", x" + (errors[i].count || 1) + ")\n" +
          "   ❌ " + (errors[i].error || "").slice(0, 120) + "\n"
      }
      out += "\n💡 Fix dengan tombol di notifikasi error, atau:\n" +
        "/errorfix <fitur> — AI fix\n" +
        "/errorcode <fitur> — lihat kode\n" +
        "/errordelete <fitur> — hapus dari daftar"
      return m.reply(out, { parse_mode: "HTML" })
    }

    if (command === "errorclear") {
      errorLog.clearErrors()
      return m.reply("Semua error log dihapus.")
    }

    if (command === "errorfix" || command === "errorai") {
      if (!text) return m.reply("Penggunaan: /errorfix <nama_fitur>")

      const errors = errorLog.getErrors()
      const entry = errors.find(e => e.feature === text || e.feature.includes(text))
      if (!entry) return m.reply("Fitur '" + text + "' tidak ada di error log.")

      const wait = await m.reply("AI sedang mencoba fix " + text + "...")

      // Read plugin/case code
      let code = ""
      let source = "plugin"
      try {
        if (fs.existsSync("./plugins/" + text + ".js")) {
          code = fs.readFileSync("./plugins/" + text + ".js", "utf8")
        } else if (fs.existsSync("./case.js")) {
          code = fs.readFileSync("./case.js", "utf8")
          source = "case"
        } else {
          throw new Error("File tidak ditemukan")
        }
      } catch (e) {
        try { await Rafz.editMessageText("Gagal baca kode: " + e.message, { chat_id: m.chat, message_id: wait.message_id }) } catch {}
        return m.reply("Gagal baca kode: " + e.message)
      }

      const prompt = "Fix this Telegram bot plugin code that has error:\n\nError: " + entry.error.slice(0, 200) + "\n\nCode:\n" + code.slice(0, 15000) + "\n\nReturn ONLY the fixed code, no explanation."

      try {
        const res = await httpPost(GEMINI_URL + GEMINI_API_KEY, {
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: { temperature: 0.1, maxOutputTokens: 8192 }
        })

        const fixed = res?.candidates?.[0]?.content?.parts?.[0]?.text || ""
        if (!fixed || fixed.length < 100) throw new Error("AI tidak menghasilkan fix yang valid")

        if (fixed.startsWith("```")) {
          const lines = fixed.split("\n")
          if (lines[0].startsWith("```")) lines.shift()
          if (lines[lines.length - 1].startsWith("```")) lines.pop()
        }

        // Save fix
        if (source === "plugin" && fs.existsSync("./plugins/" + text + ".js")) {
          fs.writeFileSync("./plugins/" + text + ".js", fixed)
        } else if (source === "case") {
          fs.writeFileSync("./case.js", fixed)
        }

        // Reload plugin
        try { delete require.cache[require.resolve("./plugins/" + text + ".js")] } catch {}
        try { delete require.cache[require.resolve("./case.js")] } catch {}

        errorLog.removeError(text)
        return m.reply("FIX BERHASIL!\nFitur: " + text + "\nSumber: " + source + "\n\nFile sudah diperbarui dan plugin direload. Coba jalankan fiturnya sekarang.", { parse_mode: "HTML" })
      } catch (aiErr) {
        return m.reply("AI fix gagal: " + aiErr.message)
      }
    }

    if (command === "errordelete") {
      if (!text) return m.reply("Penggunaan: /errordelete <nama_fitur>")
      const errors = errorLog.getErrors()
      const entry = errors.find(e => e.feature === text || e.feature.includes(text))
      if (!entry) return m.reply("Fitur '" + text + "' tidak ada di error log.")
      errorLog.removeError(text)
      return m.reply("Fitur '" + text + "' dihapus dari error log.")
    }

    if (command === "errorraw" || command === "errorai2") {
      if (!text) return m.reply("Penggunaan: /errorraw <nama_fitur>")
      const raw = errorLog.rawError(text) || errorLog.rawError(String(text).trim())
      if (!raw) {
        const all = errorLog.getErrors().find(e => e.feature.includes(text))
        if (!all) return m.reply("Fitur '" + text + "' tidak ada di error log.")
        return m.reply((errorLog.rawError(all.feature) || "-").slice(0, 3800), { parse_mode: "HTML" })
      }
      return m.reply(raw.slice(0, 3800), { parse_mode: "HTML" })
    }

    if (command === "errorcode") {
      if (!text) return m.reply("Penggunaan: /errorcode <nama_fitur>")
      const errors = errorLog.getErrors()
      const entry = errors.find(e => e.feature === text || e.feature.includes(text))
      if (!entry) return m.reply("Fitur '" + text + "' tidak ada di error log.")
      let code = ""
      try {
        if (fs.existsSync("./plugins/" + text + ".js")) code = fs.readFileSync("./plugins/" + text + ".js", "utf8")
        else if (fs.existsSync("./case.js")) code = fs.readFileSync("./case.js", "utf8")
      } catch {}
      if (!code) return m.reply("Kode tidak ditemukan.")
      return m.reply("<b>KODE: " + text + "</b>\n\n<code>" + code.slice(0, 3000).replace(/</g, "<").replace(/>/g, ">") + "</code>", { parse_mode: "HTML" })
    }

    return false
  } catch (e) {
    console.error("[gemini]", e?.message)
    try { await m.reply("Error: " + (e?.message || e)) } catch {}
    return false
  }
}

handler.command = ["errorfix", "errorai", "errorlist", "geterror", "geterrors", "errorclear", "errordelete", "errorcode", "errorraw", "errorai2"]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
