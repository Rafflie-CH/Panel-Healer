/* port5.js — fitur WA yang belum terport (rescan Furina/Prabowo/Rafzbotz).
   /ffstalk — cek akun FF via order.codashop.com (API resmi Codashop) ✅
   /githubstalk — profil GitHub (api.github.com) ✅
   /npmstalk — info package npm (registry.npmjs.org) ✅
   /tarot — kartu tarot random + arti (gambar via ishtarcollective/fallback) ✅
   /sambungkata — game sambung kata (port prabowo lib/sambungkata.js) ✅ lokal
   /ttsearch2 — search TikTok (tikwm; kalau diblokir Cloudflare → pakai API intern)
   Semua reply i18n (m.t) + tombol berstyle. */

"use strict"
const https = require("https")

const esc = (s) => String(s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")

const reqJson = (url, opts = {}) => new Promise((resolve, reject) => {
  const u = new URL(url)
  const req = https.request({
    hostname: u.hostname, path: u.pathname + u.search, method: opts.method || "GET",
    headers: { "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36", ...(opts.headers || {}) },
    timeout: 20000
  }, (res) => {
    let d = ""
    res.on("data", (c) => { d += c; if (d.length > 8e6) req.destroy() })
    res.on("end", () => {
      try { resolve(JSON.parse(d)) } catch (e) { reject(new Error("bad json (HTTP " + res.statusCode + ")")) }
    })
  })
  req.on("timeout", () => req.destroy(new Error("timeout")))
  req.on("error", reject)
  if (opts.body) req.write(typeof opts.body === "string" ? opts.body : JSON.stringify(opts.body))
  req.end()
})

/* ══════════════ FF STALK (api.isan.eu.org — terverifikasi hidup) ══════════════ */
const ffStalk = async (userId) => {
  const r = await reqJson("https://api.isan.eu.org/nickname/ff?id=" + encodeURIComponent(userId))
  if (!r || r.success === false || !r.name) throw new Error(r.message || "user not found")
  return { nickname: r.name, userId }
}

/* ══════════════ TAROT (kartu + arti lokal) ══════════════ */
const TAROT = [
  ["the-fool", "The Fool", "Awal baru, spontanitas, keberatan mengambil risiko"],
  ["the-magician", "The Magician", "Kemauan, kreativitas, kekuatan manifestasi"],
  ["the-high-priestess", "The High Priestess", "Intuisi, misteri, pengetahuan batin"],
  ["the-empress", "The Empress", "Kesuburan, kelimpahan, kasih sayang"],
  ["the-emperor", "The Emperor", "Otoritas, struktur, stabilitas"],
  ["the-hierophant", "The Hierophant", "Tradisi, bimbingan spiritual, pendidikan"],
  ["the-lovers", "The Lovers", "Cinta, harmoni, pilihan penting"],
  ["the-chariot", "The Chariot", "Kemenangan, tekad, kontrol"],
  ["strength", "Strength", "Keberanian, kesabaran, kekuatan batin"],
  ["the-hermit", "The Hermit", "Introspeksi, kesendirian, kebijaksanaan"],
  ["wheel-of-fortune", "Wheel of Fortune", "Perubahan takdir, keberuntungan, siklus"],
  ["justice", "Justice", "Keadilan, keseimbangan, kebenaran"],
  ["the-hanged-man", "The Hanged Man", "Perspektif baru, pengorbanan, menunggu"],
  ["death", "Death", "Akhir & awal, transformasi, perubahan besar"],
  ["temperance", "Temperance", "Moderasi, kesabaran, keseimbangan"],
  ["the-devil", "The Devil", "Keterikatan, godaan, materi"],
  ["the-tower", "The Tower", "Kejutan, kekacauan, pembongkaran"],
  ["the-star", "The Star", "Harapan, inspirasi, pemulihan"],
  ["the-moon", "The Moon", "Ilusi, ketakutan, alam bawah sadar"],
  ["the-sun", "The Sun", "Kebahagiaan, kesuksesan, vitalitas"],
  ["judgement", "Judgement", "Kebangkitan, evaluasi diri, pemanggilan"],
  ["the-world", "The World", "Penyelesaian, pencapaian, keutuhan"]
]

/* ══════════════ SAMBUNG KATA (lokal) ══════════════ */
const SAMBUNG_WORDS = ["apel", "lumpur", "rusa", "anggur", "ragam", "mata", "tas", "sapu", "ular", "radio", "obat", "tasbih", "hidup", "putih", "hati", "ironi", "ilusi", "sapi", "pisang", "gelas", "sandal", "lampu", "ujian", "nanas", "sabit", "timbangan", "nanas", "sepeda", "alpukat", "terigu", "ubur", "rambut", "tomat", "tulip", "perahu", "handuk", "kunci", "indigo", "origami", "imun"]
const last2 = (w) => String(w).slice(-2).toLowerCase()

/* ══════════════ handler ══════════════ */
const handler = async (m, { Rafz, command, text }) => {
  const tr = (k, v) => (m.t ? m.t(k, v) : key => key)
  const q = String(text || "").trim()
  const px = (global.prefix && global.prefix[0]) || "/"

  if (command === "ffstalk" || command === "cekff") {
    if (!/^\d{6,12}$/.test(q)) return m.reply("⚠️ <code>" + px + "ffstalk 123456789</code>", { parse_mode: "HTML" })
    try {
      const r = await ffStalk(q)
      return m.reply("🎮 <b>FREE FIRE</b>\n\n🆔 <code>" + esc(q) + "</code>\n👤 <b>" + esc(r.nickname) + "</b>", { parse_mode: "HTML" })
    } catch (e) {
      return m.reply("❌ " + (m.t ? m.t("common.failed") : "Failed") + " — " + esc(String(e.message || e).slice(0, 50)), { parse_mode: "HTML" })
    }
  }

  if (command === "githubstalk" || command === "ghstalk") {
    if (!q) return m.reply("⚠️ <code>" + px + "githubstalk torvalds</code>", { parse_mode: "HTML" })
    try {
      const u = await reqJson("https://api.github.com/users/" + encodeURIComponent(q))
      if (u.message) throw new Error(u.message)
      const repos = await reqJson("https://api.github.com/users/" + encodeURIComponent(q) + "/repos?per_page=5&sort=updated").catch(() => [])
      let out = "🐙 <b>GITHUB — " + esc(u.login) + "</b>\n\n"
      out += "👤 " + esc(u.name || "-") + "\n"
      if (u.bio) out += "📝 " + esc(String(u.bio).slice(0, 150)) + "\n"
      out += "📦 <b>Repos</b>: " + (u.public_repos || 0) + " • ⭐ " + (u.followers || 0) + " followers\n"
      out += "📍 " + esc(u.location || "-") + "\n"
      out += "📅 " + tr("port5.joined") + ": " + esc(String(u.created_at || "").slice(0, 10)) + "\n"
      if (Array.isArray(repos) && repos.length) {
        out += "\n🗂 <b>" + tr("port5.recentRepos") + ":</b>\n"
        repos.forEach(r => { out += "• " + esc(r.name) + " ⭐" + (r.stargazers_count || 0) + "\n" })
      }
      return m.reply(out.slice(0, 3500), { parse_mode: "HTML", reply_markup: { inline_keyboard: [[{ text: "🌐 GitHub", url: u.html_url, style: "primary" }]] } })
    } catch (e) {
      return m.reply("❌ " + (m.t ? m.t("common.failed") : "Failed") + " — " + esc(String(e.message || e).slice(0, 50)), { parse_mode: "HTML" })
    }
  }

  if (command === "npmstalk" || command === "npm2") {
    if (!q) return m.reply("⚠️ <code>" + px + "npmstalk axios</code>", { parse_mode: "HTML" })
    try {
      const p = await reqJson("https://registry.npmjs.org/" + encodeURIComponent(q))
      if (p.error) throw new Error("package not found")
      const latest = p["dist-tags"]?.latest || "?"
      const v = p.versions?.[latest] || {}
      let out = "📦 <b>NPM — " + esc(p.name) + "</b>\n\n"
      out += "🏷 <b>" + tr("port5.latest") + "</b>: " + esc(latest) + "\n"
      out += "📝 " + esc(String(v.description || "-").slice(0, 200)) + "\n"
      out += "📅 <b>" + tr("port5.modified") + "</b>: " + esc(String(p.time?.modified || "").slice(0, 10)) + "\n"
      out += "🔢 <b>" + tr("port5.versions") + "</b>: " + Object.keys(p.versions || {}).length + "\n"
      if (v.author?.name) out += "👤 " + esc(v.author.name) + "\n"
      if (v.homepage) out += "🔗 " + esc(String(v.homepage).slice(0, 70)) + "\n"
      const kb = { inline_keyboard: [[{ text: "🌐 npmjs.com", url: "https://www.npmjs.com/package/" + encodeURIComponent(q), style: "primary" }]] }
      return m.reply(out.slice(0, 3500), { parse_mode: "HTML", reply_markup: kb })
    } catch (e) {
      return m.reply("❌ " + (m.t ? m.t("common.failed") : "Failed") + " — " + esc(String(e.message || e).slice(0, 50)), { parse_mode: "HTML" })
    }
  }

  if (command === "tarot") {
    const [file, name, meaning] = TAROT[Math.floor(Math.random() * TAROT.length)]
    const up = Math.random() > 0.5
    const urls = [
      "https://www.trustedtarot.com/img/cards/" + file + ".png",
      "https://ishtarcollective.blob.core.windows.net/rider-waite-tarot/" + file + ".jpg"
    ]
    const caption = "🔮 <b>TAROT — " + esc(name) + (up ? " (Upright)" : " (Reversed)") + "</b>\n\n💡 " + esc(up ? meaning : "Energi terbalik: " + meaning) + "\n\n<i>" + (m.t ? m.t("maker.fakeWarn") : "For fun only") + "</i>"
    for (const u of urls) {
      try { await Rafz.sendPhoto(m.chat, u, { caption, parse_mode: "HTML", reply_to_message_id: m.id, allow_sending_without_reply: true }); return true } catch {}
    }
    /* fallback tanpa gambar */
    return m.reply(caption, { parse_mode: "HTML" })
  }

  if (command === "sambungkata") {
    const S = (global.sambung = global.sambung || {})
    const key = String(m.chat)
    if (!S[key]) {
      const w = SAMBUNG_WORDS[Math.floor(Math.random() * SAMBUNG_WORDS.length)]
      S[key] = { word: w, by: String(m.sender), at: Date.now() }
      return m.reply("🔗 <b>SAMBUNG KATA</b>\n\n🅰️ " + tr("port5.skStart") + ": <b>" + esc(w) + "</b>\n\n👉 " + tr("port5.skRule") + " <b>...<code>" + esc(last2(w)) + "</code></b>\n⏱ 120s", { parse_mode: "HTML" })
    }
    delete S[key]
    return m.reply("🛑 <b>SAMBUNG KATA</b> " + tr("port5.ended"), { parse_mode: "HTML" })
  }

  if (command === "ttsearch2" || command === "ttdl2") {
    /* tikwm.com DIBLOKIR Cloudflare (403 permanen) → info jelas, bukan "gagal" generik */
    return m.reply("🚫 " + (m.t ? m.t("port5.tikwmDead") : "Search TikTok tidak tersedia (API diblokir)") + "\n💡 " + (m.t ? m.t("port5.tikwmAlt") : "Gunakan /ttsearch"), { parse_mode: "HTML" })
  }

  return false
}

/* hook jawaban sambung kata (non-command) */
const skHook = async (m) => {
  try {
    if (m.isCmd) return false
    const S = global.sambung || {}
    const key = String(m.chat)
    const st = S[key]
    if (!st) return false
    if (Date.now() - st.at > 120000) { delete S[key]; return false }
    const w = String(m.body || "").trim().toLowerCase()
    if (!/^[a-z]{3,}$/.test(w)) return false
    if (last2(w) === last2(st.word) && w !== st.word) {
      S[key] = { word: w, by: String(m.sender), at: Date.now() }
      await m.reply("✅ <b>" + esc(w) + "</b> — " + (m.t ? m.t("port5.nextWord") : "next word ending with") + " <b>...<code>" + esc(last2(w)) + "</code></b>", { parse_mode: "HTML" })
      return true
    }
    return false
  } catch { return false }
}

try {
  const prevHook = global.roseMsgHook
  global.roseMsgHook = async (m, ctx) => {
    const g = await skHook(m)
    if (g === true) return true
    if (typeof prevHook === "function") return prevHook(m, ctx)
    return false
  }
} catch {}

handler.command = ["ffstalk", "cekff", "githubstalk", "ghstalk", "npmstalk", "npm2", "tarot", "sambungkata", "ttsearch2", "ttdl2"] /* ttsearch2/ttdl2 = stub (tikwm diblokir) */
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
