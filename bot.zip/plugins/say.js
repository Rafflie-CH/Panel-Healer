let handler = async (m, { args }) => {
  try {
    const tr = (key, vars) => (m.t ? m.t(key, vars) : key)
    if (!args || !args[0]) return m.reply(tr("say.noText"))
    await m.reply(args.join(" "))
  } catch (e) {
    console.log("say plugin error:", e.message)
    try {
      await m.reply("Error: " + (e.message || "unknown"))
    } catch {}
  }
}

handler.command = ["say"]

module.exports = handler

try {
  let fs = require("fs")
  let file = require.resolve(__filename)
  fs.watchFile(file, () => {
    try {
      fs.unwatchFile(file)
      delete require.cache[file]
      require(file)
    } catch {}
  })
} catch {}
