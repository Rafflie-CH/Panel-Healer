/* plugin: premium.js — Alight Motion Premium (3 mode)
   1. /ampremium email      → kirim link premium AM ke email (API key owner, dari Prabowo MD)
   2. /amverify email|link  → verifikasi link aktivasi premium
   3. /presetam link        → info preset Alight Motion dari share link (dari RafzBotz)

   + /fakelobby (fake lobby FF/ML) tetap di sini.

   API key diset lewat /set amkey SK-XXXX (disimpan di settings.js → global.amkey).
   Kalau API premium-key mati/403, otomatis fallback ke reg-email OTP
   (lemon-email API dari RafzBotz) supaya fitur tetap jalan. */

"use strict"
const https = require("https")
const http = require("http")
const fs = require("fs")
const path = require("path")
const fakeimg = require("../library/fakeimg")

const SETTINGS_PATH = path.join(__dirname, "..", "settings.js")
const AM_REG_DB = "./library/database/amreg.json"

const getBuffer = (url) =>
  new Promise((resolve, reject) => {
    const follow = (u) => {
      try {
        const mod = u.startsWith("https") ? https : http
        const parsed = new URL(u)
        mod.get({
          hostname: parsed.hostname,
          path: parsed.pathname + parsed.search,
          timeout: 30000,
          headers: { "User-Agent": "Mozilla/5.0" }
        }, (res) => {
          if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location)
            return follow(new URL(res.headers.location, u).href)
          if (res.statusCode !== 200) return reject(new Error("HTTP " + res.statusCode))
          const c = []
          res.on("data", d => c.push(d))
          res.on("end", () => resolve(Buffer.concat(c)))
          res.on("error", reject)
        }).on("error", reject).on("timeout", function() { this.destroy(); reject(new Error("Timeout")) })
      } catch (e) { reject(e) }
    }
    follow(url)
  })

const httpPostJson = (url, obj, hdrs = {}) =>
  new Promise((resolve, reject) => {
    try {
      const parsed = new URL(url)
      const data = JSON.stringify(obj)
      const mod = parsed.protocol === "https:" ? https : http
      const req = mod.request({
        hostname: parsed.hostname,
        path: parsed.pathname + parsed.search,
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Content-Length": Buffer.byteLength(data),
          "User-Agent": "Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 Chrome/134.0.0.0 Mobile Safari/537.36",
          "Origin": parsed.origin,
          "Referer": parsed.origin + "/",
          ...hdrs
        },
        timeout: 30000
      }, (res) => {
        let d = ""
        res.on("data", c => d += c)
        res.on("end", () => { try { resolve({ status: res.statusCode, body: JSON.parse(d) }) } catch { resolve({ status: res.statusCode, body: d }) } })
      })
      req.on("error", reject)
      req.on("timeout", () => { req.destroy(); reject(new Error("Timeout")) })
      req.write(data)
      req.end()
    } catch (e) { reject(e) }
  })

const httpGetJson = async (url) => {
  const buf = await getBuffer(url)
  try { return JSON.parse(buf.toString("utf8")) } catch { return null }
}

/* ── DB registrasi AM ── */
const loadReg = () => { try { const j = JSON.parse(fs.readFileSync(AM_REG_DB, "utf8")); return (j && typeof j === "object" && !Array.isArray(j)) ? j : {} } catch { return {} } }
const saveReg = (d) => { try { fs.mkdirSync(path.dirname(AM_REG_DB), { recursive: true }); fs.writeFileSync(AM_REG_DB, JSON.stringify(d, null, 2)) } catch {} }

const genOtp = () => String(Math.floor(100000 + Math.random() * 900000))

/* ── kirim email via lemon-email (API RafzBotz) ── */
const sendEmailLemon = async (to, subject, message) => {
  const { status, body } = await httpPostJson("https://lemon-email.vercel.app/send-email",
    { to: String(to).trim(), subject: String(subject).trim(), message: String(message).trim() })
  if (status >= 200 && status < 300 && body && body.status === "success") return { ok: true }
  return { ok: false, error: (body && body.message) || ("HTTP " + status) }
}

/* ── API premium AM (free-restapi, butuh key owner) ── */
const amPremiumSend = async (email, key) =>
  httpGetJson(`https://www.free-restapi.biz.id/api/alightmotion-send?email=${encodeURIComponent(email)}&apikey=${encodeURIComponent(key)}`)

const amPremiumVerify = async (email, link, key) =>
  httpGetJson(`https://www.free-restapi.biz.id/api/alightmotion-verify?email=${encodeURIComponent(email)}&link=${encodeURIComponent(link)}&apikey=${encodeURIComponent(key)}`)

const isEmail = (s) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(s || "").trim())

const AMPREMIUM_HELP = (px) =>
  `<b>✨ ALIGHT MOTION PREMIUM</b>\n\n` +
  `1️⃣ Kirim link premium ke email:\n<code>${px}ampremium email@kamu.com</code>\n\n` +
  `2️⃣ Verifikasi link dari email:\n<code>${px}amverify email|link_verifikasi</code>\n\n` +
  `3️⃣ Registrasi via email + OTP:\n<code>${px}amreg email|nama</code>\nlalu <code>${px}amotp kode_otp</code>\n\n` +
  `4️⃣ Info preset AM dari share link:\n<code>${px}presetam https://alight.link/...</code>`

const handler = async (m, { Rafz, command, text }) => {
  try {
    const px = (global.prefix && global.prefix[0]) || "/"
    const q = (text || "").trim()
    const sender = String(m.sender)

    /* ─────────── /ampremium email ─────────── */
    if (command === "ampremium" || command === "amprem" || command === "ampremium2" || command === "amprem2") {
      if (!q || !isEmail(q))
        return m.reply(`📧 Input email kamu!\nContoh: <code>${px}ampremium email@domain.com</code>`, { parse_mode: "HTML" })
      const email = q.trim()
      const wait = await m.reply("⏳ Mengirim link premium ke email...", { parse_mode: "HTML" })
      const del = () => { try { Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {}) } catch {} }

      const key = global.amkey || ""
      let ok = false, msg = ""

      if (key) {
        try {
          const res = await amPremiumSend(email, key)
          if (res && (res.status === true || res.status === 200)) {
            ok = true
            msg =
              `✅ <b>ALIGHT MOTION PREMIUM BERHASIL</b>\n_Link verifikasi berhasil dikirim ke email_\n\n` +
              `📧 <b>Target Email:</b> <code>${email}</code>\n\n` +
              `📌 <b>LANGKAH AKTIVASI:</b>\n` +
              `1️⃣ Cek kotak masuk / <b>folder spam</b> — cari email dari Alight Motion\n` +
              `2️⃣ Tekan tombol <b>"Login"</b> di dalam email\n` +
              `3️⃣ Salin seluruh link yang muncul di browser\n\n` +
              `📝 Setelah itu verifikasi dengan:\n<code>${px}amverify ${email} | link_dari_browser</code>`
          } else {
            const rsn = (res && res.data && res.data.message) || (res && res.message) || "API menolak"
            msg = "⚠️ API premium: " + String(rsn).slice(0, 120)
          }
        } catch (e) { msg = "⚠️ API premium error: " + e.message }
      } else {
        msg = "⚠️ API key belum diset. Owner bisa set dengan <code>" + px + "set amkey SK-XXXX</code>"
      }

      /* fallback: kirim panduan aktivasi via lemon-email supaya user tetap dapat email */
      if (!ok) {
        try {
          const mail = await sendEmailLemon(email,
            "Alight Motion Premium - Panduan Aktivasi",
            "Halo!\n\nBerikut panduan aktivasi Alight Motion PREMIUM:\n\n" +
            "1. Pastikan aplikasi Alight Motion terbaru terinstall\n" +
            "2. Buat/verifikasi akun dengan email ini\n" +
            "3. Hubungi owner bot untuk aktivasi premium (kirim email ini sebagai bukti)\n\n" +
            "Terima kasih!")
          if (mail.ok) msg += "\n\n📩 Panduan aktivasi juga dikirim ke email kamu."
        } catch {}
      }

      del()
      return m.reply(msg + "\n\n" + AMPREMIUM_HELP(px), { parse_mode: "HTML" })
    }

    /* ─────────── /amverify email|link ─────────── */
    if (command === "amverify" || command === "amverify2" || command === "amverif") {
      const parts = q.split("|").map(s => s.trim())
      const email = parts[0], link = parts.slice(1).join("|")
      if (!email || !link || !isEmail(email))
        return m.reply(`❌ <b>Format Salah!</b>\n\nGunakan format:\n<code>${px}amverify email@domain.com | link_verifikasi</code>\n\nContoh:\n<code>${px}amverify user@gmail.com | https://www.alightmotion.com/verify/xxx</code>`, { parse_mode: "HTML" })

      const wait = await m.reply("⏳ Memverifikasi...", { parse_mode: "HTML" })
      const del = () => { try { Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {}) } catch {} }

      const key = global.amkey || ""
      if (!key) {
        del()
        return m.reply("⚠️ API key belum diset. Owner set dengan <code>" + px + "set amkey SK-XXXX</code>", { parse_mode: "HTML" })
      }

      try {
        const res = await amPremiumVerify(email, link, key)
        del()
        if (res && (res.status === true || res.status === 200)) {
          const code = res.data?.codeOrder || "-"
          return m.reply(
            `✅ <b>VERIFIKASI SUKSES</b>\n_Akun premium aktif!_\n\n` +
            `📧 Email: <code>${email}</code>\n⏰ Durasi: <code>1 Tahun</code>\n📌 Code Order: <code>${code}</code>\n\n` +
            `Silakan login di aplikasi Alight Motion dengan email tersebut.\n` +
            `Nikmati semua fitur premium, efek berbayar, dan ekspor tanpa watermark! 🎉`,
            { parse_mode: "HTML" }
          )
        }
        return m.reply("❌ <b>Gagal Verifikasi!</b>\n" + String((res && res.data && res.data.message) || (res && res.message) || "API menolak").slice(0, 150), { parse_mode: "HTML" })
      } catch (e) {
        del()
        return m.reply("❌ Error: " + e.message, { parse_mode: "HTML" })
      }
    }

    /* ─────────── /amreg email|nama — registrasi via email + OTP ─────────── */
    if (command === "amreg" || command === "amregister" || command === "regemail") {
      const parts = q.split("|").map(s => s.trim())
      const email = parts[0], nama = parts[1] || "User AM"
      if (!email || !isEmail(email))
        return m.reply(`Format: <code>${px}amreg email|nama</code>\nContoh: <code>${px}amreg user@gmail.com|Dika</code>`, { parse_mode: "HTML" })

      const wait = await m.reply("⏳ Mengirim kode OTP ke email...", { parse_mode: "HTML" })
      const otp = genOtp()
      const mail = await sendEmailLemon(email,
        "Kode Verifikasi Alight Motion",
        `Halo ${nama}!\n\nKode OTP kamu: ${otp}\n\nKirim dengan perintah:\n${px}amotp ${otp}`)
      try { Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {}) } catch {}

      if (!mail.ok)
        return m.reply("❌ Gagal kirim OTP ke email: " + (mail.error || "unknown"), { parse_mode: "HTML" })

      const db = loadReg()
      db[sender] = { email, nama, otp, at: Date.now() }
      saveReg(db)
      return m.reply(
        `📩 Kode OTP telah dikirim ke: <code>${email}</code>\n\n` +
        `Verifikasi dengan:\n<code>${px}amotp kode_otp</code>`,
        { parse_mode: "HTML" }
      )
    }

    /* ─────────── /amotp kode — verifikasi OTP ─────────── */
    if (command === "amotp" || command === "amverifotp" || command === "verifemail") {
      const db = loadReg()
      const reg = db[sender]
      if (!reg) return m.reply("Tidak ada registrasi aktif. Mulai dengan <code>" + px + "amreg email|nama</code>", { parse_mode: "HTML" })
      if (Date.now() - reg.at > 15 * 60 * 1000) {
        delete db[sender]; saveReg(db)
        return m.reply("Kode OTP kedaluwarsa. Ulangi <code>" + px + "amreg email|nama</code>", { parse_mode: "HTML" })
      }
      if (String(q).trim() !== reg.otp) return m.reply("❌ Kode OTP salah.")
      delete db[sender]; saveReg(db)
      return m.reply(
        `✅ <b>Email terverifikasi!</b>\n\n📧 <code>${reg.email}</code>\n👤 ${reg.nama}\n\n` +
        `Data ini yang dipakai untuk aktivasi premium. Hubungi owner jika belum aktif.`,
        { parse_mode: "HTML" }
      )
    }

    /* ─────────── /presetam link — info preset AM (RafzBotz) ─────────── */
    if (command === "presetam" || command === "ampreset") {
      if (!q) return m.reply(`Contoh: <code>${px}presetam https://alightcreative.com/am/share/u/xxx/p/xxx</code>`, { parse_mode: "HTML" })
      if (!/^https?:\/\//i.test(q)) return m.reply("URL tidak valid. Tambahkan http:// atau https://")
      if (!/(alight\.link|alightcreative\.com)/i.test(q)) return m.reply("URL Alight Motion tidak valid.")
      const wait = await m.reply("⏳ Mengambil info preset...", { parse_mode: "HTML" })
      try {
        const buf = await getBuffer(q)
        const html = buf.toString("utf8")
        const meta = (prop) => {
          const re = new RegExp('<meta[^>]+(?:property|name)="' + prop + '"[^>]+content="([^"]*)"')
          const mm = html.match(re)
          return mm ? mm[1] : null
        }
        const title = meta("og:title") || "Tidak ditemukan"
        const desc = meta("og:description") || "Tidak ditemukan"
        try { Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {}) } catch {}
        return m.reply(`<b>✨ PRESET ALIGHT MOTION</b>\n\njudul: ${title}\ndeskripsi: ${desc}\n\n🔗 ${q}`, { parse_mode: "HTML", disable_web_page_preview: true })
      } catch (e) {
        try { Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {}) } catch {}
        return m.reply("Gagal mengambil info preset. Pastikan URL benar dan coba lagi.")
      }
    }

    /* ─────────── /fakelobby game|judul (FOTO) ─────────── */
    if (command === "fakelobby" || command === "flobby") {
      const tr = (key, vars) => (m.t ? m.t(key, vars) : key)
      if (!q) return m.reply(
        "⚠️ " + tr("use.usage") + ": " + px + "fakelobby ff|judul\n" +
        tr("use.example") + ": " + px + "fakelobby ff|Ranked Push",
        { parse_mode: "HTML" }
      )
      const parts = q.split("|")
      const game = (parts[0] || "ff").toLowerCase()
      const title = parts.slice(1).join("|") || "Lobby"
      if (game !== "ff" && game !== "ml")
        return m.reply(tr("prem.unknownGame"))

      const wait = await m.reply("⏳ " + tr("use.making") + "...", { parse_mode: "HTML" })
      try {
        const buf = await fakeimg.fakeLobby(game, title)
        try { Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {}) } catch {}
        await Rafz.sendPhoto(m.chat, buf, {
          caption: "🎮 <b>" + (game === "ff" ? "FREE FIRE" : "MOBILE LEGENDS") + " LOBBY</b>\n" + tr("maker.title") + ": " + fakeimg.escapeXml(title) + "\n\n" + tr("maker.joinNow") + "\n<i>" + tr("maker.fakeWarn") + "</i>",
          parse_mode: "HTML",
          reply_to_message_id: m.id,
          allow_sending_without_reply: true
        })
        return true
      } catch (e) {
        try { Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {}) } catch {}
        return m.reply("❌ " + tr("use.failed") + " " + e.message)
      }
    }

    return false
  } catch (e) {
    console.error("[premium]", e?.message)
    try { await m.reply("Error: " + (e?.message || e)) } catch {}
    return false
  }
}

handler.command = ["ampremium", "amprem", "ampremium2", "amprem2", "amverify", "amverify2", "amverif", "amreg", "amregister", "regemail", "amotp", "amverifotp", "verifemail", "presetam", "ampreset", "fakelobby", "flobby"]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
