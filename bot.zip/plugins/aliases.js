/* plugin: aliases.js — daftar semua command ke Telegram (menu garis 3)
   + shortcut alias biar command panjang bisa diketik singkat.

   /setcommands (owner)   → daftarkan ulang command list ke Telegram
   Daftar command otomatis dibuang yang owner-only (Telegram menampilkan
   ini ke SEMUA user, jadi cuma fitur publik yang masuk).

   Alias otomatis (contoh):
     /youtubedownload → /ytdl      /youtubemp3 → /ytdl
     /tiktokdownload → /tt         /stickerline → /sticker
     /wikipedia → /wiki            /kalkulator → /calc
     /cuacahariini → /weather      /terjemah → /tr
     /bantuan → /menu              /awal → /start                */

"use strict"
const fs = require("fs")
const path = require("path")

/* ── ALIAS: shortcut → command asli ── */
const ALIASES = {
  /* Rose / Barker / Protectron batch-5 */
  myid: "id", chatid: "id", userinfo: "info", user: "info",
  administrator: "promote", adminpromote: "promote", admindemote: "demote",
  warningsmode: "setwarnmode", warnlimit: "setwarnlimit", resetwarns: "resetwarn",
  delwarn: "unwarn", removewarn: "unwarn",
  delrules: "clearrules", rule: "rules",
  unpin_all: "unpinall", pinall: "unpinall",
  delnote: "clear", delnoteall: "clearall", savememo: "save",
  removeword: "rmblocklist", blockedwords: "blocklist",
  unbanall: "unban", banuser: "ban", muteuser: "mute",
  connectchat: "connect", connectionslist: "connections",
  locktype: "locktypes", locklist: "locks",
  welcomehelp2: "welcomehelp", ruleswelcome: "welcomehelp",
  antiraidtime: "raidtime", raid: "antiraid",
  floodsetting: "flood", floodmode: "setfloodmode",
  gifsearch: "gif", tenor: "gif",
  urbandictionary: "ud", urban: "ud",
  addhelperbot: "addhelper",
  whitelists: "whitelist", blacklists: "blacklist",
  statusshield: "status", protectron: "status",
  /* YouTube */
  youtubedownload: "ytdl", ytdownload: "ytdl", ytmp3: "ytdl", ytmp4: "ytdl",
  youtube: "ytdl", lagu: "play", musik: "play", music: "play",
  /* TikTok */
  tiktokdownload: "tt", ttdl: "tt", tiktok: "tt",
  /* Sticker */
  stickerline: "sticker", stikerin: "sticker", stikerr: "sticker",
  bratgenerator: "brat", bratvid: "brat", quotemaker: "qc", quotesticker: "qc",
  memesticker: "smeme", memestick: "smeme",
  /* Utility */
  wikipedia: "wiki", kalkulator: "calc", kalku: "calc",
  cuacahariini: "weather", cuaca2: "weather",
  terjemah: "tr", translate2: "tr", terjemahan: "tr",
  pendeklink: "short", shortlink2: "short", shorturl: "short",
  texttospeech: "tts", suarabot: "tts", suara: "tts",
  qrcode: "qr", gambarqr: "qr",
  tangkapanlayar: "ss", screenshotweb: "ss", ssweb2: "ss",
  passwordku: "pass", buatpassword: "pass",
  infokota: "time", jamsekarang: "time",
  /* Search & stalk */
  cari: "google", gsearch2: "google", carigoogel: "google",
  gambar: "pinterest", image: "pinterest",
  stalkig: "igstalk", igstalker: "igstalk",
  stalktt: "tiktokstalk", ttstalker: "tiktokstalk",
  stalkgithub: "githubstalk", ghstalker: "githubstalk",
  /* Audio FX */
  bassboost: "bass", bassbooster: "bass",
  percepat: "fast", perlahan: "slow", cepat: "fast", lambat: "slow",
  suararobot: "robot", suarajerapah: "earrape", suaratupai: "tupai",
  /* Primbon & fun */
  cintacak: "love", pasangan: "love", kecocokan: "love",
  tafsirmimpi2: "artimimpi", mimpiku: "artimimpi",
  ramalanzodiak: "zodiak", zodiakku: "zodiak",
  katakata: "quote", katabijak2: "bijak", quote2: "quote",
  /* Panel */
  buatpanel: "cpanel", createpanel: "cpanel", panelbaru: "cpanel",
  hapuspanel: "delpanel", panelku: "listpanel", panelgwa: "mypanel",
  buatadmin: "cadmin", createadmin: "cadmin",
  /* Identity */
  daftarseller: "addseller", tambahseller: "addseller",
  daftarowner: "addowner", tambahowner: "addowner",
  /* Misc */
  bantuan: "menu", help2: "menu", menuutama: "menu", daftarfitur: "allmenu",
  allmenu2: "allmenu", listcommand: "listfitur",
  infogempa: "gempa", gempaterkini: "gempa",
  fotoprofil: "getpp", ppku: "getpp",
  berhenti: "batal", stop: "batal", reset: "batal",
  /* porting WA bot — downloader & search */
  searchtiktok2: "ttsearch", ttsr: "ttsearch",
  spotifysearch2: "ssearch", soundcloudsearch: "scs",
  pinterestdl2: "pindl", pinhd: "pindl",
  sfilematis2: "sfile", gdrivesearch2: "gdrive",
  modapk: "apkmod", hmods: "happymod",
  allinone: "aiodl", links: "aiodl",
  /* porting WA — stalk */
  npmdetil: "npmstalk2", npmsearch2: "npmsearch",
  rbxstalk: "robloxstalk2", stalkroblox2: "robloxstalk2",
  stalkthreads: "threadsstalk", xuser: "xstalk",
  mcmod: "modrinth", modmc: "modrinth",
  fontku: "fontlist", carifont: "fontlist",
  /* porting WA batch-4 — fx populer & command baru */
  ttp: "ttp2", attp: "attp2",
  neonlight: "neon", neoneffect: "neon", galaxytext: "galaxy",
  underwater: "3dunderwater", sandsummer: "writeinsandsummerbeach",
  avengertext: "logo3davengers", blackpinktext: "blackpinklogo",
  glitchtext: "digitalglitch", pixelglitch: "aawesomeglitch",
  brokenglass2: "brokenglassphoto", pencilart: "pencilphoto",
  tearimage: "tearphoto", crtframe: "brokenglassphoto",
  surahlist: "surah", daftarsurah: "surah", bacaansurah: "surah",
  ayatquran: "ayat", cariayat: "ayat", murotalquran: "murotal",
  jadwalshalat: "jadwalsholat", jadwal2: "jadwalsholat", shalat: "jadwalsholat",
  arahkiblat: "kiblat", qibladirection: "kiblat", kalenderhijriah: "hijri",
  tanggalhijriah: "hijri", doaharian3: "doa", kumpulandoa: "doa",
  bacaantahlil: "tahlil", asmaulhusna3: "asmaulhusna2",
  ramalannasibku: "ramalannasib", nasibramalan: "ramalannasib",
  usahabisnis: "sifatusaha", rejekihoki2: "rejekihoki",
  potensipenyakit2: "potensipenyakit", tarotkartu: "kartutarot",
  tarotcek: "kartutarot", fengshuicek: "fengshui",
  karaktersifat: "sifatkarakter", keberuntungan: "potensikeberuntungan",
  haribaikcek: "haribaik", harisangar2: "harisangar", harinaas2: "harinaas",
  nagahari2: "nagahari", arahrejeki2alias: "arahrejeki",
  peruntungan2: "ramalanperuntungan", masasuburcek: "masasubur",
  zodiakcheck: "zodiakcek", shiocheck: "shiocek",
  nomorhoki2: "nomorhoki", nomorhoki3: "nomorhoki",
  wetonjawacek: "wetonjawa", memancing: "memancingikan",
  kecocokannama: "cocoknama", pantun2: "pantun", pantunmerdeka: "pantun",
  renunganharian: "renungan", katacinta2: "katacinta",
  gombalan2: "gombal2", bucinquote: "bucin2", motivasiku: "motivasi2",
  bijakquote: "bijak2", faktaunik: "fakta2", wangywangy: "wangy",
  siapakah: "siapa", kapankah2: "kapan", dimanakah: "dimana",
  quizcaklontong: "caklontong", lontong: "caklontong",
  tebakalimat: "tebakkalimat", tebakalimat2: "tebakkalimat",
  tebakkabupaten2: "tebakkabupaten", tebakkabupaten3: "tebakkabupaten",
  tebakkimia2: "tebakkimia", tebakkimia3: "tebakkimia",
  tebaklirik2: "tebaklirik", tebaklirik3: "tebaklirik",
  tebakbendera3: "tebakbendera2", soalaktif: "soal3",
  tiktoknowm: "ttnowm", tiktoknowm2: "ttnowm", ttwm: "ttnowm",
  tiktokaudio: "ttaudio", tiktokmp3: "ttaudio", ttmusik: "ttmusic",
  tiktokinfo: "ttinfo", ttstalk2: "ttinfo",
  minecraft: "mcserver", mcstatus2: "mcserver", mccheck: "mcserver",
  kursbca: "kurs", kursmatauang: "kurs", rates: "kurs",
  gempabumi2: "gempa2", gempaterkini2: "gempa2", bmkg: "gempa2",
  wilayah: "provinsi", wilayahindonesia: "provinsi", daftarprovinsi: "provinsi",
  apkmir: "apkmirror", apkpuredl: "apkpure",
  /* porting WA — fun & islami */
  cekjanda: "janda", cekduda: "duda", cekpedofil: "pedofil",
  cekpenyakit: "penyakit", cekpekerjaan: "pekerjaan",
  ceknasib: "nasib", cekrezeki: "rezeki", ceksifat2: "sifat",
  cekhobi: "hobi", cekpintar: "pintar", cekmaling: "maling",
  haribaik2: "haribaik", harisial2: "harisial",
  ceknikah: "nikah", cekpesugihan2: "pesugihan", cekhoki: "hoki", cekfuture: "future",
  doaharian2: "doa", wirid2: "wirid", asma2: "asmaulhusna",
  kursi: "ayatkursi", niat: "niatsholat", tahilsingkat: "tahlil",
  /* porting WA — media & games */
  tohd2: "tohd", jernihkan: "tohd", bunder: "tocircle",
  hitamputih: "tograyscale", sepia2: "tosepia", pixelku: "topixel",
  putarfoto: "rotate", cerminfoto: "flop",
  reactchat: "fakereact", ketik2: "typewriter", captchaku: "captcha",
  tebaklagu2: "tebaklagu", tebakkata2: "tebakkata", tebakgame2: "tebakgame", bom: "tebakbom",
  /* porting WA — grup & owner */
  absensi: "absen", absenrekap: "absenlist", absentutup: "absenreset",
  votingmulai: "votemulai", votinghasil: "votehasil", votingtutup: "voteselesai",
  pengumuman2: "pengumuman", announce2: "announce",
  tambahseller2: "addseller2", tambahowner2b: "addowner2",
  warning: "warn2", cekwarning2: "cekwarn", resetwarns: "resetwarn2",
  cloneoff: "stopclone", clonestop: "stopclone",
  tambahserver: "addserver", serverbaru: "addserver", hapusserver: "delserver",
  tambahsubdo: "addsubdo", domainbaru: "addsubdo", hapusdomain: "deldomain"
}

/* ── handler: /alias <cmd> [args] dan /setcommands ── */
const handler = async (m, { Rafz, command, text }) => {
  try {
    const px = (global.prefix && global.prefix[0]) || "/"
    const sender = String(m.sender)
    const isCreator = (global.owner || []).includes(sender)

    /* ── /setcommands — daftarkan command list ke Telegram (menu garis 3) ── */
    if (command === "setcommands" || command === "setcmd") {
      if (!isCreator) return m.reply(m.t ? m.t("denied.owner") : "⛔ Owner only.")
      const wait = await m.reply(m.t ? m.t("cmdlist.registering") : "Registering...", { parse_mode: "HTML" })
      const res = await buildAndSetCommands(Rafz)
      try { Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {}) } catch {}
      return m.reply(
        res.ok
          ? `✅ ` + (m.t ? m.t("cmdlist.ok", { n: res.count }) : res.count + " commands registered.")
          : "❌ " + res.error,
        { parse_mode: "HTML" }
      )
    }

    /* ── /batal2 — alias lain tak perlu, /batal di case.js ── */
    return false
  } catch (e) {
    console.error("[aliases]", e?.message)
    return false
  }
}

/* ── kumpulkan command publik dari semua plugin → setMyCommands ── */
const buildAndSetCommands = async (Rafz) => {
  try {
    const pluginsDir = path.join(__dirname, "..", "plugins")
    const files = fs.readdirSync(pluginsDir).filter(f => f.endsWith(".js"))
    const skipCmds = new Set([
      /* internal / callback */
      "ytdl_dl", "tt_dl", "cpanel_server",
      /* owner-only & rawan abuse — tidak masuk menu publik Telegram */
      "set", "getset", "settinginfo", "addowner", "delowner", "listowner",
      "addseller", "delseller", "listseller", "addsuper", "addsuperseller",
      "delsuper", "listsuper", "delsuperseller", "addpv", "delpv", "listpv",
      "clone", "clonecancel", "cloneconfirm", "clonelist", "clonedel",
      "addfitur", "delfitur", "ambilfitur", "getfitur", "getcase", "listfitur",
      "testall", "testfitur", "testfeature",
      "errorfix", "errorai", "errorlist", "geterror", "geterrors", "errorclear",
      "errordelete", "errorcode", "errorraw", "errorai2",
      "backup", "backupset", "uploadscript", "upl", "setcommands", "setcmd",
      "bc", "broadcast", "stats", "panelstat", "addgb", "setgb", "notifgroup",
      "blclean", "cleanpanel", "cdomain", "cdomainpanel", "listsubdo", "delsubdo",
      "panelmanager", "cfgmanager", "configmanager", "addserver", "addsrv", "delserver", "delsrv", "servers", "listsrv",
      "addsubdo", "adddomain", "deldomain", "delcf", "stopclone", "cloneoff",
      "warn2", "cekwarn", "mywarns2", "resetwarn2", "unwarn2",
      "monitor", "mon", "top10", "montop", "unsuspend", "monhelp",
      "pvcreate", "pvlist", "pvinfo", "pvdelete", "pvstart", "pvstop", "pvhelp",
      "ping", "copy", "=>", ">", "$",
      /* alias-nya sendiri tidak perlu masuk */
      ...Object.keys(ALIASES)
    ])

    const seen = new Set()
    const list = []
    const DESC = {
      start: "🏠 Mulai bot / tampilkan menu",
      menu: "📋 Menu utama (semua fitur)",
      allmenu: "📚 Semua fitur per kategori",
      lang: "🌐 Ganti bahasa (ID/EN)",
      cpanel: "🖥️ Buat panel server",
      unli: "🖥️ Panel unlimited (shortcut)",
      delpanel: "🗑️ Hapus panel",
      listpanel: "🧾 Lihat panel kamu",
      mypanel: "🖥️ Ringkasan panel kamu",
      cadmin: "👑 Buat admin panel",
      batal: "🧹 Batal/bersihkan sesi stuck",
      brat: "🎨 Brat sticker dari teks",
      sticker: "🎨 Reply foto/stiker → pack",
      qc: "💬 Quote chat sticker",
      smeme: "😂 Meme sticker (reply foto)",
      style: "🔤 25 gaya font teks",
      play: "🎵 Play lagu dari YouTube",
      ytdl: "📥 Download YouTube (audio/video)",
      tt: "📥 Download TikTok",
      tourl: "🔗 Upload media jadi link",
      short: "🔗 Pendekkan link",
      qr: "🔳 Buat QR code",
      wiki: "📖 Wikipedia",
      weather: "🌤️ Cuaca kota",
      tr: "🌐 Terjemahan",
      tts: "🔊 Text jadi suara",
      ss: "📸 Screenshot website",
      calc: "🧮 Kalkulator",
      pass: "🔐 Generator password",
      b64: "🔄 Base64 encode/decode",
      hash: "#️⃣ Hash md5/sha256",
      time: "🕒 Waktu kota",
      ip: "🌐 Info IP",
      github: "🐙 Profil GitHub",
      npm: "📦 Info package npm",
      define: "📚 Kamus Inggris",
      getid: "🆔 ID user/chat",
      getpp: "🖼️ Foto profil user",
      gempa: "🌍 Info gempa BMKG",
      google: "🔍 Cari di Google",
      pinterest: "🖼️ Cari gambar",
      lirik: "🎵 Lirik lagu",
      chord: "🎸 Chord lagu",
      kbbi: "📘 Kamus KBBI",
      gsmarena: "📱 Spek HP",
      igstalk: "📸 Stalk Instagram",
      tiktokstalk: "🎵 Stalk TikTok",
      githubstalk: "🐙 Stalk GitHub",
      ffstalk: "🎮 Stalk Free Fire",
      robloxstalk: "🎮 Stalk Roblox",
      ttt: "🎮 TicTacToe vs bot/user",
      tttmove: "🎮 Langkah TicTacToe",
      family100: "🎲 Family 100",
      tebakbendera: "🚩 Tebak bendera",
      asahotak: "🧠 Asah otak",
      susunkata: "🔤 Susun kata",
      siapakahaku: "❓ Siapakah aku",
      tebaktebakan: "💭 Tebak-tebakan",
      tekateki: "🧩 Teka-teki",
      tebakgambar: "🖼️ Tebak emoji",
      suit: "✊✋✌️ Suit vs bot",
      dice: "🎲 Dadu",
      coin: "🪙 Lempar koin",
      slot: "🎰 Slot",
      dare: "🔥 Dare",
      truth: "💬 Truth",
      artitarot: "🔮 Kartu tarot",
      fakta: "🧠 Fakta unik",
      puisi: "📜 Puisi",
      bijak: "💡 Kata bijak",
      gombalan: "😏 Gombalan",
      motivasi: "🔥 Motivasi",
      cerpen: "📖 Cerita pendek",
      arahrezeki: "🍀 Arah rezeki",
      ampremium: "✨ AM premium via email",
      amverify: "✅ Verifikasi AM premium",
      amreg: "📧 Registrasi AM + OTP",
      amotp: "🔑 Verifikasi OTP AM",
      presetam: "🎬 Info preset Alight Motion",
      fakelobby: "🎮 Fake lobby FF/ML",
      ektp: "🪪 Generator e-KTP",
      fakedana: "💳 Fake payment",
      mediafire: "📥 Download MediaFire",
      gitclone: "📥 Download repo GitHub",
      spotify: "🎵 Download Spotify",
      soundcloud: "🎵 Download SoundCloud",
      toimg: "🖼️ Sticker → foto",
      tovn: "🎤 Audio → voice note",
      tovideo: "🎬 Video note → video",
      emojimix: "😄 Gabung 2 emoji",
      removebg: "✂️ Hapus background",
      bass: "🎧 Efek bass (reply audio)",
      blown: "🎧 Efek blown",
      earrape: "🎧 Efek earrape",
      nightcore: "🎧 Efek nightcore",
      robot: "🤖 Efek suara robot",
      tupai: "🐿️ Efek suara tupai",
      slow: "🐢 Percepat/perlahan audio",
      fast: "🐇 Percepat audio",
      reverse: "🔁 Balik audio",
      afk: "😴 Set mode AFK",
      warn: "⚠️ Warn user (grup)",
      antilink: "🛡️ Anti link on/off",
      antitoxic: "🛡️ Anti toxic on/off",
      tagall: "📣 Tag semua admin",
      rules: "📜 Rules grup",
      report: "🚨 Report ke admin",
      uptime: "⏱️ Uptime bot",
      mypanel: "🖥️ Panel milikku",
      info: "👤 Info lengkap user",
      rate: "📊 Rate sesuatu",
      love: "💕 Kecocokan cinta",
      pick: "🤔 Pilih salah satu",
      roll: "🎯 Roll angka",
      reverse: "🔁 Balik teks",
      bucin: "💔 Kata bucin",
      quote: "💡 Kata motivasi",
      wpick: "🎲 Pilih user dari mention",
      stickerinfo: "ℹ️ Info pack stiker",
      say: "💬 Bot mengulang teks",
      soal: "❓ Lihat soal aktif",
      skipquiz: "⏭️ Skip kuis",
      resetwarn: "♻️ Reset warn user",
      warns: "ℹ️ Cek warn user",
      pin: "📌 Pin pesan",
      unpin: "📌 Lepas pin",
      topcmd: "📊 Top 10 command",
      topmessage: "💬 Top user aktif"
    }

    for (const f of files) {
      try {
        const p = path.join(pluginsDir, f)
        delete require.cache[require.resolve(p)]
        const mod = require(p)
        if (typeof mod !== "function" || !Array.isArray(mod.command)) continue
        for (const c of mod.command) {
          if (typeof c !== "string" || !/^[a-z0-9_]+$/i.test(c)) continue
          if (skipCmds.has(c.toLowerCase())) continue
          const key = c.toLowerCase()
          if (seen.has(key)) continue
          seen.add(key)
          list.push({ command: key.slice(0, 32), description: (DESC[key] || "✦ /" + key).slice(0, 256) })
        }
      } catch {}
    }

    /* cap 100 (batas Telegram per scope) — prioritas yang punya deskripsi dulu */
    const withDesc = list.filter(c => DESC[c.command])
    const withoutDesc = list.filter(c => !DESC[c.command])
    const final = [...withDesc, ...withoutDesc].slice(0, 100)

    /* cache hash — TIDAK PANGGIL setMyCommands kalau daftar tidak berubah
       (mencegah 429 Too Many Requests / spam API saat boot berulang) */
    const crypto = require("crypto")
    const sig = crypto.createHash("md5").update(JSON.stringify(final)).digest("hex")
    const cacheFile = path.join(__dirname, "..", "library", "database", "cmdcache.txt")
    try {
      if (fs.existsSync(cacheFile) && fs.readFileSync(cacheFile, "utf8").trim() === sig) {
        return { ok: true, count: final.length, skipped: true }
      }
    } catch {}

    try { fs.mkdirSync(path.dirname(cacheFile), { recursive: true }) } catch {}
    // tulis cache SETELAH sukses setMyCommands — biar kalau gagal (429 dll) next boot coba lagi
    await Rafz.setMyCommands(final)
    try { fs.writeFileSync(cacheFile, sig) } catch {}
    return { ok: true, count: final.length }
  } catch (e) {
    return { ok: false, error: e.message }
  }
}

/* ── self-exec: daftarkan command list saat bot start (delay 15 detik) ── */
try {
  const t = setTimeout(() => {
    try {
      const bot = global.Rafz || global.conn
      if (bot && typeof bot.setMyCommands === "function") {
        buildAndSetCommands(bot).then(r => {
          // skip log biar ga spam tiap boot/restart; cuma log kalo beneran update atau error
          if (r.skipped) {
            // silent — daftar command sama, ga perlu log
          } else if (r.ok) {
            console.log("Telegram command list: " + r.count + " commands terdaftar")
          } else {
            console.log("setMyCommands fail:", r.error)
          }
        }).catch(() => {})
      }
    } catch {}
  }, 15000)
  if (t && typeof t.unref === "function") t.unref()
} catch {}

handler.command = ["setcommands", "setcmd"]
module.exports = handler

/* ── resolver alias untuk handler.js ──
   handler.js memanggil global.resolveAlias(cmd) sebelum cek plugin */
global.resolveAlias = global.resolveAlias || ((cmd) => ALIASES[String(cmd || "").toLowerCase()] || null)
global.buildAndSetCommands = buildAndSetCommands

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
