/* games3.js — porting quiz dari WA bot (Rafzbotz/Prabowo/Furina).
   Bank soal: BochilTeam/database (games/*.json, terverifikasi hidup 2026-09)
   + bank lokal fallback (anti error).
   Jawaban diketik langsung di chat (global.gameAnswerHook chain — sama pola
   dengan games2/quizzes supaya tidak tabrakan). */

"use strict"
const fs = require("fs")
const path = require("path")

const DB = "./library/database/quizzes3.json"
const load = () => { try { const j = JSON.parse(fs.readFileSync(DB, "utf8")); return j && typeof j === "object" ? j : {} } catch { return {} } }
const save = (d) => { try { fs.mkdirSync("library/database", { recursive: true }); fs.writeFileSync(DB, JSON.stringify(d, null, 2)) } catch {} }
const pick = (a) => a[Math.floor(Math.random() * a.length)]
const norm = (s) => String(s || "").toLowerCase().trim().replace(/[^a-z0-9 ]/g, "")
const esc = (s) => String(s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")

const FILE = {
  caklontong: "games/caklontong.json",
  tebakkalimat: "games/tebakkalimat.json",
  tebakkabupaten: "games/tebakkabupaten.json",
  tebakkimia: "games/tebakkimia.json",
  tebaklirik: "games/tebaklirik.json",
  tebakbendera2: "games/tebakbendera2.json"
}

const NAME = {
  caklontong: "CAK LONTONG", tebakkalimat: "TEBAK KALIMAT", tebakkabupaten: "TEBAK KABUPATEN",
  tebakkimia: "TEBAK KIMIA", tebaklirik: "TEBAK LIRIK", tebakbendera2: "TEBAK BENDERA 2"
}

/* fallback lokal (kalau GitHub mati — fitur tetap jalan) */
const LOCAL = {
  caklontong: [
    { q: "Makhluk hidup yang bisa hidup di air dan di darat (3 huruf)... plus petunjuk: 'katak punya saudara'", a: "kodok", hint: "bujet" },
    { q: "Alat masak dari tanah liat (4 huruf)... 'masak nasi'", a: "kuali", hint: "panci" }
  ],
  tebakkalimat: [
    { q: "Kata 'rumah sakit' jika disingkat menjadi...", a: "rs", hint: "dua huruf" },
    { q: "Sebutan untuk orang yang baru belajar mengemudi...", a: "nyetir", hint: "S-I-M" }
  ],
  tebakkabupaten: [
    { q: "Kabupaten di Jawa Barat yang terkenal dengan 'kebun binatang' terbesarnya", a: "cianjur", hint: "sing huruf awal C" }
  ],
  tebakkimia: [
    { q: "Simbol unsur emas (2 huruf)", a: "au", hint: "aurum" },
    { q: "Simbol unsur air raksa (2 huruf)", a: "hg", hint: "hydrargyrum" }
  ],
  tebaklirik: [
    { q: "'Kar'ku terhenti dan tak'kan bergerak' — judul lagunya?", a: "melompat lebih tinggi", hint: "Sheila On 7" }
  ],
  tebakbendera2: [
    { q: "Bendera putih-merah di atas milik negara?", a: "indonesia", hint: "merah putih" }
  ]
}

/* normalisasi bank: setiap game punya bentuk soal/jawaban berbeda */
const toItems = (game, db) => {
  const items = []
  if (!Array.isArray(db)) return items
  for (const r of db) {
    if (game === "caklontong" && r.soal && r.jawaban)
      items.push({ q: r.soal, a: r.jawaban, hint: r.desc || "—" })
    else if (game === "tebakkalimat" && r.soal && r.jawaban)
      items.push({ q: r.soal, a: r.jawaban, hint: "—" })
    else if (game === "tebakkabupaten" && r.soal && r.jawaban)
      items.push({ q: r.soal, a: r.jawaban, hint: "—" })
    else if (game === "tebakkimia" && r.lambang && r.unsur)
      items.push({ q: "Simbol unsur " + r.unsur + " ?", a: r.lambang, hint: r.unsur })
    else if (game === "tebaklirik" && r.soal && r.jawaban)
      items.push({ q: r.soal, a: r.jawaban, hint: "—" })
    else if (game === "tebakbendera2" && r.name && r.img)
      items.push({ q: "Bendera negara ini?", img: r.img, a: r.name, hint: r.name[0] + "..." })
  }
  return items
}

const CACHE = {}
const getBank = async (game) => {
  if (CACHE[game] && CACHE[game].length) return CACHE[game]
  try {
    const r = await fetch("https://raw.githubusercontent.com/BochilTeam/database/master/" + FILE[game], { signal: AbortSignal.timeout(15000) })
    if (!r.ok) throw new Error("HTTP " + r.status)
    const db = await r.json()
    const items = toItems(game, db)
    if (items.length) { CACHE[game] = items; return items }
  } catch {}
  CACHE[game] = LOCAL[game] || []
  return CACHE[game]
}

/* ── hook jawaban (chain global) ── */
const answerHook = async (m, { text, chatKey }) => {
  const db = load()
  const g = db[chatKey]
  if (!g || !NAME[g.game]) return false
  const q = norm(text)
  if (!q) return false
  if (q === norm(g.answer)) {
    delete db[chatKey]; save(db)
    await m.reply("🎉 <b>BENAR!</b> Jawaban: <b>" + esc(g.answer) + "</b>\n" + (m.pushName || m.sender) + " menjawab dengan benar.", { parse_mode: "HTML" })
    return true
  }
  if (q === "hint") {
    await m.reply("💡 <b>Hint:</b> " + esc(g.hint || "-") + "\n_" + String(g.answer).replace(/[a-z]/gi, "_") + "_", { parse_mode: "HTML" })
    return true
  }
  return true /* sedang main → chat dianggap percobaan jawaban */
}

const handler = async (m, { Rafz, command, text }) => {
  try {
    const tr = (key, vars) => (m.t ? m.t(key, vars) : key)
    const chatKey = String(m.chat) + ":" + String(m.sender)
    const px = (global.prefix && global.prefix[0]) || "/"

    if (FILE[command]) {
      const bank = await getBank(command)
      if (!bank.length) return m.reply(tr("common.failed"), { parse_mode: "HTML" })
      const item = pick(bank)
      const db = load()
      db[chatKey] = { game: command, answer: norm(item.a), q: item.q, hint: item.hint, img: item.img || null, at: Date.now() }
      save(db)
      const kb = item.img ? { inline_keyboard: [[{ text: "🖼️ Lihat Soal", url: item.img, style: "primary" }]] } : undefined
      await m.reply(
        "🎮 <b>" + NAME[command] + "</b>\n\n❓ " + esc(item.q) +
        "\n\n⏳ " + tr("quiz.startHint") + "\n💡 <code>" + px + "soal3</code> / ketik <code>hint</code>",
        { parse_mode: "HTML", reply_markup: kb }
      )
      if (item.img) {
        try { await Rafz.sendPhoto(m.chat, item.img, { caption: "🖼️ " + NAME[command], reply_to_message_id: m.id, allow_sending_without_reply: true }) } catch {}
      }
      return true
    }

    if (command === "soal3" || command === "skipquiz2") {
      const db = load()
      const g = db[chatKey]
      if (!g || !NAME[g.game]) return m.reply(tr("quiz.noGameHint", { px: px + "caklontong" }), { parse_mode: "HTML" })
      if (command === "skipquiz2") {
        delete db[chatKey]; save(db)
        return m.reply("⏭️ " + tr("quiz.skipped") + " — Jawaban: <b>" + esc(g.answer) + "</b>", { parse_mode: "HTML" })
      }
      return m.reply("<b>" + NAME[g.game] + "</b>\n\n❓ " + esc(g.q), { parse_mode: "HTML" })
    }

    return false
  } catch (e) {
    console.error("[games3]", command, e?.message)
    try { await m.reply("❌ " + esc(String(e?.message || e).slice(0, 120)), { parse_mode: "HTML" }) } catch {}
    return false
  }
}

handler.command = ["caklontong", "tebakkalimat", "tebakkabupaten", "tebakkimia", "tebaklirik", "tebakbendera2", "soal3", "skipquiz2"]
module.exports = handler

/* hook jawaban non-command — chain ke global (games2/quizzes sudah pasang punya mereka) */
try {
  const prev = global.gameAnswerHook
  global.gameAnswerHook = async (m, ctx) => {
    if (prev) { const r = await prev(m, ctx); if (r) return r }
    return answerHook(m, ctx)
  }
} catch {}

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
