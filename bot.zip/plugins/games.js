/* plugin: games.js — fitur fun & games (bersih dari konten dewasa)
   Hapus (permintaan user): ceksange, tobrut, cekpedofil, dsb.
   TicTacToe vs bot & vs user ada di plugins/tictactoe.js */

"use strict"
const fs = require("fs")

const DB = "./library/database/games.json"
const load = () => { try { const j = JSON.parse(fs.readFileSync(DB, "utf8")); return j && typeof j === "object" ? j : {} } catch { return {} } }
const save = (d) => { try { fs.mkdirSync("library/database", { recursive: true }); fs.writeFileSync(DB, JSON.stringify(d, null, 2)) } catch {} }

const pick = (arr) => arr[Math.floor(Math.random() * arr.length)]
const rnd = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min
const bar = (v) => "█".repeat(Math.round(v / 10)) + "░".repeat(10 - Math.round(v / 10))

const handler = async (m, { Rafz, command, text }) => {
  try {
    const px = (global.prefix && global.prefix[0]) || "/"
    const q = (text || "").trim()
    const sender = String(m.sender)
    const db = load()

    // ===== KERANG AJAIB =====
    if (["apakah", "bisakah", "dapatkah", "what", "apa"].includes(command)) {
      if (!q) return m.reply("Contoh: " + px + command + " aku kaya?")
      return m.reply("Pertanyaan: " + q + "\nJawaban: " + pick(["Ya", "Tidak", "Mungkin", "Coba tanya lagi", "Bisa jadi", "Tentu saja"]))
    }
    if (["when", "kapankah"].includes(command)) {
      if (!q) return m.reply("Contoh: " + px + "when aku menikah?")
      return m.reply("Pertanyaan: " + q + "\nJawaban: " + pick(["Besok", "Minggu depan", "Bulan depan", "Tahun depan", "Sebentar lagi", "100 tahun lagi"]))
    }
    if (command === "rate") {
      if (!q) return m.reply("Contoh: " + px + "rate kegantenganmu")
      const v = rnd(0, 100)
      return m.reply("Rating: " + q + "\n" + bar(v) + " " + v + "%")
    }

    // ===== CEK FITUR (fun checks — bersih dari konten dewasa) =====
    const cekList = ["ceksifat", "checkme", "cekyatim", "cekjodoh", "cekmiskin", "cekwibu", "cekkaya", "cekiqotak", "cekkodam", "kodam", "cekwatak", "watak", "cekkeberuntungan", "cekcatchy"]
    if (cekList.includes(command)) {
      const target = m.mentioned?.[0]?.id ? m.mentioned[0].name || m.mentioned[0].username : (m.quoted?.sender ? "yang direply" : q || m.pushName)
      const v = rnd(0, 100)
      return m.reply("Cek " + command.replace("cek", "").toUpperCase() + " untuk " + target + ":\n" + bar(v) + " " + v + "%")
    }

    const cekCmd = ["yatim", "piatu", "jomblo", "koruptor", "psikopat", "miskin", "tukangjajan", "jelek", "mokondo", "penipu", "tukangcopet", "ganteng", "cantik", "kurus", "gemuk", "tepos", "badut", "wibu", "janda", "jodohku", "tolol", "bego", "pinter", "hebat", "suka"]
    if (cekCmd.includes(command)) {
      const target = m.mentioned?.[0]?.id ? m.mentioned[0].name || m.mentioned[0].username : (m.quoted?.sender ? "yang direply" : q || m.pushName)
      const v = rnd(0, 100)
      return m.reply("Cek " + command.toUpperCase() + " untuk " + target + ":\n" + bar(v) + " " + v + "%\n\n" + pick(["Facts!", "So true!", "No debat!", "100% real"]))
    }

    // ===== TEBAK ANGKA =====
    if (["tebakangka", "togel", "tebaktogel"].includes(command)) {
      const angka = rnd(0, 100)
      db.tebakangka = { angka, chat: String(m.chat), sender, active: true, tries: 3 }
      save(db)
      return m.reply("Tebak angka 0-100! Kamu punya 3 kesempatan.\nKetik " + px + "answer <angka>")
    }
    if (command === "answer") {
      const game = db.tebakangka
      if (!game || !game.active || game.sender !== sender) return m.reply("Tidak ada game aktif. Ketik " + px + "tebakangka")
      const guess = parseInt(q)
      if (isNaN(guess)) return m.reply("Ketik " + px + "answer <angka>")
      game.tries = (game.tries || 3) - 1
      if (guess === game.angka) {
        db.tebakangka = null; save(db)
        return m.reply("BENAR! Angkanya " + game.angka + "!")
      }
      if (game.tries <= 0) {
        db.tebakangka = null; save(db)
        return m.reply("Kesempatan habis! Angkanya " + game.angka + ".")
      }
      save(db)
      if (guess < game.angka) return m.reply("Terlalu kecil! Sisa " + game.tries + " kesempatan.")
      return m.reply("Terlalu besar! Sisa " + game.tries + " kesempatan.")
    }

    // ===== SLOT =====
    if (["slot", "slots", "gameslot"].includes(command)) {
      const emojis = ["🍒", "🍋", "🍊", "🥕", "🍆"]
      const s = [pick(emojis), pick(emojis), pick(emojis)]
      const win = s[0] === s[1] && s[1] === s[2]
      return m.reply("SLOT\n\n[ " + s.join(" | ") + " ]\n\n" + (win ? "🎉 JACKPOT!" : "Belum beruntung"))
    }

    // ===== COIN FLIP =====
    if (command === "flipping" || command === "coinflip") {
      return m.reply("Koin: " + (Math.random() < 0.5 ? "GAMING" : "ANGKA"))
    }

    // ===== SUIT =====
    if (command === "suit") {
      const opts = ["batu", "kertas", "gunting"]
      if (!q || !opts.includes(q.toLowerCase())) return m.reply("Pilih: batu/kertas/gunting\nContoh: " + px + "suit batu")
      const botChoice = pick(opts)
      const user = q.toLowerCase()
      let result = "SERI!"
      if ((user === "batu" && botChoice === "gunting") || (user === "gunting" && botChoice === "kertas") || (user === "kertas" && botChoice === "batu")) result = "KAMU MENANG!"
      else if (user !== botChoice) result = "BOT MENANG!"
      return m.reply("Kamu: " + user + "\nBot: " + botChoice + "\n\n" + result)
    }

    // ===== TEBAK KATA (quiz) =====
    if (command === "tebakkata") {
      const questions = [
        { q: "Hewan yang bisa terbang dan aktif malam?", a: "kelelawar" },
        { q: "Ibukota Indonesia?", a: "jakarta" },
        { q: "Planet terbesar di tata surya?", a: "jupiter" },
        { q: "Air yang membeku disebut?", a: "es" },
        { q: "Alat untuk memotong kertas?", a: "gunting" },
        { q: "Hewan pemakan tumbuhan disebut?", a: "herbivora" },
        { q: "Proses tumbuhan membuat makanan?", a: "fotosintesis" }
      ]
      const quiz = pick(questions)
      db.tebakkata = { quiz, chat: String(m.chat), sender, active: true }
      save(db)
      return m.reply("TEBAK KATA\n\n" + quiz.q + "\n\nKetik " + px + "jawabkata <jawaban>")
    }
    if (command === "jawabkata") {
      const game = db.tebakkata
      if (!game || !game.active || game.sender !== sender) return m.reply("Tidak ada game. Ketik " + px + "tebakkata")
      if (q.toLowerCase().trim() === game.quiz.a) {
        db.tebakkata = null; save(db)
        return m.reply("BENAR! Jawabannya: " + game.quiz.a)
      }
      return m.reply("Salah! Coba lagi.")
    }

    // ===== TEBAK GAMBAR (emoji puzzle) =====
    if (command === "tebakgambar") {
      const puzzles = [
        { e: "🏠 + 📚", a: "perpustakaan" },
        { e: "🚗 + 🏥", a: "mobil ambulans" },
        { e: "🌧️ + ☂️", a: "hujan" },
        { e: "🐱 + 🐟", a: "kucing makan ikan" },
        { e: "⚽ + 🥅", a: "gol" },
        { e: "🌙 + ⭐", a: "malam" },
        { e: "📱 + 🎵", a: "musik" }
      ]
      const puz = pick(puzzles)
      db.tebakgambar = { puz, chat: String(m.chat), sender, active: true }
      save(db)
      return m.reply("TEBAK GAMBAR (emoji puzzle)\n\n" + puz.e + "\n\nKetik " + px + "jawabgambar <jawaban>")
    }
    if (command === "jawabgambar") {
      const game = db.tebakgambar
      if (!game || !game.active || game.sender !== sender) return m.reply("Tidak ada game. Ketik " + px + "tebakgambar")
      if (q.toLowerCase().trim() === game.puz.a) {
        db.tebakgambar = null; save(db)
        return m.reply("BENAR! Jawabannya: " + game.puz.a)
      }
      return m.reply("Salah! Coba lagi.")
    }

    // ===== SPIN / CASINO (fun tanpa uang) =====
    if (command === "casino" || command === "spin") {
      const reels = ["🕹️", "🎮", "🎲", "⭐", "🎰"]
      return m.reply("SPIN\n\n[ " + pick(reels) + " | " + pick(reels) + " | " + pick(reels) + " ]")
    }

    // ===== DARE / TRUTH (bersih) =====
    if (command === "dare") {
      return m.reply("DARE\n\n" + pick([
        "Kirim pesan ke temanmu bilang 'kamu udah makan?'",
        "Post foto paling jelek kamu di story",
        "Telepon temanmu dan nyanyikan lagu daerah",
        "Bilang ke orang tua 'aku sayang kalian'",
        "Chat teman lama dan bilang 'kangen'",
        "Kirim voice note nyanyi lagu nasional"
      ]))
    }
    if (command === "truth") {
      return m.reply("TRUTH\n\n" + pick([
        "Siapa idolamu dan kenapa?",
        "Apa hal paling memalukan yang pernah kamu lakukan?",
        "Siapa teman yang paling kamu sayangi?",
        "Apa rahasia kamu yang belum ada yang tahu?",
        "Kapan terakhir kamu nangis?",
        "Apa mimpimu 5 tahun lagi?"
      ]))
    }

    // ===== TEKA-TEKI =====
    if (command === "tekateki" || command === "riddle") {
      const riddles = [
        { q: "Aku punya kaki tapi tidak bisa jalan. Apa aku?", a: "meja" },
        { q: "Makin banyak diambil, makin besar ukuranku. Apa aku?", a: "lubang" },
        { q: "Punya leher tapi tanpa kepala. Apa aku?", a: "botol" },
        { q: "Aku bisa terbang tanpa sayap dan menangis tanpa mata. Apa aku?", a: "awan" },
        { q: "Semakin panjang aku, semakin dekat umurmu. Apa aku?", a: "waktu" }
      ]
      const r = pick(riddles)
      db.tekateki = { r, chat: String(m.chat), sender, active: true }
      save(db)
      return m.reply("TEKA-TEKI\n\n" + r.q + "\n\nKetik " + px + "jawabteki <jawaban> (hint: jawaban 1 kata)")
    }
    if (command === "jawabteki") {
      const game = db.tekateki
      if (!game || !game.active || game.sender !== sender) return m.reply("Tidak ada teka-teki. Ketik " + px + "tekateki")
      if (q.toLowerCase().trim() === game.r.a) {
        db.tekateki = null; save(db)
        return m.reply("BENAR! Jawabannya: " + game.r.a)
      }
      return m.reply("Salah! Coba lagi.")
    }

    return false
  } catch (e) {
    console.error("[games]", e?.message)
    try { await m.reply("Error: " + (e?.message || e)) } catch {}
    return false
  }
}

handler.command = ["apakah", "bisakah", "dapatkah", "what", "apa", "when", "kapankah", "rate", "ceksifat", "checkme", "cekyatim", "cekjodoh", "cekmiskin", "cekwibu", "cekkaya", "cekiqotak", "cekkodam", "kodam", "cekwatak", "watak", "cekkeberuntungan", "cekcatchy", "yatim", "piatu", "jomblo", "koruptor", "psikopat", "miskin", "tukangjajan", "jelek", "mokondo", "penipu", "tukangcopet", "ganteng", "cantik", "kurus", "gemuk", "tepos", "badut", "wibu", "janda", "jodohku", "tolol", "bego", "pinter", "hebat", "suka", "tebakangka", "togel", "tebaktogel", "answer", "slot", "slots", "gameslot", "flipping", "coinflip", "suit", "tebakkata", "jawabkata", "tebakgambar", "jawabgambar", "casino", "spin", "dare", "truth", "tekateki", "riddle", "jawabteki"]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
