/* plugin: quizzes.js — kuis interaktif (porting Prabowo MD)
   /tebakbendera /asahotak /susunkata /siapakahaku /tebaktebakan /family100
   Jawab langsung di chat (jawaban benar auto-tersimpan per chat).
   /skipquiz → skip, /soal → lihat soal aktif */

"use strict"
const fs = require("fs")

const DB = "./library/database/quizzes.json"
const load = () => { try { const j = JSON.parse(fs.readFileSync(DB, "utf8")); return j && typeof j === "object" ? j : {} } catch { return {} } }
const save = (d) => { try { fs.mkdirSync("library/database", { recursive: true }); fs.writeFileSync(DB, JSON.stringify(d, null, 2)) } catch {} }

const pick = (arr) => arr[Math.floor(Math.random() * arr.length)]
const norm = (s) => String(s || "").toLowerCase().trim().replace(/[^a-z0-9 ]/g, "")

/* bank soal lokal — selalu jalan tanpa API */
const BANK = {
  tebakbendera: [
    { q: "🇯🇵 Bendera negara mana ini?", a: "jepang" },
    { q: "🇰🇷 Bendera negara mana ini?", a: "korea selatan" },
    { q: "🇩🇪 Bendera negara mana ini?", a: "jerman" },
    { q: "🇧🇷 Bendera negara mana ini?", a: "brazil" },
    { q: "🇪🇬 Bendera negara mana ini?", a: "mesir" },
    { q: "🇹🇭 Bendera negara mana ini?", a: "thailand" },
    { q: "🇸🇦 Bendera negara mana ini?", a: "arab saudi" },
    { q: "🇮🇳 Bendera negara mana ini?", a: "india" }
  ],
  asahotak: [
    { q: "Aku punya gigi tapi tidak bisa menggigit. Apa aku?", a: "sisir" },
    { q: "Semakin banyak diambil, semakin besar. Apa aku?", a: "lubang" },
    { q: "Punya mata tapi tidak bisa melihat. Apa aku?", a: "jarum" },
    { q: "Aku naik tapi tidak pernah turun. Apa aku?", a: "umur" },
    { q: "Hewan apa yang paling kaya?", a: "kambing" }
  ],
  susunkata: [
    { q: "Susun huruf ini: K-A-T-U-L-S", a: "tutul" },
    { q: "Susun huruf ini: B-A-S-O-O-R", a: "sebrar" },
    { q: "Susun huruf ini: G-U-R-A-A-L", a: "ragual" },
    { q: "Susun huruf ini: P-A-N-G-S-A", a: "pagans" }
  ],
  siapakahaku: [
    { q: "Aku presiden pertama Indonesia. Siapakah aku?", a: "soekarno" },
    { q: "Aku penemu lampu pijar. Siapakah aku?", a: "edison" },
    { q: "Aku pelukis Mona Lisa. Siapakah aku?", a: "davinci" },
    { q: "Aku penemu teori relativitas. Siapakah aku?", a: "einstein" },
    { q: "Aku presiden kedua Indonesia. Siapakah aku?", a: "soeharto" }
  ],
  tebaktebakan: [
    { q: "Apa yang punya leher tapi tanpa kepala?", a: "botol" },
    { q: "Apa yang bisa terbang tanpa sayap?", a: "waktu" },
    { q: "Apa yang naik ketika turun?", a: "ombak" },
    { q: "Apa yang selalu datang tapi tidak pernah tiba?", a: "besok" }
  ]
}

const NAME = { tebakbendera: "Tebak Bendera", asahotak: "Asah Otak", susunkata: "Susun Kata", siapakahaku: "Siapakah Aku", tebaktebakan: "Tebak-Tebakan" }

/* bank soal versi EN — dipakai kalau bahasa user en */
const BANK_EN = {
  tebakbendera: [
    { q: "🇯🇵 Which country's flag is this?", a: "japan" },
    { q: "🇰🇷 Which country's flag is this?", a: "south korea" },
    { q: "🇩🇪 Which country's flag is this?", a: "germany" },
    { q: "🇧🇷 Which country's flag is this?", a: "brazil" },
    { q: "🇪🇬 Which country's flag is this?", a: "egypt" },
    { q: "🇹🇭 Which country's flag is this?", a: "thailand" },
    { q: "🇸🇦 Which country's flag is this?", a: "saudi arabia" },
    { q: "🇮🇳 Which country's flag is this?", a: "india" }
  ],
  asahotak: [
    { q: "I have teeth but cannot bite. What am I?", a: "comb" },
    { q: "The more you take, the bigger I get. What am I?", a: "hole" },
    { q: "I have an eye but cannot see. What am I?", a: "needle" },
    { q: "I go up but never come down. What am I?", a: "age" },
    { q: "Which animal is the richest?", a: "goat" }
  ],
  susunkata: [
    { q: "Unscramble: L-E-P-P-A", a: "apple" },
    { q: "Unscramble: T-E-N-I-S-S-E", a: "fitness" },
    { q: "Unscramble: R-A-E-H-T", a: "earth" },
    { q: "Unscramble: P-A-E-R", a: "pear" }
  ],
  siapakahaku: [
    { q: "I invented the light bulb. Who am I?", a: "edison" },
    { q: "I painted the Mona Lisa. Who am I?", a: "davinci" },
    { q: "I discovered the theory of relativity. Who am I?", a: "einstein" },
    { q: "I was the first man on the Moon. Who am I?", a: "armstrong" },
    { q: "I founded Microsoft. Who am I?", a: "gates" }
  ],
  tebaktebakan: [
    { q: "What has a neck but no head?", a: "bottle" },
    { q: "What can fly without wings?", a: "time" },
    { q: "What rises when it falls?", a: "wave" },
    { q: "What always comes but never arrives?", a: "tomorrow" }
  ]
}

const handler = async (m, { Rafz, command, text }) => {
  try {
    const px = (global.prefix && global.prefix[0]) || "/"
    const q = (text || "").trim()
    const sender = String(m.sender)
    const chatKey = String(m.chat)
    const db = load()

    const tr = (key, vars) => (m.t ? m.t(key, vars) : key)
    const bank = (m.lang === "en") ? BANK_EN : BANK

    /* ── /family100 — 8 jawaban dicari ── */
    if (command === "family100") {
      const sets = [
        { q: tr("quiz.f100Fruit"), answers: tr("quiz.f100FruitA").split(",") },
        { q: tr("quiz.f100Pet"), answers: tr("quiz.f100PetA").split(",") },
        { q: tr("quiz.f100Vehicle"), answers: tr("quiz.f100VehicleA").split(",") },
        { q: tr("quiz.f100Rainbow"), answers: tr("quiz.f100RainbowA").split(",") }
      ]
      const s = pick(sets)
      db[chatKey] = { game: "family100", answers: s.answers, found: [], q: s.q, at: Date.now() }
      save(db)
      return m.reply(
        `<b>🎮 FAMILY 100</b>\n\n❓ ${s.q}\n\n✅ ${tr("quiz.found")}: 0/${s.answers.length}\n\n${tr("quiz.startHint")} (${tr("quiz.needCount", { n: s.answers.length })})`,
        { parse_mode: "HTML" }
      )
    }

    /* ── mulai kuis pilihan ── */
    if (bank[command]) {
      const item = pick(bank[command])
      db[chatKey] = { game: command, answer: item.a, q: item.q, at: Date.now() }
      save(db)
      return m.reply(
        `<b>🎮 ${NAME[command].toUpperCase()}</b>\n\n${item.q}\n\n⏳ ${tr("quiz.startHint")}\n💡 <code>${px}skipquiz</code> ${tr("quiz.toSkip")}`,
        { parse_mode: "HTML" }
      )
    }

    /* ── /soal — tampilkan soal aktif ── */
    if (command === "soal") {
      const g = db[chatKey]
      if (!g) return m.reply(tr("quiz.noGameHint", { px: px }))
      let out = `<b>${tr("quiz.activeQuestion")} (${g.game})</b>\n\n❓ ${g.q}\n`
      if (g.game === "family100" && g.found?.length) out += "\n✅ " + tr("quiz.alreadyFound") + ": " + g.found.join(", ")
      return m.reply(out, { parse_mode: "HTML" })
    }

    /* ── /skipquiz ── */
    if (command === "skipquiz" || command === "skipsk") {
      const g = db[chatKey]
      if (!g) return m.reply(tr("quiz.noGame"))
      const ans = g.game === "family100" ? g.answers.join(", ") : g.answer
      delete db[chatKey]; save(db)
      return m.reply("⏭️ " + tr("quiz.skipAnswer") + " <b>" + ans + "</b>", { parse_mode: "HTML" })
    }

    /* ── jawaban langsung (bukan command) ── */
    if (!m.isCmd && q && db[chatKey]) {
      const g = db[chatKey]
      if (g.game === "family100") {
        const idx = g.answers.findIndex(a => norm(a) === norm(q))
        if (idx >= 0 && !g.found.includes(g.answers[idx])) {
          g.found.push(g.answers[idx])
          if (g.found.length >= g.answers.length) {
            delete db[chatKey]; save(db)
            return m.reply(`🎉 <b>${g.answers[idx]}</b> ${tr("quiz.right")}! ${tr("quiz.allFound")}\n\n🏆 ${tr("quiz.fullAnswer")}: ${g.answers.join(", ")}`, { parse_mode: "HTML" })
          }
          save(db)
          return m.reply(`✅ ${tr("quiz.correctWord")}: <b>${g.answers[idx]}</b> (${g.found.length}/${g.answers.length})`, { parse_mode: "HTML" })
        }
        return true /* salah → diem aja biar chat nggak berisik */
      }
      if (norm(q) === norm(g.answer)) {
        delete db[chatKey]; save(db)
        return m.reply(`🎉 <b>${tr("quiz.correctWord").toUpperCase()}!</b> ${sender} ${tr("quiz.answeredBy")}: ${g.answer}`, { parse_mode: "HTML" })
      }
      return true /* salah → diem */
    }

    return false
  } catch (e) {
    console.error("[quizzes]", e?.message)
    return false
  }
}

handler.command = ["tebakbendera", "asahotak", "susunkata", "siapakahaku", "tebaktebakan", "family100", "soal", "skipquiz", "skipsk"]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
