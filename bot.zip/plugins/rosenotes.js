/* rosenotes.js — Rose: welcome/goodbye, filters (auto-reply), notes, command disabling,
   federations (fban lintas grup dalam fed), log channel.
   Fillings: {first} {last} {fullname} {username} {id} {mention} {chatname} {count} {user}
   Welcome/goodbye jalan lewat global.roseMemberHook (dipanggil handler.js saat
   ada service message new_chat_members/left_chat_member). */

"use strict"
const gstore = require("../library/gstore")

const esc = (s) => String(s || "").replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;")
const fill = (tpl, vars) => {
  let s = String(tpl || "")
  const map = {
    first: vars.first || "", last: vars.last || "", fullname: [vars.first, vars.last].filter(Boolean).join(" ") || vars.first || "",
    username: vars.username ? "@" + vars.username : "", id: vars.id || "", mention: vars.mention || "",
    chatname: vars.chatname || "", count: vars.count || "?", user: vars.mention || vars.first || "",
    admin: vars.admin || "", chat: vars.chatname || ""
  }
  for (const [k, v] of Object.entries(map)) s = s.replace(new RegExp("\\{" + k + "\\}", "gi"), v)
  return s
}
const nameOf = (u) => u ? { first: u.first_name || "", last: u.last_name || "", username: u.username || "", id: String(u.id), mention: '<a href="tg://user?id=' + u.id + '">' + esc(u.first_name || "user") + "</a>" } : {}

const isAdmin = async (Rafz, chat, uid) => {
  try {
    if ((global.owner || []).includes(String(uid))) return true
    const admins = await Rafz.getChatAdministrators(chat)
    return admins.some(a => String(a.user?.id) === String(uid))
  } catch { return false }
}

/* ══════════════════ MEMBER HOOK (welcome/goodbye + raid counter) ══════════════════ */
const memberHook = async (msg, Rafz) => {
  try {
    if (!msg || !Rafz) return
    const chat = String(msg.chat?.id)
    if (!msg.new_chat_members?.length && !msg.left_chat_member) return

    /* autoantiraid: hitung join per interval 60s */
    if (msg.new_chat_members?.length) {
      const autoN = gstore.get("antiraid", chat + ":auto", 0)
      if (autoN) {
        const n = gstore.counterInc("roseduty", chat + ":joins", 60)
        if (n > autoN) {
          const cur = gstore.get("antiraid", chat, {})
          if (!cur.on) gstore.set("antiraid", chat, { on: true, until: Date.now() + 2 * 3600 * 1000 })
        }
      }
    }

    const wl = gstore.get("welcome", chat, null)
    const gb = gstore.get("goodbye", chat, null)

    if (msg.new_chat_members?.length) {
      for (const u of msg.new_chat_members) {
        if (u.is_bot) continue
        const v = nameOf(u)
        /* tandai utk antiraid enforcement */
        gstore.set("antiraid", chat + ":j" + v.id, true)

        /* captcha: mute + kirim soal */
        const capOn = gstore.get("captcha", chat + ":on", false)
        if (capOn) {
          const mode = gstore.get("captcha", chat + ":mode", "button")
          try {
            await Rafz.restrictChatMember(msg.chat.id, u.id, { permissions: { can_send_messages: false } })
          } catch {}
          let a, b, answer, question, buttons = null
          if (mode === "math") {
            a = 2 + Math.floor(Math.random() * 20); b = 2 + Math.floor(Math.random() * 20)
            answer = a + b; question = "🤖 " + v.first + " — " + a + " + " + b + " = ?"
          } else {
            const emojis = ["🍎", "🚗", "🐱", "🌸", "⚽", "🎧", "🍕", "🌙"]
            const pick = emojis[Math.floor(Math.random() * emojis.length)]
            const wrongs = emojis.filter(e => e !== pick).sort(() => Math.random() - 0.5).slice(0, 2)
            const opts = [pick, ...wrongs].sort(() => Math.random() - 0.5)
            answer = pick; question = "🤖 " + v.first + " — tap " + pick
            buttons = opts.map(e => ({ text: e, callback_data: "/capans " + v.id + " " + e, style: "secondary" }))
          }
          gstore.set("captcha", chat + ":u" + v.id, { mode: mode === "math" ? "math" : "button", answer })
          const kb = buttons ? { inline_keyboard: [[buttons[0], buttons[1]], [buttons[2]]] } : undefined
          try { await Rafz.sendMessage(msg.chat.id, question, { parse_mode: "HTML", reply_markup: kb }) } catch {}
        }

        if (wl && wl.on && wl.text) {
          const memb = await Rafz.getChatMemberCount(msg.chat.id).catch(() => "?")
          const txt = fill(wl.text, { ...v, chatname: msg.chat?.title || "", count: memb })
          try {
            const sent = await Rafz.sendMessage(msg.chat.id, txt, { parse_mode: "HTML" })
            /* cleanwelcome: hapus pesan welcome sebelumnya */
            if (gstore.get("welcome", chat + ":clean", false) && sent?.message_id) {
              const prev = gstore.get("welcome", chat + ":msgid", null)
              if (prev) { try { await Rafz.deleteMessage(msg.chat.id, prev) } catch {} }
              gstore.set("welcome", chat + ":msgid", sent.message_id)
            }
          } catch {}
        }
      }
    }

    if (msg.left_chat_member && gb && gb.on && gb.text) {
      const v = nameOf(msg.left_chat_member)
      const txt = fill(gb.text, { ...v, chatname: msg.chat?.title || "" })
      try { await Rafz.sendMessage(msg.chat.id, txt, { parse_mode: "HTML" }) } catch {}
    }
  } catch (e) { console.error("[rosenotes member]", e?.message) }
}
try {
  const prev = global.roseMemberHook
  global.roseMemberHook = async (msg, bot) => {
    if (prev) await prev(msg, bot)
    await memberHook(msg, bot)
  }
} catch {}

/* ══════════════════ COMMANDS ══════════════════ */
const handler = async (m, { Rafz, command, text }) => {
  try {
    const tr = (key, vars) => (m.t ? m.t(key, vars) : key)
    const px = (global.prefix && global.prefix[0]) || "/"
    const chat = String(m.chat)
    const admin = await isAdmin(Rafz, m.chat, m.sender)
    const args = String(text || "").trim()

    /* ═══ 1.8 WELCOME ═══ */
    if (command === "welcome" || command === "goodbye") {
      const col = command
      const cfg = gstore.get(col, chat, null)
      if (/^(on|off)$/i.test(args)) {
        const on = args.toLowerCase() === "on"
        gstore.set(col, chat, { on, text: cfg?.text || (col === "welcome" ? "👋 {mention} welcome to {chatname}!" : "👋 {fullname} left {chatname}") })
        return m.reply("✅ " + command.toUpperCase() + " " + (on ? "ON" : "OFF"), { parse_mode: "HTML" })
      }
      if (!cfg || !cfg.text) return m.reply("ℹ️ " + tr("rose." + col + "Off") + "\n💡 <code>" + px + "set" + col + " teks</code>", { parse_mode: "HTML" })
      return m.reply("👋 <b>" + command.toUpperCase() + "</b>: " + (cfg.on ? "✅ ON" : "❌ OFF") + "\n\n" + esc(cfg.text).slice(0, 800), { parse_mode: "HTML" })
    }
    if (command === "setwelcome" || command === "setgoodbye") {
      if (!admin) return m.reply(tr("rose.adminOnly"), { parse_mode: "HTML" })
      const col = command.replace("set", "").toLowerCase()
      if (!args) return m.reply("⚠️ <code>" + px + command + " Halo {first}, selamat datang di {chatname}!</code>", { parse_mode: "HTML" })
      const cfg = gstore.get(col, chat, { on: true })
      cfg.text = args
      gstore.set(col, chat, cfg)
      return m.reply("✅ " + col.toUpperCase() + " " + tr("rose.saved") + "\n\n" + esc(args).slice(0, 500), { parse_mode: "HTML" })
    }
    if (command === "resetwelcome" || command === "resetgoodbye") {
      if (!admin) return m.reply(tr("rose.adminOnly"), { parse_mode: "HTML" })
      const col = command.replace("reset", "").toLowerCase()
      gstore.del(col, chat)
      return m.reply("✅ " + tr("rose.resetDone2") + " " + col.toUpperCase(), { parse_mode: "HTML" })
    }
    if (command === "welcomehelp") {
      return m.reply(
        "ℹ️ <b>WELCOME FILLINGS</b>\n\n<code>{first} {last} {fullname} {username} {id} {mention} {chatname} {count}</code>\n\n" +
        "Contoh:\n<code>" + px + "setwelcome Halo {mention}! Kamu member ke-{count} di {chatname}</code>",
        { parse_mode: "HTML" }
      )
    }
    if (command === "welcomemute") {
      if (!admin) return m.reply(tr("rose.adminOnly"), { parse_mode: "HTML" })
      const on = !/^off$/i.test(args)
      gstore.set("captcha", chat + ":on", on)
      return m.reply("✅ " + tr("rose.welcomeMute") + " " + (on ? "ON (captcha)" : "OFF"), { parse_mode: "HTML" })
    }
    if (command === "cleanwelcome") {
      /* hapus pesan welcome sebelumnya saat member baru join (mode Rose) */
      if (!admin) return m.reply(tr("rose.adminOnly"), { parse_mode: "HTML" })
      const on = !/^off$/i.test(args)
      gstore.set("welcome", chat + ":clean", on)
      return m.reply("🧹 <b>cleanwelcome</b>: " + (on ? "ON ✅" : "OFF ❌"), { parse_mode: "HTML" })
    }
    if (command === "privatenotes") {
      /* note dikirim ke PM user, bukan di grup (mode Rose) */
      if (!admin) return m.reply(tr("rose.adminOnly"), { parse_mode: "HTML" })
      const on = !/^off$/i.test(args)
      gstore.set("notes", chat + ":private", on)
      return m.reply("📩 <b>privatenotes</b>: " + (on ? "ON ✅" : "OFF ❌"), { parse_mode: "HTML" })
    }

    /* ═══ 1.15 FILTERS (auto-reply) ═══ */
    if (command === "filter" || command === "filteradd") {
      if (!admin) return m.reply(tr("rose.adminOnly"), { parse_mode: "HTML" })
      if (!args) return m.reply("⚠️ <code>" + px + "filter halo Halo juga!</code>", { parse_mode: "HTML" })
      const sp = args.indexOf(" ")
      const trig = args.slice(0, sp).trim()
      const reply = args.slice(sp + 1).trim()
      if (!trig || !reply) return m.reply("⚠️ <code>" + px + "filter kata balasan</code>", { parse_mode: "HTML" })
      let mode = null, t = trig
      const pm = trig.match(/^(prefix|exact):(.*)$/)
      if (pm) { mode = pm[1]; t = pm[2] }
      const cur = gstore.arrGet("filters", chat)
      cur.push({ t, mode, reply })
      gstore.set("filters", chat, cur)
      return m.reply("✅ " + tr("rose.filterSaved") + ": <code>" + esc(t) + "</code>", { parse_mode: "HTML" })
    }
    if (command === "stop" || command === "stopfilter") {
      if (!admin) return m.reply(tr("rose.adminOnly"), { parse_mode: "HTML" })
      const cur = gstore.arrGet("filters", chat)
      gstore.set("filters", chat, cur.filter(x => x.t !== args.trim()))
      return m.reply("✅ " + tr("rose.filterRemoved"), { parse_mode: "HTML" })
    }
    if (command === "stopall") {
      if (!admin) return m.reply(tr("rose.adminOnly"), { parse_mode: "HTML" })
      gstore.set("filters", chat, [])
      return m.reply("✅ " + tr("rose.done"), { parse_mode: "HTML" })
    }
    if (command === "filters" || command === "filterlist") {
      const cur = gstore.arrGet("filters", chat)
      if (!cur.length) return m.reply("💬 <b>FILTERS</b> — " + tr("rose.empty"), { parse_mode: "HTML" })
      return m.reply("💬 <b>FILTERS</b> (" + cur.length + ")\n\n" + cur.map(x => "• <code>" + esc(x.t) + "</code>" + (x.mode ? " (" + x.mode + ")" : "")).join("\n"), { parse_mode: "HTML" })
    }

    /* ═══ 1.16 NOTES ═══ */
    if (command === "save" || command === "savenote") {
      if (!admin) return m.reply(tr("rose.adminOnly"), { parse_mode: "HTML" })
      if (!args) return m.reply("⚠️ <code>" + px + "save faq Baca rules dulu</code>", { parse_mode: "HTML" })
      const sp = args.indexOf(" ")
      const trig = args.slice(0, sp).replace(/^#/, "").trim()
      const content = sp > 0 ? args.slice(sp + 1).trim() : (m.quoted?.text ? m.quoted.text : "")
      if (!trig || !content) return m.reply("⚠️ <code>" + px + "save nama isi</code> (atau reply pesan)", { parse_mode: "HTML" })
      gstore.set("notes", chat + ":" + trig, { text: content, by: String(m.sender), at: Date.now() })
      return m.reply("💾 " + tr("rose.noteSaved") + " <code>#" + esc(trig) + "</code>", { parse_mode: "HTML" })
    }
    if (command === "get" || command === "getnote") {
      const trig = args.replace(/^#/, "").trim()
      const note = trig ? gstore.get("notes", chat + ":" + trig, null) : null
      if (!note) return m.reply(tr("rose.noteNotFound"), { parse_mode: "HTML" })
      /* privatenotes: kirim isi note ke PM user */
      if (gstore.get("notes", chat + ":private", false)) {
        try {
          await Rafz.sendMessage(String(m.sender), "📝 <b>#" + esc(trig) + "</b>\n\n" + esc(note.text).slice(0, 2500), { parse_mode: "HTML" })
          return m.reply("📩 " + tr("rose.sentToPm"), { parse_mode: "HTML" })
        } catch { /* PM gagal → fallback kirim di chat */ }
      }
      return m.reply("📝 <b>#" + esc(trig) + "</b>\n\n" + esc(note.text).slice(0, 2500), { parse_mode: "HTML" })
    }
    if (command === "notes" || command === "notelist") {
      const cur = gstore.list("notes").filter(([k]) => String(k).startsWith(chat + ":"))
      if (!cur.length) return m.reply("📝 <b>NOTES</b> — " + tr("rose.empty"), { parse_mode: "HTML" })
      return m.reply("📝 <b>NOTES</b> (" + cur.length + ")\n\n" + cur.map(([k]) => "• <code>#" + esc(String(k).split(":").slice(1).join(":")) + "</code>").join("\n"), { parse_mode: "HTML" })
    }
    if (command === "clear" || command === "clearnote") {
      if (!admin) return m.reply(tr("rose.adminOnly"), { parse_mode: "HTML" })
      const trig = args.replace(/^#/, "").trim()
      gstore.del("notes", chat + ":" + trig)
      return m.reply("✅ " + tr("rose.noteRemoved") + " <code>#" + esc(trig) + "</code>", { parse_mode: "HTML" })
    }
    if (command === "clearall") {
      if (!admin) return m.reply(tr("rose.adminOnly"), { parse_mode: "HTML" })
      for (const [k] of gstore.list("notes")) if (String(k).startsWith(chat + ":")) gstore.del("notes", k)
      return m.reply("✅ " + tr("rose.done"), { parse_mode: "HTML" })
    }

    /* ═══ 1.19 DISABLE COMMANDS ═══ */
    if (command === "disable") {
      if (!admin) return m.reply(tr("rose.adminOnly"), { parse_mode: "HTML" })
      const cmd = args.trim().replace(/^[\/!.]/, "")
      if (!cmd) return m.reply("⚠️ <code>" + px + "disable welcome2</code>", { parse_mode: "HTML" })
      gstore.arrAdd("disabled", chat, cmd)
      return m.reply("🚫 " + tr("rose.cmdDisabled") + " <code>" + esc(cmd) + "</code>", { parse_mode: "HTML" })
    }
    if (command === "enable") {
      if (!admin) return m.reply(tr("rose.adminOnly"), { parse_mode: "HTML" })
      const cmd = args.trim().replace(/^[\/!.]/, "")
      gstore.arrRemove("disabled", chat, cmd)
      return m.reply("✅ " + tr("rose.cmdEnabled") + " <code>" + esc(cmd) + "</code>", { parse_mode: "HTML" })
    }
    if (command === "disabled") {
      const cur = gstore.arrGet("disabled", chat)
      return m.reply("🚫 <b>DISABLED</b>\n" + (cur.length ? cur.map(c => "• <code>" + esc(c) + "</code>").join("\n") : "—"), { parse_mode: "HTML" })
    }

    /* ═══ 1.21 FEDERATIONS ═══ */
    if (command === "newfed") {
      if (!args) return m.reply("⚠️ <code>" + px + "newfed Fed Nama</code>", { parse_mode: "HTML" })
      if (gstore.get("feds", "u" + m.sender, null)) return m.reply("⚠️ " + tr("rose.alreadyHaveFed") + " <code>" + esc(gstore.get("feds", "u" + m.sender)) + "</code>", { parse_mode: "HTML" })
      const fid = "F" + Math.random().toString(36).slice(2, 8).toUpperCase()
      gstore.set("feds", fid, { name: args, owner: String(m.sender), chats: [], bans: [], created: Date.now() })
      gstore.set("feds", "u" + m.sender, fid)
      return m.reply("🌐 <b>FED dibuat!</b>\n\n🏷️ ID: <code>" + fid + "</code>\n📛 " + esc(args) + "\n👑 " + (m.pushName || m.sender), { parse_mode: "HTML" })
    }
    if (command === "delfed") {
      const fid = gstore.get("feds", "u" + m.sender)
      if (!fid) return m.reply(tr("rose.noFed"), { parse_mode: "HTML" })
      gstore.del("feds", fid); gstore.del("feds", "u" + m.sender)
      return m.reply("✅ " + tr("rose.fedDeleted"), { parse_mode: "HTML" })
    }
    if (command === "joinfed") {
      if (!admin) return m.reply(tr("rose.adminOnly"), { parse_mode: "HTML" })
      const fid = args.trim().toUpperCase()
      const fed = gstore.get("feds", fid)
      if (!fed) return m.reply(tr("rose.fedNotFound"), { parse_mode: "HTML" })
      fed.chats = (fed.chats || []).filter(c => c !== chat); fed.chats.push(chat)
      gstore.set("feds", fid, fed)
      gstore.set("feds", "c" + chat, fid)
      return m.reply("🌐 " + tr("rose.fedJoined") + " <b>" + esc(fed.name) + "</b>", { parse_mode: "HTML" })
    }
    if (command === "leavefed") {
      if (!admin) return m.reply(tr("rose.adminOnly"), { parse_mode: "HTML" })
      const fid = gstore.get("feds", "c" + chat)
      if (!fid) return m.reply(tr("rose.noFed"), { parse_mode: "HTML" })
      const fed = gstore.get("feds", fid)
      if (fed) { fed.chats = (fed.chats || []).filter(c => c !== chat); gstore.set("feds", fid, fed) }
      gstore.del("feds", "c" + chat)
      return m.reply("✅ " + tr("rose.fedLeft"), { parse_mode: "HTML" })
    }
    if (command === "fedinfo" || command === "chatfed") {
      const fid = gstore.get("feds", "c" + chat) || args.trim().toUpperCase()
      const fed = fid ? gstore.get("feds", fid) : null
      if (!fed) return m.reply(tr("rose.fedNotFound"), { parse_mode: "HTML" })
      return m.reply(
        "🌐 <b>FEDERATION</b>\n\n🏷️ <code>" + fid + "</code>\n📛 " + esc(fed.name) + "\n" +
        "👑 Owner: <code>" + esc(fed.owner) + "</code>\n" +
        "💬 " + tr("rose.fedChats") + ": <b>" + (fed.chats || []).length + "</b>\n" +
        "🚫 " + tr("rose.fedBans") + ": <b>" + (fed.bans || []).length + "</b>",
        { parse_mode: "HTML" }
      )
    }
    if (command === "fban") {
      if (!admin) return m.reply(tr("rose.adminOnly"), { parse_mode: "HTML" })
      const fid = gstore.get("feds", "c" + chat)
      if (!fid) return m.reply(tr("rose.noFed"), { parse_mode: "HTML" })
      const fed = gstore.get("feds", fid)
      if (!fed) return m.reply(tr("rose.fedNotFound"), { parse_mode: "HTML" })
      if (String(m.sender) !== String(fed.owner) && !(fed.admins || []).includes(String(m.sender))) return m.reply(tr("rose.fedOwnerOnly"), { parse_mode: "HTML" })
      const tgt = m.quoted?.sender || String(args.split(/\s+/)[0] || "").replace("@", "").replace(/\D/g, "")
      if (!tgt || !/^\d{5,}$/.test(tgt)) return m.reply(tr("rose.needTarget"), { parse_mode: "HTML" })
      if (!fed.bans.includes(tgt)) fed.bans.push(tgt)
      gstore.set("feds", fid, fed)
      let n = 0
      for (const c of fed.chats || []) { try { await Rafz.banChatMember(c, tgt); n++ } catch {} }
      return m.reply("🌐🔨 " + tr("rose.fedBanned") + " <code>" + esc(tgt) + "</code> — " + n + " chats", { parse_mode: "HTML" })
    }
    if (command === "unfban") {
      const fid = gstore.get("feds", "c" + chat)
      const fed = fid ? gstore.get("feds", fid) : null
      if (!fed) return m.reply(tr("rose.noFed"), { parse_mode: "HTML" })
      const tgt = String(args.split(/\s+/)[0] || "").replace(/\D/g, "")
      fed.bans = (fed.bans || []).filter(x => x !== tgt)
      gstore.set("feds", fid, fed)
      return m.reply("✅ " + tr("rose.fedUnbanned"), { parse_mode: "HTML" })
    }
    if (command === "fedpromote") {
      const fid = gstore.get("feds", "c" + chat)
      const fed = fid ? gstore.get("feds", fid) : null
      if (!fed || String(m.sender) !== String(fed.owner)) return m.reply(tr("rose.fedOwnerOnly"), { parse_mode: "HTML" })
      const tgt = m.quoted?.sender || String(args).replace(/\D/g, "")
      if (!tgt) return m.reply(tr("rose.needTarget"), { parse_mode: "HTML" })
      fed.admins = [...(fed.admins || []), String(tgt)]
      gstore.set("feds", fid, fed)
      return m.reply("✅ " + tr("rose.fedPromoted"), { parse_mode: "HTML" })
    }

    return false
  } catch (e) {
    console.error("[rosenotes]", command, e?.message)
    try { await m.reply("❌ " + esc(String(e?.message || e).slice(0, 120)), { parse_mode: "HTML" }) } catch {}
    return false
  }
}

/* captcha answer via callback */
const cbHandler = async (m, { Rafz }) => {
  try {
    const cb = String(m.callback || "")
    const mt = cb.match(/^\/capans\s+(\d+)\s+(.+)$/)
    if (!mt) return false
    const chat = String(m.chat)
    const pending = gstore.get("captcha", chat + ":u" + mt[1], null)
    if (!pending) return false
    const uid = String(m.sender)
    if (uid !== mt[1]) { try { await Rafz.answerCallbackQuery(m.callbackId, { text: (m.t ? m.t("rose.captchaNotYours") : "This captcha is not yours!") }) } catch {}; return true }
    if (mt[2] === String(pending.answer)) {
      gstore.del("captcha", chat + ":u" + mt[1])
      try { await Rafz.restrictChatMember(m.chat, uid, { permissions: { can_send_messages: true, can_send_polls: true, can_send_other_messages: true, can_add_web_page_previews: true, can_invite_users: true } }) } catch {}
      try { await Rafz.answerCallbackQuery(m.callbackId, { text: "✅ Verified!" }) } catch {}
      await m.reply("✅ <a href=\"tg://user?id=" + uid + "\">user</a> verified!", { parse_mode: "HTML" })
    } else {
      try { await Rafz.answerCallbackQuery(m.callbackId, { text: "❌ Salah!" }) } catch {}
    }
    return true
  } catch { return false }
}

const combined = async (m, opts) => {
  if (m.callback && /^\/capans\b/.test(String(m.callback))) return cbHandler(m, opts)
  return handler(m, opts)
}
combined.command = [
  "welcome", "goodbye", "setwelcome", "setgoodbye", "resetwelcome", "resetgoodbye", "welcomehelp", "welcomemute", "cleanwelcome",
  "filter", "filteradd", "stop", "stopfilter", "stopall", "filters", "filterlist",
  "save", "savenote", "get", "getnote", "notes", "notelist", "clear", "clearnote", "clearall", "privatenotes",
  "disable", "enable", "disabled",
  "newfed", "delfed", "joinfed", "leavefed", "fedinfo", "chatfed", "fban", "unfban", "fedpromote"
]
module.exports = combined

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
