/* plugin: audiofx.js — efek audio via ffmpeg-static (porting Prabowo MD)
   /bass /blown /earrape /fast /slow /nightcore /smooth /robot /squirrel
   /reverse /fat /deep /removenoise /tupai
   Reply audio/voice/video dengan command. Output = voice note (OGG). */

"use strict"
const fs = require("fs")
const path = require("path")
const os = require("os")
const { execFileSync } = require("child_process")

const ffmpegPath = (() => {
  try { return require("ffmpeg-static") } catch { return null }
})()

const tgBuffer = async (Rafz, fileId) => {
  const info = await Rafz.getFile(fileId)
  const res = await fetch(`https://api.telegram.org/file/bot${Rafz.token}/${info.file_path}`)
  return Buffer.from(await res.arrayBuffer())
}

/* filter ffmpeg per efek (dipakai -af) */
const FX = {
  bass:        { af: "equalizer=f=54:width_type=o:width=2:g=14,gain=g=8", desc: "Bass boost" },
  blown:       { af: "acrusher=bits=4:mode=log:aa=0,supereducer", desc: "Blown" },
  earrape:     { af: "acrusher=bits=2:mode=log:aa=0,volume=14", desc: "Earrape" },
  fast:        { af: "atempo=1.6", desc: "Fast" },
  slow:        { af: "atempo=0.72", desc: "Slow" },
  nightcore:   { af: "asetrate=44100*1.35,aresample=44100,atempo=1.05", desc: "Nightcore" },
  smooth:      { af: "firequalizer=gain='0.7*sin(0.00015*f)'", desc: "Smooth" },
  robot:       { af: " vibrato=f=4:d=0.9,tremolo=f=25:d=0.7", desc: "Robot" },
  squirrel:    { af: "asetrate=44100*1.6,aresample=44100", desc: "Squirrel/Tupai" },
  deep:        { af: "asetrate=44100*0.72,aresample=44100,atempo=0.96", desc: "Deep" },
  fat:         { af: "bass=g=10,equalizer=f=130:width_type=o:width=2:g=7", desc: "Fat" },
  reverse:     { af: "areverse", desc: "Reverse" },
  removenoise: { af: "afftdn=nr=24:nf=-25", desc: "Noise removal" }
}

const applyFx = (buf, af) => {
  if (!ffmpegPath || !fs.existsSync(ffmpegPath)) throw new Error("ffmpeg tidak tersedia di server")
  const inFile = path.join(os.tmpdir(), "afx_in_" + Date.now() + ".bin")
  const outFile = path.join(os.tmpdir(), "afx_out_" + Date.now() + ".ogg")
  try {
    fs.writeFileSync(inFile, buf)
    execFileSync(ffmpegPath, [
      "-y", "-loglevel", "error", "-i", inFile,
      "-af", af,
      "-ar", "48000", "-ac", "1",
      "-c:a", "libopus", "-b:a", "96k",
      outFile
    ], { timeout: 90000 })
    const out = fs.readFileSync(outFile)
    if (!out.length) throw new Error("hasil kosong")
    return out
  } finally {
    try { fs.unlinkSync(inFile) } catch {}
    try { fs.unlinkSync(outFile) } catch {}
  }
}

const handler = async (m, { Rafz, command }) => {
  try {
    const tr = (key, vars) => (m.t ? m.t(key, vars) : key)
    /* alias: /tupai = squirrel */
    if (command === "tupai" && FX.squirrel) command = "squirrel"
    if (!FX[command]) return false

    const src = (m.quoted && m.quoted.fileId) ? m.quoted : (m.fileId ? m : null)
    if (!src || !src.fileId)
      return m.reply(`${tr("fx.usage", { cmd: command })}\n${tr("fx.list")} ${Object.keys(FX).join(", ")}`, { parse_mode: "HTML" })

    const wait = await m.reply(tr("fx.processing"), { parse_mode: "HTML" })
    try {
      const buf = await tgBuffer(Rafz, src.fileId)
      const out = applyFx(buf, FX[command].af)
      try { Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {}) } catch {}
      await Rafz.sendVoice(m.chat, out, {
        caption: `🎧 ${FX[command].desc} — oleh ${global.botname || "Bot"}`,
        reply_to_message_id: m.id, allow_sending_without_reply: true
      })
      return true
    } catch (e) {
      try { Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {}) } catch {}
      return m.reply(tr("use.failed") + " " + (e?.message || e))
    }
  } catch (e) {
    console.error("[audiofx]", e?.message)
    try { await m.reply("⚠️ Error: " + (e?.message || e)) } catch {}
    return false
  }
}

handler.command = Object.keys(FX).concat(["tupai"])
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
