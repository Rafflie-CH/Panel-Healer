"use strict"
const https = require("https")
const http = require("http")

const UA = "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/130 Mobile Safari/537.36"

const getBuffer = (url, hdrs = {}) =>
  new Promise((resolve, reject) => {
    try {
      const follow = (u, depth = 0) => {
        if (depth > 5) return reject(new Error("Too many redirects"))
        const parsed = new URL(u)
        const mod = parsed.protocol === "https:" ? https : http
        mod.get({ hostname: parsed.hostname, path: parsed.pathname + parsed.search, timeout: 60000, headers: { "User-Agent": UA, ...hdrs } }, (res) => {
          if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) return follow(new URL(res.headers.location, u).href, depth + 1)
          if (res.statusCode !== 200) return reject(new Error("HTTP " + res.statusCode))
          const c = []
          res.on("data", d => c.push(d))
          res.on("end", () => resolve(Buffer.concat(c)))
        }).on("error", reject).on("timeout", function () { this.destroy(); reject(new Error("Timeout")) })
      }
      follow(url)
    } catch (e) { reject(e) }
  })

const split2 = (q) => {
  const parts = q.split("|").map(s => s.trim())
  return [parts[0] || "TEXT", parts[1] || "TEXT"]
}

const handler = async (m, { Rafz, command, text }) => {
  try {
    const px = (global.prefix && global.prefix[0]) || "/"
    const q = (text || "").trim()

    const TEXTPRO = {
      "pornhub": ["https://api.siputzx.my.id/api/maker/textpro/pornhub", 2],
      "blackpink": ["https://api.siputzx.my.id/api/maker/textpro/blackpink", 1],
      "glitch": ["https://api.siputzx.my.id/api/maker/textpro/glitch", 2],
      "avengers": ["https://api.siputzx.my.id/api/maker/textpro/avengers", 2],
      "marvel": ["https://api.siputzx.my.id/api/maker/textpro/marvel", 2],
      "naruto": ["https://api.siputzx.my.id/api/maker/textpro/naruto", 1],
      "bear": ["https://api.siputzx.my.id/api/maker/textpro/bear", 2],
      "wolfgalaxy": ["https://api.siputzx.my.id/api/maker/textpro/wolf-galaxy", 2],
      "grafitti": ["https://api.siputzx.my.id/api/maker/textpro/write-graffiti", 1],
      "wetglass": ["https://api.siputzx.my.id/api/maker/textpro/wetglass", 1],
      "pavement": ["https://api.siputzx.my.id/api/maker/textpro/pavement", 1],
      "painting": ["https://api.siputzx.my.id/api/maker/textpro/painting", 1],
      "dragonball": ["https://api.siputzx.my.id/api/maker/textpro/dragonball", 1],
      "foggyglass": ["https://api.siputzx.my.id/api/maker/textpro/foggy-glass", 1],
      "devilwings": ["https://api.siputzx.my.id/api/maker/textpro/devil-wings", 1],
      "mascot": ["https://api.siputzx.my.id/api/maker/textpro/mascot", 1],
      "comic": ["https://api.siputzx.my.id/api/maker/textpro/comic", 1],
      "pixelglitch": ["https://api.siputzx.my.id/api/maker/textpro/pixel-glitch", 1]
    }

    if (TEXTPRO[command]) {
      if (!q) return m.reply("Penggunaan: " + px + command + " " + (TEXTPRO[command][1] === 2 ? "teks1|teks2" : "teks"))
      const [t1, t2] = split2(q)
      const wait = await m.reply("Membuat logo...")
      try {
        let url = TEXTPRO[command][0] + "?text=" + encodeURIComponent(t1)
        if (TEXTPRO[command][1] === 2) url += "&text2=" + encodeURIComponent(t2)
        const buf = await getBuffer(url)
        if (!buf || buf.length < 1000) throw new Error("Logo kosong")
        await Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {})
        await Rafz.sendPhoto(m.chat, buf, { caption: "TEXT PRO: " + command.toUpperCase(), reply_to_message_id: m.id, allow_sending_without_reply: true })
        return true
      } catch (e) {
        try { await Rafz.deleteMessage(m.chat, wait.message_id) } catch {}
        return m.reply("Gagal membuat logo " + command + ": " + e.message)
      }
    }

    if (command === "ttp" || command === "attp") {
      if (!q) return m.reply("Penggunaan: " + px + command + " teks")
      const wait = await m.reply("Membuat...")
      try {
        let buf
        if (command === "ttp") {
          buf = await getBuffer("https://api.siputzx.my.id/api/maker/ttp?text=" + encodeURIComponent(q))
        } else {
          buf = await getBuffer("https://api.siputzx.my.id/api/maker/attp?text=" + encodeURIComponent(q))
        }
        if (!buf || buf.length < 500) throw new Error("kosong")
        await Rafz.deleteMessage(m.chat, wait.message_id).catch(() => {})
        await Rafz.sendDocument(m.chat, buf, { filename: command + ".webp", caption: "Sticker " + command.toUpperCase() + ": " + q.slice(0, 50), reply_to_message_id: m.id })
        return true
      } catch (e) {
        try { await Rafz.deleteMessage(m.chat, wait.message_id) } catch {}
        return m.reply("Gagal: " + e.message)
      }
    }

    return false
  } catch (e) {
    console.error("[textmaker]", e?.message)
    try { await m.reply("Error: " + (e?.message || e)) } catch {}
    return false
  }
}

handler.command = ["pornhub", "blackpink", "glitch", "avengers", "marvel", "naruto", "bear", "wolfgalaxy", "grafitti", "wetglass", "pavement", "painting", "dragonball", "foggyglass", "devilwings", "mascot", "comic", "pixelglitch", "ttp", "attp"]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
