/* plugin: afk.js - /afk dan deteksi afk */
"use strict"
const fss = require("fs")
const path = require("path")

const AFK_DB = "./library/database/afk.json"

const loadAfk = () => {
  try { const j = JSON.parse(fss.readFileSync(AFK_DB, "utf8")); return (j && typeof j === "object" && !Array.isArray(j)) ? j : {} } catch { return {} }
}
const saveAfk = (data) => {
  try { fss.mkdirSync(path.dirname(AFK_DB), { recursive: true }); fss.writeFileSync(AFK_DB, JSON.stringify(data, null, 2)) } catch {}
}

const handler = async (m, { Rafz, command, text }) => {
  try {
    const px = (global.prefix && global.prefix[0]) || "/"
    const sender = String(m.sender)
    const afk = loadAfk()

    if (command === "afk") {
      const reason = (text || "").trim() || "Tidak ada alasan"
      afk[sender] = { reason, at: Date.now() }
      saveAfk(afk)
      return m.reply("<b>AFK</b>\nAlasan: " + reason, { parse_mode: "HTML" })
    }

    // Check if user is AFK and sends a message (not command)
    if (m.isCmd && afk[sender]) {
      const elapsed = Math.round((Date.now() - afk[sender].at) / 60000)
      delete afk[sender]
      saveAfk(afk)
      return m.reply("Selamat datang kembali! Kamu afk selama " + elapsed + " menit.", { parse_mode: "HTML" })
    }

    // If someone mentions an AFK user
    if (m.mentioned && m.mentioned.length > 0) {
      for (const ment of m.mentioned) {
        if (afk[ment.id]) {
          const elapsed = Math.round((Date.now() - afk[ment.id].at) / 60000)
          await m.reply(
            "<a href=\"tg://user?id=" + ment.id + "\"><b>" + (ment.name || ment.id) + "</b></a> sedang AFK\nAlasan: " + afk[ment.id].reason + "\nSejak: " + elapsed + " menit lalu",
            { parse_mode: "HTML" }
          )
        }
      }
    }

    return false
  } catch (e) {
    console.error("[afk]", e?.message)
    return false
  }
}

handler.command = ["afk"]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
