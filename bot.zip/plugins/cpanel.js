/* plugin: cpanel.js — shortcut cpanel
   /unli nama|target  atau /unli nama target — create panel unlimited
   /1gb nama|target    — create panel 1GB
   /2gb ... /10gb
   /unliv2 nama target — unlimited server 2
   /1gbv2 nama target  — 1GB server 2

   Format target fleksibel: pakai | ATAU spasi.
   Contoh (sesuai saran @alpiqqq):
     /unli nama-panel
     /unli nama-panel @target
     /1gb toko-me 123456789                      */

"use strict"

const parseShortcut = (command) => {
  const match = command.match(/^(\d+)gb(v(\d+))?$/i)
  if (match) {
    const gb = parseInt(match[1])
    const srv = match[3] || "1"
    return { ram: gb, disk: gb, cpu: Math.min(400, gb * 50), server: srv }
  }
  const unliMatch = command.match(/^unli(mited)?(v(\d+))?$/i)
  if (unliMatch) {
    const srv = unliMatch[3] || "1"
    return { ram: 0, disk: 0, cpu: 0, server: srv }
  }
  return null
}

const handler = async (m, { Rafz, command, text }) => {
  try {
    const px = (global.prefix && global.prefix[0]) || "/"
    const sender = String(m.sender)
    const tr = (key, vars) => (m.t ? m.t(key, vars) : key)

    const readArr = (f) => {
      try { const j = JSON.parse(require("fs").readFileSync("./library/database/" + f, "utf8")); return Array.isArray(j) ? j : [] } catch { return [] }
    }

    const isCreator = (global.owner || []).includes(sender)
    const isOwner = isCreator || readArr("owner.json").includes(sender)
    const isSuper = readArr("superseller.json").includes(sender) || isOwner
    const isSeller = readArr("seller.json").includes(sender) || isSuper

    if (!isSeller && !isSuper && !isOwner) return m.reply(tr("denied.seller"), { parse_mode: "HTML" })

    const spec = parseShortcut(command)
    if (!spec) return false

    if (!text) {
      return m.reply(
        `⚠️ <b>Penggunaan:</b> <code>${px}${command} nama|target</code>\n` +
        `atau <code>${px}${command} nama target</code>\n\n` +
        `Contoh:\n<code>${px}${command} myserver|me</code>\n` +
        `<code>${px}${command} myserver @target</code>\n` +
        `<code>${px}${command} myserver 123456789</code>`,
        { parse_mode: "HTML" }
      )
    }

    /* parsing fleksibel: "nama|target" ATAU "nama target" (spasi, sesuai saran) */
    let name, target
    if (text.includes("|")) {
      const parts = text.split("|").map(s => s.trim())
      name = parts[0]
      target = parts[1] || "me"
    } else {
      const parts = text.trim().split(/\s+/)
      name = parts[0]
      target = parts[1] || "me"
    }

    if (!name) return m.reply("❌ Nama panel harus diisi.", { parse_mode: "HTML" })

    let serverName = spec.server
    if (!isSuper && !isOwner) serverName = "1"
    /* FIX: global.panelServer bisa undefined sebelum /setserver pernah dijalankan */
    if (!global.panelServer || !global.panelServer[serverName]) serverName = "1"
    if (!global.panelServer || !global.panelServer[serverName]) {
      /* default: tanpa konfigurasi server sama sekali → pakai server "1" apa adanya
         (case cpanel yang validasi detail) */
      global.panelServer = global.panelServer || {}
      global.panelServer["1"] = global.panelServer["1"] || { name: "Server 1" }
    }

    const ramStr = spec.ram === 0 ? "unli" : String(spec.ram)

    const caseFile = require("../case")
    const sub = Object.assign({}, m)
    sub.isCmd = true
    sub.command = "cpanel"
    sub.text = `${name}|${target}|${ramStr}|1|${serverName}`
    sub.body = `${px}cpanel ${sub.text}`
    sub.raw = sub.body
    sub.args = [name, target, ramStr, "1", serverName]

    try {
      await caseFile(sub, Rafz)
    } catch (e) {
      await m.reply("❌ Gagal: " + (e?.message || e), { parse_mode: "HTML" })
    }

    return true
  } catch (e) {
    console.error("[cpanel]", e?.message)
    try { await m.reply("⚠️ Error: " + (e?.message || e)) } catch {}
    return false
  }
}

const cmds = []
for (let i = 1; i <= 10; i++) cmds.push(i + "gb")
cmds.push("unli", "unlimited")
try {
  const allServers = Object.keys(global.panelServer || {})
  for (const srv of allServers) {
    if (srv === "1") continue
    for (let i = 1; i <= 10; i++) cmds.push(i + "gbv" + srv)
    cmds.push("unliv" + srv, "unlimitedv" + srv)
  }
} catch {}

handler.command = cmds
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
