/* barker.js — Barker Tag Bot (porting @zazyvala_bot).
   /all /callall — tag semua member yang pernah ketahuan bot (cache user per grup),
   /callone N — tag satu-satu per pesan (hindari limit notif),
   /callsign /setme /me /bigme — panggilan personal, /unreg — opt-out dari /all.
   Teknik Barker: batching 5 mention/pesan + zero-width space supaya notif terkirim. */

"use strict"
const gstore = require("../library/gstore")

const ZWSP = "\u200B"

/* cache user per grup: diisi otomatis dari SETIAP pesan (roseMsgHook chain) */
const cacheUser = (chat, u) => {
  if (!u || u.is_bot) return
  gstore.set("members", String(chat) + ":" + String(u.id), {
    id: String(u.id), first: (u.first_name || "").slice(0, 60), username: u.username || "", at: Date.now()
  })
}
try {
  const prev = global.roseMsgHook
  global.roseMsgHook = async (m, ctx) => {
    try {
      if (m?.isGroup && m.raw?.from) cacheUser(m.chat, m.raw.from)
    } catch {}
    if (prev) { const r = await prev(m, ctx); if (r) return r }
    return false
  }
} catch {}

const mention = (u) => '<a href="tg://user?id=' + u.id + '">' + (u.first || "user") + ZWSP + "</a>"

const handler = async (m, { Rafz, command, text }) => {
  try {
    const tr = (key, vars) => (m.t ? m.t(key, vars) : key)
    if (!m.isGroup) return m.reply(tr("rose.groupOnly"), { parse_mode: "HTML" })
    const chat = String(m.chat)

    /* ═══ /all /callall — tag semua (batch @ 5 mention) ═══ */
    if (command === "all" || command === "callall" || command === "tagall2") {
      const admin = await isAdminLocal(Rafz, m.chat, m.sender)
      if (!admin) return m.reply(tr("rose.adminOnly"), { parse_mode: "HTML" })
      const members = gstore.list("members")
        .filter(([k]) => String(k).startsWith(chat + ":"))
        .map(([, v]) => v)
        .filter(u => !gstore.get("unreg", u.id, false))
        .sort((a, b) => (a.at || 0) - (b.at || 0))
      if (!members.length) return m.reply(tr("barker.noMembers"), { parse_mode: "HTML" })

      const caption = String(text || "").trim()
      const batch = []
      for (let i = 0; i < members.length; i += 5) batch.push(members.slice(i, i + 5))
      let sent = 0
      for (const chunk of batch) {
        let msg = caption && sent === 0 ? esc(caption) + "\n\n" : ""
        msg += chunk.map(mention).join(" ")
        try { await Rafz.sendMessage(m.chat, msg, { parse_mode: "HTML", reply_to_message_id: sent === 0 ? m.id : undefined, allow_sending_without_reply: true }) } catch {}
        sent++
        if (batch.length > 1) await new Promise(r => setTimeout(r, 1200))
      }
      return true
    }

    /* ═══ /callone N — satu-satu per pesan ═══ */
    if (command === "callone") {
      const admin = await isAdminLocal(Rafz, m.chat, m.sender)
      if (!admin) return m.reply(tr("rose.adminOnly"), { parse_mode: "HTML" })
      const n = Math.min(parseInt(text) || 10, 30)
      const members = gstore.list("members").filter(([k]) => String(k).startsWith(chat + ":")).map(([, v]) => v).filter(u => !gstore.get("unreg", u.id, false))
      if (!members.length) return m.reply(tr("barker.noMembers"), { parse_mode: "HTML" })
      const list = members.slice(0, n)
      const wait = await m.reply("📣 0/" + list.length, { parse_mode: "HTML" })
      for (let i = 0; i < list.length; i++) {
        try { await Rafz.sendMessage(m.chat, "📣 " + mention(list[i]), { parse_mode: "HTML" }) } catch {}
        try { await Rafz.editMessageText("📣 " + (i + 1) + "/" + list.length, { chat_id: m.chat, message_id: wait.message_id, parse_mode: "HTML" }) } catch {}
        await new Promise(r => setTimeout(r, 800))
      }
      return true
    }

    /* ═══ /admins — tag admin saja ═══ */
    if (command === "calladmins") {
      try {
        const admins = await Rafz.getChatAdministrators(m.chat)
        const list = admins.filter(a => !a.user?.is_bot).map(a => ({ id: String(a.user.id), first: a.user.first_name || "admin" }))
        let msg = "📣 <b>" + tr("barker.admins") + "</b>\n\n"
        msg += list.map(mention).join(" ")
        return await m.reply(msg, { parse_mode: "HTML" })
      } catch { return m.reply(tr("common.failed")) }
    }

    /* ═══ callsign: /setme /me /bigme ═══ */
    if (command === "setme" || command === "changeme") {
      if (!text) return m.reply("⚠️ <code>/setme 🔥Rafz</code>", { parse_mode: "HTML" })
      gstore.set("callsign", String(m.sender), String(text).slice(0, 32))
      return m.reply("✅ " + tr("barker.callsignSet") + ": " + esc(String(text).slice(0, 32)), { parse_mode: "HTML" })
    }
    if (command === "me" || command === "mycallsign") {
      const cs = gstore.get("callsign", String(m.sender), null)
      return m.reply("🪪 " + (cs ? esc(cs) : tr("barker.noCallsign")), { parse_mode: "HTML" })
    }
    if (command === "bigme") {
      const cs = gstore.get("callsign", String(m.sender), m.pushName || "user")
      return m.reply("🪪 <b><u>" + esc(cs) + "</u></b>", { parse_mode: "HTML" })
    }

    /* ═══ /unreg — opt-out dari /all ═══ */
    if (command === "unreg") {
      const cur = !gstore.get("unreg", String(m.sender), false)
      gstore.set("unreg", String(m.sender), cur)
      return m.reply(cur ? "🔕 " + tr("barker.unregOn") : "🔔 " + tr("barker.unregOff"), { parse_mode: "HTML" })
    }
    if (command === "reg") {
      gstore.set("unreg", String(m.sender), false)
      return m.reply("🔔 " + tr("barker.unregOff"), { parse_mode: "HTML" })
    }

    /* ═══ /upatterns /cpatterns — info template ═══ */
    if (command === "upatterns" || command === "cpatterns") {
      return m.reply(
        "ℹ️ <b>" + (command === "upatterns" ? "UNREG" : "CALL") + " PATTERNS</b>\n\n" +
        (command === "upatterns"
          ? tr("barker.upatternsInfo") + "\n<code>/unreg</code>, <code>/reg</code>"
          : tr("barker.cpatternsInfo") + "\n<code>/setme</code>, <code>/me</code>, <code>/bigme</code>"),
        { parse_mode: "HTML" }
      )
    }

    return false
  } catch (e) {
    console.error("[barker]", command, e?.message)
    try { await m.reply("❌ " + String(e?.message || e).slice(0, 120), { parse_mode: "HTML" }) } catch {}
    return false
  }
}

async function isAdminLocal(Rafz, chat, uid) {
  try {
    if ((global.owner || []).includes(String(uid))) return true
    const admins = await Rafz.getChatAdministrators(chat)
    return admins.some(a => String(a.user?.id) === String(uid))
  } catch { return false }
}

handler.command = ["all", "callall", "tagall2", "callone", "calladmins", "setme", "changeme", "me", "mycallsign", "bigme", "unreg", "reg", "upatterns", "cpatterns"]
module.exports = handler

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
