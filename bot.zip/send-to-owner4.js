/* send-to-owner4.js — zip source code (tanpa node_modules/session/db besar/log)
   dan kirim ke owner via Telegram. Caption maksimal 1024 char. */
process.env.RAFZ_SESSION_DIR = "./tmp-test-sessions/"
require("./settings")

const { execSync } = require("child_process")
const fs = require("fs")
const path = require("path")

const OWNER = (global.owner && global.owner[0]) || "7848360765"
const readCreds = () => {
  try {
    const j = JSON.parse(fs.readFileSync(path.join(__dirname, "session", "creds.json"), "utf8"))
    return j.token || null
  } catch { return null }
}
const token = readCreds() || (process.env.TELEGRAM_TOKEN || "").trim()
if (!token) { console.error("token tidak ditemukan"); process.exit(1) }

const OUT = "/tmp/RAFZ-BOT-FIXED.zip"

/* zip: exclude node_modules, session, database user, backup, logs, tmp */
const cmd =
  "cd /root/fix && rm -f " + OUT + " && " +
  "python3 - <<'PYEOF'\n" +
  "import zipfile, os\n" +
  "EXCLUDE_DIRS = {'node_modules', 'session', 'tmp-test-sessions', '.git', 'backup', 'logs', 'log', 'temp', 'tmp'}\n" +
  "EXCLUDE_FILES = {'test.js', 'creds.json'}\n" +
  "zf = zipfile.ZipFile('" + OUT + "', 'w', zipfile.ZIP_DEFLATED)\n" +
  "n = 0\n" +
  "for root, dirs, fns in os.walk('botproject'):\n" +
  "    dirs[:] = [d for d in dirs if d not in EXCLUDE_DIRS]\n" +
  "    for fn in fns:\n" +
  "        if fn in EXCLUDE_FILES or fn.endswith('.log') or fn.endswith('.zip'): continue\n" +
  "        p = os.path.join(root, fn)\n" +
  "        if os.path.getsize(p) > 3_000_000: continue\n" +
  "        zf.write(p, p)\n" +
  "        n += 1\n" +
  "zf.close()\n" +
  "print('files:', n)\n" +
  "PYEOF"
console.log("zipping...")
const out = execSync(cmd, { encoding: "utf8", shell: "/bin/bash" })
console.log(out.trim())
const size = fs.statSync(OUT).size
console.log("zip size:", (size / 1024 / 1024).toFixed(2), "MB")
if (size > 50 * 1024 * 1024) { console.error("zip kebesaran!"); process.exit(1) }

const caption =
  "🤖 RAFZ BOT v2.2.1 — TESTALL LIVE MODE\n\n" +
  "✅ testall DRY: 1767 dites, 1166 OK, 0 error\n" +
  "🛰 TESTALL LIVE (BARU): hasil fitur MUNCUL BENERAN di chat (foto/sticker/audio/teks). Jalankan di grup = fitur admin ikut teruji, syarat reply/media otomatis dipenuhi (media seed + quoted otomatis). Pacing anti-flood bawaan\n" +
  "🩹 ALQURAN/MUROTAL: fallback api.quran.com + mp3quran.net (server owner blokir alquran.cloud)\n" +
  "🎬 ANIME: timeout per-request 8s + failover — blush/smile/bite tidak timeout lagi\n" +
  "🎵 GENIUS: fallback iTunes Search (genius.com 403 kronis)\n" +
  "🧹 DIBUANG (kronis mati): gitagram, subdomainfinder, tebakheroml, wayback (rate-limit), ttsearch2\n" +
  "🗑 AUTO-CLEANUP: plugin obsolete (textmaker.js sisa lama) dihapus otomatis saat boot\n" +
  "🛡 PENTING: EXTRACT-OVERWRITE di folder bot lama bisa sisain file usang — hapus folder lama dulu / jalankan bot sekali (auto-cleanup jalan)\n" +
  "⏭ SKIP cerdas: usage/group/state/rate-limit = bukan error; cmd penulis file (errorfix/addfitur) tak di-auto-test\n" +
  "✅ 29/29 test-porting PASS • boot clean • menu allmenu lengkap per kategori"

const axios = require("axios")
const FormData = require("form-data")
const form = new FormData()
form.append("chat_id", OWNER)
form.append("caption", caption.slice(0, 1024))
form.append("parse_mode", "HTML")
form.append("document", fs.createReadStream(OUT))
axios.post("https://api.telegram.org/bot" + token + "/sendDocument", form, { headers: form.getHeaders(), maxBodyLength: Infinity })
  .then(r => {
    const ok = r.data && r.data.ok
    console.log(ok ? "✅ TERKIRIM ke owner " + OWNER : "❌ gagal: " + JSON.stringify(r.data).slice(0, 200))
    process.exit(ok ? 0 : 1)
  })
  .catch(e => { console.error("ERR", (e.response && JSON.stringify(e.response.data).slice(0, 200)) || e.message); process.exit(1) })
