const fs = require("fs")
const Module = require("module")
const path = require("path")

/* NTBA_FIX_350: node-telegram-bot-api tidak lagi melempar
   "EFATAL: Unsupported Buffer file-type" saat Buffer tidak terdeteksi
   file-type-nya (mis. MP3 dari Google TTS) — content-type otomatis
   di-fallback ke application/octet-stream. WAJIB diset SEBELUM bot start. */
try { process.env.NTBA_FIX_350 = "1" } catch {}

try {
  const originalLoader = Module._extensions[".json"]

  Module._extensions[".json"] = (module, filename) => {
    try {
      if (!fs.existsSync(filename)) {
        const dir = path.dirname(filename)
        if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true })

        let def = "[]"
        if (/cache|user|panel|admin|session/i.test(filename)) def = "{}"

        fs.writeFileSync(filename, def)
      }

      try {
        originalLoader(module, filename)
      } catch {
        const isObj = /cache|user|panel|admin|session/i.test(filename)
        fs.writeFileSync(filename, isObj ? "{}" : "[]")
        originalLoader(module, filename)
      }
    } catch (e) {
      try {
        module.exports = /cache|user|panel|admin|session/i.test(filename) ? {} : []
      } catch {
        module.exports = []
      }
    }
  }
} catch (e) {
  console.log("autodb init error:", e.message)
}
