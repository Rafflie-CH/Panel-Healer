 const fs = require("fs")
const chalk = require("chalk")
const { version } = require("./package.json")

global.owner = [""] // ID Owner
global.namaOwner = "RAFZZ" // Nama Owner
global.botname = "RAFZ BOT" // Nama bot
global.botname2 = "RAFZ BOT"
global.packname = "SAN"
global.author = "Rafzbot"
global.versi = version
global.noPrefix = false

/* ── Prefix command (bisa lebih dari satu) ── */
global.prefix = ["/", ".", "#", "!"]

global.linkOwner = "https://t.me/rafzbotz"

/* ── Zona waktu & format tanggal (dipakai semua notif/timestamp) ── */
global.timeZone = "Asia/Jakarta"
global.locale = "id-ID"

/* ── Umur sesi wizard (menit) ── */
global.sessionTtlMinutes = 30
global.confirmTtlMinutes = 5

/* ── Batas input wizard create panel ── */
global.panelLimits = {
  ramMax: 1024,   /* GB */
  diskMax: 1024,  /* GB */
  cpuMax: 1600,   /* % */
  bulanMax: 120   /* durasi */
}

/* ── Default server panel & template server baru ── */
global.defaultServer = "1"
global.panelDocker = "ghcr.io/parkervcp/yolks:nodejs_24"
global.panelEmailDomain = "gmail.com"
global.featureLimits = { databases: 5, backups: 5, allocations: 5 }

/* ── Username panel yang dilindungi cleanpanel mode 1/2/3 ── */
global.safeUsers = ["rafz", "owner", "admin"]

/* ── Sound random setelah /start ── */
global.SOUND_URLS = [
  "https://files.catbox.moe/3pl2cx.mp3",
  "https://files.catbox.moe/xgezaf.mp3",
  "https://files.catbox.moe/0i6vgt.mp3",
  "https://files.catbox.moe/t1hdxs.mp3",
  "https://files.catbox.moe/vxeplp.mp3",
  "https://files.catbox.moe/i576hx.mp3",
  "https://files.catbox.moe/7te9xy.mp3",
  "https://files.catbox.moe/4t8i8h.mp3",
  "https://files.catbox.moe/3o6ila.mp3",
  "https://files.catbox.moe/1dyxif.mp3",
  "https://files.catbox.moe/g8azeo.mp3",
  "https://files.catbox.moe/1ybbsa.mp3",
  "https://files.catbox.moe/07gpif.mp3",
  "https://files.catbox.moe/6q6spg.mp3",
  "https://files.catbox.moe/9m4j6q.mp3",
  "https://files.catbox.moe/6of79p.mp3",
  "https://files.catbox.moe/tto94f.mp3",
  "https://files.catbox.moe/671kb2.mp3",
  "https://files.catbox.moe/2dwg6e.mp3"
]

/* ── Broadcast & test ── */
global.broadcastDelayMs = 100      /* jeda antar user saat /bc (anti flood) */
global.featureTestTimeoutMs = 35000 /* timeout test 1 fitur di /testall */

/* ── ANTI "Too Many Requests" (429) — library/antiflood.js ──
   Semua panggilan Telegram API di-auto-retry kalau kena limit:
   bot menunggu sesuai `retry_after` dari Telegram lalu mencoba lagi. */
global.flood = {
  maxRetry: 5,     /* maks retry ulang per request kalau masih kena 429 */
  maxPerSec: 25,   /* pace global: maks request API per detik (anti burst) */
  maxWaitSec: 60,  /* batas tunggu retry_after (detik) per attempt */
  jitterMs: 250,   /* acakan tambahan biar semua request tidak retry bareng */
  verbose: true    /* log tiap retry ke console */
}

/* ── Foto welcome /start ── */
global.WELCOME_PHOTO = "https://img101.pixhost.to/images/77/546441106_skyzopedia.jpg"

/* ── Group notifikasi (diset lewat /addgb) ── */
global.notifGroupId = "test" // diset via /addgb

/* ── Backup otomatis ── */
global.backup = {
  enabled: true,
  intervalMs: 6 * 60 * 60 * 1000, // setiap 6 jam
  sendToOwner: true // kirim file backup ke owner
}

/* ── CloudFlare multi-domain ── */
global.cf = {
  domains: {
    "": {
      zone: "",
      apikey: ""
    }
  }
}

/* ── Panel server (multi-server) ── */
global.panelServer = {
  1: {
    name: "",
    domain: "",
    apikey: ",
    capikey: "",
    egg: "15",
    nestid: "5",
    loc: "1"
  }
}

global.privateServerId = "1"

/* ── Monitor ── */
global.monitor = {
  enabled: true,
  chatId: null,
  ramThreshold: 90,
  diskThreshold: 92,
  ramAbsoluteMaxMiB: 6144,
  diskAbsoluteMaxMiB: 30720,
  pollIntervalMs: 45000,
  suspiciousDiskGrowthMiB: 3584,
  suspiciousDiskGrowthPct: 35,
  suspendCooldownMs: 300000,
  autoDeleteAfterMs: 0,
  debug: false,
  dbPath: "./library/database/ptero-stats.json"
}

/* ── Foto panel ── */
global.image = {
  menu: "https://img101.pixhost.to/images/77/546441106_skyzopedia.jpg",
  reply: "https://img101.pixhost.to/images/77/546441106_skyzopedia.jpg",
  logo: "https://img101.pixhost.to/images/77/546441106_skyzopedia.jpg"
}

/* ── Bahasa default ── */
global.defaultLang = "id"

try {
  let file = require.resolve(__filename)
  fs.watchFile(file, () => {
    try {
      fs.unwatchFile(file)
      console.log(chalk.redBright(`Update ${__filename}`))
      delete require.cache[file]
      require(file)
    } catch(e) {
      console.log("settings reload error:", e.message)
    }
  })
} catch(e) {
  console.log("settings watch error:", e.message)
}