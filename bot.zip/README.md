# RAFZ Telegram Bot (Panel Manager) v1.1.0

Bot Telegram untuk manage Pterodactyl Panel / Domain / Seller system + 100+ fitur tools, sticker pack, utility & fun.

## Fitur Baru (v1.1.0)
- **Warna tombol konsisten** — semua inline keyboard pakai `style` (Bot API 9.4+), fallback aman kalau tidak didukung
- **Edit-message** — hasil command mengedit pesan progress (bukan spam pesan baru)
- **tourl 10 host** — Qu.ax, TmpFiles, Put.icu, Termai, Uguu, Upload.ee, ImgBB, Pone.rs, Litterbox, Catbox (paralel)
- **Sticker pack** — /brat, /bratpack, /sticker membuat/menambah pack personal (`createNewStickerSet`) → bisa disimpan ke Favorit
- **/info @tag** — sekarang fetch user yang di-tag (text_mention + cache @username)
- **/allmenu** — semua fitur per kategori
- **Utility** — /short /qr /calc /weather /wiki /tr /ip /github /npm /pass /b64 /hash /time /ss /tts /define /getid
- **Fun** — /8ball /dice /coin /rate /love /pick /roll /reverse /bucin /quote /wpick
- **UI welcome rapi** — blockquote (tidak terpotong di layar sempit), multi-bahasa
- **m.react** — reaksi asli Telegram via setMessageReaction
- **Bahasa menyeluruh** — semua teks baru tersedia id/en via language.js

## Fitur Anti-Crash
- Global `uncaughtException` & `unhandledRejection` handler
- Try-catch di hampir semua file & fungsi kritis
- Auto-restart polling saat error jaringan sementara
- JSON loader yang tidak pernah crash (auto-repair file rusak)
- Session wizard tersimpan ke disk (survive restart)
- Plugin & case hot-reload aman

## Cara jalanin

```bash
npm install
npm start
```

Dependensi tambahan v1.1.0: `file-type`, `mime-types`, `cheerio`.

Atau langsung:
```bash
node index.js
```

Masukkan token BotFather saat pertama kali, atau set env:
```bash
export TELEGRAM_TOKEN=123456:ABC...
npm start
```

## Health check
Server HTTP di port `7860` (atau `PORT` env):
- `GET /health`
- `GET /`

## Struktur
- `index.js` – entry + anti-crash + polling
- `settings.js` – konfigurasi (owner, panel, CF, dll)
- `case.js` – semua command utama
- `library/handler.js` – message builder + plugin loader
- `plugins/` – plugin tambahan (`menu`, `say`, ...)
- `library/database/` – JSON DB + session

## Catatan
- Jangan jalankan lebih dari 1 instance dengan token yang sama (akan 409 Conflict)
- Node.js >= 18 direkomendasikan (native fetch)
