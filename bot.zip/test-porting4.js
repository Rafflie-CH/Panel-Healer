/* test-porting4.js — harness test offline batch-4:
   1. Load SEMUA plugin (deteksi syntax/require error)
   2. Hitung total command
   3. Mock-call sampel command baru (textmaker3, islamic3, games3, media3, nekos3, quotegen, primbon2)
      dengan QUERY nyata + deteksi fail-reply ala testall
   Jalankan: RAFZ_SESSION_DIR=./tmp-test-sessions/ timeout 120 node test-porting4.js
*/
process.env.RAFZ_SESSION_DIR = "./tmp-test-sessions/"
require("./settings")

const path = require("path")
const fs = require("fs")

let pass = 0, failCnt = 0
const results = []
const ok = (name, extra) => { pass++; results.push("✅ " + name + (extra ? " — " + extra : "")) }
const bad = (name, why) => { failCnt++; results.push("❌ " + name + " — " + why) }

/* ── 1. load semua plugin ── */
const pluginsDir = path.join(__dirname, "plugins")
const files = fs.readdirSync(pluginsDir).filter(f => f.endsWith(".js"))
let totalCmds = 0, loadErr = 0
const loaded = {}
for (const f of files) {
  try {
    const p = path.join(pluginsDir, f)
    delete require.cache[require.resolve(p)]
    const mod = require(p)
    if (typeof mod === "function" && Array.isArray(mod.command)) {
      totalCmds += mod.command.length
      loaded[f] = mod
    }
  } catch (e) { loadErr++; bad("load " + f, e.message.slice(0, 80)) }
}
if (loadErr === 0) ok("load semua plugin (" + files.length + " file)", totalCmds + " commands")
else bad("load plugin", loadErr + " file gagal")

/* ── 2. language keys ── */
try {
  const L = require("./library/language")
  const need = ["tm3.needText", "tm3.needMore", "tm3.needPhoto", "tm3.making", "tm3.done", "tm3.fail",
    "fx.pageInfo", "isl3.surahHint", "isl3.surahNotFound", "isl3.moreAyah", "isl3.downloading",
    "isl3.audioLink", "isl3.doaHint", "isl3.doaNotFound", "prim2.usage", "media3.mcOffline",
    "media3.kursNotFound", "media3.pickBelow", "qt.needName", "common.enjoy",
    "menu.btnEffects", "menu.hint.listfx", "menu.hint.fxText", "menu.hint.fxPhoto"]
  let missing = []
  for (const k of need) {
    if (!L.t("id", k) || L.t("id", k) === k) missing.push(k + "(id)")
    if (!L.t("en", k) || L.t("en", k) === k) missing.push(k + "(en)")
  }
  if (missing.length === 0) ok("language.js keys batch-4 (id+en)")
  else bad("language.js keys", missing.join(", ").slice(0, 120))
  /* default lang harus punya semua teks sama seperti id */
} catch (e) { bad("language load", e.message.slice(0, 80)) }

/* ── 3. mock infra ── */
const errorLog = require("./library/errorlog")
const mockBot = {
  token: "TEST:TOKEN",
  sendMessage: async () => ({ message_id: 1 }),
  sendPhoto: async () => ({ message_id: 1 }),
  sendAudio: async () => ({ message_id: 1 }),
  sendVideo: async () => ({ message_id: 1 }),
  sendDocument: async () => ({ message_id: 1 }),
  sendSticker: async () => ({ message_id: 1 }),
  editMessageText: async () => ({ message_id: 1 }),
  deleteMessage: async () => true,
  answerCallbackQuery: async () => true,
  getFile: async () => ({ file_path: "x" })
}
const mockMsg = (cmd, args) => {
  const failReplies = []
  const last = { text: "" }
  const record = (t) => {
    try { if (errorLog.isFailReply(t)) failReplies.push(String(t).replace(/<[^>]+>/g, "").trim().slice(0, 140)) } catch {}
    last.text = String(t || "").slice(0, 300)
    return { message_id: 1 }
  }
  return {
    raw: "/" + cmd + " " + args.join(" "), id: 999, chat: 123, sender: "7848360765",
    pushName: "Tester", isGroup: false, text: args.join(" "),
    body: "/" + cmd + " " + args.join(" "), isCmd: true, prefix: "/", command: cmd, args,
    lang: "id", t: (k, v) => k, setLang: () => false, entities: [], mentioned: [],
    media: null, fileId: null, quoted: null, callback: null, callbackId: null,
    reply: async (t) => record(t), send: async (t) => record(t),
    react: async () => ({}), edit: async (t) => record(t),
    failReplies, _lastText: last
  }
}

const testCmd = async (pluginFile, cmd, args, expectHandled) => {
  const plugin = loaded[pluginFile]
  if (!plugin) return bad(cmd, "plugin " + pluginFile + " tidak loaded")
  if (!plugin.command.includes(cmd)) return bad(cmd, "command tidak terdaftar di " + pluginFile)
  const mm = mockMsg(cmd, args)
  try {
    const res = await Promise.race([
      plugin(mm, { Rafz: mockBot, args, text: args.join(" "), command: cmd, prefix: "/" }),
      new Promise((_, rej) => setTimeout(() => rej(new Error("timeout 25s")), 25000))
    ])
    if (mm.failReplies.length) return bad(cmd, "fail-reply: " + mm.failReplies[0].slice(0, 90))
    if (res === false) {
      if (expectHandled === false) return ok(cmd, "not-handled OK")
      return bad(cmd, "return false")
    }
    ok(cmd, res === true ? "handled" : "reply")
  } catch (e) {
    bad(cmd, String(e.message || e).slice(0, 90))
  }
}

/* ── 4. TESTS (API nyata, jaringan) ── */
;(async () => {
  console.log("→ testing quotegen (lokal)...")
  await testCmd("quotegen.js", "pantun", [])
  await testCmd("quotegen.js", "bucin", [])
  await testCmd("quotegen.js", "wangy", ["dika"])
  await testCmd("quotegen.js", "dare", [])

  console.log("→ testing games3 (BochilTeam)...")
  await testCmd("games3.js", "caklontong", [])
  await testCmd("games3.js", "tebakkimia", [])

  console.log("→ testing islamic3 (alquran.cloud)...")
  await testCmd("islamic3.js", "surah", ["1"])
  await testCmd("islamic3.js", "ayat", ["2:255"])
  await testCmd("islamic3.js", "jadwalsholat", ["jakarta"])
  await testCmd("islamic3.js", "hijri", [])
  await testCmd("islamic3.js", "kiblat", [])
  await testCmd("islamic3.js", "doa", ["1"])
  await testCmd("islamic3.js", "tahlil", [])
  await testCmd("islamic3.js", "asmaulhusna2", [])

  console.log("→ testing media3...")
  await testCmd("media3.js", "kurs", ["USD"])
  await testCmd("media3.js", "gempa2", [])
  await testCmd("media3.js", "mcserver", ["mc.hypixel.net"])
  await testCmd("media3.js", "provinsi", [])
  await testCmd("media3.js", "ttinfo", ["https://vt.tiktok.com/ZSabc123/"], true) /* link palsu → fail-reply dilarang? tikwm kasih error → tapi itu bukan fail-reply kalau formatnya proper */

  console.log("→ testing nekos3...")
  await testCmd("nekos3.js", "neko", [])
  await testCmd("nekos3.js", "waifu", [])

  console.log("→ testing primbon2 (primbon.com)...")
  await testCmd("primbon2.js", "nomorhoki", ["6281234567890"])
  await testCmd("primbon2.js", "ramalannasib", ["14 2 2000"])
  await testCmd("primbon2.js", "zodiakcek", ["aquarius"])

  console.log("→ testing textmaker3 (fx scraper, 2 sampel)...")
  await testCmd("textmaker3.js", "listfx", [])
  await testCmd("textmaker3.js", "1917", ["RafzBot"])
  await testCmd("textmaker3.js", "pencilphoto", [], true) /* tanpa foto → usage reply (bukan fail) */

  /* ── 5. total & summary ── */
  console.log("\n══════════ HASIL ══════════")
  for (const r of results) console.log(r)
  console.log("\nPASS: " + pass + "  FAIL: " + failCnt)
  console.log("TOTAL COMMANDS: " + totalCmds)
  process.exit(failCnt > 0 ? 1 : 0)
})().catch(e => { console.error("FATAL", e); process.exit(1) })
