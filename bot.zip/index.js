const fs = require("fs")
const path = require("path")
const chalk = require("chalk")
const readline = require("readline-sync")
const TelegramBot = require("node-telegram-bot-api")
const Module = require("module")

try {
  require("./settings")
} catch (e) {
  console.error(chalk.red("Gagal load settings.js:"), e.message)
  process.exit(1)
}

// Initialize error logging system
try {
  require("./library/errorlog")
  console.log(chalk.green("Error logging system initialized"))
} catch (e) {
  console.log(chalk.yellow("Error log system failed:"), e.message)
}

/* ===== GLOBAL ANTI-CRASH ===== */
process.on("uncaughtException", (err) => {
  console.error(chalk.redBright("[UNCAUGHT EXCEPTION]"), err && err.stack ? err.stack : err)
})

process.on("unhandledRejection", (reason, promise) => {
  console.error(chalk.redBright("[UNHANDLED REJECTION]"), reason)
})

process.on("warning", (w) => {
  console.warn(chalk.yellow("[PROCESS WARNING]"), w && w.message ? w.message : w)
})

/* Soft JSON loader – never crash on bad/missing json */
const originalLoader = Module._extensions[".json"]
Module._extensions[".json"] = function (module, filename) {
  try {
    if (!fs.existsSync(filename)) {
      fs.mkdirSync(path.dirname(filename), { recursive: true })
      const isObj = /cache|user|panel|admin|session/i.test(filename)
      fs.writeFileSync(filename, isObj ? "{}" : "[]")
    }
    const raw = fs.readFileSync(filename, "utf8") || "[]"
    module.exports = JSON.parse(raw)
  } catch (e) {
    try {
      const isObj = /cache|user|panel|admin|session/i.test(filename)
      fs.writeFileSync(filename, isObj ? "{}" : "[]")
      module.exports = isObj ? {} : []
    } catch {
      module.exports = []
    }
  }
}

const sessionDir = path.join(__dirname, "session")
const creds = path.join(sessionDir, "creds.json")

try {
  if (!fs.existsSync(sessionDir)) fs.mkdirSync(sessionDir, { recursive: true })
} catch (e) {
  console.error(chalk.red("Gagal buat folder session:"), e.message)
}

/* Baca session. Kalau rusak / kosong, minta token ulang (jangan mati). */
const readSession = () => {
  try {
    if (!fs.existsSync(creds)) return null
    const raw = fs.readFileSync(creds, "utf8").trim()
    if (!raw) return null
    const data = JSON.parse(raw)
    const tk = data && typeof data === "object" ? data.token || null : null
    return tk ? String(tk).trim() : null
  } catch (e) {
    console.log(chalk.yellow("Session rusak/kosong, token diminta ulang"))
    return null
  }
}

let token = readSession() || (process.env.TELEGRAM_TOKEN || "").trim() || null

if (token) {
  console.log(chalk.green("✓ Menggunakan session tersimpan"))
} else {
  console.log(chalk.yellow("Masukkan token Telegram BotFather:"))
  try {
    token = (readline.question("> ") || "").trim()
  } catch (e) {
    token = null
  }

  if (!token) {
    console.log(chalk.red("Token kosong, bot dihentikan"))
    process.exit(1)
  }

  try {
    fs.writeFileSync(creds, JSON.stringify({ token }, null, 2))
    console.log(chalk.green("✓ Session tersimpan"))
  } catch (e) {
    console.log(chalk.yellow("Gagal simpan session, lanjut pakai token sementara"))
  }
}

/* ===== TELEGRAM CLIENT ===== */
let bot
try {
  bot = new TelegramBot(token, {
    polling: {
      autoStart: false,
      interval: 300,
      params: {
        timeout: 20,
        allowed_updates: ["message", "callback_query"]
      }
    }
  })
} catch (e) {
  console.error(chalk.red("Gagal inisialisasi TelegramBot:"), e.message)
  process.exit(1)
}

/* ===== ANTI-FLOOD (429 Too Many Requests) =====
   Pasang auto-retry + throttle global ke SEMUA method API bot.
   Kalau Telegram balas "too many request", bot menunggu sesuai
   retry_after lalu mengirim ulang otomatis — berlaku untuk semua
   plugin, edit pesan, delete, dan answerCallbackQuery. */
try {
  const antiflood = require("./library/antiflood")
  antiflood.install(bot)
  global.antiflood = antiflood
} catch (e) {
  console.log(chalk.yellow("Antiflood gagal dimuat:"), e.message)
}

/* Health-check server (untuk Hugging Face / Docker / uptime monitor) */
try {
  const express = require("express")
  const app = express()
  const PORT = process.env.PORT || 7860

  app.get("/", (req, res) => {
    res.status(200).json({ status: "ok", bot: global.botname || "RAFZ BOT", uptime: process.uptime() })
  })

  app.get("/health", (req, res) => {
    res.status(200).json({ status: "Bot is alive and well!", uptime: process.uptime() })
  })

  app.listen(PORT, () => {
    console.log(chalk.cyan(`🌐 Health check server di port ${PORT}`))
  }).on("error", (err) => {
    console.log(chalk.yellow("Health server gagal start (port mungkin dipakai):"), err.message)
  })
} catch (e) {
  console.log(chalk.yellow("Express health server dilewati:"), e.message)
}

/* Bersihin webhook + update lama, lalu mulai polling
   FIX: jangan wrap getUpdates di antiflood + jangan restart agresif
   biar ga loop polling_error. Library udah self-recover di banyak kasus. */
let isRestarting = false
let pollRestartCount = 0
let lastPollLog = 0
let consecutiveTempErrors = 0
let lastTempErrorAt = 0
const POLL_LOG_COOLDOWN = 60000 // 1 log tiap 60 dtk max
const POLL_RESTART_BASE = 45000 // minimal 45s antar restart
const POLL_RESTART_MAX = 300000 // max backoff 5 menit
const CONSECUTIVE_BEFORE_RESTART = 3 // baru restart setelah 3 error temp beruntun

const startBot = async () => {
  if (isRestarting) return
  isRestarting = true
  try {
    try {
      await bot.deleteWebHook({ drop_pending_updates: true })
    } catch (e) {
      /* ignore */
    }

    try {
      try { await bot.stopPolling() } catch {}
      await new Promise(r => setTimeout(r, 1000))
      await bot.startPolling({ restart: true })
      console.log(chalk.blue("✓ Bot aktif – polling clean"))
      pollRestartCount = 0
      consecutiveTempErrors = 0
    } catch (e) {
      console.error(chalk.red("Gagal startPolling:"), e.message)
      const backoff = Math.min(POLL_RESTART_BASE * Math.pow(1.5, pollRestartCount), POLL_RESTART_MAX)
      pollRestartCount++
      setTimeout(() => {
        isRestarting = false
        startBot()
      }, backoff)
      return
    }
  } finally {
    setTimeout(() => { isRestarting = false }, 2500)
  }
}

/* Hindari listener dobel (hot-reload / double require) — clear dulu baru pasang */
try { bot.removeAllListeners() } catch {}

/* 409 Conflict = ada instance lain yang pakai token yang sama */
let dupWarned = false
let lastPollRestart = 0

bot.on("polling_error", (e) => {
  try {
    const msg = String(e && (e.message || e) || "unknown")
    const now = Date.now()

    // 409 Conflict — instance lain (bukan error script)
    if (msg.includes("409") || msg.includes("Conflict")) {
      if (!dupWarned) {
        dupWarned = true
        console.log(chalk.red("⚠️  Ada bot LAIN yang polling pakai token ini (409 Conflict)."))
        console.log(chalk.yellow("   Matikan instance lain (HF Space / VPS / local lain)."))
        console.log(chalk.yellow("   Kalau tidak, update bisa diambil bot lain dan session tombol sering expired."))
      }
      consecutiveTempErrors = 0
      return
    }

    /* 429 → biarin antiflood / library handle, JANGAN restart */
    if (msg.includes("429") || /too many requests/i.test(msg)) {
      if (now - lastPollLog > POLL_LOG_COOLDOWN) {
        lastPollLog = now
        const ra = msg.match(/retry\s*after\s*(\d+)/i)
        const waitSec = ra ? Number(ra[1]) : 5
        console.log(chalk.yellow(`Polling kena flood limit (429), jeda ${waitSec}s...`))
      }
      consecutiveTempErrors = 0
      return
    }

    // error sementara / network
    const isTemp =
      msg.includes("ETELEGRAM") ||
      msg.includes("EFATAL") ||
      msg.includes("ECONNRESET") ||
      msg.includes("ETIMEDOUT") ||
      msg.includes("ENOTFOUND") ||
      msg.includes("EAI_AGAIN") ||
      msg.includes("socket hang up") ||
      msg.includes("RequestTimeoutError") ||
      msg.includes("Aborted") ||
      /timeout|network|connect|ECONNREFUSED/i.test(msg)

    if (isTemp) {
      // reset consecutive kalo jaraknya jauh (>2 menit)
      if (now - lastTempErrorAt > 120000) consecutiveTempErrors = 0
      consecutiveTempErrors++
      lastTempErrorAt = now

      if (now - lastPollLog > POLL_LOG_COOLDOWN) {
        lastPollLog = now
        console.log(chalk.yellow(`Polling error sementara x${consecutiveTempErrors} (network/timeout) — library biasanya recover sendiri`))
      }

      // cuma restart kalau udah beruntun + cooldown lewat
      // biar ga bikin loop sendiri (stop/start malah nambah error)
      const cooldown = Math.min(
        POLL_RESTART_BASE * Math.pow(1.4, pollRestartCount),
        POLL_RESTART_MAX
      )
      if (
        consecutiveTempErrors >= CONSECUTIVE_BEFORE_RESTART &&
        !isRestarting &&
        (now - lastPollRestart > cooldown)
      ) {
        lastPollRestart = now
        pollRestartCount++
        consecutiveTempErrors = 0
        const delay = Math.min(5000 + pollRestartCount * 2000, 20000)
        console.log(chalk.yellow(`Restart polling (backoff) dalam ${Math.round(delay/1000)}s...`))
        setTimeout(() => {
          if (isRestarting) return
          try {
            bot.stopPolling().catch(() => {})
            setTimeout(() => startBot(), 1500)
          } catch {}
        }, delay)
      }
      return
    }

    // error lain
    if (now - lastPollLog > POLL_LOG_COOLDOWN) {
      lastPollLog = now
      console.log(chalk.red("POLL ERR:"), msg.slice(0, 220))
    }
  } catch (err) {
    console.error("Error di handler polling_error:", err.message)
  }
})

bot.on("webhook_error", (e) => {
  try {
    console.log(chalk.red("HOOK ERR:"), e && e.message ? e.message : e)
  } catch {}
})

bot.on("error", (e) => {
  try {
    console.log(chalk.red("BOT ERR:"), e && e.message ? e.message : e)
  } catch {}
})

global.Rafz = bot
global.conn = bot

let handler
try {
  handler = require("./library/handler")
} catch (e) {
  console.error(chalk.red("Gagal load handler:"), e.message)
  process.exit(1)
}

/* SINGLE LISTENER – semua message & callback lewat handler yang sudah di-wrap try/catch */
bot.on("message", (msg) => {
  try {
    if (handler && typeof handler.message === "function") {
      handler.message(msg, bot).catch((err) => {
        console.error(chalk.red("[MSG HANDLER]"), err && err.stack ? err.stack : err)
      })
    }
  } catch (e) {
    console.error(chalk.red("[MSG LISTENER]"), e.message)
  }
})

bot.on("callback_query", (q) => {
  try {
    if (handler && typeof handler.callback === "function") {
      handler.callback(q, bot).catch((err) => {
        console.error(chalk.red("[CB HANDLER]"), err && err.stack ? err.stack : err)
      })
    }
  } catch (e) {
    console.error(chalk.red("[CB LISTENER]"), e.message)
  }
})

/* start polling SETELAH semua listener terpasang (anti race) */
startBot()

try {
  bot.getWebHookInfo().then((info) => {
    console.log(chalk.gray("Webhook:", info && info.url ? info.url : "none"))
  }).catch(() => {})
} catch {}

/* ── start multi-panel monitor (kalau enabled di settings) ── */
try {
  const monitor = require("./library/monitor")
  global.monitorModule = monitor
  if (global.monitor && global.monitor.enabled) {
    setTimeout(() => {
      try {
        monitor.start(bot)
      } catch (e) {
        console.error(chalk.red("[MONITOR START]"), e && e.message ? e.message : e)
      }
    }, 2500)
  }
} catch (e) {
  console.error(chalk.red("[MONITOR LOAD]"), e && e.message ? e.message : e)
}

/* ── start backup otomatis ── */
try {
  const backup = require("./library/backup")
  global.backupModule = backup
  backup.start(bot)
} catch (e) {
  console.error(chalk.red("[BACKUP LOAD]"), e && e.message ? e.message : e)
}

console.log(chalk.greenBright(`🚀 ${global.botname || "RAFZ BOT"} siap (anti-crash mode)`))

/* cache username bot — dipakai fitur sticker pack (suffix _by_<botusername>) */
try {
  bot.getMe().then((me) => {
    global._botUsername = me.username
    console.log(chalk.gray("Bot username: @" + me.username))
  }).catch(() => {})
} catch {}
