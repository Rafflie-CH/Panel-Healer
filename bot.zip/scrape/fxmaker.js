/* fxmaker.js — scraper photooxy.com + en.ephoto360.com untuk Telegram bot.
   Port dari WA bot (Furina/Rafzbotz), dirapikan + anti-flood friendly.
   Tiga mode scraper:
   - fxText(url, texts)      → efek teks (1..6 input "text[]")
   - fxRadio(url, texts, radio) → efek dengan pilihan radio (flag dsb)
   - fxPhoto(url, buffer, texts) → efek photo-frame (upload "myfile")
   Hasil: URL gambar jadi (build_server + image path).

   NOTE 2026-09: respons POST kini memuat JSON di <input name="form_value_input"
   value="{&quot;...&quot;}"> (HTML-escaped). Regex lama <div id="form_value">
   sudah TIDAK ada — scraper ini pakai kedua format (baru + lama) supaya tahan
   perubahan di masa depan. */

"use strict"
const axios = require("axios")

const UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36"
const sleep = (ms) => new Promise(r => setTimeout(r, ms))

const decodeHTML = (s) => String(s || "")
  .replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&lt;/g, "<")
  .replace(/&gt;/g, ">").replace(/&amp;/g, "&").replace(/\\\//g, "/")

/* ambil form dasar dari halaman efek */
async function fetchForm(url) {
  const res = await axios.get(url, {
    timeout: 30000,
    maxRedirects: 5,
    headers: { "user-agent": UA, "accept-language": "en-US,en;q=0.9" },
    transformResponse: [(d) => d]
  })
  const html = typeof res.data === "string" ? res.data : String(res.data)
  const token = /<input[^>]+name="token"[^>]+value="([^"]+)"/.exec(html)
  const bs = /<input[^>]+name="build_server"[^>]+value="([^"]+)"/.exec(html)
  const bsi = /<input[^>]+name="build_server_id"[^>]+value="([^"]+)"/.exec(html)
  if (!token || !bs) throw new Error("fxmaker: token form tidak ditemukan (halaman berubah?)")
  const cookies = (res.headers["set-cookie"] || []).map(c => c.split(";")[0]).join("; ")
  return { html, token: token[1], build_server: bs[1], build_server_id: bsi ? bsi[1] : "", cookie: cookies }
}

/* parse form_value dari respons POST — 2 format (input hidden baru / div lama) */
function parseFormValue(html) {
  /* format baru: input hidden dengan value JSON yang di-escape */
  let m = /<input[^>]+name="form_value_input"[^>]+value="([^"]+)"/.exec(html)
  if (m) {
    try {
      const j = JSON.parse(decodeHTML(m[1]))
      if (j && typeof j === "object") return j
    } catch {}
  }
  /* format lama: div id=form_value berisi JSON */
  m = /<div[^>]*id\s*=\s*["']?form_value["']?[^>]*>([\s\S]*?)<\/div>/.exec(html)
  if (m) {
    try {
      const j = JSON.parse(decodeHTML(m[1].trim()))
      if (j && typeof j === "object") return j
    } catch {}
  }
  throw new Error("fxmaker: form_value tidak ditemukan")
}

/* POST form + ambil form_value JSON */
async function submitForm(url, fields, cookie) {
  const FormData = require("form-data")
  const form = new FormData()
  for (const [k, v] of Object.entries(fields)) form.append(k, v)
  const res = await axios.post(url, form, {
    timeout: 60000,
    maxRedirects: 5,
    headers: { "user-agent": UA, cookie, ...form.getHeaders() },
    transformResponse: [(d) => d]
  })
  const html = typeof res.data === "string" ? res.data : String(res.data)
  const formValue = parseFormValue(html)
  const cookies = (res.headers["set-cookie"] || []).map(c => c.split(";")[0]).join("; ") || cookie
  return { formValue, cookie: cookies }
}

/* GET create-image → URL gambar */
async function createImageAt(base, formValue, cookie) {
  const qs = new URLSearchParams(formValue).toString()
  const res = await axios.get(base + "/effect/create-image?" + qs, {
    timeout: 60000,
    headers: { "user-agent": UA, cookie },
    transformResponse: [(d) => d]
  })
  let j
  try { j = JSON.parse(res.data) } catch { throw new Error("fxmaker: create-image bukan JSON") }
  if (!j || !j.image) throw new Error("fxmaker: create-image tanpa image")
  return j.full_url || j.image
}

async function runEffect(url, buildFields, attempt = 1) {
  try {
    const { token, build_server, build_server_id, cookie } = await fetchForm(url)
    const fields = Object.assign({}, buildFields, {
      sumbit: "GO", token, build_server, build_server_id
    })
    const { formValue, cookie: ck2 } = await submitForm(url, fields, cookie)
    const host = url.includes("photooxy.com") ? "https://photooxy.com" : "https://en.ephoto360.com"
    let image
    try {
      image = await createImageAt(host, formValue, ck2)
    } catch (e1) {
      /* fallback: coba host satunya (efek cross-domain) */
      const alt = host === "https://photooxy.com" ? "https://en.ephoto360.com" : "https://photooxy.com"
      image = await createImageAt(alt, formValue, ck2)
    }
    return image.startsWith("http") ? image : build_server + image
  } catch (e) {
    if (attempt < 2) { await sleep(1500); return runEffect(url, buildFields, attempt + 1) }
    throw e
  }
}

/* ── PUBLIC API ─────────────────────────────────────────────── */

/* efek teks: texts = array string (1-6) */
async function fxText(url, texts) {
  const arr = Array.isArray(texts) ? texts : [texts]
  const fields = {}
  arr.slice(0, 6).forEach((t, i) => { fields["text[" + i + "]"] = String(t || " ") })
  return runEffect(url, fields)
}

/* efek dengan radio (contoh: pilihan bendera/tema). radio = value radio0 */
async function fxRadio(url, texts, radio) {
  const arr = Array.isArray(texts) ? texts : [texts]
  const fields = { "radio0[radio]": String(radio || "") }
  arr.slice(0, 6).forEach((t, i) => { fields["text[" + i + "]"] = String(t || " ") })
  return runEffect(url, fields)
}

/* efek upload foto (photo frame). buffer = Buffer foto; texts opsional */
async function fxPhoto(url, buffer, texts) {
  const { token, build_server, build_server_id, cookie } = await fetchForm(url)
  const FormData = require("form-data")
  const form = new FormData()
  form.append("myfile", buffer, { filename: "photo.jpg", contentType: "image/jpeg" })
  const fields = { sumbit: "GO", token, build_server, build_server_id }
  for (const [k, v] of Object.entries(fields)) form.append(k, v)
  const res = await axios.post(url, form, {
    timeout: 90000,
    maxRedirects: 5,
    headers: { "user-agent": UA, cookie, ...form.getHeaders() },
    transformResponse: [(d) => d]
  })
  const html = typeof res.data === "string" ? res.data : String(res.data)
  const formValue = parseFormValue(html)
  const host = url.includes("photooxy.com") ? "https://photooxy.com" : "https://en.ephoto360.com"
  let image
  try {
    image = await createImageAt(host, formValue, cookie)
  } catch (e1) {
    const alt = host === "https://photooxy.com" ? "https://en.ephoto360.com" : "https://photooxy.com"
    image = await createImageAt(alt, formValue, cookie)
  }
  return image.startsWith("http") ? image : build_server + image
}

module.exports = { fxText, fxRadio, fxPhoto, _fetchForm: fetchForm }

try {
  const fs2 = require("fs")
  const file = require.resolve(__filename)
  fs2.watchFile(file, () => { try { fs2.unwatchFile(file); delete require.cache[file]; require(file) } catch {} })
} catch {}
